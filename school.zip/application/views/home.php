<?php echo $this->session->flashdata('message'); ?>

Selamat datang <?php echo $user['nama'] ?>

<br/>
