<body class="">
    <header id="overview" class="subhead">
        <div class="container">
            <h1>Sekolah</h1>
            <p class="lead">....</p>
        </div>
    </header>
    <div class="clearfix"></div>
    <div class="container">
        <div class="row">
            