</div>
</div>
</div>
<div class="clearfix"></div>
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="span4 text-left">I-Panel M.Ts YPP Darul Hikam</div>
            <div class="span4 offset7 text-right">License By <a href="http://www.hostinggokil.com" target="_blank">SATU <span style="color: #000000;">IT</span> MEDIA</a></div>
        </div>
    </div>
</footer>
</body>
</html>