<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-29 03:34:54 --> Config Class Initialized
DEBUG - 2013-08-29 03:34:54 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:34:54 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:34:54 --> URI Class Initialized
DEBUG - 2013-08-29 03:34:54 --> Router Class Initialized
DEBUG - 2013-08-29 03:34:54 --> Output Class Initialized
DEBUG - 2013-08-29 03:34:54 --> Security Class Initialized
DEBUG - 2013-08-29 03:34:54 --> Input Class Initialized
DEBUG - 2013-08-29 03:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 03:34:55 --> Language Class Initialized
DEBUG - 2013-08-29 03:34:55 --> Loader Class Initialized
DEBUG - 2013-08-29 03:34:55 --> Helper loaded: url_helper
DEBUG - 2013-08-29 03:34:55 --> Helper loaded: file_helper
DEBUG - 2013-08-29 03:34:55 --> Helper loaded: form_helper
DEBUG - 2013-08-29 03:34:55 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 03:34:55 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 03:34:55 --> Database Driver Class Initialized
ERROR - 2013-08-29 03:34:55 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp\htdocs\school\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-08-29 03:34:57 --> Session Class Initialized
DEBUG - 2013-08-29 03:34:57 --> Helper loaded: string_helper
DEBUG - 2013-08-29 03:34:57 --> A session cookie was not found.
DEBUG - 2013-08-29 03:34:58 --> Session routines successfully run
DEBUG - 2013-08-29 03:34:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 03:34:58 --> Controller Class Initialized
ERROR - 2013-08-29 03:34:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:34:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:34:58 --> Model Class Initialized
DEBUG - 2013-08-29 03:34:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 03:34:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 03:34:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 03:34:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 03:34:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:34:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:34:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 03:34:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 03:34:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 03:34:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 03:34:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 03:34:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 03:34:59 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 03:34:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 03:34:59 --> Final output sent to browser
DEBUG - 2013-08-29 03:34:59 --> Total execution time: 5.6233
DEBUG - 2013-08-29 03:35:00 --> Config Class Initialized
DEBUG - 2013-08-29 03:35:00 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:35:00 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:35:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:35:00 --> URI Class Initialized
DEBUG - 2013-08-29 03:35:00 --> Router Class Initialized
ERROR - 2013-08-29 03:35:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 03:36:29 --> Config Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:36:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:36:29 --> URI Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Router Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Output Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Security Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Input Class Initialized
DEBUG - 2013-08-29 03:36:29 --> XSS Filtering completed
DEBUG - 2013-08-29 03:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 03:36:29 --> Language Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Loader Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Helper loaded: url_helper
DEBUG - 2013-08-29 03:36:29 --> Helper loaded: file_helper
DEBUG - 2013-08-29 03:36:29 --> Helper loaded: form_helper
DEBUG - 2013-08-29 03:36:29 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 03:36:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 03:36:29 --> Database Driver Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Session Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Helper loaded: string_helper
DEBUG - 2013-08-29 03:36:29 --> Session routines successfully run
DEBUG - 2013-08-29 03:36:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Controller Class Initialized
ERROR - 2013-08-29 03:36:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:36:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:36:29 --> Model Class Initialized
DEBUG - 2013-08-29 03:36:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 03:36:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 03:36:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 03:36:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 03:36:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:36:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:36:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\controllers\user_sessions.php 87
ERROR - 2013-08-29 03:36:29 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\school\application\views\shared\head.php 14
DEBUG - 2013-08-29 03:36:29 --> File loaded: application/views/shared/head.php
ERROR - 2013-08-29 03:36:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\controllers\user_sessions.php 88
DEBUG - 2013-08-29 03:36:29 --> File loaded: application/views/shared/scripts.php
ERROR - 2013-08-29 03:36:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\controllers\user_sessions.php 89
DEBUG - 2013-08-29 03:36:29 --> File loaded: application/views/shared/header.php
ERROR - 2013-08-29 03:36:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\controllers\user_sessions.php 90
ERROR - 2013-08-29 03:36:29 --> Severity: Notice  --> Undefined variable: content_title C:\xampp\htdocs\school\application\views\shared\content_title.php 2
DEBUG - 2013-08-29 03:36:29 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 03:36:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\controllers\user_sessions.php 91
DEBUG - 2013-08-29 03:36:29 --> File loaded: application/views/user_sessions/login.php
ERROR - 2013-08-29 03:36:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\controllers\user_sessions.php 92
DEBUG - 2013-08-29 03:36:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 03:36:29 --> Final output sent to browser
DEBUG - 2013-08-29 03:36:29 --> Total execution time: 0.2520
DEBUG - 2013-08-29 03:36:30 --> Config Class Initialized
DEBUG - 2013-08-29 03:36:30 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:36:30 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:36:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:36:30 --> URI Class Initialized
DEBUG - 2013-08-29 03:36:30 --> Router Class Initialized
ERROR - 2013-08-29 03:36:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 03:36:44 --> Config Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:36:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:36:44 --> URI Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Router Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Output Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Security Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Input Class Initialized
DEBUG - 2013-08-29 03:36:44 --> XSS Filtering completed
DEBUG - 2013-08-29 03:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 03:36:44 --> Language Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Loader Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Helper loaded: url_helper
DEBUG - 2013-08-29 03:36:44 --> Helper loaded: file_helper
DEBUG - 2013-08-29 03:36:44 --> Helper loaded: form_helper
DEBUG - 2013-08-29 03:36:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 03:36:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 03:36:44 --> Database Driver Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Session Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Helper loaded: string_helper
DEBUG - 2013-08-29 03:36:44 --> Session routines successfully run
DEBUG - 2013-08-29 03:36:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Controller Class Initialized
ERROR - 2013-08-29 03:36:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:36:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:36:44 --> Model Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 03:36:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 03:36:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 03:36:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 03:36:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:36:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:36:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 03:36:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 03:36:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 03:36:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 03:36:44 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 03:36:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 03:36:44 --> Final output sent to browser
DEBUG - 2013-08-29 03:36:44 --> Total execution time: 0.2800
DEBUG - 2013-08-29 03:36:44 --> Config Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:36:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:36:44 --> URI Class Initialized
DEBUG - 2013-08-29 03:36:44 --> Router Class Initialized
ERROR - 2013-08-29 03:36:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 03:46:41 --> Config Class Initialized
DEBUG - 2013-08-29 03:46:41 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:46:43 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:46:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:46:44 --> URI Class Initialized
DEBUG - 2013-08-29 03:46:45 --> Router Class Initialized
DEBUG - 2013-08-29 03:46:51 --> Output Class Initialized
DEBUG - 2013-08-29 03:46:52 --> Security Class Initialized
DEBUG - 2013-08-29 03:46:52 --> Input Class Initialized
DEBUG - 2013-08-29 03:46:52 --> XSS Filtering completed
DEBUG - 2013-08-29 03:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 03:46:52 --> Language Class Initialized
DEBUG - 2013-08-29 03:46:55 --> Loader Class Initialized
DEBUG - 2013-08-29 03:46:56 --> Helper loaded: url_helper
DEBUG - 2013-08-29 03:46:56 --> Helper loaded: file_helper
DEBUG - 2013-08-29 03:46:57 --> Helper loaded: form_helper
DEBUG - 2013-08-29 03:46:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 03:46:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 03:46:59 --> Database Driver Class Initialized
DEBUG - 2013-08-29 03:46:59 --> Session Class Initialized
DEBUG - 2013-08-29 03:46:59 --> Helper loaded: string_helper
DEBUG - 2013-08-29 03:47:02 --> Session garbage collection performed.
DEBUG - 2013-08-29 03:47:02 --> Session routines successfully run
DEBUG - 2013-08-29 03:47:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 03:47:02 --> Controller Class Initialized
ERROR - 2013-08-29 03:47:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:47:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:47:04 --> Model Class Initialized
DEBUG - 2013-08-29 03:47:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 03:47:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 03:47:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 03:47:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 03:47:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:47:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:47:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 03:47:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 03:47:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 03:47:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 03:47:08 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 03:47:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 03:47:08 --> Final output sent to browser
DEBUG - 2013-08-29 03:47:08 --> Total execution time: 40.3323
DEBUG - 2013-08-29 03:47:09 --> Config Class Initialized
DEBUG - 2013-08-29 03:47:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:47:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:47:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:47:09 --> URI Class Initialized
DEBUG - 2013-08-29 03:47:09 --> Router Class Initialized
ERROR - 2013-08-29 03:47:09 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 03:48:16 --> Config Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:48:16 --> URI Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Router Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Output Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Security Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Input Class Initialized
DEBUG - 2013-08-29 03:48:16 --> XSS Filtering completed
DEBUG - 2013-08-29 03:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 03:48:16 --> Language Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Loader Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Helper loaded: url_helper
DEBUG - 2013-08-29 03:48:16 --> Helper loaded: file_helper
DEBUG - 2013-08-29 03:48:16 --> Helper loaded: form_helper
DEBUG - 2013-08-29 03:48:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 03:48:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 03:48:16 --> Database Driver Class Initialized
ERROR - 2013-08-29 03:48:16 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp\htdocs\school\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-08-29 03:48:16 --> Session Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Helper loaded: string_helper
DEBUG - 2013-08-29 03:48:16 --> Session routines successfully run
DEBUG - 2013-08-29 03:48:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Controller Class Initialized
ERROR - 2013-08-29 03:48:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:48:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:48:16 --> Model Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 03:48:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 03:48:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 03:48:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 03:48:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:48:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:48:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 03:48:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 03:48:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 03:48:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 03:48:16 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 03:48:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 03:48:16 --> Final output sent to browser
DEBUG - 2013-08-29 03:48:16 --> Total execution time: 0.3580
DEBUG - 2013-08-29 03:48:16 --> Config Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:48:16 --> URI Class Initialized
DEBUG - 2013-08-29 03:48:16 --> Router Class Initialized
ERROR - 2013-08-29 03:48:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 03:51:42 --> Config Class Initialized
DEBUG - 2013-08-29 03:51:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:51:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:51:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:51:42 --> URI Class Initialized
DEBUG - 2013-08-29 03:51:42 --> Router Class Initialized
DEBUG - 2013-08-29 03:51:42 --> Output Class Initialized
DEBUG - 2013-08-29 03:51:42 --> Security Class Initialized
DEBUG - 2013-08-29 03:51:42 --> Input Class Initialized
DEBUG - 2013-08-29 03:51:43 --> XSS Filtering completed
DEBUG - 2013-08-29 03:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 03:51:44 --> Language Class Initialized
DEBUG - 2013-08-29 03:51:45 --> Loader Class Initialized
DEBUG - 2013-08-29 03:51:46 --> Helper loaded: url_helper
DEBUG - 2013-08-29 03:51:46 --> Helper loaded: file_helper
DEBUG - 2013-08-29 03:51:46 --> Helper loaded: form_helper
DEBUG - 2013-08-29 03:51:46 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 03:51:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 03:51:52 --> Database Driver Class Initialized
DEBUG - 2013-08-29 03:51:59 --> Session Class Initialized
DEBUG - 2013-08-29 03:51:59 --> Helper loaded: string_helper
DEBUG - 2013-08-29 03:52:17 --> Session routines successfully run
DEBUG - 2013-08-29 03:52:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 03:52:17 --> Controller Class Initialized
ERROR - 2013-08-29 03:52:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:52:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:52:20 --> Model Class Initialized
DEBUG - 2013-08-29 03:52:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 03:52:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 03:52:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 03:52:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 03:52:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 03:52:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 03:52:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 03:52:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 03:52:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 03:52:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 03:52:26 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 03:52:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 03:52:26 --> Final output sent to browser
DEBUG - 2013-08-29 03:52:26 --> Total execution time: 44.3965
DEBUG - 2013-08-29 03:52:29 --> Config Class Initialized
DEBUG - 2013-08-29 03:52:29 --> Hooks Class Initialized
DEBUG - 2013-08-29 03:52:29 --> Utf8 Class Initialized
DEBUG - 2013-08-29 03:52:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 03:52:29 --> URI Class Initialized
DEBUG - 2013-08-29 03:52:29 --> Router Class Initialized
ERROR - 2013-08-29 03:52:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:23:33 --> Config Class Initialized
DEBUG - 2013-08-29 04:23:33 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:23:33 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:23:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:23:33 --> URI Class Initialized
DEBUG - 2013-08-29 04:23:33 --> Router Class Initialized
DEBUG - 2013-08-29 04:23:33 --> Output Class Initialized
DEBUG - 2013-08-29 04:23:33 --> Security Class Initialized
DEBUG - 2013-08-29 04:23:33 --> Input Class Initialized
DEBUG - 2013-08-29 04:23:33 --> XSS Filtering completed
DEBUG - 2013-08-29 04:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:23:33 --> Language Class Initialized
DEBUG - 2013-08-29 04:23:33 --> Loader Class Initialized
DEBUG - 2013-08-29 04:23:33 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:23:33 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:23:34 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:23:34 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:23:34 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:23:34 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:23:34 --> Session Class Initialized
DEBUG - 2013-08-29 04:23:34 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:23:34 --> Session routines successfully run
DEBUG - 2013-08-29 04:23:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:23:34 --> Controller Class Initialized
ERROR - 2013-08-29 04:23:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:23:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:23:34 --> Model Class Initialized
DEBUG - 2013-08-29 04:23:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:23:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:23:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:23:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:23:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:23:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:30:53 --> Config Class Initialized
DEBUG - 2013-08-29 04:30:53 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:30:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:30:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:30:54 --> URI Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Router Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Output Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Security Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Input Class Initialized
DEBUG - 2013-08-29 04:30:54 --> XSS Filtering completed
DEBUG - 2013-08-29 04:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:30:54 --> Language Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Loader Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:30:54 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:30:54 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:30:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:30:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:30:54 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Session Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:30:54 --> Session routines successfully run
DEBUG - 2013-08-29 04:30:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Controller Class Initialized
ERROR - 2013-08-29 04:30:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:30:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:30:54 --> Model Class Initialized
DEBUG - 2013-08-29 04:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:30:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:30:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:30:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:30:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:30:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:31:12 --> Config Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:31:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:31:12 --> URI Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Router Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Output Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Security Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Input Class Initialized
DEBUG - 2013-08-29 04:31:12 --> XSS Filtering completed
DEBUG - 2013-08-29 04:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:31:12 --> Language Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Loader Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:31:12 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:31:12 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:31:12 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:31:12 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:31:12 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Session Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:31:12 --> Session routines successfully run
DEBUG - 2013-08-29 04:31:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Controller Class Initialized
ERROR - 2013-08-29 04:31:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:31:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:31:12 --> Model Class Initialized
DEBUG - 2013-08-29 04:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:31:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:31:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:31:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:31:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:31:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:31:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:31:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:31:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:31:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:31:13 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:31:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:31:13 --> Final output sent to browser
DEBUG - 2013-08-29 04:31:13 --> Total execution time: 0.6330
DEBUG - 2013-08-29 04:31:13 --> Config Class Initialized
DEBUG - 2013-08-29 04:31:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:31:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:31:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:31:13 --> URI Class Initialized
DEBUG - 2013-08-29 04:31:13 --> Router Class Initialized
ERROR - 2013-08-29 04:31:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:31:52 --> Config Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:31:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:31:52 --> URI Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Router Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Output Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Security Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Input Class Initialized
DEBUG - 2013-08-29 04:31:52 --> XSS Filtering completed
DEBUG - 2013-08-29 04:31:52 --> XSS Filtering completed
DEBUG - 2013-08-29 04:31:52 --> XSS Filtering completed
DEBUG - 2013-08-29 04:31:52 --> XSS Filtering completed
DEBUG - 2013-08-29 04:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:31:52 --> Language Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Loader Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:31:52 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:31:52 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:31:52 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:31:52 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:31:52 --> Database Driver Class Initialized
ERROR - 2013-08-29 04:31:52 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp\htdocs\school\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-08-29 04:31:52 --> Session Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:31:52 --> Session garbage collection performed.
DEBUG - 2013-08-29 04:31:52 --> Session routines successfully run
DEBUG - 2013-08-29 04:31:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Controller Class Initialized
ERROR - 2013-08-29 04:31:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:31:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:31:52 --> Model Class Initialized
DEBUG - 2013-08-29 04:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:31:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:31:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:31:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:31:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:31:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:32:14 --> Config Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:32:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:32:14 --> URI Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Router Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Output Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Security Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Input Class Initialized
DEBUG - 2013-08-29 04:32:14 --> XSS Filtering completed
DEBUG - 2013-08-29 04:32:14 --> XSS Filtering completed
DEBUG - 2013-08-29 04:32:14 --> XSS Filtering completed
DEBUG - 2013-08-29 04:32:14 --> XSS Filtering completed
DEBUG - 2013-08-29 04:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:32:14 --> Language Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Loader Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:32:14 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:32:14 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:32:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:32:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:32:14 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Session Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:32:14 --> Session routines successfully run
DEBUG - 2013-08-29 04:32:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Controller Class Initialized
ERROR - 2013-08-29 04:32:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:32:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:32:14 --> Model Class Initialized
DEBUG - 2013-08-29 04:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:32:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:32:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:32:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:32:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:32:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:32:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:32:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:32:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:32:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:32:15 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:32:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:32:15 --> Final output sent to browser
DEBUG - 2013-08-29 04:32:15 --> Total execution time: 0.7290
DEBUG - 2013-08-29 04:32:15 --> Config Class Initialized
DEBUG - 2013-08-29 04:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:32:15 --> URI Class Initialized
DEBUG - 2013-08-29 04:32:15 --> Router Class Initialized
ERROR - 2013-08-29 04:32:15 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:32:28 --> Config Class Initialized
DEBUG - 2013-08-29 04:32:28 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:32:28 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:32:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:32:28 --> URI Class Initialized
DEBUG - 2013-08-29 04:32:28 --> Router Class Initialized
DEBUG - 2013-08-29 04:32:28 --> Output Class Initialized
DEBUG - 2013-08-29 04:32:28 --> Security Class Initialized
DEBUG - 2013-08-29 04:32:28 --> Input Class Initialized
DEBUG - 2013-08-29 04:32:28 --> XSS Filtering completed
DEBUG - 2013-08-29 04:32:28 --> XSS Filtering completed
DEBUG - 2013-08-29 04:32:28 --> XSS Filtering completed
DEBUG - 2013-08-29 04:32:28 --> XSS Filtering completed
DEBUG - 2013-08-29 04:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:32:28 --> Language Class Initialized
DEBUG - 2013-08-29 04:32:29 --> Loader Class Initialized
DEBUG - 2013-08-29 04:32:29 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:32:29 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:32:29 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:32:29 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:32:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:32:29 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:32:29 --> Session Class Initialized
DEBUG - 2013-08-29 04:32:29 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:32:29 --> Session routines successfully run
DEBUG - 2013-08-29 04:32:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:32:29 --> Controller Class Initialized
ERROR - 2013-08-29 04:32:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:32:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:32:29 --> Model Class Initialized
DEBUG - 2013-08-29 04:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:32:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:32:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:32:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:32:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:32:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:32:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:32:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:32:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:32:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:32:29 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:32:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:32:29 --> Final output sent to browser
DEBUG - 2013-08-29 04:32:29 --> Total execution time: 0.3520
DEBUG - 2013-08-29 04:32:29 --> Config Class Initialized
DEBUG - 2013-08-29 04:32:29 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:32:29 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:32:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:32:29 --> URI Class Initialized
DEBUG - 2013-08-29 04:32:29 --> Router Class Initialized
ERROR - 2013-08-29 04:32:29 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:33:48 --> Config Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:33:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:33:48 --> URI Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Router Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Output Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Security Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Input Class Initialized
DEBUG - 2013-08-29 04:33:48 --> XSS Filtering completed
DEBUG - 2013-08-29 04:33:48 --> XSS Filtering completed
DEBUG - 2013-08-29 04:33:48 --> XSS Filtering completed
DEBUG - 2013-08-29 04:33:48 --> XSS Filtering completed
DEBUG - 2013-08-29 04:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:33:48 --> Language Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Loader Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:33:48 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:33:48 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:33:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:33:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:33:48 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Session Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:33:48 --> Session routines successfully run
DEBUG - 2013-08-29 04:33:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Controller Class Initialized
ERROR - 2013-08-29 04:33:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:33:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:33:48 --> Model Class Initialized
DEBUG - 2013-08-29 04:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:33:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:33:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:33:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:33:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:33:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:33:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:33:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:33:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:33:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:33:48 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:33:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:33:48 --> Final output sent to browser
DEBUG - 2013-08-29 04:33:48 --> Total execution time: 0.3550
DEBUG - 2013-08-29 04:33:49 --> Config Class Initialized
DEBUG - 2013-08-29 04:33:49 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:33:49 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:33:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:33:49 --> URI Class Initialized
DEBUG - 2013-08-29 04:33:49 --> Router Class Initialized
ERROR - 2013-08-29 04:33:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:34:45 --> Config Class Initialized
DEBUG - 2013-08-29 04:34:45 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:34:45 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:34:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:34:45 --> URI Class Initialized
DEBUG - 2013-08-29 04:34:45 --> Router Class Initialized
DEBUG - 2013-08-29 04:34:45 --> Output Class Initialized
DEBUG - 2013-08-29 04:34:45 --> Security Class Initialized
DEBUG - 2013-08-29 04:34:45 --> Input Class Initialized
DEBUG - 2013-08-29 04:34:45 --> XSS Filtering completed
DEBUG - 2013-08-29 04:34:45 --> XSS Filtering completed
DEBUG - 2013-08-29 04:34:45 --> XSS Filtering completed
DEBUG - 2013-08-29 04:34:45 --> XSS Filtering completed
DEBUG - 2013-08-29 04:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:34:45 --> Language Class Initialized
DEBUG - 2013-08-29 04:34:45 --> Loader Class Initialized
DEBUG - 2013-08-29 04:34:45 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:34:45 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:34:45 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:34:45 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:34:45 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:34:46 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:34:46 --> Session Class Initialized
DEBUG - 2013-08-29 04:34:46 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:34:46 --> Session routines successfully run
DEBUG - 2013-08-29 04:34:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:34:46 --> Controller Class Initialized
ERROR - 2013-08-29 04:34:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:34:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:34:46 --> Model Class Initialized
DEBUG - 2013-08-29 04:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:34:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:34:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:34:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:34:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:34:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:34:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:34:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:34:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:34:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:34:46 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:34:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:34:46 --> Final output sent to browser
DEBUG - 2013-08-29 04:34:46 --> Total execution time: 0.3560
DEBUG - 2013-08-29 04:34:46 --> Config Class Initialized
DEBUG - 2013-08-29 04:34:46 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:34:46 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:34:46 --> URI Class Initialized
DEBUG - 2013-08-29 04:34:46 --> Router Class Initialized
ERROR - 2013-08-29 04:34:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:36:24 --> Config Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:36:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:36:24 --> URI Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Router Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Output Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Security Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Input Class Initialized
DEBUG - 2013-08-29 04:36:24 --> XSS Filtering completed
DEBUG - 2013-08-29 04:36:24 --> XSS Filtering completed
DEBUG - 2013-08-29 04:36:24 --> XSS Filtering completed
DEBUG - 2013-08-29 04:36:24 --> XSS Filtering completed
DEBUG - 2013-08-29 04:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:36:24 --> Language Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Loader Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:36:24 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:36:24 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:36:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:36:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:36:24 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Session Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:36:24 --> Session routines successfully run
DEBUG - 2013-08-29 04:36:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Controller Class Initialized
ERROR - 2013-08-29 04:36:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:36:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:36:24 --> Model Class Initialized
DEBUG - 2013-08-29 04:36:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:36:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:36:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:36:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:36:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:36:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:36:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:36:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:36:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:36:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:36:24 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:36:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:36:24 --> Final output sent to browser
DEBUG - 2013-08-29 04:36:24 --> Total execution time: 0.4710
DEBUG - 2013-08-29 04:36:25 --> Config Class Initialized
DEBUG - 2013-08-29 04:36:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:36:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:36:25 --> URI Class Initialized
DEBUG - 2013-08-29 04:36:25 --> Router Class Initialized
ERROR - 2013-08-29 04:36:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:36:35 --> Config Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:36:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:36:35 --> URI Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Router Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Output Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Security Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Input Class Initialized
DEBUG - 2013-08-29 04:36:35 --> XSS Filtering completed
DEBUG - 2013-08-29 04:36:35 --> XSS Filtering completed
DEBUG - 2013-08-29 04:36:35 --> XSS Filtering completed
DEBUG - 2013-08-29 04:36:35 --> XSS Filtering completed
DEBUG - 2013-08-29 04:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:36:35 --> Language Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Loader Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:36:35 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:36:35 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:36:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:36:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:36:35 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Session Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:36:35 --> Session routines successfully run
DEBUG - 2013-08-29 04:36:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Controller Class Initialized
ERROR - 2013-08-29 04:36:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:36:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:36:35 --> Model Class Initialized
DEBUG - 2013-08-29 04:36:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:36:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:36:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:36:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:36:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:36:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:36:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:36:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:36:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:36:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:36:35 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:36:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:36:35 --> Final output sent to browser
DEBUG - 2013-08-29 04:36:35 --> Total execution time: 0.3370
DEBUG - 2013-08-29 04:36:36 --> Config Class Initialized
DEBUG - 2013-08-29 04:36:36 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:36:36 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:36:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:36:36 --> URI Class Initialized
DEBUG - 2013-08-29 04:36:36 --> Router Class Initialized
ERROR - 2013-08-29 04:36:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:37:20 --> Config Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:37:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:37:20 --> URI Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Router Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Output Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Security Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Input Class Initialized
DEBUG - 2013-08-29 04:37:20 --> XSS Filtering completed
DEBUG - 2013-08-29 04:37:20 --> XSS Filtering completed
DEBUG - 2013-08-29 04:37:20 --> XSS Filtering completed
DEBUG - 2013-08-29 04:37:20 --> XSS Filtering completed
DEBUG - 2013-08-29 04:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:37:20 --> Language Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Loader Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:37:20 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:37:20 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:37:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:37:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:37:20 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Session Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:37:20 --> Session routines successfully run
DEBUG - 2013-08-29 04:37:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Controller Class Initialized
ERROR - 2013-08-29 04:37:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:37:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:37:20 --> Model Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:37:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:37:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:37:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:37:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:37:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:37:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:37:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:37:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:37:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:37:20 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:37:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:37:20 --> Final output sent to browser
DEBUG - 2013-08-29 04:37:20 --> Total execution time: 0.3490
DEBUG - 2013-08-29 04:37:20 --> Config Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:37:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:37:20 --> URI Class Initialized
DEBUG - 2013-08-29 04:37:20 --> Router Class Initialized
ERROR - 2013-08-29 04:37:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:38:22 --> Config Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:38:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:38:22 --> URI Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Router Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Output Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Security Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Input Class Initialized
DEBUG - 2013-08-29 04:38:22 --> XSS Filtering completed
DEBUG - 2013-08-29 04:38:22 --> XSS Filtering completed
DEBUG - 2013-08-29 04:38:22 --> XSS Filtering completed
DEBUG - 2013-08-29 04:38:22 --> XSS Filtering completed
DEBUG - 2013-08-29 04:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:38:22 --> Language Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Loader Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:38:22 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:38:22 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:38:22 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:38:22 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:38:22 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Session Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:38:22 --> Session routines successfully run
DEBUG - 2013-08-29 04:38:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Controller Class Initialized
ERROR - 2013-08-29 04:38:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:38:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:38:22 --> Model Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:38:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:38:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:38:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:38:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:38:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:38:22 --> Model Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Form Validation Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 04:38:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:38:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:38:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:38:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:38:22 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:38:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:38:22 --> Final output sent to browser
DEBUG - 2013-08-29 04:38:22 --> Total execution time: 0.5240
DEBUG - 2013-08-29 04:38:22 --> Config Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:38:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:38:22 --> URI Class Initialized
DEBUG - 2013-08-29 04:38:22 --> Router Class Initialized
ERROR - 2013-08-29 04:38:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:39:45 --> Config Class Initialized
DEBUG - 2013-08-29 04:39:45 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:39:45 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:39:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:39:45 --> URI Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Router Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Output Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Security Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Input Class Initialized
DEBUG - 2013-08-29 04:39:46 --> XSS Filtering completed
DEBUG - 2013-08-29 04:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:39:46 --> Language Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Loader Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:39:46 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:39:46 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:39:46 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:39:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:39:46 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Session Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:39:46 --> Session routines successfully run
DEBUG - 2013-08-29 04:39:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Controller Class Initialized
ERROR - 2013-08-29 04:39:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:39:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:39:46 --> Model Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:39:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:39:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:39:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:39:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:39:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:39:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:39:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:39:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:39:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:39:46 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 04:39:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:39:46 --> Final output sent to browser
DEBUG - 2013-08-29 04:39:46 --> Total execution time: 0.3570
DEBUG - 2013-08-29 04:39:46 --> Config Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:39:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:39:46 --> URI Class Initialized
DEBUG - 2013-08-29 04:39:46 --> Router Class Initialized
ERROR - 2013-08-29 04:39:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:40:03 --> Config Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:40:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:40:03 --> URI Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Router Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Output Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Security Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Input Class Initialized
DEBUG - 2013-08-29 04:40:03 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:03 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:03 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:03 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:40:03 --> Language Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Loader Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:40:03 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:40:03 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:40:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:40:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:40:03 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Session Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:40:03 --> Session routines successfully run
DEBUG - 2013-08-29 04:40:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Controller Class Initialized
ERROR - 2013-08-29 04:40:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:40:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:40:03 --> Model Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:40:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:40:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:40:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:40:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:40:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:40:03 --> Model Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Form Validation Class Initialized
DEBUG - 2013-08-29 04:40:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 04:40:04 --> Config Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:40:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:40:04 --> URI Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Router Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Output Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Security Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Input Class Initialized
DEBUG - 2013-08-29 04:40:04 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:04 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:40:04 --> Language Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Loader Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:40:04 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Session Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:40:04 --> Session routines successfully run
DEBUG - 2013-08-29 04:40:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Controller Class Initialized
ERROR - 2013-08-29 04:40:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:40:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:40:04 --> Model Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:40:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:40:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:40:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:40:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:40:04 --> Config Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:40:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:40:04 --> URI Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Router Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Output Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Security Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Input Class Initialized
DEBUG - 2013-08-29 04:40:04 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:04 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:40:04 --> Language Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Loader Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:40:04 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Session Class Initialized
DEBUG - 2013-08-29 04:40:04 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:40:05 --> Session routines successfully run
DEBUG - 2013-08-29 04:40:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:40:05 --> Controller Class Initialized
ERROR - 2013-08-29 04:40:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:40:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:40:05 --> Model Class Initialized
DEBUG - 2013-08-29 04:40:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:40:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:40:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:40:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:40:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:40:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:40:05 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-29 04:40:05 --> Final output sent to browser
DEBUG - 2013-08-29 04:40:05 --> Total execution time: 0.4760
DEBUG - 2013-08-29 04:40:46 --> Config Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:40:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:40:46 --> URI Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Router Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Output Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Security Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Input Class Initialized
DEBUG - 2013-08-29 04:40:46 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:46 --> XSS Filtering completed
DEBUG - 2013-08-29 04:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:40:46 --> Language Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Loader Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:40:46 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:40:46 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:40:46 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:40:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:40:46 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Session Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:40:46 --> Session routines successfully run
DEBUG - 2013-08-29 04:40:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Controller Class Initialized
ERROR - 2013-08-29 04:40:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:40:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:40:46 --> Model Class Initialized
DEBUG - 2013-08-29 04:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:40:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:40:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:40:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:40:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:40:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:40:46 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-29 04:40:46 --> Final output sent to browser
DEBUG - 2013-08-29 04:40:46 --> Total execution time: 0.4320
DEBUG - 2013-08-29 04:42:49 --> Config Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:42:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:42:49 --> URI Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Router Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Output Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Security Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Input Class Initialized
DEBUG - 2013-08-29 04:42:49 --> XSS Filtering completed
DEBUG - 2013-08-29 04:42:49 --> XSS Filtering completed
DEBUG - 2013-08-29 04:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:42:49 --> Language Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Loader Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:42:49 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:42:49 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:42:49 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:42:49 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:42:49 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Session Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:42:49 --> Session routines successfully run
DEBUG - 2013-08-29 04:42:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Controller Class Initialized
ERROR - 2013-08-29 04:42:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:42:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:42:49 --> Model Class Initialized
DEBUG - 2013-08-29 04:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:42:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:42:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:42:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:42:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:42:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:42:49 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-29 04:42:49 --> Final output sent to browser
DEBUG - 2013-08-29 04:42:49 --> Total execution time: 0.4660
DEBUG - 2013-08-29 04:42:55 --> Config Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:42:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:42:55 --> URI Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Router Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Output Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Security Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Input Class Initialized
DEBUG - 2013-08-29 04:42:55 --> XSS Filtering completed
DEBUG - 2013-08-29 04:42:55 --> XSS Filtering completed
DEBUG - 2013-08-29 04:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:42:55 --> Language Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Loader Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:42:55 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:42:55 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:42:55 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:42:55 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:42:55 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Session Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:42:55 --> Session routines successfully run
DEBUG - 2013-08-29 04:42:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Controller Class Initialized
ERROR - 2013-08-29 04:42:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:42:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:42:55 --> Model Class Initialized
DEBUG - 2013-08-29 04:42:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:42:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:42:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:42:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:42:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:42:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:42:56 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-29 04:42:56 --> Final output sent to browser
DEBUG - 2013-08-29 04:42:56 --> Total execution time: 0.3720
DEBUG - 2013-08-29 04:43:01 --> Config Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:43:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:43:01 --> URI Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Router Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Output Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Security Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Input Class Initialized
DEBUG - 2013-08-29 04:43:01 --> XSS Filtering completed
DEBUG - 2013-08-29 04:43:01 --> XSS Filtering completed
DEBUG - 2013-08-29 04:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:43:01 --> Language Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Loader Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:43:01 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:43:01 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:43:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:43:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:43:01 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Session Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:43:01 --> Session garbage collection performed.
DEBUG - 2013-08-29 04:43:01 --> Session routines successfully run
DEBUG - 2013-08-29 04:43:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Controller Class Initialized
ERROR - 2013-08-29 04:43:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:43:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:43:01 --> Model Class Initialized
DEBUG - 2013-08-29 04:43:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:43:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:43:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:43:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:43:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:43:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:43:01 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-29 04:43:01 --> Final output sent to browser
DEBUG - 2013-08-29 04:43:01 --> Total execution time: 0.4290
DEBUG - 2013-08-29 04:43:08 --> Config Class Initialized
DEBUG - 2013-08-29 04:43:08 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:43:08 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:43:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:43:08 --> URI Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Router Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Output Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Security Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Input Class Initialized
DEBUG - 2013-08-29 04:43:09 --> XSS Filtering completed
DEBUG - 2013-08-29 04:43:09 --> XSS Filtering completed
DEBUG - 2013-08-29 04:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:43:09 --> Language Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Loader Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:43:09 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:43:09 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:43:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:43:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:43:09 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Session Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:43:09 --> Session routines successfully run
DEBUG - 2013-08-29 04:43:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Controller Class Initialized
ERROR - 2013-08-29 04:43:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:43:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:43:09 --> Model Class Initialized
DEBUG - 2013-08-29 04:43:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:43:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:43:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:43:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:43:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:43:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:43:09 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-29 04:43:09 --> Final output sent to browser
DEBUG - 2013-08-29 04:43:09 --> Total execution time: 0.4130
DEBUG - 2013-08-29 04:43:13 --> Config Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:43:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:43:13 --> URI Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Router Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Output Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Security Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Input Class Initialized
DEBUG - 2013-08-29 04:43:13 --> XSS Filtering completed
DEBUG - 2013-08-29 04:43:13 --> XSS Filtering completed
DEBUG - 2013-08-29 04:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:43:13 --> Language Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Loader Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:43:13 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:43:13 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:43:13 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:43:13 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:43:13 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Session Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:43:13 --> Session routines successfully run
DEBUG - 2013-08-29 04:43:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Controller Class Initialized
ERROR - 2013-08-29 04:43:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:43:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:43:13 --> Model Class Initialized
DEBUG - 2013-08-29 04:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:43:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:43:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:43:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:43:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:43:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:43:13 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-29 04:43:13 --> Final output sent to browser
DEBUG - 2013-08-29 04:43:13 --> Total execution time: 0.4920
DEBUG - 2013-08-29 04:44:19 --> Config Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:44:20 --> URI Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Router Class Initialized
DEBUG - 2013-08-29 04:44:20 --> No URI present. Default controller set.
DEBUG - 2013-08-29 04:44:20 --> Output Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Security Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Input Class Initialized
DEBUG - 2013-08-29 04:44:20 --> XSS Filtering completed
DEBUG - 2013-08-29 04:44:20 --> XSS Filtering completed
DEBUG - 2013-08-29 04:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:44:20 --> Language Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Loader Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:44:20 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:44:20 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:44:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:44:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:44:20 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Session Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:44:20 --> Session routines successfully run
DEBUG - 2013-08-29 04:44:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Controller Class Initialized
ERROR - 2013-08-29 04:44:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:44:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:44:20 --> Model Class Initialized
DEBUG - 2013-08-29 04:44:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:44:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:44:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:44:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:44:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:44:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:44:20 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-29 04:44:20 --> Final output sent to browser
DEBUG - 2013-08-29 04:44:20 --> Total execution time: 0.4130
DEBUG - 2013-08-29 04:48:32 --> Config Class Initialized
DEBUG - 2013-08-29 04:48:32 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:48:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:48:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:48:32 --> URI Class Initialized
DEBUG - 2013-08-29 04:48:32 --> Router Class Initialized
DEBUG - 2013-08-29 04:48:32 --> No URI present. Default controller set.
DEBUG - 2013-08-29 04:48:32 --> Output Class Initialized
DEBUG - 2013-08-29 04:48:32 --> Security Class Initialized
DEBUG - 2013-08-29 04:48:32 --> Input Class Initialized
DEBUG - 2013-08-29 04:48:32 --> XSS Filtering completed
DEBUG - 2013-08-29 04:48:32 --> XSS Filtering completed
DEBUG - 2013-08-29 04:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:48:32 --> Language Class Initialized
DEBUG - 2013-08-29 04:48:32 --> Loader Class Initialized
DEBUG - 2013-08-29 04:48:32 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:48:32 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:48:32 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:48:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:48:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:48:33 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:48:33 --> Session Class Initialized
DEBUG - 2013-08-29 04:48:33 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:48:33 --> Session routines successfully run
DEBUG - 2013-08-29 04:48:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:48:33 --> Controller Class Initialized
ERROR - 2013-08-29 04:48:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:48:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:48:33 --> Model Class Initialized
DEBUG - 2013-08-29 04:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:48:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:48:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:48:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:48:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:48:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:48:35 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\controllers\welcome.php 24
ERROR - 2013-08-29 04:48:35 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\school\application\views\shared\head.php 14
DEBUG - 2013-08-29 04:48:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:48:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:48:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:48:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 04:48:37 --> File loaded: application/views/shared/breadcrumb.php
ERROR - 2013-08-29 04:48:37 --> Severity: Notice  --> Undefined variable: content_title C:\xampp\htdocs\school\application\views\shared\content_title.php 2
DEBUG - 2013-08-29 04:48:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:49:58 --> Config Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:49:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:49:58 --> URI Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Router Class Initialized
DEBUG - 2013-08-29 04:49:58 --> No URI present. Default controller set.
DEBUG - 2013-08-29 04:49:58 --> Output Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Security Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Input Class Initialized
DEBUG - 2013-08-29 04:49:58 --> XSS Filtering completed
DEBUG - 2013-08-29 04:49:58 --> XSS Filtering completed
DEBUG - 2013-08-29 04:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:49:58 --> Language Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Loader Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:49:58 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:49:58 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:49:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:49:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:49:58 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Session Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:49:58 --> Session garbage collection performed.
DEBUG - 2013-08-29 04:49:58 --> Session routines successfully run
DEBUG - 2013-08-29 04:49:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Controller Class Initialized
ERROR - 2013-08-29 04:49:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:49:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:49:58 --> Model Class Initialized
DEBUG - 2013-08-29 04:49:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:49:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:49:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:49:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:49:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:49:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:49:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:49:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:49:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:49:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 04:49:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 04:49:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:50:12 --> Config Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:50:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:50:12 --> URI Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Router Class Initialized
DEBUG - 2013-08-29 04:50:12 --> No URI present. Default controller set.
DEBUG - 2013-08-29 04:50:12 --> Output Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Security Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Input Class Initialized
DEBUG - 2013-08-29 04:50:12 --> XSS Filtering completed
DEBUG - 2013-08-29 04:50:12 --> XSS Filtering completed
DEBUG - 2013-08-29 04:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:50:12 --> Language Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Loader Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:50:12 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:50:12 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:50:12 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:50:12 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:50:12 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Session Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:50:12 --> Session routines successfully run
DEBUG - 2013-08-29 04:50:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Controller Class Initialized
ERROR - 2013-08-29 04:50:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:50:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:50:12 --> Model Class Initialized
DEBUG - 2013-08-29 04:50:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:50:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:50:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:50:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:50:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:50:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:50:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:50:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:50:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:50:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 04:50:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 04:50:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:50:12 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 04:50:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:50:12 --> Final output sent to browser
DEBUG - 2013-08-29 04:50:12 --> Total execution time: 0.4920
DEBUG - 2013-08-29 04:50:13 --> Config Class Initialized
DEBUG - 2013-08-29 04:50:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:50:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:50:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:50:13 --> URI Class Initialized
DEBUG - 2013-08-29 04:50:13 --> Router Class Initialized
ERROR - 2013-08-29 04:50:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 04:50:58 --> Config Class Initialized
DEBUG - 2013-08-29 04:50:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:50:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:50:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:50:58 --> URI Class Initialized
DEBUG - 2013-08-29 04:50:58 --> Router Class Initialized
DEBUG - 2013-08-29 04:50:59 --> No URI present. Default controller set.
DEBUG - 2013-08-29 04:50:59 --> Output Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Security Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Input Class Initialized
DEBUG - 2013-08-29 04:50:59 --> XSS Filtering completed
DEBUG - 2013-08-29 04:50:59 --> XSS Filtering completed
DEBUG - 2013-08-29 04:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 04:50:59 --> Language Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Loader Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Helper loaded: url_helper
DEBUG - 2013-08-29 04:50:59 --> Helper loaded: file_helper
DEBUG - 2013-08-29 04:50:59 --> Helper loaded: form_helper
DEBUG - 2013-08-29 04:50:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 04:50:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 04:50:59 --> Database Driver Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Session Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Helper loaded: string_helper
DEBUG - 2013-08-29 04:50:59 --> Session routines successfully run
DEBUG - 2013-08-29 04:50:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Controller Class Initialized
ERROR - 2013-08-29 04:50:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:50:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:50:59 --> Model Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 04:50:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 04:50:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 04:50:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 04:50:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 04:50:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 04:50:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 04:50:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 04:50:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 04:50:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 04:50:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 04:50:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 04:50:59 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 04:50:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 04:50:59 --> Final output sent to browser
DEBUG - 2013-08-29 04:50:59 --> Total execution time: 0.5410
DEBUG - 2013-08-29 04:50:59 --> Config Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Hooks Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Utf8 Class Initialized
DEBUG - 2013-08-29 04:50:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 04:50:59 --> URI Class Initialized
DEBUG - 2013-08-29 04:50:59 --> Router Class Initialized
ERROR - 2013-08-29 04:50:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 05:10:15 --> Config Class Initialized
DEBUG - 2013-08-29 05:10:15 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:10:15 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:10:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:10:15 --> URI Class Initialized
DEBUG - 2013-08-29 05:10:15 --> Router Class Initialized
DEBUG - 2013-08-29 05:10:15 --> No URI present. Default controller set.
DEBUG - 2013-08-29 05:10:15 --> Output Class Initialized
DEBUG - 2013-08-29 05:10:15 --> Security Class Initialized
DEBUG - 2013-08-29 05:10:16 --> Input Class Initialized
DEBUG - 2013-08-29 05:10:16 --> XSS Filtering completed
DEBUG - 2013-08-29 05:10:16 --> XSS Filtering completed
DEBUG - 2013-08-29 05:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:10:16 --> Language Class Initialized
DEBUG - 2013-08-29 05:10:16 --> Loader Class Initialized
DEBUG - 2013-08-29 05:10:16 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:10:16 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:10:16 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:10:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:10:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:10:16 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:10:16 --> Session Class Initialized
DEBUG - 2013-08-29 05:10:16 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:10:16 --> Session routines successfully run
DEBUG - 2013-08-29 05:10:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:10:16 --> Controller Class Initialized
ERROR - 2013-08-29 05:10:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:10:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:10:16 --> Model Class Initialized
DEBUG - 2013-08-29 05:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:10:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:10:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:10:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:10:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:10:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:10:17 --> Severity: Notice  --> Undefined property: Welcome::$user_model C:\xampp\htdocs\school\application\controllers\welcome.php 30
DEBUG - 2013-08-29 05:11:33 --> Config Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:11:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:11:33 --> URI Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Router Class Initialized
DEBUG - 2013-08-29 05:11:33 --> No URI present. Default controller set.
DEBUG - 2013-08-29 05:11:33 --> Output Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Security Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Input Class Initialized
DEBUG - 2013-08-29 05:11:33 --> XSS Filtering completed
DEBUG - 2013-08-29 05:11:33 --> XSS Filtering completed
DEBUG - 2013-08-29 05:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:11:33 --> Language Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Loader Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:11:33 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:11:33 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:11:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:11:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:11:33 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Session Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:11:33 --> Session routines successfully run
DEBUG - 2013-08-29 05:11:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Controller Class Initialized
ERROR - 2013-08-29 05:11:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:11:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:11:33 --> Model Class Initialized
DEBUG - 2013-08-29 05:11:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:11:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:11:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:11:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:11:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:11:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:11:34 --> Model Class Initialized
ERROR - 2013-08-29 05:11:34 --> Severity: Notice  --> Undefined property: Welcome::$user_group_model C:\xampp\htdocs\school\application\controllers\welcome.php 25
DEBUG - 2013-08-29 05:11:53 --> Config Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:11:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:11:53 --> URI Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Router Class Initialized
DEBUG - 2013-08-29 05:11:53 --> No URI present. Default controller set.
DEBUG - 2013-08-29 05:11:53 --> Output Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Security Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Input Class Initialized
DEBUG - 2013-08-29 05:11:53 --> XSS Filtering completed
DEBUG - 2013-08-29 05:11:53 --> XSS Filtering completed
DEBUG - 2013-08-29 05:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:11:53 --> Language Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Loader Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:11:53 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:11:53 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:11:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:11:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:11:53 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Session Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:11:53 --> Session routines successfully run
DEBUG - 2013-08-29 05:11:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:11:53 --> Controller Class Initialized
ERROR - 2013-08-29 05:11:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:11:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:11:54 --> Model Class Initialized
DEBUG - 2013-08-29 05:11:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:11:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:11:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:11:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:11:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:11:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:11:54 --> Model Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Config Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:12:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:12:06 --> URI Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Router Class Initialized
DEBUG - 2013-08-29 05:12:06 --> No URI present. Default controller set.
DEBUG - 2013-08-29 05:12:06 --> Output Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Security Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Input Class Initialized
DEBUG - 2013-08-29 05:12:06 --> XSS Filtering completed
DEBUG - 2013-08-29 05:12:06 --> XSS Filtering completed
DEBUG - 2013-08-29 05:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:12:06 --> Language Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Loader Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:12:06 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:12:06 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:12:06 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:12:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:12:06 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Session Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:12:06 --> Session routines successfully run
DEBUG - 2013-08-29 05:12:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Controller Class Initialized
ERROR - 2013-08-29 05:12:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:12:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:12:06 --> Model Class Initialized
DEBUG - 2013-08-29 05:12:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:12:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:12:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:12:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:12:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:12:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:12:06 --> Model Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Config Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:12:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:12:40 --> URI Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Router Class Initialized
DEBUG - 2013-08-29 05:12:40 --> No URI present. Default controller set.
DEBUG - 2013-08-29 05:12:40 --> Output Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Security Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Input Class Initialized
DEBUG - 2013-08-29 05:12:40 --> XSS Filtering completed
DEBUG - 2013-08-29 05:12:40 --> XSS Filtering completed
DEBUG - 2013-08-29 05:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:12:40 --> Language Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Loader Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:12:40 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:12:40 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:12:40 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:12:40 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:12:40 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Session Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:12:40 --> Session routines successfully run
DEBUG - 2013-08-29 05:12:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Controller Class Initialized
ERROR - 2013-08-29 05:12:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:12:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:12:40 --> Model Class Initialized
DEBUG - 2013-08-29 05:12:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:12:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:12:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:12:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:12:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:12:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:12:40 --> Model Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Config Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:15:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:15:09 --> URI Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Router Class Initialized
DEBUG - 2013-08-29 05:15:09 --> No URI present. Default controller set.
DEBUG - 2013-08-29 05:15:09 --> Output Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Security Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Input Class Initialized
DEBUG - 2013-08-29 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-29 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-29 05:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:15:09 --> Language Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Loader Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:15:09 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:15:09 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:15:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:15:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:15:09 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Session Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:15:09 --> Session routines successfully run
DEBUG - 2013-08-29 05:15:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Controller Class Initialized
ERROR - 2013-08-29 05:15:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:15:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:15:09 --> Model Class Initialized
DEBUG - 2013-08-29 05:15:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:15:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:15:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:15:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:15:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:15:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:15:09 --> Model Class Initialized
DEBUG - 2013-08-29 05:15:16 --> Config Class Initialized
DEBUG - 2013-08-29 05:15:16 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:15:16 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:15:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:15:16 --> URI Class Initialized
DEBUG - 2013-08-29 05:15:16 --> Router Class Initialized
DEBUG - 2013-08-29 05:15:16 --> Output Class Initialized
DEBUG - 2013-08-29 05:15:16 --> Security Class Initialized
DEBUG - 2013-08-29 05:15:16 --> Input Class Initialized
DEBUG - 2013-08-29 05:15:16 --> XSS Filtering completed
DEBUG - 2013-08-29 05:15:16 --> XSS Filtering completed
DEBUG - 2013-08-29 05:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:15:16 --> Language Class Initialized
DEBUG - 2013-08-29 05:15:16 --> Loader Class Initialized
DEBUG - 2013-08-29 05:15:16 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:15:17 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:15:17 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:15:17 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:15:17 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:15:17 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:15:17 --> Session Class Initialized
DEBUG - 2013-08-29 05:15:17 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:15:17 --> Session routines successfully run
DEBUG - 2013-08-29 05:15:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:15:17 --> Controller Class Initialized
ERROR - 2013-08-29 05:15:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:15:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:15:17 --> Model Class Initialized
DEBUG - 2013-08-29 05:15:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:15:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:15:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:15:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:15:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:15:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:15:17 --> 404 Page Not Found --> user_sessions/logout
DEBUG - 2013-08-29 05:23:37 --> Config Class Initialized
DEBUG - 2013-08-29 05:23:37 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:23:37 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:23:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:23:37 --> URI Class Initialized
DEBUG - 2013-08-29 05:23:37 --> Router Class Initialized
DEBUG - 2013-08-29 05:23:37 --> Output Class Initialized
DEBUG - 2013-08-29 05:23:37 --> Security Class Initialized
DEBUG - 2013-08-29 05:23:37 --> Input Class Initialized
DEBUG - 2013-08-29 05:23:37 --> XSS Filtering completed
DEBUG - 2013-08-29 05:23:37 --> XSS Filtering completed
DEBUG - 2013-08-29 05:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:23:37 --> Language Class Initialized
DEBUG - 2013-08-29 05:23:37 --> Loader Class Initialized
DEBUG - 2013-08-29 05:23:37 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:23:37 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:23:38 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:23:38 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:23:38 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:23:38 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:23:38 --> Session Class Initialized
DEBUG - 2013-08-29 05:23:38 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:23:38 --> Session routines successfully run
DEBUG - 2013-08-29 05:23:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:23:38 --> Controller Class Initialized
ERROR - 2013-08-29 05:23:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:23:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:23:38 --> Model Class Initialized
DEBUG - 2013-08-29 05:23:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:23:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:23:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:23:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:23:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:23:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:23:38 --> Config Class Initialized
DEBUG - 2013-08-29 05:23:38 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:23:38 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:23:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:23:38 --> URI Class Initialized
DEBUG - 2013-08-29 05:23:38 --> Router Class Initialized
ERROR - 2013-08-29 05:23:38 --> 404 Page Not Found --> auth
DEBUG - 2013-08-29 05:24:01 --> Config Class Initialized
DEBUG - 2013-08-29 05:24:01 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:24:01 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:24:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:24:01 --> URI Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Router Class Initialized
DEBUG - 2013-08-29 05:24:02 --> No URI present. Default controller set.
DEBUG - 2013-08-29 05:24:02 --> Output Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Security Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Input Class Initialized
DEBUG - 2013-08-29 05:24:02 --> XSS Filtering completed
DEBUG - 2013-08-29 05:24:02 --> XSS Filtering completed
DEBUG - 2013-08-29 05:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:24:02 --> Language Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Loader Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:24:02 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Session Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:24:02 --> Session routines successfully run
DEBUG - 2013-08-29 05:24:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Controller Class Initialized
ERROR - 2013-08-29 05:24:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:24:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:24:02 --> Model Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:24:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:24:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:24:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:24:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:24:02 --> Model Class Initialized
ERROR - 2013-08-29 05:24:02 --> Severity: Warning  --> key() expects parameter 1 to be array, null given C:\xampp\htdocs\school\application\libraries\Flexi_auth_lite.php 315
DEBUG - 2013-08-29 05:24:02 --> Config Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:24:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:24:02 --> URI Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Router Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Output Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Security Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Input Class Initialized
DEBUG - 2013-08-29 05:24:02 --> XSS Filtering completed
DEBUG - 2013-08-29 05:24:02 --> XSS Filtering completed
DEBUG - 2013-08-29 05:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:24:02 --> Language Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Loader Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:24:02 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Session Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:24:02 --> Session routines successfully run
DEBUG - 2013-08-29 05:24:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:24:02 --> Controller Class Initialized
ERROR - 2013-08-29 05:24:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:24:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:24:03 --> Model Class Initialized
DEBUG - 2013-08-29 05:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:24:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:24:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:24:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:24:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:24:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:24:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 05:24:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 05:24:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 05:24:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 05:24:03 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 05:24:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 05:24:03 --> Final output sent to browser
DEBUG - 2013-08-29 05:24:03 --> Total execution time: 0.8841
DEBUG - 2013-08-29 05:24:03 --> Config Class Initialized
DEBUG - 2013-08-29 05:24:03 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:24:03 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:24:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:24:03 --> URI Class Initialized
DEBUG - 2013-08-29 05:24:03 --> Router Class Initialized
ERROR - 2013-08-29 05:24:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 05:24:21 --> Config Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:24:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:24:21 --> URI Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Router Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Output Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Security Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Input Class Initialized
DEBUG - 2013-08-29 05:24:21 --> XSS Filtering completed
DEBUG - 2013-08-29 05:24:21 --> XSS Filtering completed
DEBUG - 2013-08-29 05:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:24:21 --> Language Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Loader Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:24:21 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:24:21 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:24:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:24:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:24:21 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Session Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:24:21 --> Session garbage collection performed.
DEBUG - 2013-08-29 05:24:21 --> Session routines successfully run
DEBUG - 2013-08-29 05:24:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Controller Class Initialized
ERROR - 2013-08-29 05:24:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:24:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:24:21 --> Model Class Initialized
DEBUG - 2013-08-29 05:24:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:24:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:24:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:24:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:24:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:24:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:24:22 --> Pagination Class Initialized
DEBUG - 2013-08-29 05:24:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 05:24:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 05:24:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 05:24:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 05:24:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 05:24:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 05:24:22 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-29 05:24:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 05:24:22 --> Final output sent to browser
DEBUG - 2013-08-29 05:24:22 --> Total execution time: 1.5841
DEBUG - 2013-08-29 05:24:23 --> Config Class Initialized
DEBUG - 2013-08-29 05:24:23 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:24:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:24:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:24:23 --> URI Class Initialized
DEBUG - 2013-08-29 05:24:23 --> Router Class Initialized
ERROR - 2013-08-29 05:24:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 05:25:19 --> Config Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:25:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:25:19 --> URI Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Router Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Output Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Security Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Input Class Initialized
DEBUG - 2013-08-29 05:25:19 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:19 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:25:19 --> Language Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Loader Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:25:19 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:25:19 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:25:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:25:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:25:19 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Session Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:25:19 --> Session routines successfully run
DEBUG - 2013-08-29 05:25:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Controller Class Initialized
ERROR - 2013-08-29 05:25:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:19 --> Model Class Initialized
DEBUG - 2013-08-29 05:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:25:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:25:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:25:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:25:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 05:25:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 05:25:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 05:25:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 05:25:20 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 05:25:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 05:25:20 --> Final output sent to browser
DEBUG - 2013-08-29 05:25:20 --> Total execution time: 0.5430
DEBUG - 2013-08-29 05:25:20 --> Config Class Initialized
DEBUG - 2013-08-29 05:25:20 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:25:20 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:25:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:25:20 --> URI Class Initialized
DEBUG - 2013-08-29 05:25:20 --> Router Class Initialized
ERROR - 2013-08-29 05:25:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 05:25:26 --> Config Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:25:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:25:26 --> URI Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Router Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Output Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Security Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Input Class Initialized
DEBUG - 2013-08-29 05:25:26 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:26 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:26 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:26 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:26 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:25:26 --> Language Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Loader Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:25:26 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:25:26 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:25:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:25:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:25:26 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Session Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:25:26 --> Session routines successfully run
DEBUG - 2013-08-29 05:25:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Controller Class Initialized
ERROR - 2013-08-29 05:25:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:26 --> Model Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:25:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:25:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:25:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:25:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:26 --> Model Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Form Validation Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 05:25:26 --> Config Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:25:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:25:26 --> URI Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Router Class Initialized
DEBUG - 2013-08-29 05:25:26 --> Output Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Security Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Input Class Initialized
DEBUG - 2013-08-29 05:25:27 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:27 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:25:27 --> Language Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Loader Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:25:27 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Session Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:25:27 --> Session routines successfully run
DEBUG - 2013-08-29 05:25:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Controller Class Initialized
ERROR - 2013-08-29 05:25:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:27 --> Model Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:25:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:25:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:25:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:27 --> Config Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:25:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:25:27 --> URI Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Router Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Output Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Security Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Input Class Initialized
DEBUG - 2013-08-29 05:25:27 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:27 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:25:27 --> Language Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Loader Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:25:27 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Session Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:25:27 --> Session routines successfully run
DEBUG - 2013-08-29 05:25:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Controller Class Initialized
ERROR - 2013-08-29 05:25:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:27 --> Model Class Initialized
DEBUG - 2013-08-29 05:25:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:25:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:25:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:25:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:25:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:27 --> Model Class Initialized
DEBUG - 2013-08-29 05:25:42 --> Config Class Initialized
DEBUG - 2013-08-29 05:25:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:25:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:25:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:25:42 --> URI Class Initialized
DEBUG - 2013-08-29 05:25:42 --> Router Class Initialized
DEBUG - 2013-08-29 05:25:42 --> Output Class Initialized
DEBUG - 2013-08-29 05:25:42 --> Security Class Initialized
DEBUG - 2013-08-29 05:25:42 --> Input Class Initialized
DEBUG - 2013-08-29 05:25:42 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:42 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:25:42 --> Language Class Initialized
DEBUG - 2013-08-29 05:25:42 --> Loader Class Initialized
DEBUG - 2013-08-29 05:25:42 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:25:42 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:25:42 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:25:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:25:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:25:43 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:25:43 --> Session Class Initialized
DEBUG - 2013-08-29 05:25:43 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:25:43 --> Session routines successfully run
DEBUG - 2013-08-29 05:25:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:25:43 --> Controller Class Initialized
ERROR - 2013-08-29 05:25:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:43 --> Model Class Initialized
DEBUG - 2013-08-29 05:25:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:25:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:25:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:25:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:25:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:43 --> Model Class Initialized
DEBUG - 2013-08-29 05:25:58 --> Config Class Initialized
DEBUG - 2013-08-29 05:25:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:25:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:25:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:25:58 --> URI Class Initialized
DEBUG - 2013-08-29 05:25:58 --> Router Class Initialized
DEBUG - 2013-08-29 05:25:58 --> Output Class Initialized
DEBUG - 2013-08-29 05:25:59 --> Security Class Initialized
DEBUG - 2013-08-29 05:25:59 --> Input Class Initialized
DEBUG - 2013-08-29 05:25:59 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:59 --> XSS Filtering completed
DEBUG - 2013-08-29 05:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:25:59 --> Language Class Initialized
DEBUG - 2013-08-29 05:25:59 --> Loader Class Initialized
DEBUG - 2013-08-29 05:25:59 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:25:59 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:25:59 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:25:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:25:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:25:59 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:25:59 --> Session Class Initialized
DEBUG - 2013-08-29 05:25:59 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:25:59 --> Session routines successfully run
DEBUG - 2013-08-29 05:25:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:25:59 --> Controller Class Initialized
ERROR - 2013-08-29 05:25:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:59 --> Model Class Initialized
DEBUG - 2013-08-29 05:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:25:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:25:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:25:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:25:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:25:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:25:59 --> Model Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Config Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:26:34 --> URI Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Router Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Output Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Security Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Input Class Initialized
DEBUG - 2013-08-29 05:26:34 --> XSS Filtering completed
DEBUG - 2013-08-29 05:26:34 --> XSS Filtering completed
DEBUG - 2013-08-29 05:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:26:34 --> Language Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Loader Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:26:34 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:26:34 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:26:34 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Session Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:26:34 --> Session routines successfully run
DEBUG - 2013-08-29 05:26:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Controller Class Initialized
ERROR - 2013-08-29 05:26:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:26:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:26:34 --> Model Class Initialized
DEBUG - 2013-08-29 05:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:26:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:26:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:26:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:26:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:26:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:26:34 --> Model Class Initialized
DEBUG - 2013-08-29 05:26:42 --> Config Class Initialized
DEBUG - 2013-08-29 05:26:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:26:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:26:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:26:42 --> URI Class Initialized
DEBUG - 2013-08-29 05:26:42 --> Router Class Initialized
DEBUG - 2013-08-29 05:26:42 --> Output Class Initialized
DEBUG - 2013-08-29 05:26:42 --> Security Class Initialized
DEBUG - 2013-08-29 05:26:42 --> Input Class Initialized
DEBUG - 2013-08-29 05:26:42 --> XSS Filtering completed
DEBUG - 2013-08-29 05:26:42 --> XSS Filtering completed
DEBUG - 2013-08-29 05:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:26:43 --> Language Class Initialized
DEBUG - 2013-08-29 05:26:43 --> Loader Class Initialized
DEBUG - 2013-08-29 05:26:43 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:26:43 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:26:43 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:26:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:26:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:26:43 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:26:43 --> Session Class Initialized
DEBUG - 2013-08-29 05:26:43 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:26:43 --> Session routines successfully run
DEBUG - 2013-08-29 05:26:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:26:43 --> Controller Class Initialized
ERROR - 2013-08-29 05:26:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:26:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:26:43 --> Model Class Initialized
DEBUG - 2013-08-29 05:26:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:26:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:26:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:26:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:26:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:26:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:26:43 --> Model Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Config Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:26:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:26:58 --> URI Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Router Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Output Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Security Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Input Class Initialized
DEBUG - 2013-08-29 05:26:58 --> XSS Filtering completed
DEBUG - 2013-08-29 05:26:58 --> XSS Filtering completed
DEBUG - 2013-08-29 05:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:26:58 --> Language Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Loader Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:26:58 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:26:58 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:26:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:26:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:26:58 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Session Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:26:58 --> Session routines successfully run
DEBUG - 2013-08-29 05:26:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Controller Class Initialized
ERROR - 2013-08-29 05:26:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:26:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:26:58 --> Model Class Initialized
DEBUG - 2013-08-29 05:26:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:26:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:26:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:26:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:26:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:26:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:26:58 --> Model Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Config Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:27:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:27:11 --> URI Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Router Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Output Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Security Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Input Class Initialized
DEBUG - 2013-08-29 05:27:11 --> XSS Filtering completed
DEBUG - 2013-08-29 05:27:11 --> XSS Filtering completed
DEBUG - 2013-08-29 05:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:27:11 --> Language Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Loader Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:27:11 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:27:11 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:27:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:27:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:27:11 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Session Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:27:11 --> Session routines successfully run
DEBUG - 2013-08-29 05:27:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Controller Class Initialized
ERROR - 2013-08-29 05:27:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:27:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:27:11 --> Model Class Initialized
DEBUG - 2013-08-29 05:27:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:27:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:27:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:27:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:27:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:27:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:27:11 --> Model Class Initialized
DEBUG - 2013-08-29 05:28:10 --> Config Class Initialized
DEBUG - 2013-08-29 05:28:10 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:28:10 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:28:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:28:10 --> URI Class Initialized
DEBUG - 2013-08-29 05:28:10 --> Router Class Initialized
DEBUG - 2013-08-29 05:28:10 --> Output Class Initialized
DEBUG - 2013-08-29 05:28:10 --> Security Class Initialized
DEBUG - 2013-08-29 05:28:11 --> Input Class Initialized
DEBUG - 2013-08-29 05:28:11 --> XSS Filtering completed
DEBUG - 2013-08-29 05:28:11 --> XSS Filtering completed
DEBUG - 2013-08-29 05:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:28:11 --> Language Class Initialized
DEBUG - 2013-08-29 05:28:11 --> Loader Class Initialized
DEBUG - 2013-08-29 05:28:11 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:28:11 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:28:11 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:28:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:28:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:28:11 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:28:11 --> Session Class Initialized
DEBUG - 2013-08-29 05:28:11 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:28:11 --> Session routines successfully run
DEBUG - 2013-08-29 05:28:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:28:11 --> Controller Class Initialized
ERROR - 2013-08-29 05:28:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:28:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:28:11 --> Model Class Initialized
DEBUG - 2013-08-29 05:28:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:28:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:28:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:28:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:28:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:28:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:28:11 --> Model Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Config Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:29:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:29:32 --> URI Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Router Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Output Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Security Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Input Class Initialized
DEBUG - 2013-08-29 05:29:32 --> XSS Filtering completed
DEBUG - 2013-08-29 05:29:32 --> XSS Filtering completed
DEBUG - 2013-08-29 05:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:29:32 --> Language Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Loader Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:29:32 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:29:32 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:29:32 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:29:32 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:29:32 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Session Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:29:32 --> Session routines successfully run
DEBUG - 2013-08-29 05:29:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Controller Class Initialized
ERROR - 2013-08-29 05:29:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:29:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:29:32 --> Model Class Initialized
DEBUG - 2013-08-29 05:29:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:29:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:29:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:29:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:29:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:29:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:29:32 --> Model Class Initialized
DEBUG - 2013-08-29 05:29:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 05:29:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 05:29:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 05:29:32 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 05:29:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 05:29:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 05:29:32 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 05:29:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 05:29:32 --> Final output sent to browser
DEBUG - 2013-08-29 05:29:32 --> Total execution time: 0.7450
DEBUG - 2013-08-29 05:29:33 --> Config Class Initialized
DEBUG - 2013-08-29 05:29:33 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:29:33 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:29:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:29:33 --> URI Class Initialized
DEBUG - 2013-08-29 05:29:33 --> Router Class Initialized
ERROR - 2013-08-29 05:29:33 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 05:49:12 --> Config Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:49:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:49:12 --> URI Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Router Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Output Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Security Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Input Class Initialized
DEBUG - 2013-08-29 05:49:12 --> XSS Filtering completed
DEBUG - 2013-08-29 05:49:12 --> XSS Filtering completed
DEBUG - 2013-08-29 05:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:49:12 --> Language Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Loader Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:49:12 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:49:12 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:49:12 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:49:12 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:49:12 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Session Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:49:12 --> Session routines successfully run
DEBUG - 2013-08-29 05:49:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:49:12 --> Controller Class Initialized
ERROR - 2013-08-29 05:49:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:49:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:49:13 --> Model Class Initialized
DEBUG - 2013-08-29 05:49:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:49:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:49:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:49:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:49:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:49:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:49:13 --> Pagination Class Initialized
DEBUG - 2013-08-29 05:49:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 05:49:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 05:49:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 05:49:13 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 05:49:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 05:49:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 05:49:13 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-29 05:49:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 05:49:13 --> Final output sent to browser
DEBUG - 2013-08-29 05:49:13 --> Total execution time: 2.3191
DEBUG - 2013-08-29 05:49:14 --> Config Class Initialized
DEBUG - 2013-08-29 05:49:14 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:49:14 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:49:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:49:14 --> URI Class Initialized
DEBUG - 2013-08-29 05:49:14 --> Router Class Initialized
ERROR - 2013-08-29 05:49:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 05:49:16 --> Config Class Initialized
DEBUG - 2013-08-29 05:49:16 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:49:16 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:49:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:49:16 --> URI Class Initialized
DEBUG - 2013-08-29 05:49:16 --> Router Class Initialized
DEBUG - 2013-08-29 05:49:16 --> Output Class Initialized
DEBUG - 2013-08-29 05:49:16 --> Security Class Initialized
DEBUG - 2013-08-29 05:49:16 --> Input Class Initialized
DEBUG - 2013-08-29 05:49:16 --> XSS Filtering completed
DEBUG - 2013-08-29 05:49:16 --> XSS Filtering completed
DEBUG - 2013-08-29 05:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:49:16 --> Language Class Initialized
DEBUG - 2013-08-29 05:49:16 --> Loader Class Initialized
DEBUG - 2013-08-29 05:49:16 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:49:16 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:49:16 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:49:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:49:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:49:17 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:49:17 --> Session Class Initialized
DEBUG - 2013-08-29 05:49:17 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:49:17 --> Session routines successfully run
DEBUG - 2013-08-29 05:49:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:49:17 --> Controller Class Initialized
ERROR - 2013-08-29 05:49:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:49:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:49:17 --> Model Class Initialized
DEBUG - 2013-08-29 05:49:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:49:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:49:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:49:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:49:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:49:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:50:24 --> Config Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:50:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:50:24 --> URI Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Router Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Output Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Security Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Input Class Initialized
DEBUG - 2013-08-29 05:50:24 --> XSS Filtering completed
DEBUG - 2013-08-29 05:50:24 --> XSS Filtering completed
DEBUG - 2013-08-29 05:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:50:24 --> Language Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Loader Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:50:24 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:50:24 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:50:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:50:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:50:24 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Session Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:50:24 --> Session routines successfully run
DEBUG - 2013-08-29 05:50:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Controller Class Initialized
ERROR - 2013-08-29 05:50:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:50:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:50:24 --> Model Class Initialized
DEBUG - 2013-08-29 05:50:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:50:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:50:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:50:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:50:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:50:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:50:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 05:50:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 05:50:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 05:50:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 05:50:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 05:50:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 05:50:25 --> File loaded: application/views/privileges/new.php
DEBUG - 2013-08-29 05:50:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 05:51:00 --> Config Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:51:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:51:00 --> URI Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Router Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Output Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Security Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Input Class Initialized
DEBUG - 2013-08-29 05:51:00 --> XSS Filtering completed
DEBUG - 2013-08-29 05:51:00 --> XSS Filtering completed
DEBUG - 2013-08-29 05:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:51:00 --> Language Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Loader Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:51:00 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:51:00 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:51:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:51:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:51:00 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Session Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:51:00 --> Session routines successfully run
DEBUG - 2013-08-29 05:51:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Controller Class Initialized
ERROR - 2013-08-29 05:51:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:51:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:51:00 --> Model Class Initialized
DEBUG - 2013-08-29 05:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:51:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:51:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:51:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:51:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:51:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:51:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 05:51:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 05:51:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 05:51:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 05:51:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 05:51:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 05:51:00 --> File loaded: application/views/privileges/new.php
DEBUG - 2013-08-29 05:51:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 05:51:01 --> Final output sent to browser
DEBUG - 2013-08-29 05:51:01 --> Total execution time: 1.0571
DEBUG - 2013-08-29 05:51:01 --> Config Class Initialized
DEBUG - 2013-08-29 05:51:01 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:51:01 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:51:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:51:01 --> URI Class Initialized
DEBUG - 2013-08-29 05:51:01 --> Router Class Initialized
ERROR - 2013-08-29 05:51:01 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 05:51:36 --> Config Class Initialized
DEBUG - 2013-08-29 05:51:36 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:51:36 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:51:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:51:36 --> URI Class Initialized
DEBUG - 2013-08-29 05:51:36 --> Router Class Initialized
DEBUG - 2013-08-29 05:51:36 --> Output Class Initialized
DEBUG - 2013-08-29 05:51:36 --> Security Class Initialized
DEBUG - 2013-08-29 05:51:36 --> Input Class Initialized
DEBUG - 2013-08-29 05:51:36 --> XSS Filtering completed
DEBUG - 2013-08-29 05:51:36 --> XSS Filtering completed
DEBUG - 2013-08-29 05:51:36 --> XSS Filtering completed
DEBUG - 2013-08-29 05:51:36 --> XSS Filtering completed
DEBUG - 2013-08-29 05:51:36 --> XSS Filtering completed
DEBUG - 2013-08-29 05:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:51:37 --> Language Class Initialized
DEBUG - 2013-08-29 05:51:37 --> Loader Class Initialized
DEBUG - 2013-08-29 05:51:37 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:51:37 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:51:37 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:51:37 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:51:37 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:51:37 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:51:37 --> Session Class Initialized
DEBUG - 2013-08-29 05:51:37 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:51:37 --> Session routines successfully run
DEBUG - 2013-08-29 05:51:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:51:37 --> Controller Class Initialized
ERROR - 2013-08-29 05:51:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:51:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:51:37 --> Model Class Initialized
DEBUG - 2013-08-29 05:51:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:51:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:51:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:51:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:51:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:51:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:51:37 --> Form Validation Class Initialized
DEBUG - 2013-08-29 05:51:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 05:51:37 --> DB Transaction Failure
ERROR - 2013-08-29 05:51:37 --> Query error: Table 'school.privileges' doesn't exist
DEBUG - 2013-08-29 05:51:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 05:54:53 --> Config Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:54:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:54:53 --> URI Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Router Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Output Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Security Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Input Class Initialized
DEBUG - 2013-08-29 05:54:53 --> XSS Filtering completed
DEBUG - 2013-08-29 05:54:53 --> XSS Filtering completed
DEBUG - 2013-08-29 05:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:54:53 --> Language Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Loader Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:54:53 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:54:53 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:54:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:54:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:54:53 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Session Class Initialized
DEBUG - 2013-08-29 05:54:53 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:54:56 --> Session routines successfully run
DEBUG - 2013-08-29 05:54:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:54:56 --> Controller Class Initialized
ERROR - 2013-08-29 05:54:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:54:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:54:56 --> Model Class Initialized
DEBUG - 2013-08-29 05:54:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:54:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:54:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:54:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:54:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:54:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:54:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 05:54:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 05:54:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 05:54:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 05:54:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 05:54:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 05:54:59 --> File loaded: application/views/privileges/new.php
DEBUG - 2013-08-29 05:54:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 05:55:01 --> Final output sent to browser
DEBUG - 2013-08-29 05:55:01 --> Total execution time: 8.1065
DEBUG - 2013-08-29 05:55:02 --> Config Class Initialized
DEBUG - 2013-08-29 05:55:02 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:55:02 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:55:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:55:02 --> URI Class Initialized
DEBUG - 2013-08-29 05:55:02 --> Router Class Initialized
ERROR - 2013-08-29 05:55:02 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 05:56:33 --> Config Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:56:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:56:33 --> URI Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Router Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Output Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Security Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Input Class Initialized
DEBUG - 2013-08-29 05:56:33 --> XSS Filtering completed
DEBUG - 2013-08-29 05:56:33 --> XSS Filtering completed
DEBUG - 2013-08-29 05:56:33 --> XSS Filtering completed
DEBUG - 2013-08-29 05:56:33 --> XSS Filtering completed
DEBUG - 2013-08-29 05:56:33 --> XSS Filtering completed
DEBUG - 2013-08-29 05:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:56:33 --> Language Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Loader Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:56:33 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:56:33 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:56:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:56:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:56:33 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Session Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:56:33 --> Session routines successfully run
DEBUG - 2013-08-29 05:56:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Controller Class Initialized
ERROR - 2013-08-29 05:56:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:56:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:56:33 --> Model Class Initialized
DEBUG - 2013-08-29 05:56:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:56:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:56:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:56:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:56:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:56:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:56:37 --> Form Validation Class Initialized
DEBUG - 2013-08-29 05:56:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 05:56:38 --> DB Transaction Failure
ERROR - 2013-08-29 05:56:38 --> Query error: Table 'school.privileges' doesn't exist
DEBUG - 2013-08-29 05:56:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 05:57:58 --> Config Class Initialized
DEBUG - 2013-08-29 05:57:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:57:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:57:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:57:58 --> URI Class Initialized
DEBUG - 2013-08-29 05:57:58 --> Router Class Initialized
DEBUG - 2013-08-29 05:57:58 --> Output Class Initialized
DEBUG - 2013-08-29 05:57:58 --> Security Class Initialized
DEBUG - 2013-08-29 05:57:58 --> Input Class Initialized
DEBUG - 2013-08-29 05:57:58 --> XSS Filtering completed
DEBUG - 2013-08-29 05:57:58 --> XSS Filtering completed
DEBUG - 2013-08-29 05:57:58 --> XSS Filtering completed
DEBUG - 2013-08-29 05:57:58 --> XSS Filtering completed
DEBUG - 2013-08-29 05:57:58 --> XSS Filtering completed
DEBUG - 2013-08-29 05:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:57:59 --> Language Class Initialized
DEBUG - 2013-08-29 05:57:59 --> Loader Class Initialized
DEBUG - 2013-08-29 05:57:59 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:57:59 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:57:59 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:57:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:57:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:57:59 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:57:59 --> Session Class Initialized
DEBUG - 2013-08-29 05:57:59 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:57:59 --> Session routines successfully run
DEBUG - 2013-08-29 05:57:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:57:59 --> Controller Class Initialized
ERROR - 2013-08-29 05:57:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:57:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:57:59 --> Model Class Initialized
DEBUG - 2013-08-29 05:57:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:57:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:57:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:57:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:58:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:58:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:58:03 --> Form Validation Class Initialized
DEBUG - 2013-08-29 05:58:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 05:58:29 --> Config Class Initialized
DEBUG - 2013-08-29 05:58:29 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:58:29 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:58:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:58:29 --> URI Class Initialized
DEBUG - 2013-08-29 05:58:29 --> Router Class Initialized
DEBUG - 2013-08-29 05:58:29 --> Output Class Initialized
DEBUG - 2013-08-29 05:58:29 --> Security Class Initialized
DEBUG - 2013-08-29 05:58:29 --> Input Class Initialized
DEBUG - 2013-08-29 05:58:29 --> XSS Filtering completed
DEBUG - 2013-08-29 05:58:29 --> XSS Filtering completed
DEBUG - 2013-08-29 05:58:29 --> XSS Filtering completed
DEBUG - 2013-08-29 05:58:29 --> XSS Filtering completed
DEBUG - 2013-08-29 05:58:29 --> XSS Filtering completed
DEBUG - 2013-08-29 05:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:58:29 --> Language Class Initialized
DEBUG - 2013-08-29 05:58:30 --> Loader Class Initialized
DEBUG - 2013-08-29 05:58:30 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:58:30 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:58:30 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:58:30 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:58:30 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:58:30 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:58:30 --> Session Class Initialized
DEBUG - 2013-08-29 05:58:30 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:58:30 --> Session routines successfully run
DEBUG - 2013-08-29 05:58:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:58:30 --> Controller Class Initialized
ERROR - 2013-08-29 05:58:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:58:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:58:30 --> Model Class Initialized
DEBUG - 2013-08-29 05:58:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:58:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:58:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:58:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:58:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:58:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:58:30 --> Form Validation Class Initialized
DEBUG - 2013-08-29 05:58:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 05:58:31 --> Config Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:58:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:58:31 --> URI Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Router Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Output Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Security Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Input Class Initialized
DEBUG - 2013-08-29 05:58:31 --> XSS Filtering completed
DEBUG - 2013-08-29 05:58:31 --> XSS Filtering completed
DEBUG - 2013-08-29 05:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 05:58:31 --> Language Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Loader Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Helper loaded: url_helper
DEBUG - 2013-08-29 05:58:31 --> Helper loaded: file_helper
DEBUG - 2013-08-29 05:58:31 --> Helper loaded: form_helper
DEBUG - 2013-08-29 05:58:31 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 05:58:31 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 05:58:31 --> Database Driver Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Session Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Helper loaded: string_helper
DEBUG - 2013-08-29 05:58:31 --> Session routines successfully run
DEBUG - 2013-08-29 05:58:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Controller Class Initialized
ERROR - 2013-08-29 05:58:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:58:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:58:31 --> Model Class Initialized
DEBUG - 2013-08-29 05:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 05:58:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 05:58:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 05:58:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 05:58:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 05:58:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 05:58:34 --> Pagination Class Initialized
DEBUG - 2013-08-29 05:58:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 05:58:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 05:58:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 05:58:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 05:58:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 05:58:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 05:58:35 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-29 05:58:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 05:58:35 --> Final output sent to browser
DEBUG - 2013-08-29 05:58:35 --> Total execution time: 4.1262
DEBUG - 2013-08-29 05:58:35 --> Config Class Initialized
DEBUG - 2013-08-29 05:58:35 --> Hooks Class Initialized
DEBUG - 2013-08-29 05:58:35 --> Utf8 Class Initialized
DEBUG - 2013-08-29 05:58:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 05:58:35 --> URI Class Initialized
DEBUG - 2013-08-29 05:58:35 --> Router Class Initialized
ERROR - 2013-08-29 05:58:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 06:32:41 --> Config Class Initialized
DEBUG - 2013-08-29 06:32:41 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:32:41 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:32:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:32:41 --> URI Class Initialized
DEBUG - 2013-08-29 06:32:41 --> Router Class Initialized
DEBUG - 2013-08-29 06:32:41 --> Output Class Initialized
DEBUG - 2013-08-29 06:32:41 --> Security Class Initialized
DEBUG - 2013-08-29 06:32:41 --> Input Class Initialized
DEBUG - 2013-08-29 06:32:41 --> XSS Filtering completed
DEBUG - 2013-08-29 06:32:41 --> XSS Filtering completed
DEBUG - 2013-08-29 06:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:32:41 --> Language Class Initialized
DEBUG - 2013-08-29 06:32:41 --> Loader Class Initialized
DEBUG - 2013-08-29 06:32:42 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:32:42 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:32:42 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:32:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:32:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:32:42 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:32:42 --> Session Class Initialized
DEBUG - 2013-08-29 06:32:42 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:32:43 --> Session routines successfully run
DEBUG - 2013-08-29 06:32:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:32:43 --> Controller Class Initialized
ERROR - 2013-08-29 06:32:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:32:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:32:43 --> Model Class Initialized
DEBUG - 2013-08-29 06:32:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:32:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:32:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:32:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:32:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:32:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:32:44 --> Pagination Class Initialized
DEBUG - 2013-08-29 06:32:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 06:32:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 06:32:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 06:32:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 06:32:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 06:32:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 06:32:44 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-29 06:32:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 06:32:44 --> Final output sent to browser
DEBUG - 2013-08-29 06:32:44 --> Total execution time: 3.6102
DEBUG - 2013-08-29 06:32:44 --> Config Class Initialized
DEBUG - 2013-08-29 06:32:44 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:32:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:32:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:32:44 --> URI Class Initialized
DEBUG - 2013-08-29 06:32:44 --> Router Class Initialized
ERROR - 2013-08-29 06:32:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 06:32:58 --> Config Class Initialized
DEBUG - 2013-08-29 06:32:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:32:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:32:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:32:58 --> URI Class Initialized
DEBUG - 2013-08-29 06:32:58 --> Router Class Initialized
DEBUG - 2013-08-29 06:32:58 --> Output Class Initialized
DEBUG - 2013-08-29 06:32:58 --> Security Class Initialized
DEBUG - 2013-08-29 06:32:58 --> Input Class Initialized
DEBUG - 2013-08-29 06:32:58 --> XSS Filtering completed
DEBUG - 2013-08-29 06:32:59 --> XSS Filtering completed
DEBUG - 2013-08-29 06:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:32:59 --> Language Class Initialized
DEBUG - 2013-08-29 06:32:59 --> Loader Class Initialized
DEBUG - 2013-08-29 06:32:59 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:32:59 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:32:59 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:32:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:32:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:32:59 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:32:59 --> Session Class Initialized
DEBUG - 2013-08-29 06:32:59 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:32:59 --> Session routines successfully run
DEBUG - 2013-08-29 06:32:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:32:59 --> Controller Class Initialized
ERROR - 2013-08-29 06:32:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:32:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:32:59 --> Model Class Initialized
DEBUG - 2013-08-29 06:32:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:32:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:32:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:32:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:32:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:32:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:32:59 --> Pagination Class Initialized
DEBUG - 2013-08-29 06:32:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 06:32:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 06:32:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 06:32:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 06:32:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 06:32:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 06:32:59 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 06:32:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 06:32:59 --> Final output sent to browser
DEBUG - 2013-08-29 06:32:59 --> Total execution time: 1.1011
DEBUG - 2013-08-29 06:33:00 --> Config Class Initialized
DEBUG - 2013-08-29 06:33:00 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:33:00 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:33:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:33:00 --> URI Class Initialized
DEBUG - 2013-08-29 06:33:00 --> Router Class Initialized
ERROR - 2013-08-29 06:33:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 06:33:03 --> Config Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:33:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:33:03 --> URI Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Router Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Output Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Security Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Input Class Initialized
DEBUG - 2013-08-29 06:33:03 --> XSS Filtering completed
DEBUG - 2013-08-29 06:33:03 --> XSS Filtering completed
DEBUG - 2013-08-29 06:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:33:03 --> Language Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Loader Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:33:03 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:33:03 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:33:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:33:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:33:03 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Session Class Initialized
DEBUG - 2013-08-29 06:33:03 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:33:04 --> Session routines successfully run
DEBUG - 2013-08-29 06:33:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:33:04 --> Controller Class Initialized
ERROR - 2013-08-29 06:33:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:33:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:33:04 --> Model Class Initialized
DEBUG - 2013-08-29 06:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:33:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:33:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:33:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:33:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:33:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:33:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 06:33:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 06:33:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 06:33:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 06:33:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 06:33:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 06:33:04 --> File loaded: application/views/group_privileges/new.php
DEBUG - 2013-08-29 06:33:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 06:33:43 --> Config Class Initialized
DEBUG - 2013-08-29 06:33:43 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:33:43 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:33:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:33:43 --> URI Class Initialized
DEBUG - 2013-08-29 06:33:43 --> Router Class Initialized
DEBUG - 2013-08-29 06:33:43 --> Output Class Initialized
DEBUG - 2013-08-29 06:33:43 --> Security Class Initialized
DEBUG - 2013-08-29 06:33:43 --> Input Class Initialized
DEBUG - 2013-08-29 06:33:43 --> XSS Filtering completed
DEBUG - 2013-08-29 06:33:43 --> XSS Filtering completed
DEBUG - 2013-08-29 06:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:33:43 --> Language Class Initialized
DEBUG - 2013-08-29 06:33:43 --> Loader Class Initialized
DEBUG - 2013-08-29 06:33:43 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:33:43 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:33:43 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:33:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:33:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:33:44 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:33:44 --> Session Class Initialized
DEBUG - 2013-08-29 06:33:44 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:33:44 --> Session routines successfully run
DEBUG - 2013-08-29 06:33:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:33:44 --> Controller Class Initialized
ERROR - 2013-08-29 06:33:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:33:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:33:44 --> Model Class Initialized
DEBUG - 2013-08-29 06:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:33:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:33:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:33:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:33:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:33:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:33:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 06:33:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 06:33:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 06:33:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 06:33:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 06:33:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 06:33:48 --> File loaded: application/views/group_privileges/new.php
DEBUG - 2013-08-29 06:33:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 06:33:49 --> Final output sent to browser
DEBUG - 2013-08-29 06:33:49 --> Total execution time: 5.8073
DEBUG - 2013-08-29 06:33:49 --> Config Class Initialized
DEBUG - 2013-08-29 06:33:50 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:33:50 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:33:50 --> URI Class Initialized
DEBUG - 2013-08-29 06:33:50 --> Router Class Initialized
ERROR - 2013-08-29 06:33:50 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 06:34:42 --> Config Class Initialized
DEBUG - 2013-08-29 06:34:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:34:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:34:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:34:42 --> URI Class Initialized
DEBUG - 2013-08-29 06:34:42 --> Router Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Output Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Security Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Input Class Initialized
DEBUG - 2013-08-29 06:34:43 --> XSS Filtering completed
DEBUG - 2013-08-29 06:34:43 --> XSS Filtering completed
DEBUG - 2013-08-29 06:34:43 --> XSS Filtering completed
DEBUG - 2013-08-29 06:34:43 --> XSS Filtering completed
DEBUG - 2013-08-29 06:34:43 --> XSS Filtering completed
DEBUG - 2013-08-29 06:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:34:43 --> Language Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Loader Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:34:43 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:34:43 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:34:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:34:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:34:43 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Session Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:34:43 --> Session routines successfully run
DEBUG - 2013-08-29 06:34:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Controller Class Initialized
ERROR - 2013-08-29 06:34:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:34:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:34:43 --> Model Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:34:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:34:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:34:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:34:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:34:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:34:43 --> Form Validation Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 06:34:43 --> Config Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:34:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:34:43 --> URI Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Router Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Output Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Security Class Initialized
DEBUG - 2013-08-29 06:34:43 --> Input Class Initialized
DEBUG - 2013-08-29 06:34:43 --> XSS Filtering completed
DEBUG - 2013-08-29 06:34:44 --> XSS Filtering completed
DEBUG - 2013-08-29 06:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:34:44 --> Language Class Initialized
DEBUG - 2013-08-29 06:34:44 --> Loader Class Initialized
DEBUG - 2013-08-29 06:34:44 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:34:44 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:34:44 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:34:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:34:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:34:44 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:34:44 --> Session Class Initialized
DEBUG - 2013-08-29 06:34:44 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:34:44 --> Session routines successfully run
DEBUG - 2013-08-29 06:34:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:34:44 --> Controller Class Initialized
ERROR - 2013-08-29 06:34:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:34:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:34:44 --> Model Class Initialized
DEBUG - 2013-08-29 06:34:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:34:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:34:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:34:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:34:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:34:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:34:44 --> Pagination Class Initialized
DEBUG - 2013-08-29 06:34:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 06:34:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 06:34:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 06:34:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 06:34:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 06:34:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 06:34:44 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 06:34:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 06:34:44 --> Final output sent to browser
DEBUG - 2013-08-29 06:34:44 --> Total execution time: 1.0631
DEBUG - 2013-08-29 06:34:45 --> Config Class Initialized
DEBUG - 2013-08-29 06:34:45 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:34:45 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:34:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:34:45 --> URI Class Initialized
DEBUG - 2013-08-29 06:34:45 --> Router Class Initialized
ERROR - 2013-08-29 06:34:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 06:53:49 --> Config Class Initialized
DEBUG - 2013-08-29 06:53:50 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:53:50 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:53:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:53:50 --> URI Class Initialized
DEBUG - 2013-08-29 06:53:51 --> Router Class Initialized
DEBUG - 2013-08-29 06:53:51 --> No URI present. Default controller set.
DEBUG - 2013-08-29 06:53:51 --> Output Class Initialized
DEBUG - 2013-08-29 06:53:51 --> Security Class Initialized
DEBUG - 2013-08-29 06:53:51 --> Input Class Initialized
DEBUG - 2013-08-29 06:53:51 --> XSS Filtering completed
DEBUG - 2013-08-29 06:53:51 --> XSS Filtering completed
DEBUG - 2013-08-29 06:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:53:51 --> Language Class Initialized
DEBUG - 2013-08-29 06:53:51 --> Loader Class Initialized
DEBUG - 2013-08-29 06:53:51 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:53:51 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:53:51 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:53:51 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:53:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:53:51 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:53:51 --> Session Class Initialized
DEBUG - 2013-08-29 06:53:52 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:53:52 --> Session routines successfully run
DEBUG - 2013-08-29 06:53:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:53:52 --> Controller Class Initialized
ERROR - 2013-08-29 06:53:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:53:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:53:52 --> Model Class Initialized
DEBUG - 2013-08-29 06:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:53:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:53:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:53:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:53:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:53:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:53:52 --> Model Class Initialized
DEBUG - 2013-08-29 06:53:53 --> DB Transaction Failure
ERROR - 2013-08-29 06:53:53 --> Query error: Table 'school.users' doesn't exist
DEBUG - 2013-08-29 06:53:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 06:54:13 --> Config Class Initialized
DEBUG - 2013-08-29 06:54:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:54:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:54:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:54:13 --> URI Class Initialized
DEBUG - 2013-08-29 06:54:13 --> Router Class Initialized
DEBUG - 2013-08-29 06:54:13 --> No URI present. Default controller set.
DEBUG - 2013-08-29 06:54:13 --> Output Class Initialized
DEBUG - 2013-08-29 06:54:13 --> Security Class Initialized
DEBUG - 2013-08-29 06:54:13 --> Input Class Initialized
DEBUG - 2013-08-29 06:54:13 --> XSS Filtering completed
DEBUG - 2013-08-29 06:54:13 --> XSS Filtering completed
DEBUG - 2013-08-29 06:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:54:13 --> Language Class Initialized
DEBUG - 2013-08-29 06:54:13 --> Loader Class Initialized
DEBUG - 2013-08-29 06:54:13 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:54:13 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:54:13 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:54:13 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:54:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:54:14 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:54:14 --> Session Class Initialized
DEBUG - 2013-08-29 06:54:14 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:54:14 --> Session routines successfully run
DEBUG - 2013-08-29 06:54:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:54:14 --> Controller Class Initialized
ERROR - 2013-08-29 06:54:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:54:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:54:14 --> Model Class Initialized
DEBUG - 2013-08-29 06:54:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:54:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:54:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:54:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:54:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:54:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:54:16 --> Model Class Initialized
DEBUG - 2013-08-29 06:54:16 --> DB Transaction Failure
ERROR - 2013-08-29 06:54:16 --> Query error: Unknown column 'user_id' in 'where clause'
DEBUG - 2013-08-29 06:54:16 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 06:54:44 --> Config Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:54:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:54:44 --> URI Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Router Class Initialized
DEBUG - 2013-08-29 06:54:44 --> No URI present. Default controller set.
DEBUG - 2013-08-29 06:54:44 --> Output Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Security Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Input Class Initialized
DEBUG - 2013-08-29 06:54:44 --> XSS Filtering completed
DEBUG - 2013-08-29 06:54:44 --> XSS Filtering completed
DEBUG - 2013-08-29 06:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:54:44 --> Language Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Loader Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:54:44 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:54:44 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:54:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:54:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:54:44 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Session Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:54:44 --> Session routines successfully run
DEBUG - 2013-08-29 06:54:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:54:44 --> Controller Class Initialized
ERROR - 2013-08-29 06:54:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:54:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:54:45 --> Model Class Initialized
DEBUG - 2013-08-29 06:54:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:54:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:54:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:54:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:54:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:54:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:54:50 --> Model Class Initialized
DEBUG - 2013-08-29 06:54:50 --> DB Transaction Failure
ERROR - 2013-08-29 06:54:50 --> Query error: Unknown column 'users.user_id' in 'on clause'
DEBUG - 2013-08-29 06:54:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 06:55:09 --> Config Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:55:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:55:09 --> URI Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Router Class Initialized
DEBUG - 2013-08-29 06:55:09 --> No URI present. Default controller set.
DEBUG - 2013-08-29 06:55:09 --> Output Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Security Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Input Class Initialized
DEBUG - 2013-08-29 06:55:09 --> XSS Filtering completed
DEBUG - 2013-08-29 06:55:09 --> XSS Filtering completed
DEBUG - 2013-08-29 06:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:55:09 --> Language Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Loader Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:55:09 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:55:09 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:55:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:55:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:55:09 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Session Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:55:09 --> Session routines successfully run
DEBUG - 2013-08-29 06:55:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Controller Class Initialized
ERROR - 2013-08-29 06:55:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:55:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:55:09 --> Model Class Initialized
DEBUG - 2013-08-29 06:55:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:55:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:55:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:55:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:55:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:55:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:55:16 --> Model Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Config Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:56:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:56:48 --> URI Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Router Class Initialized
DEBUG - 2013-08-29 06:56:48 --> No URI present. Default controller set.
DEBUG - 2013-08-29 06:56:48 --> Output Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Security Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Input Class Initialized
DEBUG - 2013-08-29 06:56:48 --> XSS Filtering completed
DEBUG - 2013-08-29 06:56:48 --> XSS Filtering completed
DEBUG - 2013-08-29 06:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:56:48 --> Language Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Loader Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:56:48 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:56:48 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:56:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:56:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:56:48 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Session Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:56:48 --> Session routines successfully run
DEBUG - 2013-08-29 06:56:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Controller Class Initialized
ERROR - 2013-08-29 06:56:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:56:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:56:48 --> Model Class Initialized
DEBUG - 2013-08-29 06:56:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:56:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:56:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:56:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:56:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:56:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:56:49 --> Model Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Config Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:56:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:56:56 --> URI Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Router Class Initialized
DEBUG - 2013-08-29 06:56:56 --> No URI present. Default controller set.
DEBUG - 2013-08-29 06:56:56 --> Output Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Security Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Input Class Initialized
DEBUG - 2013-08-29 06:56:56 --> XSS Filtering completed
DEBUG - 2013-08-29 06:56:56 --> XSS Filtering completed
DEBUG - 2013-08-29 06:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:56:56 --> Language Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Loader Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:56:56 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:56:56 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:56:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:56:56 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:56:56 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Session Class Initialized
DEBUG - 2013-08-29 06:56:56 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:56:56 --> Session routines successfully run
DEBUG - 2013-08-29 06:56:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Controller Class Initialized
ERROR - 2013-08-29 06:56:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:56:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:56:57 --> Model Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:56:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:56:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:56:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:56:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:56:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:56:57 --> Model Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Config Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Hooks Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Utf8 Class Initialized
DEBUG - 2013-08-29 06:56:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 06:56:57 --> URI Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Router Class Initialized
DEBUG - 2013-08-29 06:56:57 --> No URI present. Default controller set.
DEBUG - 2013-08-29 06:56:57 --> Output Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Security Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Input Class Initialized
DEBUG - 2013-08-29 06:56:57 --> XSS Filtering completed
DEBUG - 2013-08-29 06:56:57 --> XSS Filtering completed
DEBUG - 2013-08-29 06:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 06:56:57 --> Language Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Loader Class Initialized
DEBUG - 2013-08-29 06:56:57 --> Helper loaded: url_helper
DEBUG - 2013-08-29 06:56:57 --> Helper loaded: file_helper
DEBUG - 2013-08-29 06:56:57 --> Helper loaded: form_helper
DEBUG - 2013-08-29 06:56:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 06:56:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 06:56:58 --> Database Driver Class Initialized
DEBUG - 2013-08-29 06:56:58 --> Session Class Initialized
DEBUG - 2013-08-29 06:57:01 --> Helper loaded: string_helper
DEBUG - 2013-08-29 06:57:01 --> Session routines successfully run
DEBUG - 2013-08-29 06:57:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 06:57:01 --> Controller Class Initialized
ERROR - 2013-08-29 06:57:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:57:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:57:01 --> Model Class Initialized
DEBUG - 2013-08-29 06:57:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 06:57:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 06:57:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 06:57:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 06:57:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 06:57:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 06:57:04 --> Model Class Initialized
DEBUG - 2013-08-29 07:19:29 --> Config Class Initialized
DEBUG - 2013-08-29 07:19:29 --> Hooks Class Initialized
DEBUG - 2013-08-29 07:19:29 --> Utf8 Class Initialized
DEBUG - 2013-08-29 07:19:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 07:19:29 --> URI Class Initialized
DEBUG - 2013-08-29 07:19:29 --> Router Class Initialized
DEBUG - 2013-08-29 07:19:29 --> No URI present. Default controller set.
DEBUG - 2013-08-29 07:19:29 --> Output Class Initialized
DEBUG - 2013-08-29 07:19:29 --> Security Class Initialized
DEBUG - 2013-08-29 07:19:29 --> Input Class Initialized
DEBUG - 2013-08-29 07:19:29 --> XSS Filtering completed
DEBUG - 2013-08-29 07:19:29 --> XSS Filtering completed
DEBUG - 2013-08-29 07:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 07:19:29 --> Language Class Initialized
DEBUG - 2013-08-29 07:19:29 --> Loader Class Initialized
DEBUG - 2013-08-29 07:19:29 --> Helper loaded: url_helper
DEBUG - 2013-08-29 07:19:30 --> Helper loaded: file_helper
DEBUG - 2013-08-29 07:19:30 --> Helper loaded: form_helper
DEBUG - 2013-08-29 07:19:30 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 07:19:30 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 07:19:30 --> Database Driver Class Initialized
DEBUG - 2013-08-29 07:19:31 --> Session Class Initialized
DEBUG - 2013-08-29 07:19:31 --> Helper loaded: string_helper
DEBUG - 2013-08-29 07:19:31 --> Session routines successfully run
DEBUG - 2013-08-29 07:19:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 07:19:31 --> Controller Class Initialized
ERROR - 2013-08-29 07:19:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 07:19:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 07:19:31 --> Model Class Initialized
DEBUG - 2013-08-29 07:19:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 07:19:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 07:19:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 07:19:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 07:19:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 07:19:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 07:19:31 --> Model Class Initialized
DEBUG - 2013-08-29 07:34:17 --> Config Class Initialized
DEBUG - 2013-08-29 07:34:17 --> Hooks Class Initialized
DEBUG - 2013-08-29 07:34:17 --> Utf8 Class Initialized
DEBUG - 2013-08-29 07:34:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 07:34:17 --> URI Class Initialized
DEBUG - 2013-08-29 07:34:17 --> Router Class Initialized
DEBUG - 2013-08-29 07:34:17 --> No URI present. Default controller set.
DEBUG - 2013-08-29 07:34:17 --> Output Class Initialized
DEBUG - 2013-08-29 07:34:17 --> Security Class Initialized
DEBUG - 2013-08-29 07:34:17 --> Input Class Initialized
DEBUG - 2013-08-29 07:34:17 --> XSS Filtering completed
DEBUG - 2013-08-29 07:34:17 --> XSS Filtering completed
DEBUG - 2013-08-29 07:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 07:34:17 --> Language Class Initialized
DEBUG - 2013-08-29 07:34:17 --> Loader Class Initialized
DEBUG - 2013-08-29 07:34:18 --> Helper loaded: url_helper
DEBUG - 2013-08-29 07:34:18 --> Helper loaded: file_helper
DEBUG - 2013-08-29 07:34:18 --> Helper loaded: form_helper
DEBUG - 2013-08-29 07:34:18 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 07:34:18 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 07:34:18 --> Database Driver Class Initialized
DEBUG - 2013-08-29 07:34:18 --> Session Class Initialized
DEBUG - 2013-08-29 07:34:18 --> Helper loaded: string_helper
DEBUG - 2013-08-29 07:34:18 --> Session routines successfully run
DEBUG - 2013-08-29 07:34:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 07:34:18 --> Controller Class Initialized
ERROR - 2013-08-29 07:34:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 07:34:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 07:34:19 --> Model Class Initialized
DEBUG - 2013-08-29 07:34:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 07:34:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 07:34:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 07:34:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 07:34:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 07:34:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 07:34:19 --> Model Class Initialized
ERROR - 2013-08-29 07:34:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\application\controllers\welcome.php 38
DEBUG - 2013-08-29 07:34:41 --> Config Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 07:34:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 07:34:42 --> URI Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Router Class Initialized
DEBUG - 2013-08-29 07:34:42 --> No URI present. Default controller set.
DEBUG - 2013-08-29 07:34:42 --> Output Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Security Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Input Class Initialized
DEBUG - 2013-08-29 07:34:42 --> XSS Filtering completed
DEBUG - 2013-08-29 07:34:42 --> XSS Filtering completed
DEBUG - 2013-08-29 07:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 07:34:42 --> Language Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Loader Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Helper loaded: url_helper
DEBUG - 2013-08-29 07:34:42 --> Helper loaded: file_helper
DEBUG - 2013-08-29 07:34:42 --> Helper loaded: form_helper
DEBUG - 2013-08-29 07:34:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 07:34:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 07:34:42 --> Database Driver Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Session Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Helper loaded: string_helper
DEBUG - 2013-08-29 07:34:42 --> Session routines successfully run
DEBUG - 2013-08-29 07:34:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Controller Class Initialized
ERROR - 2013-08-29 07:34:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 07:34:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 07:34:42 --> Model Class Initialized
DEBUG - 2013-08-29 07:34:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 07:34:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 07:34:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 07:34:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 07:34:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 07:34:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 07:34:42 --> Model Class Initialized
ERROR - 2013-08-29 07:34:42 --> Severity: Warning  --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\school\application\controllers\welcome.php 38
DEBUG - 2013-08-29 07:50:34 --> Config Class Initialized
DEBUG - 2013-08-29 07:50:34 --> Hooks Class Initialized
DEBUG - 2013-08-29 07:50:34 --> Utf8 Class Initialized
DEBUG - 2013-08-29 07:50:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 07:50:34 --> URI Class Initialized
DEBUG - 2013-08-29 07:50:34 --> Router Class Initialized
DEBUG - 2013-08-29 07:50:34 --> No URI present. Default controller set.
DEBUG - 2013-08-29 07:50:34 --> Output Class Initialized
DEBUG - 2013-08-29 07:50:34 --> Security Class Initialized
DEBUG - 2013-08-29 07:50:34 --> Input Class Initialized
DEBUG - 2013-08-29 07:50:34 --> XSS Filtering completed
DEBUG - 2013-08-29 07:50:34 --> XSS Filtering completed
DEBUG - 2013-08-29 07:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 07:50:34 --> Language Class Initialized
DEBUG - 2013-08-29 07:50:34 --> Loader Class Initialized
DEBUG - 2013-08-29 07:50:34 --> Helper loaded: url_helper
DEBUG - 2013-08-29 07:50:34 --> Helper loaded: file_helper
DEBUG - 2013-08-29 07:50:35 --> Helper loaded: form_helper
DEBUG - 2013-08-29 07:50:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 07:50:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 07:50:35 --> Database Driver Class Initialized
DEBUG - 2013-08-29 07:50:35 --> Session Class Initialized
DEBUG - 2013-08-29 07:50:35 --> Helper loaded: string_helper
DEBUG - 2013-08-29 07:50:35 --> Session routines successfully run
DEBUG - 2013-08-29 07:50:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 07:50:35 --> Controller Class Initialized
ERROR - 2013-08-29 07:50:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 07:50:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 07:50:35 --> Model Class Initialized
DEBUG - 2013-08-29 07:50:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 07:50:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 07:50:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 07:50:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 07:50:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 07:50:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 07:50:36 --> Model Class Initialized
DEBUG - 2013-08-29 08:37:37 --> Config Class Initialized
DEBUG - 2013-08-29 08:37:37 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:37:37 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:37:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:37:37 --> URI Class Initialized
DEBUG - 2013-08-29 08:37:37 --> Router Class Initialized
DEBUG - 2013-08-29 08:37:37 --> No URI present. Default controller set.
DEBUG - 2013-08-29 08:37:37 --> Output Class Initialized
DEBUG - 2013-08-29 08:37:37 --> Security Class Initialized
DEBUG - 2013-08-29 08:37:38 --> Input Class Initialized
DEBUG - 2013-08-29 08:37:38 --> XSS Filtering completed
DEBUG - 2013-08-29 08:37:38 --> XSS Filtering completed
DEBUG - 2013-08-29 08:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:37:38 --> Language Class Initialized
DEBUG - 2013-08-29 08:37:38 --> Loader Class Initialized
DEBUG - 2013-08-29 08:37:38 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:37:38 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:37:38 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:37:38 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:37:38 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:37:39 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:37:39 --> Session Class Initialized
DEBUG - 2013-08-29 08:37:39 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:37:39 --> Session routines successfully run
DEBUG - 2013-08-29 08:37:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:37:39 --> Controller Class Initialized
ERROR - 2013-08-29 08:37:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:37:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:37:39 --> Model Class Initialized
DEBUG - 2013-08-29 08:37:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:37:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:37:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:37:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:37:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:37:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:37:40 --> Severity: Notice  --> Undefined property: Welcome::$user_model C:\xampp\htdocs\school\application\core\MY_application_controller.php 37
DEBUG - 2013-08-29 08:38:13 --> Config Class Initialized
DEBUG - 2013-08-29 08:38:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:38:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:38:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:38:14 --> URI Class Initialized
DEBUG - 2013-08-29 08:38:14 --> Router Class Initialized
DEBUG - 2013-08-29 08:38:14 --> No URI present. Default controller set.
DEBUG - 2013-08-29 08:38:14 --> Output Class Initialized
DEBUG - 2013-08-29 08:38:14 --> Security Class Initialized
DEBUG - 2013-08-29 08:38:14 --> Input Class Initialized
DEBUG - 2013-08-29 08:38:14 --> XSS Filtering completed
DEBUG - 2013-08-29 08:38:14 --> XSS Filtering completed
DEBUG - 2013-08-29 08:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:38:14 --> Language Class Initialized
DEBUG - 2013-08-29 08:38:14 --> Loader Class Initialized
DEBUG - 2013-08-29 08:38:14 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:38:14 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:38:14 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:38:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:38:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:38:14 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:38:14 --> Session Class Initialized
DEBUG - 2013-08-29 08:38:14 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:38:14 --> Session routines successfully run
DEBUG - 2013-08-29 08:38:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:38:14 --> Controller Class Initialized
ERROR - 2013-08-29 08:38:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:38:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:38:14 --> Model Class Initialized
DEBUG - 2013-08-29 08:38:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:38:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:38:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:38:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:38:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:38:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:38:14 --> Model Class Initialized
ERROR - 2013-08-29 08:38:14 --> Severity: Notice  --> Undefined variable: user C:\xampp\htdocs\school\application\controllers\welcome.php 19
DEBUG - 2013-08-29 08:38:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 08:38:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 08:38:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 08:38:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 08:38:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 08:38:15 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 08:38:15 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\school\application\views\home.php 3
DEBUG - 2013-08-29 08:38:15 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 08:38:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 08:38:15 --> Final output sent to browser
DEBUG - 2013-08-29 08:38:15 --> Total execution time: 1.3781
DEBUG - 2013-08-29 08:38:15 --> Config Class Initialized
DEBUG - 2013-08-29 08:38:15 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:38:15 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:38:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:38:15 --> URI Class Initialized
DEBUG - 2013-08-29 08:38:15 --> Router Class Initialized
ERROR - 2013-08-29 08:38:15 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 08:40:09 --> Config Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:40:09 --> URI Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Router Class Initialized
DEBUG - 2013-08-29 08:40:09 --> No URI present. Default controller set.
DEBUG - 2013-08-29 08:40:09 --> Output Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Security Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Input Class Initialized
DEBUG - 2013-08-29 08:40:09 --> XSS Filtering completed
DEBUG - 2013-08-29 08:40:09 --> XSS Filtering completed
DEBUG - 2013-08-29 08:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:40:09 --> Language Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Loader Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:40:09 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:40:09 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:40:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:40:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:40:09 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Session Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:40:09 --> Session routines successfully run
DEBUG - 2013-08-29 08:40:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:40:09 --> Controller Class Initialized
ERROR - 2013-08-29 08:40:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:40:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:40:10 --> Model Class Initialized
DEBUG - 2013-08-29 08:40:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:40:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:40:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:40:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:40:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:40:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:40:10 --> Model Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Config Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:40:31 --> URI Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Router Class Initialized
DEBUG - 2013-08-29 08:40:31 --> No URI present. Default controller set.
DEBUG - 2013-08-29 08:40:31 --> Output Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Security Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Input Class Initialized
DEBUG - 2013-08-29 08:40:31 --> XSS Filtering completed
DEBUG - 2013-08-29 08:40:31 --> XSS Filtering completed
DEBUG - 2013-08-29 08:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:40:31 --> Language Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Loader Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:40:31 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:40:31 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:40:31 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:40:31 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:40:31 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Session Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:40:31 --> Session routines successfully run
DEBUG - 2013-08-29 08:40:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Controller Class Initialized
ERROR - 2013-08-29 08:40:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:40:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:40:31 --> Model Class Initialized
DEBUG - 2013-08-29 08:40:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:40:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:40:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:40:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:40:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:40:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:40:31 --> Model Class Initialized
DEBUG - 2013-08-29 08:40:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 08:40:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 08:40:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 08:40:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 08:40:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 08:40:31 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 08:40:31 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\school\application\views\home.php 3
DEBUG - 2013-08-29 08:40:32 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 08:40:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 08:40:32 --> Final output sent to browser
DEBUG - 2013-08-29 08:40:32 --> Total execution time: 0.9091
DEBUG - 2013-08-29 08:40:32 --> Config Class Initialized
DEBUG - 2013-08-29 08:40:32 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:40:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:40:32 --> URI Class Initialized
DEBUG - 2013-08-29 08:40:32 --> Router Class Initialized
ERROR - 2013-08-29 08:40:32 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 08:42:25 --> Config Class Initialized
DEBUG - 2013-08-29 08:42:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:42:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:42:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:42:25 --> URI Class Initialized
DEBUG - 2013-08-29 08:42:28 --> Router Class Initialized
DEBUG - 2013-08-29 08:42:28 --> No URI present. Default controller set.
DEBUG - 2013-08-29 08:42:28 --> Output Class Initialized
DEBUG - 2013-08-29 08:42:29 --> Security Class Initialized
DEBUG - 2013-08-29 08:42:29 --> Input Class Initialized
DEBUG - 2013-08-29 08:42:29 --> XSS Filtering completed
DEBUG - 2013-08-29 08:42:29 --> XSS Filtering completed
DEBUG - 2013-08-29 08:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:42:29 --> Language Class Initialized
DEBUG - 2013-08-29 08:42:29 --> Loader Class Initialized
DEBUG - 2013-08-29 08:42:29 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:42:29 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:42:29 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:42:29 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:42:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:42:29 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:42:29 --> Session Class Initialized
DEBUG - 2013-08-29 08:42:29 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:42:29 --> Session routines successfully run
DEBUG - 2013-08-29 08:42:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:42:29 --> Controller Class Initialized
ERROR - 2013-08-29 08:42:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:42:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:42:29 --> Model Class Initialized
DEBUG - 2013-08-29 08:42:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:42:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:42:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:42:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:42:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:42:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:42:30 --> Model Class Initialized
DEBUG - 2013-08-29 08:42:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 08:42:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 08:42:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 08:42:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 08:42:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 08:42:31 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 08:42:31 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 08:42:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 08:42:31 --> Final output sent to browser
DEBUG - 2013-08-29 08:42:31 --> Total execution time: 5.8873
DEBUG - 2013-08-29 08:42:31 --> Config Class Initialized
DEBUG - 2013-08-29 08:42:31 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:42:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:42:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:42:32 --> URI Class Initialized
DEBUG - 2013-08-29 08:42:32 --> Router Class Initialized
ERROR - 2013-08-29 08:42:32 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 08:42:56 --> Config Class Initialized
DEBUG - 2013-08-29 08:42:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:42:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:42:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:42:56 --> URI Class Initialized
DEBUG - 2013-08-29 08:42:56 --> Router Class Initialized
DEBUG - 2013-08-29 08:42:56 --> Output Class Initialized
DEBUG - 2013-08-29 08:42:56 --> Security Class Initialized
DEBUG - 2013-08-29 08:42:56 --> Input Class Initialized
DEBUG - 2013-08-29 08:42:56 --> XSS Filtering completed
DEBUG - 2013-08-29 08:42:56 --> XSS Filtering completed
DEBUG - 2013-08-29 08:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:42:56 --> Language Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Loader Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:42:57 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:42:57 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:42:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:42:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:42:57 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Session Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:42:57 --> Session routines successfully run
DEBUG - 2013-08-29 08:42:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Controller Class Initialized
ERROR - 2013-08-29 08:42:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:42:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:42:57 --> Model Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:42:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:42:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:42:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:42:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:42:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:42:57 --> Model Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Config Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:42:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:42:57 --> URI Class Initialized
DEBUG - 2013-08-29 08:42:57 --> Router Class Initialized
ERROR - 2013-08-29 08:42:57 --> 404 Page Not Found --> auth
DEBUG - 2013-08-29 08:44:05 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:05 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:05 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:05 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:05 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:05 --> No URI present. Default controller set.
DEBUG - 2013-08-29 08:44:05 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:05 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:05 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:05 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:05 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:05 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:05 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:05 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:05 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:05 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:05 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:05 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:05 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:08 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:08 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:08 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:12 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:12 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:12 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:12 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:12 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:12 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:12 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:12 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:12 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:12 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:12 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:14 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:14 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:14 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:14 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:14 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:14 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:14 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:14 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:14 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:14 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:14 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:14 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:14 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:15 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:15 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:15 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:15 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:15 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:15 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:15 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:15 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:15 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:15 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:15 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:15 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:16 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:16 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:16 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:16 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:16 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:16 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:16 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:16 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:16 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:16 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:16 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:16 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:16 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:17 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:17 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:17 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:17 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:17 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:17 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:17 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:17 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:17 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:17 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:17 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:17 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:17 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:17 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:17 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:18 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:18 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:18 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:18 --> Session garbage collection performed.
DEBUG - 2013-08-29 08:44:18 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:18 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:18 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:21 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:21 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:21 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:21 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:21 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:21 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:21 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:21 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:21 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:21 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:21 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:21 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:21 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:21 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:21 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:21 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:21 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:22 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:22 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:22 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:22 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:22 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:22 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:22 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:22 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:22 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:22 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:22 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:22 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:22 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:22 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:23 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:23 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:23 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:23 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:23 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:23 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:23 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:23 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:23 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:23 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:23 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:24 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:24 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:24 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:24 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:24 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:24 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:24 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:24 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:24 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:24 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:24 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:24 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:25 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:25 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:25 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:25 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:25 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:25 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:25 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:25 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:25 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:25 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:25 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:25 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:26 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:26 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:26 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:26 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:26 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:26 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:26 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:26 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:26 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:26 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:26 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:26 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:26 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:26 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:26 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:27 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:27 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:27 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:27 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:27 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:27 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:27 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:27 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:27 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:28 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:28 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:28 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:28 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:28 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:28 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:28 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:28 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:28 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:28 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:28 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:28 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:29 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:29 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:29 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:29 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:29 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:29 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:29 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:29 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:29 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:29 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:29 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:29 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:29 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:29 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:29 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:30 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:30 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:30 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:30 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:30 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:30 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:30 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:30 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:30 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:30 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:31 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:31 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:31 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:31 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:31 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:31 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:31 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:31 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:31 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:31 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:31 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:31 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:31 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:31 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:32 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:32 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:32 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:32 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:32 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:32 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:32 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:32 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:32 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:32 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:32 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:32 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:32 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:33 --> Config Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:44:33 --> URI Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Router Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Output Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Security Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Input Class Initialized
DEBUG - 2013-08-29 08:44:33 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:33 --> XSS Filtering completed
DEBUG - 2013-08-29 08:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:44:33 --> Language Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Loader Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:44:33 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:44:33 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:44:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:44:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:44:33 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Session Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:44:33 --> Session routines successfully run
DEBUG - 2013-08-29 08:44:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Controller Class Initialized
ERROR - 2013-08-29 08:44:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:44:33 --> Model Class Initialized
DEBUG - 2013-08-29 08:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:44:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:44:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:44:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:44:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:44:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:53:07 --> Config Class Initialized
DEBUG - 2013-08-29 08:53:07 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:53:07 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:53:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:53:07 --> URI Class Initialized
DEBUG - 2013-08-29 08:53:07 --> Router Class Initialized
DEBUG - 2013-08-29 08:53:07 --> No URI present. Default controller set.
DEBUG - 2013-08-29 08:53:07 --> Output Class Initialized
DEBUG - 2013-08-29 08:53:07 --> Security Class Initialized
DEBUG - 2013-08-29 08:53:07 --> Input Class Initialized
DEBUG - 2013-08-29 08:53:07 --> XSS Filtering completed
DEBUG - 2013-08-29 08:53:07 --> XSS Filtering completed
DEBUG - 2013-08-29 08:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:53:07 --> Language Class Initialized
DEBUG - 2013-08-29 08:53:07 --> Loader Class Initialized
DEBUG - 2013-08-29 08:53:07 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:53:07 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:53:07 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:53:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:53:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:53:08 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:53:08 --> Session Class Initialized
DEBUG - 2013-08-29 08:53:08 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:53:08 --> Session routines successfully run
DEBUG - 2013-08-29 08:53:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:53:08 --> Controller Class Initialized
ERROR - 2013-08-29 08:53:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:53:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:53:08 --> Model Class Initialized
DEBUG - 2013-08-29 08:53:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:53:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:53:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:53:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:53:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:53:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:53:09 --> Config Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:53:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:53:09 --> URI Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Router Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Output Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Security Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Input Class Initialized
DEBUG - 2013-08-29 08:53:09 --> XSS Filtering completed
DEBUG - 2013-08-29 08:53:09 --> XSS Filtering completed
DEBUG - 2013-08-29 08:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:53:09 --> Language Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Loader Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:53:09 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:53:09 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:53:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:53:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:53:09 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Session Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:53:09 --> Session routines successfully run
DEBUG - 2013-08-29 08:53:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:53:09 --> Controller Class Initialized
ERROR - 2013-08-29 08:53:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:53:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:53:10 --> Model Class Initialized
DEBUG - 2013-08-29 08:53:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:53:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:53:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:53:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:53:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:53:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:53:10 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\head.php 9
ERROR - 2013-08-29 08:53:10 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\head.php 10
ERROR - 2013-08-29 08:53:10 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\head.php 11
ERROR - 2013-08-29 08:53:10 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\head.php 12
ERROR - 2013-08-29 08:53:10 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\head.php 13
DEBUG - 2013-08-29 08:53:10 --> File loaded: application/views/shared/head.php
ERROR - 2013-08-29 08:53:10 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\scripts.php 2
ERROR - 2013-08-29 08:53:11 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\scripts.php 3
ERROR - 2013-08-29 08:53:11 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\scripts.php 4
ERROR - 2013-08-29 08:53:11 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\scripts.php 5
ERROR - 2013-08-29 08:53:11 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\scripts.php 6
ERROR - 2013-08-29 08:53:11 --> Severity: Notice  --> Undefined variable: includes_dir C:\xampp\htdocs\school\application\views\shared\scripts.php 7
DEBUG - 2013-08-29 08:53:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 08:53:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 08:53:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 08:53:11 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 08:53:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 08:53:11 --> Final output sent to browser
DEBUG - 2013-08-29 08:53:11 --> Total execution time: 2.0621
DEBUG - 2013-08-29 08:53:54 --> Config Class Initialized
DEBUG - 2013-08-29 08:53:54 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:53:54 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:53:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:53:54 --> URI Class Initialized
DEBUG - 2013-08-29 08:53:54 --> Router Class Initialized
DEBUG - 2013-08-29 08:53:54 --> Output Class Initialized
DEBUG - 2013-08-29 08:53:54 --> Security Class Initialized
DEBUG - 2013-08-29 08:53:54 --> Input Class Initialized
DEBUG - 2013-08-29 08:53:55 --> XSS Filtering completed
DEBUG - 2013-08-29 08:53:55 --> XSS Filtering completed
DEBUG - 2013-08-29 08:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:53:55 --> Language Class Initialized
DEBUG - 2013-08-29 08:53:55 --> Loader Class Initialized
DEBUG - 2013-08-29 08:53:55 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:53:55 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:53:55 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:53:55 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:53:55 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:53:55 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:53:55 --> Session Class Initialized
DEBUG - 2013-08-29 08:53:55 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:54:03 --> Session garbage collection performed.
DEBUG - 2013-08-29 08:54:03 --> Session routines successfully run
DEBUG - 2013-08-29 08:54:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:54:03 --> Controller Class Initialized
ERROR - 2013-08-29 08:54:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:54:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:54:03 --> Model Class Initialized
DEBUG - 2013-08-29 08:54:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:54:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:54:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:54:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:54:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:54:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:54:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 08:54:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 08:54:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 08:54:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 08:54:04 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 08:54:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 08:54:04 --> Final output sent to browser
DEBUG - 2013-08-29 08:54:04 --> Total execution time: 9.2735
DEBUG - 2013-08-29 08:54:11 --> Config Class Initialized
DEBUG - 2013-08-29 08:54:11 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:54:11 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:54:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:54:11 --> URI Class Initialized
DEBUG - 2013-08-29 08:54:11 --> Router Class Initialized
ERROR - 2013-08-29 08:54:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 08:54:25 --> Config Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:54:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:54:25 --> URI Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Router Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Output Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Security Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Input Class Initialized
DEBUG - 2013-08-29 08:54:25 --> XSS Filtering completed
DEBUG - 2013-08-29 08:54:25 --> XSS Filtering completed
DEBUG - 2013-08-29 08:54:25 --> XSS Filtering completed
DEBUG - 2013-08-29 08:54:25 --> XSS Filtering completed
DEBUG - 2013-08-29 08:54:25 --> XSS Filtering completed
DEBUG - 2013-08-29 08:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:54:25 --> Language Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Loader Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:54:25 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:54:25 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:54:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:54:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:54:25 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Session Class Initialized
DEBUG - 2013-08-29 08:54:25 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:54:26 --> Session routines successfully run
DEBUG - 2013-08-29 08:54:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:54:26 --> Controller Class Initialized
ERROR - 2013-08-29 08:54:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:54:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:54:26 --> Model Class Initialized
DEBUG - 2013-08-29 08:54:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:54:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:54:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:54:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:54:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:54:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:54:26 --> Model Class Initialized
DEBUG - 2013-08-29 08:54:26 --> Form Validation Class Initialized
DEBUG - 2013-08-29 08:54:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 08:54:27 --> Config Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:54:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:54:27 --> URI Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Router Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Output Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Security Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Input Class Initialized
DEBUG - 2013-08-29 08:54:27 --> XSS Filtering completed
DEBUG - 2013-08-29 08:54:27 --> XSS Filtering completed
DEBUG - 2013-08-29 08:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:54:27 --> Language Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Loader Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:54:27 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:54:27 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:54:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:54:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:54:27 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Session Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:54:27 --> Session routines successfully run
DEBUG - 2013-08-29 08:54:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Controller Class Initialized
ERROR - 2013-08-29 08:54:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:54:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:54:27 --> Model Class Initialized
DEBUG - 2013-08-29 08:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:54:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:54:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:54:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:54:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:54:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:54:28 --> Config Class Initialized
DEBUG - 2013-08-29 08:54:28 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:54:28 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:54:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:54:28 --> URI Class Initialized
DEBUG - 2013-08-29 08:54:28 --> Router Class Initialized
DEBUG - 2013-08-29 08:54:28 --> Output Class Initialized
DEBUG - 2013-08-29 08:54:28 --> Security Class Initialized
DEBUG - 2013-08-29 08:54:28 --> Input Class Initialized
DEBUG - 2013-08-29 08:54:28 --> XSS Filtering completed
DEBUG - 2013-08-29 08:54:28 --> XSS Filtering completed
DEBUG - 2013-08-29 08:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 08:54:28 --> Language Class Initialized
DEBUG - 2013-08-29 08:54:28 --> Loader Class Initialized
DEBUG - 2013-08-29 08:54:28 --> Helper loaded: url_helper
DEBUG - 2013-08-29 08:54:28 --> Helper loaded: file_helper
DEBUG - 2013-08-29 08:54:29 --> Helper loaded: form_helper
DEBUG - 2013-08-29 08:54:29 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 08:54:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 08:54:29 --> Database Driver Class Initialized
DEBUG - 2013-08-29 08:54:29 --> Session Class Initialized
DEBUG - 2013-08-29 08:54:29 --> Helper loaded: string_helper
DEBUG - 2013-08-29 08:54:29 --> Session routines successfully run
DEBUG - 2013-08-29 08:54:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 08:54:29 --> Controller Class Initialized
ERROR - 2013-08-29 08:54:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:54:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:54:29 --> Model Class Initialized
DEBUG - 2013-08-29 08:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 08:54:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 08:54:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 08:54:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 08:54:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 08:54:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 08:54:29 --> Model Class Initialized
DEBUG - 2013-08-29 08:54:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 08:54:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 08:54:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 08:54:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 08:54:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 08:54:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 08:54:30 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 08:54:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 08:54:30 --> Final output sent to browser
DEBUG - 2013-08-29 08:54:30 --> Total execution time: 2.0731
DEBUG - 2013-08-29 08:54:30 --> Config Class Initialized
DEBUG - 2013-08-29 08:54:30 --> Hooks Class Initialized
DEBUG - 2013-08-29 08:54:30 --> Utf8 Class Initialized
DEBUG - 2013-08-29 08:54:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 08:54:30 --> URI Class Initialized
DEBUG - 2013-08-29 08:54:30 --> Router Class Initialized
ERROR - 2013-08-29 08:54:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 09:36:25 --> Config Class Initialized
DEBUG - 2013-08-29 09:36:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:36:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:36:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:36:25 --> URI Class Initialized
DEBUG - 2013-08-29 09:36:25 --> Router Class Initialized
DEBUG - 2013-08-29 09:36:25 --> Output Class Initialized
DEBUG - 2013-08-29 09:36:25 --> Security Class Initialized
DEBUG - 2013-08-29 09:36:25 --> Input Class Initialized
DEBUG - 2013-08-29 09:36:25 --> XSS Filtering completed
DEBUG - 2013-08-29 09:36:25 --> XSS Filtering completed
DEBUG - 2013-08-29 09:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 09:36:25 --> Language Class Initialized
DEBUG - 2013-08-29 09:36:25 --> Loader Class Initialized
DEBUG - 2013-08-29 09:36:26 --> Helper loaded: url_helper
DEBUG - 2013-08-29 09:36:26 --> Helper loaded: file_helper
DEBUG - 2013-08-29 09:36:26 --> Helper loaded: form_helper
DEBUG - 2013-08-29 09:36:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 09:36:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 09:36:26 --> Database Driver Class Initialized
DEBUG - 2013-08-29 09:36:26 --> Session Class Initialized
DEBUG - 2013-08-29 09:36:26 --> Helper loaded: string_helper
DEBUG - 2013-08-29 09:36:26 --> Session routines successfully run
DEBUG - 2013-08-29 09:36:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 09:36:26 --> Controller Class Initialized
ERROR - 2013-08-29 09:36:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:36:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:36:26 --> Model Class Initialized
DEBUG - 2013-08-29 09:36:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 09:36:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 09:36:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 09:36:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 09:36:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:36:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:36:27 --> Model Class Initialized
ERROR - 2013-08-29 09:36:27 --> Severity: Notice  --> Use of undefined constant user_data - assumed 'user_data' C:\xampp\htdocs\school\application\core\MY_application_controller.php 33
DEBUG - 2013-08-29 09:36:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 09:36:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 09:36:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 09:36:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 09:36:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 09:36:27 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 09:36:27 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 09:36:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 09:36:27 --> Final output sent to browser
DEBUG - 2013-08-29 09:36:27 --> Total execution time: 3.4852
DEBUG - 2013-08-29 09:36:27 --> Config Class Initialized
DEBUG - 2013-08-29 09:36:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:36:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:36:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:36:27 --> URI Class Initialized
DEBUG - 2013-08-29 09:36:27 --> Router Class Initialized
ERROR - 2013-08-29 09:36:27 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 09:36:51 --> Config Class Initialized
DEBUG - 2013-08-29 09:36:51 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:36:51 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:36:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:36:51 --> URI Class Initialized
DEBUG - 2013-08-29 09:36:51 --> Router Class Initialized
DEBUG - 2013-08-29 09:36:51 --> Output Class Initialized
DEBUG - 2013-08-29 09:36:51 --> Security Class Initialized
DEBUG - 2013-08-29 09:36:51 --> Input Class Initialized
DEBUG - 2013-08-29 09:36:51 --> XSS Filtering completed
DEBUG - 2013-08-29 09:36:51 --> XSS Filtering completed
DEBUG - 2013-08-29 09:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 09:36:51 --> Language Class Initialized
DEBUG - 2013-08-29 09:36:51 --> Loader Class Initialized
DEBUG - 2013-08-29 09:36:51 --> Helper loaded: url_helper
DEBUG - 2013-08-29 09:36:51 --> Helper loaded: file_helper
DEBUG - 2013-08-29 09:36:51 --> Helper loaded: form_helper
DEBUG - 2013-08-29 09:36:51 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 09:36:52 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 09:36:52 --> Database Driver Class Initialized
DEBUG - 2013-08-29 09:36:52 --> Session Class Initialized
DEBUG - 2013-08-29 09:36:52 --> Helper loaded: string_helper
DEBUG - 2013-08-29 09:36:52 --> Session routines successfully run
DEBUG - 2013-08-29 09:36:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 09:36:52 --> Controller Class Initialized
ERROR - 2013-08-29 09:36:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:36:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:36:52 --> Model Class Initialized
DEBUG - 2013-08-29 09:36:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 09:36:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 09:36:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 09:36:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 09:36:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:36:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:36:52 --> Model Class Initialized
DEBUG - 2013-08-29 09:36:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 09:36:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 09:36:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 09:36:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 09:36:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 09:36:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 09:36:52 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 09:36:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 09:36:52 --> Final output sent to browser
DEBUG - 2013-08-29 09:36:52 --> Total execution time: 1.0781
DEBUG - 2013-08-29 09:36:52 --> Config Class Initialized
DEBUG - 2013-08-29 09:36:52 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:36:52 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:36:52 --> URI Class Initialized
DEBUG - 2013-08-29 09:36:53 --> Router Class Initialized
ERROR - 2013-08-29 09:36:53 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 09:40:13 --> Config Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:40:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:40:13 --> URI Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Router Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Output Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Security Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Input Class Initialized
DEBUG - 2013-08-29 09:40:13 --> XSS Filtering completed
DEBUG - 2013-08-29 09:40:13 --> XSS Filtering completed
DEBUG - 2013-08-29 09:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 09:40:13 --> Language Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Loader Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Helper loaded: url_helper
DEBUG - 2013-08-29 09:40:13 --> Helper loaded: file_helper
DEBUG - 2013-08-29 09:40:13 --> Helper loaded: form_helper
DEBUG - 2013-08-29 09:40:13 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 09:40:13 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 09:40:13 --> Database Driver Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Session Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Helper loaded: string_helper
DEBUG - 2013-08-29 09:40:13 --> Session routines successfully run
DEBUG - 2013-08-29 09:40:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Controller Class Initialized
ERROR - 2013-08-29 09:40:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:40:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:40:13 --> Model Class Initialized
DEBUG - 2013-08-29 09:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 09:40:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 09:40:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 09:40:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 09:40:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:40:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:40:14 --> Model Class Initialized
DEBUG - 2013-08-29 09:40:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 09:40:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 09:40:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 09:40:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 09:40:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 09:40:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 09:40:14 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 09:40:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 09:40:14 --> Final output sent to browser
DEBUG - 2013-08-29 09:40:14 --> Total execution time: 1.0911
DEBUG - 2013-08-29 09:40:14 --> Config Class Initialized
DEBUG - 2013-08-29 09:40:14 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:40:14 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:40:14 --> URI Class Initialized
DEBUG - 2013-08-29 09:40:14 --> Router Class Initialized
ERROR - 2013-08-29 09:40:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 09:42:20 --> Config Class Initialized
DEBUG - 2013-08-29 09:42:20 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:42:20 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:42:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:42:20 --> URI Class Initialized
DEBUG - 2013-08-29 09:42:20 --> Router Class Initialized
DEBUG - 2013-08-29 09:42:20 --> Output Class Initialized
DEBUG - 2013-08-29 09:42:20 --> Security Class Initialized
DEBUG - 2013-08-29 09:42:20 --> Input Class Initialized
DEBUG - 2013-08-29 09:42:20 --> XSS Filtering completed
DEBUG - 2013-08-29 09:42:20 --> XSS Filtering completed
DEBUG - 2013-08-29 09:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 09:42:20 --> Language Class Initialized
DEBUG - 2013-08-29 09:42:20 --> Loader Class Initialized
DEBUG - 2013-08-29 09:42:20 --> Helper loaded: url_helper
DEBUG - 2013-08-29 09:42:21 --> Helper loaded: file_helper
DEBUG - 2013-08-29 09:42:21 --> Helper loaded: form_helper
DEBUG - 2013-08-29 09:42:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 09:42:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 09:42:21 --> Database Driver Class Initialized
DEBUG - 2013-08-29 09:42:21 --> Session Class Initialized
DEBUG - 2013-08-29 09:42:21 --> Helper loaded: string_helper
DEBUG - 2013-08-29 09:42:21 --> Session routines successfully run
DEBUG - 2013-08-29 09:42:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 09:42:21 --> Controller Class Initialized
ERROR - 2013-08-29 09:42:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:42:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:42:21 --> Model Class Initialized
DEBUG - 2013-08-29 09:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 09:42:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 09:42:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 09:42:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 09:42:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:42:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:42:21 --> Model Class Initialized
DEBUG - 2013-08-29 09:42:21 --> Pagination Class Initialized
DEBUG - 2013-08-29 09:42:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 09:42:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 09:42:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 09:42:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 09:42:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 09:42:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 09:42:21 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-29 09:42:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 09:42:22 --> Final output sent to browser
DEBUG - 2013-08-29 09:42:22 --> Total execution time: 1.3881
DEBUG - 2013-08-29 09:42:22 --> Config Class Initialized
DEBUG - 2013-08-29 09:42:22 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:42:22 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:42:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:42:22 --> URI Class Initialized
DEBUG - 2013-08-29 09:42:22 --> Router Class Initialized
ERROR - 2013-08-29 09:42:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 09:54:27 --> Config Class Initialized
DEBUG - 2013-08-29 09:54:27 --> Config Class Initialized
DEBUG - 2013-08-29 09:54:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:54:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:54:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:54:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:54:31 --> URI Class Initialized
DEBUG - 2013-08-29 09:54:31 --> URI Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Router Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Router Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Output Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Output Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Security Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Security Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Input Class Initialized
DEBUG - 2013-08-29 09:54:31 --> Input Class Initialized
DEBUG - 2013-08-29 09:54:31 --> XSS Filtering completed
DEBUG - 2013-08-29 09:54:31 --> XSS Filtering completed
DEBUG - 2013-08-29 09:54:31 --> XSS Filtering completed
DEBUG - 2013-08-29 09:54:31 --> XSS Filtering completed
DEBUG - 2013-08-29 09:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 09:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 09:54:33 --> Language Class Initialized
DEBUG - 2013-08-29 09:54:33 --> Language Class Initialized
DEBUG - 2013-08-29 09:54:40 --> Loader Class Initialized
DEBUG - 2013-08-29 09:54:40 --> Loader Class Initialized
DEBUG - 2013-08-29 09:54:49 --> Helper loaded: url_helper
DEBUG - 2013-08-29 09:54:49 --> Helper loaded: url_helper
DEBUG - 2013-08-29 09:54:54 --> Helper loaded: file_helper
DEBUG - 2013-08-29 09:54:54 --> Helper loaded: file_helper
DEBUG - 2013-08-29 09:54:55 --> Helper loaded: form_helper
DEBUG - 2013-08-29 09:54:55 --> Helper loaded: form_helper
DEBUG - 2013-08-29 09:54:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 09:54:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 09:54:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 09:54:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 09:55:07 --> Database Driver Class Initialized
DEBUG - 2013-08-29 09:55:08 --> Database Driver Class Initialized
DEBUG - 2013-08-29 09:55:10 --> Session Class Initialized
DEBUG - 2013-08-29 09:55:10 --> Session Class Initialized
DEBUG - 2013-08-29 09:55:14 --> Helper loaded: string_helper
DEBUG - 2013-08-29 09:55:14 --> Helper loaded: string_helper
DEBUG - 2013-08-29 09:55:15 --> Session routines successfully run
DEBUG - 2013-08-29 09:55:15 --> Session routines successfully run
DEBUG - 2013-08-29 09:55:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 09:55:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 09:55:15 --> Controller Class Initialized
DEBUG - 2013-08-29 09:55:15 --> Controller Class Initialized
ERROR - 2013-08-29 09:55:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:55:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:55:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:55:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:55:22 --> Model Class Initialized
DEBUG - 2013-08-29 09:55:22 --> Model Class Initialized
DEBUG - 2013-08-29 09:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 09:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 09:55:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 09:55:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 09:55:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 09:55:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 09:55:22 --> Language file loaded: language/english/flexi_auth_lang.php
DEBUG - 2013-08-29 09:55:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 09:55:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:55:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:55:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:55:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:55:32 --> Model Class Initialized
DEBUG - 2013-08-29 09:55:32 --> Model Class Initialized
ERROR - 2013-08-29 09:55:39 --> 404 Page Not Found --> 
ERROR - 2013-08-29 09:55:39 --> 404 Page Not Found --> 
DEBUG - 2013-08-29 09:56:17 --> Config Class Initialized
DEBUG - 2013-08-29 09:56:17 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:56:17 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:56:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:56:17 --> URI Class Initialized
DEBUG - 2013-08-29 09:56:17 --> Router Class Initialized
DEBUG - 2013-08-29 09:56:17 --> Output Class Initialized
DEBUG - 2013-08-29 09:56:17 --> Security Class Initialized
DEBUG - 2013-08-29 09:56:17 --> Input Class Initialized
DEBUG - 2013-08-29 09:56:17 --> XSS Filtering completed
DEBUG - 2013-08-29 09:56:17 --> XSS Filtering completed
DEBUG - 2013-08-29 09:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 09:56:18 --> Language Class Initialized
DEBUG - 2013-08-29 09:56:18 --> Loader Class Initialized
DEBUG - 2013-08-29 09:56:18 --> Helper loaded: url_helper
DEBUG - 2013-08-29 09:56:18 --> Helper loaded: file_helper
DEBUG - 2013-08-29 09:56:18 --> Helper loaded: form_helper
DEBUG - 2013-08-29 09:56:18 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 09:56:18 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 09:56:18 --> Database Driver Class Initialized
DEBUG - 2013-08-29 09:56:18 --> Session Class Initialized
DEBUG - 2013-08-29 09:56:18 --> Helper loaded: string_helper
DEBUG - 2013-08-29 09:56:18 --> Session routines successfully run
DEBUG - 2013-08-29 09:56:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 09:56:18 --> Controller Class Initialized
ERROR - 2013-08-29 09:56:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:56:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:56:18 --> Model Class Initialized
DEBUG - 2013-08-29 09:56:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 09:56:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 09:56:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 09:56:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 09:56:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 09:56:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 09:56:19 --> Model Class Initialized
DEBUG - 2013-08-29 09:56:19 --> Pagination Class Initialized
DEBUG - 2013-08-29 09:56:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 09:56:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 09:56:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 09:56:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 09:56:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 09:56:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 09:56:19 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-29 09:56:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 09:56:19 --> Final output sent to browser
DEBUG - 2013-08-29 09:56:19 --> Total execution time: 2.2051
DEBUG - 2013-08-29 09:56:19 --> Config Class Initialized
DEBUG - 2013-08-29 09:56:19 --> Hooks Class Initialized
DEBUG - 2013-08-29 09:56:19 --> Utf8 Class Initialized
DEBUG - 2013-08-29 09:56:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 09:56:19 --> URI Class Initialized
DEBUG - 2013-08-29 09:56:19 --> Router Class Initialized
ERROR - 2013-08-29 09:56:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 10:00:44 --> Config Class Initialized
DEBUG - 2013-08-29 10:00:44 --> Hooks Class Initialized
DEBUG - 2013-08-29 10:00:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 10:00:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 10:00:44 --> URI Class Initialized
DEBUG - 2013-08-29 10:00:44 --> Router Class Initialized
DEBUG - 2013-08-29 10:00:44 --> Output Class Initialized
DEBUG - 2013-08-29 10:00:44 --> Security Class Initialized
DEBUG - 2013-08-29 10:00:44 --> Input Class Initialized
DEBUG - 2013-08-29 10:00:44 --> XSS Filtering completed
DEBUG - 2013-08-29 10:00:44 --> XSS Filtering completed
DEBUG - 2013-08-29 10:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 10:00:44 --> Language Class Initialized
DEBUG - 2013-08-29 10:00:45 --> Loader Class Initialized
DEBUG - 2013-08-29 10:00:45 --> Helper loaded: url_helper
DEBUG - 2013-08-29 10:00:45 --> Helper loaded: file_helper
DEBUG - 2013-08-29 10:00:45 --> Helper loaded: form_helper
DEBUG - 2013-08-29 10:00:45 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 10:00:45 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 10:00:45 --> Database Driver Class Initialized
DEBUG - 2013-08-29 10:00:45 --> Session Class Initialized
DEBUG - 2013-08-29 10:00:45 --> Helper loaded: string_helper
DEBUG - 2013-08-29 10:00:45 --> Session routines successfully run
DEBUG - 2013-08-29 10:00:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 10:00:45 --> Controller Class Initialized
ERROR - 2013-08-29 10:00:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 10:00:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 10:00:46 --> Model Class Initialized
DEBUG - 2013-08-29 10:00:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 10:00:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 10:00:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 10:00:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 10:00:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 10:00:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 10:00:46 --> Model Class Initialized
DEBUG - 2013-08-29 10:00:46 --> Pagination Class Initialized
DEBUG - 2013-08-29 10:00:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 10:00:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 10:00:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 10:00:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 10:00:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 10:00:47 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 10:00:47 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-29 10:00:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 10:00:47 --> Final output sent to browser
DEBUG - 2013-08-29 10:00:47 --> Total execution time: 3.4002
DEBUG - 2013-08-29 10:00:48 --> Config Class Initialized
DEBUG - 2013-08-29 10:00:48 --> Hooks Class Initialized
DEBUG - 2013-08-29 10:00:48 --> Utf8 Class Initialized
DEBUG - 2013-08-29 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 10:00:48 --> URI Class Initialized
DEBUG - 2013-08-29 10:00:48 --> Router Class Initialized
ERROR - 2013-08-29 10:00:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:08:38 --> Config Class Initialized
DEBUG - 2013-08-29 14:08:39 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:08:39 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:08:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:08:39 --> URI Class Initialized
DEBUG - 2013-08-29 14:08:39 --> Router Class Initialized
DEBUG - 2013-08-29 14:08:39 --> Output Class Initialized
DEBUG - 2013-08-29 14:08:39 --> Security Class Initialized
DEBUG - 2013-08-29 14:08:39 --> Input Class Initialized
DEBUG - 2013-08-29 14:08:39 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:08:39 --> Language Class Initialized
DEBUG - 2013-08-29 14:08:39 --> Loader Class Initialized
DEBUG - 2013-08-29 14:08:39 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:08:39 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:08:39 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:08:39 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:08:39 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:08:40 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:08:40 --> Session Class Initialized
DEBUG - 2013-08-29 14:08:40 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:08:40 --> A session cookie was not found.
DEBUG - 2013-08-29 14:08:40 --> Session routines successfully run
DEBUG - 2013-08-29 14:08:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:08:40 --> Controller Class Initialized
ERROR - 2013-08-29 14:08:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:40 --> Model Class Initialized
DEBUG - 2013-08-29 14:08:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:08:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:08:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:08:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:08:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:41 --> Config Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:08:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:08:41 --> URI Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Router Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Output Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Security Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Input Class Initialized
DEBUG - 2013-08-29 14:08:41 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:41 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:08:41 --> Language Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Loader Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:08:41 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:08:41 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:08:41 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:08:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:08:41 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Session Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:08:41 --> Session routines successfully run
DEBUG - 2013-08-29 14:08:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:08:41 --> Controller Class Initialized
ERROR - 2013-08-29 14:08:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:42 --> Model Class Initialized
DEBUG - 2013-08-29 14:08:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:08:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:08:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:08:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:08:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:08:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:08:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:08:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:08:42 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 14:08:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:08:42 --> Final output sent to browser
DEBUG - 2013-08-29 14:08:42 --> Total execution time: 1.4691
DEBUG - 2013-08-29 14:08:42 --> Config Class Initialized
DEBUG - 2013-08-29 14:08:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:08:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:08:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:08:42 --> URI Class Initialized
DEBUG - 2013-08-29 14:08:42 --> Router Class Initialized
ERROR - 2013-08-29 14:08:42 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:08:51 --> Config Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:08:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:08:52 --> URI Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Router Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Output Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Security Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Input Class Initialized
DEBUG - 2013-08-29 14:08:52 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:52 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:52 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:52 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:52 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:08:52 --> Language Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Loader Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:08:52 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:08:52 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:08:52 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:08:52 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:08:52 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Session Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:08:52 --> Session routines successfully run
DEBUG - 2013-08-29 14:08:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Controller Class Initialized
ERROR - 2013-08-29 14:08:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:52 --> Model Class Initialized
DEBUG - 2013-08-29 14:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:08:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:08:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:08:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:08:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:53 --> Model Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Form Validation Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 14:08:53 --> Config Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:08:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:08:53 --> URI Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Router Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Output Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Security Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Input Class Initialized
DEBUG - 2013-08-29 14:08:53 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:53 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:08:53 --> Language Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Loader Class Initialized
DEBUG - 2013-08-29 14:08:53 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:08:53 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:08:53 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:08:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:08:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:08:54 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Session Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:08:54 --> Session routines successfully run
DEBUG - 2013-08-29 14:08:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Controller Class Initialized
ERROR - 2013-08-29 14:08:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:54 --> Model Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:08:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:08:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:08:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:08:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:54 --> Config Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:08:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:08:54 --> URI Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Router Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Output Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Security Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Input Class Initialized
DEBUG - 2013-08-29 14:08:54 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:54 --> XSS Filtering completed
DEBUG - 2013-08-29 14:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:08:54 --> Language Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Loader Class Initialized
DEBUG - 2013-08-29 14:08:54 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:08:54 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:08:54 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:08:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:08:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:08:55 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:08:55 --> Session Class Initialized
DEBUG - 2013-08-29 14:08:55 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:08:55 --> Session routines successfully run
DEBUG - 2013-08-29 14:08:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:08:55 --> Controller Class Initialized
ERROR - 2013-08-29 14:08:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:55 --> Model Class Initialized
DEBUG - 2013-08-29 14:08:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:08:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:08:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:08:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:08:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:08:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:08:55 --> Model Class Initialized
ERROR - 2013-08-29 14:08:55 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\core\MY_application_controller.php 46
DEBUG - 2013-08-29 14:08:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:08:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:08:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:08:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:08:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:08:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:08:55 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 14:08:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:08:55 --> Final output sent to browser
DEBUG - 2013-08-29 14:08:55 --> Total execution time: 1.3031
DEBUG - 2013-08-29 14:08:56 --> Config Class Initialized
DEBUG - 2013-08-29 14:08:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:08:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:08:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:08:56 --> URI Class Initialized
DEBUG - 2013-08-29 14:08:56 --> Router Class Initialized
ERROR - 2013-08-29 14:08:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:11:10 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:10 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:10 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:10 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:11 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:11 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:11 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:11 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:11 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:11 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:11 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:11 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:11 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:11 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:11 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:12 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:12 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:12 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:12 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:12 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:12 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:12 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:12 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:12 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:12 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:11:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:11:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:11:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:11:13 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 14:11:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:11:13 --> Final output sent to browser
DEBUG - 2013-08-29 14:11:13 --> Total execution time: 1.2191
DEBUG - 2013-08-29 14:11:13 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:13 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:13 --> Router Class Initialized
ERROR - 2013-08-29 14:11:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:11:20 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:20 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:20 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:20 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:20 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:20 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:20 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:20 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:20 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:20 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:20 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:20 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:20 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:20 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:20 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:20 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:21 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:21 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:21 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:21 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:21 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:21 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Form Validation Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 14:11:21 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:21 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:21 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:22 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:22 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:22 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:22 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:22 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:22 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:22 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:22 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:22 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:22 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:22 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:22 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:22 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:22 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:22 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:22 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:22 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:22 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:23 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:23 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:23 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:23 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:23 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:23 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:23 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:23 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:23 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:23 --> Model Class Initialized
ERROR - 2013-08-29 14:11:23 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\school\application\core\MY_application_controller.php 47
DEBUG - 2013-08-29 14:11:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:11:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:11:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:11:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:11:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:11:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:11:24 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 14:11:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:11:24 --> Final output sent to browser
DEBUG - 2013-08-29 14:11:24 --> Total execution time: 1.2971
DEBUG - 2013-08-29 14:11:24 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:24 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:24 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:24 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:24 --> Router Class Initialized
ERROR - 2013-08-29 14:11:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:11:44 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:44 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:44 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:44 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:44 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:44 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:44 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:44 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:44 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:44 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:44 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:45 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:45 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:45 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:45 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:45 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:46 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:46 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:46 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:46 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:46 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:46 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:46 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:46 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:46 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:46 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:46 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:46 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:46 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:46 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:46 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:46 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:46 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:11:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:11:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:11:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:11:46 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 14:11:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:11:47 --> Final output sent to browser
DEBUG - 2013-08-29 14:11:47 --> Total execution time: 1.2311
DEBUG - 2013-08-29 14:11:47 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:47 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:47 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:47 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:47 --> Router Class Initialized
ERROR - 2013-08-29 14:11:47 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:11:53 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:53 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:53 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:53 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:53 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:53 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:53 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:53 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:53 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:53 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:53 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:53 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:53 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:54 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:54 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Form Validation Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 14:11:54 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:54 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:54 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:54 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:54 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:54 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:55 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:55 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:55 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:55 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:55 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:55 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:55 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:55 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:55 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Router Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Output Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Security Class Initialized
DEBUG - 2013-08-29 14:11:55 --> Input Class Initialized
DEBUG - 2013-08-29 14:11:56 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:56 --> XSS Filtering completed
DEBUG - 2013-08-29 14:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:11:56 --> Language Class Initialized
DEBUG - 2013-08-29 14:11:56 --> Loader Class Initialized
DEBUG - 2013-08-29 14:11:56 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:11:56 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:11:56 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:11:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:11:56 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:11:56 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:11:56 --> Session Class Initialized
DEBUG - 2013-08-29 14:11:56 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:11:56 --> Session routines successfully run
DEBUG - 2013-08-29 14:11:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:11:56 --> Controller Class Initialized
ERROR - 2013-08-29 14:11:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:56 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:11:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:11:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:11:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:11:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:11:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:11:56 --> Model Class Initialized
DEBUG - 2013-08-29 14:11:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:11:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:11:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:11:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:11:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:11:57 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 14:11:57 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\views\home.php 3
ERROR - 2013-08-29 14:11:57 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\views\home.php 3
DEBUG - 2013-08-29 14:11:57 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 14:11:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:11:57 --> Final output sent to browser
DEBUG - 2013-08-29 14:11:57 --> Total execution time: 1.4591
DEBUG - 2013-08-29 14:11:57 --> Config Class Initialized
DEBUG - 2013-08-29 14:11:57 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:11:57 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:11:57 --> URI Class Initialized
DEBUG - 2013-08-29 14:11:57 --> Router Class Initialized
ERROR - 2013-08-29 14:11:57 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:13:59 --> Config Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:13:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:13:59 --> URI Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Router Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Output Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Security Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Input Class Initialized
DEBUG - 2013-08-29 14:13:59 --> XSS Filtering completed
DEBUG - 2013-08-29 14:13:59 --> XSS Filtering completed
DEBUG - 2013-08-29 14:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:13:59 --> Language Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Loader Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:13:59 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:13:59 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:13:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:13:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:13:59 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Session Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:13:59 --> Session routines successfully run
DEBUG - 2013-08-29 14:13:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:13:59 --> Controller Class Initialized
ERROR - 2013-08-29 14:13:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:13:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:14:00 --> Model Class Initialized
DEBUG - 2013-08-29 14:14:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:14:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:14:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:14:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:14:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:14:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:14:00 --> Model Class Initialized
DEBUG - 2013-08-29 14:14:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:14:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:14:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:14:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:14:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:14:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:14:00 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 14:14:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:14:00 --> Final output sent to browser
DEBUG - 2013-08-29 14:14:00 --> Total execution time: 1.3041
DEBUG - 2013-08-29 14:14:00 --> Config Class Initialized
DEBUG - 2013-08-29 14:14:00 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:14:00 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:14:00 --> URI Class Initialized
DEBUG - 2013-08-29 14:14:00 --> Router Class Initialized
ERROR - 2013-08-29 14:14:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:15:25 --> Config Class Initialized
DEBUG - 2013-08-29 14:15:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:15:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:15:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:15:25 --> URI Class Initialized
DEBUG - 2013-08-29 14:15:25 --> Router Class Initialized
DEBUG - 2013-08-29 14:15:25 --> Output Class Initialized
DEBUG - 2013-08-29 14:15:25 --> Security Class Initialized
DEBUG - 2013-08-29 14:15:25 --> Input Class Initialized
DEBUG - 2013-08-29 14:15:25 --> XSS Filtering completed
DEBUG - 2013-08-29 14:15:25 --> XSS Filtering completed
DEBUG - 2013-08-29 14:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:15:25 --> Language Class Initialized
DEBUG - 2013-08-29 14:15:25 --> Loader Class Initialized
DEBUG - 2013-08-29 14:15:25 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:15:25 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:15:25 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:15:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:15:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:15:25 --> Database Driver Class Initialized
ERROR - 2013-08-29 14:15:25 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp\htdocs\school\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-08-29 14:15:25 --> Session Class Initialized
DEBUG - 2013-08-29 14:15:25 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:15:25 --> Session routines successfully run
DEBUG - 2013-08-29 14:15:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:15:26 --> Controller Class Initialized
ERROR - 2013-08-29 14:15:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:15:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:15:26 --> Model Class Initialized
DEBUG - 2013-08-29 14:15:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:15:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:15:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:15:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:15:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:15:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:15:26 --> Model Class Initialized
DEBUG - 2013-08-29 14:15:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:15:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:15:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:15:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:15:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:15:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:15:26 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 14:15:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:15:26 --> Final output sent to browser
DEBUG - 2013-08-29 14:15:26 --> Total execution time: 1.3181
DEBUG - 2013-08-29 14:15:26 --> Config Class Initialized
DEBUG - 2013-08-29 14:15:26 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:15:26 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:15:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:15:26 --> URI Class Initialized
DEBUG - 2013-08-29 14:15:26 --> Router Class Initialized
ERROR - 2013-08-29 14:15:27 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:18:37 --> Config Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:18:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:18:37 --> URI Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Router Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Output Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Security Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Input Class Initialized
DEBUG - 2013-08-29 14:18:37 --> XSS Filtering completed
DEBUG - 2013-08-29 14:18:37 --> XSS Filtering completed
DEBUG - 2013-08-29 14:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:18:37 --> Language Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Loader Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:18:37 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:18:37 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:18:37 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:18:37 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:18:37 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Session Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:18:37 --> Session routines successfully run
DEBUG - 2013-08-29 14:18:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Controller Class Initialized
ERROR - 2013-08-29 14:18:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:18:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:18:37 --> Model Class Initialized
DEBUG - 2013-08-29 14:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:18:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:18:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:18:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:18:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:18:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:18:38 --> Model Class Initialized
DEBUG - 2013-08-29 14:18:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:18:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:18:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:18:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:18:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:18:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:18:38 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 14:18:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:18:38 --> Final output sent to browser
DEBUG - 2013-08-29 14:18:38 --> Total execution time: 1.2421
DEBUG - 2013-08-29 14:18:38 --> Config Class Initialized
DEBUG - 2013-08-29 14:18:38 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:18:38 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:18:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:18:38 --> URI Class Initialized
DEBUG - 2013-08-29 14:18:38 --> Router Class Initialized
ERROR - 2013-08-29 14:18:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:18:47 --> Config Class Initialized
DEBUG - 2013-08-29 14:18:47 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:18:47 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:18:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:18:47 --> URI Class Initialized
DEBUG - 2013-08-29 14:18:47 --> Router Class Initialized
DEBUG - 2013-08-29 14:18:47 --> Output Class Initialized
DEBUG - 2013-08-29 14:18:47 --> Security Class Initialized
DEBUG - 2013-08-29 14:18:47 --> Input Class Initialized
DEBUG - 2013-08-29 14:18:47 --> XSS Filtering completed
DEBUG - 2013-08-29 14:18:47 --> XSS Filtering completed
DEBUG - 2013-08-29 14:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:18:47 --> Language Class Initialized
DEBUG - 2013-08-29 14:18:47 --> Loader Class Initialized
DEBUG - 2013-08-29 14:18:47 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:18:47 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:18:48 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:18:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:18:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:18:48 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:18:48 --> Session Class Initialized
DEBUG - 2013-08-29 14:18:48 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:18:48 --> Session routines successfully run
DEBUG - 2013-08-29 14:18:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:18:48 --> Controller Class Initialized
ERROR - 2013-08-29 14:18:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:18:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:18:48 --> Model Class Initialized
DEBUG - 2013-08-29 14:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:18:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:18:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:18:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:18:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:18:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:18:48 --> Model Class Initialized
ERROR - 2013-08-29 14:18:48 --> 404 Page Not Found --> 
DEBUG - 2013-08-29 14:20:09 --> Config Class Initialized
DEBUG - 2013-08-29 14:20:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:20:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:20:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:20:09 --> URI Class Initialized
DEBUG - 2013-08-29 14:20:09 --> Router Class Initialized
DEBUG - 2013-08-29 14:20:09 --> Output Class Initialized
DEBUG - 2013-08-29 14:20:09 --> Security Class Initialized
DEBUG - 2013-08-29 14:20:09 --> Input Class Initialized
DEBUG - 2013-08-29 14:20:09 --> XSS Filtering completed
DEBUG - 2013-08-29 14:20:09 --> XSS Filtering completed
DEBUG - 2013-08-29 14:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:20:09 --> Language Class Initialized
DEBUG - 2013-08-29 14:20:09 --> Loader Class Initialized
DEBUG - 2013-08-29 14:20:09 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:20:09 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:20:10 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:20:10 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:20:10 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:20:10 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:20:10 --> Session Class Initialized
DEBUG - 2013-08-29 14:20:10 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:20:10 --> Session routines successfully run
DEBUG - 2013-08-29 14:20:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:20:10 --> Controller Class Initialized
ERROR - 2013-08-29 14:20:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:20:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:20:10 --> Model Class Initialized
DEBUG - 2013-08-29 14:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:20:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:20:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:20:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:20:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:20:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:20:10 --> Model Class Initialized
DEBUG - 2013-08-29 14:20:10 --> Pagination Class Initialized
DEBUG - 2013-08-29 14:20:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:20:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:20:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:20:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:20:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:20:10 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 14:20:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-29 14:20:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-29 14:20:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-29 14:20:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-29 14:20:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-08-29 14:20:10 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-29 14:20:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:20:11 --> Final output sent to browser
DEBUG - 2013-08-29 14:20:11 --> Total execution time: 1.4681
DEBUG - 2013-08-29 14:20:11 --> Config Class Initialized
DEBUG - 2013-08-29 14:20:11 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:20:11 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:20:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:20:11 --> URI Class Initialized
DEBUG - 2013-08-29 14:20:11 --> Router Class Initialized
ERROR - 2013-08-29 14:20:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:39:52 --> Config Class Initialized
DEBUG - 2013-08-29 14:39:52 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:39:52 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:39:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:39:52 --> URI Class Initialized
DEBUG - 2013-08-29 14:39:52 --> Router Class Initialized
DEBUG - 2013-08-29 14:39:52 --> Output Class Initialized
DEBUG - 2013-08-29 14:39:52 --> Security Class Initialized
DEBUG - 2013-08-29 14:39:52 --> Input Class Initialized
DEBUG - 2013-08-29 14:39:52 --> XSS Filtering completed
DEBUG - 2013-08-29 14:39:52 --> XSS Filtering completed
DEBUG - 2013-08-29 14:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:39:53 --> Language Class Initialized
DEBUG - 2013-08-29 14:39:53 --> Loader Class Initialized
DEBUG - 2013-08-29 14:39:53 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:39:53 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:39:53 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:39:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:39:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:39:53 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:39:53 --> Session Class Initialized
DEBUG - 2013-08-29 14:39:53 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:39:53 --> Session garbage collection performed.
DEBUG - 2013-08-29 14:39:53 --> Session routines successfully run
DEBUG - 2013-08-29 14:39:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:39:53 --> Controller Class Initialized
ERROR - 2013-08-29 14:39:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:39:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:39:53 --> Model Class Initialized
DEBUG - 2013-08-29 14:39:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:39:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:39:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:39:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:39:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:39:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:39:53 --> Model Class Initialized
DEBUG - 2013-08-29 14:39:53 --> Pagination Class Initialized
DEBUG - 2013-08-29 14:39:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:39:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:39:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:39:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:39:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:39:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:39:54 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 14:39:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:39:54 --> Final output sent to browser
DEBUG - 2013-08-29 14:39:54 --> Total execution time: 1.4121
DEBUG - 2013-08-29 14:39:54 --> Config Class Initialized
DEBUG - 2013-08-29 14:39:54 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:39:54 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:39:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:39:54 --> URI Class Initialized
DEBUG - 2013-08-29 14:39:54 --> Router Class Initialized
ERROR - 2013-08-29 14:39:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:45:20 --> Config Class Initialized
DEBUG - 2013-08-29 14:45:20 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:45:20 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:45:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:45:20 --> URI Class Initialized
DEBUG - 2013-08-29 14:45:20 --> Router Class Initialized
DEBUG - 2013-08-29 14:45:20 --> Output Class Initialized
DEBUG - 2013-08-29 14:45:20 --> Security Class Initialized
DEBUG - 2013-08-29 14:45:20 --> Input Class Initialized
DEBUG - 2013-08-29 14:45:20 --> XSS Filtering completed
DEBUG - 2013-08-29 14:45:20 --> XSS Filtering completed
DEBUG - 2013-08-29 14:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:45:20 --> Language Class Initialized
DEBUG - 2013-08-29 14:45:20 --> Loader Class Initialized
DEBUG - 2013-08-29 14:45:20 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:45:21 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:45:21 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:45:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:45:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:45:21 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:45:21 --> Session Class Initialized
DEBUG - 2013-08-29 14:45:21 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:45:21 --> Session routines successfully run
DEBUG - 2013-08-29 14:45:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:45:21 --> Controller Class Initialized
ERROR - 2013-08-29 14:45:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:45:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:45:21 --> Model Class Initialized
DEBUG - 2013-08-29 14:45:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:45:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:45:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:45:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:45:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:45:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:45:21 --> Model Class Initialized
DEBUG - 2013-08-29 14:45:21 --> Pagination Class Initialized
DEBUG - 2013-08-29 14:45:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:45:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:45:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:45:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:45:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:45:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:45:21 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 14:45:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:45:22 --> Final output sent to browser
DEBUG - 2013-08-29 14:45:22 --> Total execution time: 1.4041
DEBUG - 2013-08-29 14:45:22 --> Config Class Initialized
DEBUG - 2013-08-29 14:45:22 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:45:22 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:45:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:45:22 --> URI Class Initialized
DEBUG - 2013-08-29 14:45:22 --> Router Class Initialized
ERROR - 2013-08-29 14:45:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:45:24 --> Config Class Initialized
DEBUG - 2013-08-29 14:45:24 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:45:24 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:45:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:45:24 --> URI Class Initialized
DEBUG - 2013-08-29 14:45:24 --> Router Class Initialized
DEBUG - 2013-08-29 14:45:24 --> Output Class Initialized
DEBUG - 2013-08-29 14:45:24 --> Security Class Initialized
DEBUG - 2013-08-29 14:45:24 --> Input Class Initialized
DEBUG - 2013-08-29 14:45:24 --> XSS Filtering completed
DEBUG - 2013-08-29 14:45:24 --> XSS Filtering completed
DEBUG - 2013-08-29 14:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:45:25 --> Language Class Initialized
DEBUG - 2013-08-29 14:45:25 --> Loader Class Initialized
DEBUG - 2013-08-29 14:45:25 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:45:25 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:45:25 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:45:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:45:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:45:25 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:45:25 --> Session Class Initialized
DEBUG - 2013-08-29 14:45:25 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:45:25 --> Session routines successfully run
DEBUG - 2013-08-29 14:45:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:45:25 --> Controller Class Initialized
ERROR - 2013-08-29 14:45:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:45:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:45:25 --> Model Class Initialized
DEBUG - 2013-08-29 14:45:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:45:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:45:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:45:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:45:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:45:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:45:25 --> Model Class Initialized
DEBUG - 2013-08-29 14:45:25 --> Pagination Class Initialized
DEBUG - 2013-08-29 14:45:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:45:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:45:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:45:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:45:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:45:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:45:26 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-29 14:45:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:45:26 --> Final output sent to browser
DEBUG - 2013-08-29 14:45:26 --> Total execution time: 1.4641
DEBUG - 2013-08-29 14:45:26 --> Config Class Initialized
DEBUG - 2013-08-29 14:45:26 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:45:26 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:45:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:45:26 --> URI Class Initialized
DEBUG - 2013-08-29 14:45:26 --> Router Class Initialized
ERROR - 2013-08-29 14:45:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:45:36 --> Config Class Initialized
DEBUG - 2013-08-29 14:45:36 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:45:36 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:45:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:45:37 --> URI Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Router Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Output Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Security Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Input Class Initialized
DEBUG - 2013-08-29 14:45:37 --> XSS Filtering completed
DEBUG - 2013-08-29 14:45:37 --> XSS Filtering completed
DEBUG - 2013-08-29 14:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:45:37 --> Language Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Loader Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:45:37 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:45:37 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:45:37 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:45:37 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:45:37 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Session Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:45:37 --> Session routines successfully run
DEBUG - 2013-08-29 14:45:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Controller Class Initialized
ERROR - 2013-08-29 14:45:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:45:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:45:37 --> Model Class Initialized
DEBUG - 2013-08-29 14:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:45:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:45:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:45:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:45:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:45:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:45:38 --> Model Class Initialized
DEBUG - 2013-08-29 14:45:38 --> Pagination Class Initialized
DEBUG - 2013-08-29 14:45:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:45:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:45:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:45:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:45:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:45:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:45:38 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 14:45:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:45:38 --> Final output sent to browser
DEBUG - 2013-08-29 14:45:38 --> Total execution time: 1.4691
DEBUG - 2013-08-29 14:45:38 --> Config Class Initialized
DEBUG - 2013-08-29 14:45:38 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:45:38 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:45:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:45:38 --> URI Class Initialized
DEBUG - 2013-08-29 14:45:38 --> Router Class Initialized
ERROR - 2013-08-29 14:45:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:45:41 --> Config Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:45:41 --> URI Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Router Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Output Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Security Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Input Class Initialized
DEBUG - 2013-08-29 14:45:41 --> XSS Filtering completed
DEBUG - 2013-08-29 14:45:41 --> XSS Filtering completed
DEBUG - 2013-08-29 14:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:45:41 --> Language Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Loader Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:45:41 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:45:41 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:45:41 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:45:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:45:41 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Session Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:45:41 --> Session routines successfully run
DEBUG - 2013-08-29 14:45:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Controller Class Initialized
ERROR - 2013-08-29 14:45:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:45:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:45:41 --> Model Class Initialized
DEBUG - 2013-08-29 14:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:45:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:45:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:45:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:45:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:45:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:45:42 --> Model Class Initialized
DEBUG - 2013-08-29 14:45:42 --> DB Transaction Failure
ERROR - 2013-08-29 14:45:42 --> Query error: Unknown column 'id' in 'where clause'
DEBUG - 2013-08-29 14:45:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 14:49:32 --> Config Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:49:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:49:32 --> URI Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Router Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Output Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Security Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Input Class Initialized
DEBUG - 2013-08-29 14:49:32 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:32 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:32 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:32 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:32 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:49:32 --> Language Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Loader Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:49:32 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:49:32 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:49:32 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:49:32 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:49:32 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Session Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:49:32 --> Session routines successfully run
DEBUG - 2013-08-29 14:49:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:49:32 --> Controller Class Initialized
ERROR - 2013-08-29 14:49:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:49:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:49:32 --> Model Class Initialized
DEBUG - 2013-08-29 14:49:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:49:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:49:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:49:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:49:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:49:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:49:33 --> Model Class Initialized
DEBUG - 2013-08-29 14:49:33 --> Pagination Class Initialized
DEBUG - 2013-08-29 14:49:33 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:33 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:33 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:33 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:33 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:33 --> XSS Filtering completed
DEBUG - 2013-08-29 14:49:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 14:49:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 14:49:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 14:49:33 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 14:49:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 14:49:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 14:49:33 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 14:49:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 14:49:33 --> Final output sent to browser
DEBUG - 2013-08-29 14:49:33 --> Total execution time: 1.6531
DEBUG - 2013-08-29 14:49:34 --> Config Class Initialized
DEBUG - 2013-08-29 14:49:34 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:49:34 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:49:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:49:34 --> URI Class Initialized
DEBUG - 2013-08-29 14:49:34 --> Router Class Initialized
ERROR - 2013-08-29 14:49:34 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 14:53:56 --> Config Class Initialized
DEBUG - 2013-08-29 14:53:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 14:53:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 14:53:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 14:53:56 --> URI Class Initialized
DEBUG - 2013-08-29 14:53:56 --> Router Class Initialized
DEBUG - 2013-08-29 14:53:56 --> Output Class Initialized
DEBUG - 2013-08-29 14:53:56 --> Security Class Initialized
DEBUG - 2013-08-29 14:53:56 --> Input Class Initialized
DEBUG - 2013-08-29 14:53:56 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:56 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:57 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:57 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:57 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 14:53:57 --> Language Class Initialized
DEBUG - 2013-08-29 14:53:57 --> Loader Class Initialized
DEBUG - 2013-08-29 14:53:57 --> Helper loaded: url_helper
DEBUG - 2013-08-29 14:53:57 --> Helper loaded: file_helper
DEBUG - 2013-08-29 14:53:57 --> Helper loaded: form_helper
DEBUG - 2013-08-29 14:53:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 14:53:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 14:53:57 --> Database Driver Class Initialized
DEBUG - 2013-08-29 14:53:57 --> Session Class Initialized
DEBUG - 2013-08-29 14:53:57 --> Helper loaded: string_helper
DEBUG - 2013-08-29 14:53:57 --> Session routines successfully run
DEBUG - 2013-08-29 14:53:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 14:53:57 --> Controller Class Initialized
ERROR - 2013-08-29 14:53:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:53:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:53:57 --> Model Class Initialized
DEBUG - 2013-08-29 14:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 14:53:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 14:53:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 14:53:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 14:53:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 14:53:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 14:53:57 --> Model Class Initialized
DEBUG - 2013-08-29 14:53:57 --> Pagination Class Initialized
DEBUG - 2013-08-29 14:53:57 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:57 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:58 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:58 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:58 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:58 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:58 --> XSS Filtering completed
DEBUG - 2013-08-29 14:53:58 --> DB Transaction Failure
ERROR - 2013-08-29 14:53:58 --> Query error: Not unique table/alias: 'user_privilege_groups'
DEBUG - 2013-08-29 14:53:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 15:03:15 --> Config Class Initialized
DEBUG - 2013-08-29 15:03:15 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:03:15 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:03:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:03:15 --> URI Class Initialized
DEBUG - 2013-08-29 15:03:15 --> Router Class Initialized
DEBUG - 2013-08-29 15:03:15 --> Output Class Initialized
DEBUG - 2013-08-29 15:03:15 --> Security Class Initialized
DEBUG - 2013-08-29 15:03:15 --> Input Class Initialized
DEBUG - 2013-08-29 15:03:15 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:15 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:15 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:15 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:15 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:03:15 --> Language Class Initialized
DEBUG - 2013-08-29 15:03:15 --> Loader Class Initialized
DEBUG - 2013-08-29 15:03:15 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:03:15 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:03:15 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:03:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:03:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:03:16 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:03:16 --> Session Class Initialized
DEBUG - 2013-08-29 15:03:16 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:03:16 --> Session routines successfully run
DEBUG - 2013-08-29 15:03:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:03:16 --> Controller Class Initialized
ERROR - 2013-08-29 15:03:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:03:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:03:16 --> Model Class Initialized
DEBUG - 2013-08-29 15:03:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:03:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:03:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:03:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:03:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:03:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:03:16 --> Model Class Initialized
DEBUG - 2013-08-29 15:03:16 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:03:16 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:16 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:16 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:16 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:16 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:16 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:16 --> XSS Filtering completed
DEBUG - 2013-08-29 15:03:17 --> DB Transaction Failure
ERROR - 2013-08-29 15:03:17 --> Query error: Not unique table/alias: 'user_privilege_groups'
DEBUG - 2013-08-29 15:03:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 15:08:57 --> Config Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:08:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:08:57 --> URI Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Router Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Output Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Security Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Input Class Initialized
DEBUG - 2013-08-29 15:08:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:08:57 --> Language Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Loader Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:08:57 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:08:57 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:08:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:08:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:08:57 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Session Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:08:57 --> Session routines successfully run
DEBUG - 2013-08-29 15:08:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:08:57 --> Controller Class Initialized
ERROR - 2013-08-29 15:08:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:08:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:08:58 --> Model Class Initialized
DEBUG - 2013-08-29 15:08:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:08:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:08:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:08:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:08:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:08:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:08:58 --> Model Class Initialized
DEBUG - 2013-08-29 15:08:58 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:08:58 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:58 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:58 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:58 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:58 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:58 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:58 --> XSS Filtering completed
DEBUG - 2013-08-29 15:08:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:08:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:08:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:08:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:08:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:08:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:08:58 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:08:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:08:58 --> Final output sent to browser
DEBUG - 2013-08-29 15:08:58 --> Total execution time: 1.7601
DEBUG - 2013-08-29 15:08:59 --> Config Class Initialized
DEBUG - 2013-08-29 15:08:59 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:08:59 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:08:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:08:59 --> URI Class Initialized
DEBUG - 2013-08-29 15:08:59 --> Router Class Initialized
ERROR - 2013-08-29 15:08:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:09:11 --> Config Class Initialized
DEBUG - 2013-08-29 15:09:11 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:09:11 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:09:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:09:11 --> URI Class Initialized
DEBUG - 2013-08-29 15:09:11 --> Router Class Initialized
DEBUG - 2013-08-29 15:09:11 --> Output Class Initialized
DEBUG - 2013-08-29 15:09:11 --> Security Class Initialized
DEBUG - 2013-08-29 15:09:11 --> Input Class Initialized
DEBUG - 2013-08-29 15:09:11 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:11 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:11 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:11 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:11 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:09:11 --> Language Class Initialized
DEBUG - 2013-08-29 15:09:11 --> Loader Class Initialized
DEBUG - 2013-08-29 15:09:11 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:09:11 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:09:11 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:09:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:09:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:09:11 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:09:12 --> Session Class Initialized
DEBUG - 2013-08-29 15:09:12 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:09:12 --> Session routines successfully run
DEBUG - 2013-08-29 15:09:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:09:12 --> Controller Class Initialized
ERROR - 2013-08-29 15:09:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:09:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:09:12 --> Model Class Initialized
DEBUG - 2013-08-29 15:09:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:09:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:09:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:09:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:09:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:09:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:09:12 --> Model Class Initialized
DEBUG - 2013-08-29 15:09:12 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:09:12 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:12 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:12 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:12 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:12 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:12 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:12 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:09:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:09:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:09:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:09:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:09:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:09:12 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:09:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:09:13 --> Final output sent to browser
DEBUG - 2013-08-29 15:09:13 --> Total execution time: 1.6711
DEBUG - 2013-08-29 15:09:13 --> Config Class Initialized
DEBUG - 2013-08-29 15:09:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:09:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:09:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:09:13 --> URI Class Initialized
DEBUG - 2013-08-29 15:09:13 --> Router Class Initialized
ERROR - 2013-08-29 15:09:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:09:21 --> Config Class Initialized
DEBUG - 2013-08-29 15:09:21 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:09:21 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:09:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:09:21 --> URI Class Initialized
DEBUG - 2013-08-29 15:09:21 --> Router Class Initialized
DEBUG - 2013-08-29 15:09:21 --> Output Class Initialized
DEBUG - 2013-08-29 15:09:22 --> Security Class Initialized
DEBUG - 2013-08-29 15:09:22 --> Input Class Initialized
DEBUG - 2013-08-29 15:09:22 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:22 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:22 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:22 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:22 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:09:22 --> Language Class Initialized
DEBUG - 2013-08-29 15:09:22 --> Loader Class Initialized
DEBUG - 2013-08-29 15:09:22 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:09:22 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:09:22 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:09:22 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:09:22 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:09:22 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:09:22 --> Session Class Initialized
DEBUG - 2013-08-29 15:09:22 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:09:22 --> Session routines successfully run
DEBUG - 2013-08-29 15:09:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:09:22 --> Controller Class Initialized
ERROR - 2013-08-29 15:09:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:09:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:09:22 --> Model Class Initialized
DEBUG - 2013-08-29 15:09:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:09:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:09:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:09:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:09:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:09:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:09:22 --> Model Class Initialized
DEBUG - 2013-08-29 15:09:22 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:09:22 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:09:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:09:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:09:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:09:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:09:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:09:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:09:23 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:09:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:09:23 --> Final output sent to browser
DEBUG - 2013-08-29 15:09:23 --> Total execution time: 1.6111
DEBUG - 2013-08-29 15:09:23 --> Config Class Initialized
DEBUG - 2013-08-29 15:09:23 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:09:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:09:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:09:23 --> URI Class Initialized
DEBUG - 2013-08-29 15:09:23 --> Router Class Initialized
ERROR - 2013-08-29 15:09:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:11:14 --> Config Class Initialized
DEBUG - 2013-08-29 15:11:14 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:11:14 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:11:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:11:14 --> URI Class Initialized
DEBUG - 2013-08-29 15:11:14 --> Router Class Initialized
DEBUG - 2013-08-29 15:11:14 --> Output Class Initialized
DEBUG - 2013-08-29 15:11:14 --> Security Class Initialized
DEBUG - 2013-08-29 15:11:14 --> Input Class Initialized
DEBUG - 2013-08-29 15:11:14 --> XSS Filtering completed
DEBUG - 2013-08-29 15:11:14 --> XSS Filtering completed
DEBUG - 2013-08-29 15:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:11:14 --> Language Class Initialized
DEBUG - 2013-08-29 15:11:14 --> Loader Class Initialized
DEBUG - 2013-08-29 15:11:14 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:11:14 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:11:14 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:11:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:11:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:11:15 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:11:15 --> Session Class Initialized
DEBUG - 2013-08-29 15:11:15 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:11:15 --> Session routines successfully run
DEBUG - 2013-08-29 15:11:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:11:15 --> Controller Class Initialized
ERROR - 2013-08-29 15:11:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:11:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:11:15 --> Model Class Initialized
DEBUG - 2013-08-29 15:11:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:11:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:11:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:11:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:11:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:11:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:11:15 --> Model Class Initialized
DEBUG - 2013-08-29 15:11:15 --> DB Transaction Failure
ERROR - 2013-08-29 15:11:15 --> Query error: Unknown column 'id' in 'where clause'
DEBUG - 2013-08-29 15:11:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 15:13:37 --> Config Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:13:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:13:37 --> URI Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Router Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Output Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Security Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Input Class Initialized
DEBUG - 2013-08-29 15:13:37 --> XSS Filtering completed
DEBUG - 2013-08-29 15:13:37 --> XSS Filtering completed
DEBUG - 2013-08-29 15:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:13:37 --> Language Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Loader Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:13:37 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:13:37 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:13:37 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:13:37 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:13:37 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Session Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:13:37 --> Session routines successfully run
DEBUG - 2013-08-29 15:13:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Controller Class Initialized
ERROR - 2013-08-29 15:13:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:13:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:13:37 --> Model Class Initialized
DEBUG - 2013-08-29 15:13:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:13:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:13:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:13:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:13:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:13:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:13:38 --> Model Class Initialized
DEBUG - 2013-08-29 15:13:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:13:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:13:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:13:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:13:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:13:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:13:38 --> File loaded: application/views/group_privileges/show.php
DEBUG - 2013-08-29 15:13:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:13:38 --> Final output sent to browser
DEBUG - 2013-08-29 15:13:38 --> Total execution time: 1.3171
DEBUG - 2013-08-29 15:13:38 --> Config Class Initialized
DEBUG - 2013-08-29 15:13:38 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:13:38 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:13:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:13:38 --> URI Class Initialized
DEBUG - 2013-08-29 15:13:38 --> Router Class Initialized
ERROR - 2013-08-29 15:13:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:16:06 --> Config Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:16:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:16:06 --> URI Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Router Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Output Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Security Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Input Class Initialized
DEBUG - 2013-08-29 15:16:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:16:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:16:06 --> Language Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Loader Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:16:06 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:16:06 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:16:06 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:16:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:16:06 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Session Class Initialized
DEBUG - 2013-08-29 15:16:06 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:16:07 --> Session routines successfully run
DEBUG - 2013-08-29 15:16:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:16:07 --> Controller Class Initialized
ERROR - 2013-08-29 15:16:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:16:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:16:07 --> Model Class Initialized
DEBUG - 2013-08-29 15:16:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:16:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:16:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:16:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:16:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:16:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:16:07 --> Model Class Initialized
DEBUG - 2013-08-29 15:16:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:16:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:16:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:16:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:16:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:16:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:16:07 --> File loaded: application/views/group_privileges/show.php
DEBUG - 2013-08-29 15:16:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:16:07 --> Final output sent to browser
DEBUG - 2013-08-29 15:16:07 --> Total execution time: 1.4461
DEBUG - 2013-08-29 15:16:08 --> Config Class Initialized
DEBUG - 2013-08-29 15:16:08 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:16:08 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:16:08 --> URI Class Initialized
DEBUG - 2013-08-29 15:16:08 --> Router Class Initialized
ERROR - 2013-08-29 15:16:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:16:34 --> Config Class Initialized
DEBUG - 2013-08-29 15:16:34 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:16:34 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:16:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:16:34 --> URI Class Initialized
DEBUG - 2013-08-29 15:16:34 --> Router Class Initialized
DEBUG - 2013-08-29 15:16:34 --> Output Class Initialized
DEBUG - 2013-08-29 15:16:34 --> Security Class Initialized
DEBUG - 2013-08-29 15:16:34 --> Input Class Initialized
DEBUG - 2013-08-29 15:16:34 --> XSS Filtering completed
DEBUG - 2013-08-29 15:16:34 --> XSS Filtering completed
DEBUG - 2013-08-29 15:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:16:34 --> Language Class Initialized
DEBUG - 2013-08-29 15:16:34 --> Loader Class Initialized
DEBUG - 2013-08-29 15:16:34 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:16:34 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:16:34 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:16:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:16:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:16:35 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:16:35 --> Session Class Initialized
DEBUG - 2013-08-29 15:16:35 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:16:35 --> Session routines successfully run
DEBUG - 2013-08-29 15:16:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:16:35 --> Controller Class Initialized
ERROR - 2013-08-29 15:16:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:16:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:16:35 --> Model Class Initialized
DEBUG - 2013-08-29 15:16:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:16:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:16:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:16:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:16:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:16:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:16:35 --> Model Class Initialized
DEBUG - 2013-08-29 15:16:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:16:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:16:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:16:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:16:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:16:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:16:35 --> File loaded: application/views/group_privileges/show.php
DEBUG - 2013-08-29 15:16:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:16:35 --> Final output sent to browser
DEBUG - 2013-08-29 15:16:35 --> Total execution time: 1.3621
DEBUG - 2013-08-29 15:16:36 --> Config Class Initialized
DEBUG - 2013-08-29 15:16:36 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:16:36 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:16:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:16:36 --> URI Class Initialized
DEBUG - 2013-08-29 15:16:36 --> Router Class Initialized
ERROR - 2013-08-29 15:16:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:17:02 --> Config Class Initialized
DEBUG - 2013-08-29 15:17:02 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:17:02 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:17:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:17:02 --> URI Class Initialized
DEBUG - 2013-08-29 15:17:02 --> Router Class Initialized
DEBUG - 2013-08-29 15:17:02 --> Output Class Initialized
DEBUG - 2013-08-29 15:17:02 --> Security Class Initialized
DEBUG - 2013-08-29 15:17:02 --> Input Class Initialized
DEBUG - 2013-08-29 15:17:02 --> XSS Filtering completed
DEBUG - 2013-08-29 15:17:02 --> XSS Filtering completed
DEBUG - 2013-08-29 15:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:17:02 --> Language Class Initialized
DEBUG - 2013-08-29 15:17:03 --> Loader Class Initialized
DEBUG - 2013-08-29 15:17:03 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:17:03 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:17:03 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:17:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:17:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:17:03 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:17:03 --> Session Class Initialized
DEBUG - 2013-08-29 15:17:03 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:17:03 --> Session routines successfully run
DEBUG - 2013-08-29 15:17:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:17:03 --> Controller Class Initialized
ERROR - 2013-08-29 15:17:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:17:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:17:03 --> Model Class Initialized
DEBUG - 2013-08-29 15:17:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:17:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:17:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:17:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:17:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:17:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:17:03 --> Model Class Initialized
DEBUG - 2013-08-29 15:17:03 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:17:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:17:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:17:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:17:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:17:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:17:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:17:04 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-29 15:17:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:17:04 --> Final output sent to browser
DEBUG - 2013-08-29 15:17:04 --> Total execution time: 1.4101
DEBUG - 2013-08-29 15:17:04 --> Config Class Initialized
DEBUG - 2013-08-29 15:17:04 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:17:04 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:17:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:17:04 --> URI Class Initialized
DEBUG - 2013-08-29 15:17:04 --> Router Class Initialized
ERROR - 2013-08-29 15:17:04 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:17:07 --> Config Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:17:07 --> URI Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Router Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Output Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Security Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Input Class Initialized
DEBUG - 2013-08-29 15:17:07 --> XSS Filtering completed
DEBUG - 2013-08-29 15:17:07 --> XSS Filtering completed
DEBUG - 2013-08-29 15:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:17:07 --> Language Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Loader Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:17:07 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:17:07 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:17:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:17:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:17:07 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Session Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:17:07 --> Session routines successfully run
DEBUG - 2013-08-29 15:17:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Controller Class Initialized
ERROR - 2013-08-29 15:17:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:17:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:17:07 --> Model Class Initialized
DEBUG - 2013-08-29 15:17:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:17:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:17:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:17:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:17:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:17:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:17:08 --> Model Class Initialized
DEBUG - 2013-08-29 15:17:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:17:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:17:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:17:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:17:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:17:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:17:08 --> File loaded: application/views/jurusans/show.php
DEBUG - 2013-08-29 15:17:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:17:08 --> Final output sent to browser
DEBUG - 2013-08-29 15:17:08 --> Total execution time: 1.3501
DEBUG - 2013-08-29 15:17:08 --> Config Class Initialized
DEBUG - 2013-08-29 15:17:08 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:17:08 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:17:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:17:08 --> URI Class Initialized
DEBUG - 2013-08-29 15:17:08 --> Router Class Initialized
ERROR - 2013-08-29 15:17:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:18:28 --> Config Class Initialized
DEBUG - 2013-08-29 15:18:28 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:18:28 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:18:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:18:28 --> URI Class Initialized
DEBUG - 2013-08-29 15:18:28 --> Router Class Initialized
DEBUG - 2013-08-29 15:18:28 --> Output Class Initialized
DEBUG - 2013-08-29 15:18:28 --> Security Class Initialized
DEBUG - 2013-08-29 15:18:28 --> Input Class Initialized
DEBUG - 2013-08-29 15:18:29 --> XSS Filtering completed
DEBUG - 2013-08-29 15:18:29 --> XSS Filtering completed
DEBUG - 2013-08-29 15:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:18:29 --> Language Class Initialized
DEBUG - 2013-08-29 15:18:29 --> Loader Class Initialized
DEBUG - 2013-08-29 15:18:29 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:18:29 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:18:29 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:18:29 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:18:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:18:29 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:18:29 --> Session Class Initialized
DEBUG - 2013-08-29 15:18:29 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:18:29 --> Session routines successfully run
DEBUG - 2013-08-29 15:18:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:18:29 --> Controller Class Initialized
ERROR - 2013-08-29 15:18:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:18:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:18:29 --> Model Class Initialized
DEBUG - 2013-08-29 15:18:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:18:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:18:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:18:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:18:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:18:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:18:29 --> Model Class Initialized
ERROR - 2013-08-29 15:18:29 --> Severity: Notice  --> Undefined index: upriv_groups_ugrp_fk C:\xampp\htdocs\school\application\controllers\admin\group_privileges.php 121
ERROR - 2013-08-29 15:18:29 --> Severity: Notice  --> Undefined index: upriv_groups_upriv_fk C:\xampp\htdocs\school\application\controllers\admin\group_privileges.php 122
DEBUG - 2013-08-29 15:18:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:18:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:18:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:18:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:18:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:18:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:18:30 --> File loaded: application/views/group_privileges/edit.php
DEBUG - 2013-08-29 15:18:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:18:30 --> Final output sent to browser
DEBUG - 2013-08-29 15:18:30 --> Total execution time: 1.5251
DEBUG - 2013-08-29 15:18:30 --> Config Class Initialized
DEBUG - 2013-08-29 15:18:30 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:18:30 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:18:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:18:30 --> URI Class Initialized
DEBUG - 2013-08-29 15:18:30 --> Router Class Initialized
ERROR - 2013-08-29 15:18:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:21:42 --> Config Class Initialized
DEBUG - 2013-08-29 15:21:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:21:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:21:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:21:42 --> URI Class Initialized
DEBUG - 2013-08-29 15:21:42 --> Router Class Initialized
DEBUG - 2013-08-29 15:21:42 --> Output Class Initialized
DEBUG - 2013-08-29 15:21:42 --> Security Class Initialized
DEBUG - 2013-08-29 15:21:42 --> Input Class Initialized
DEBUG - 2013-08-29 15:21:42 --> XSS Filtering completed
DEBUG - 2013-08-29 15:21:42 --> XSS Filtering completed
DEBUG - 2013-08-29 15:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:21:42 --> Language Class Initialized
DEBUG - 2013-08-29 15:21:42 --> Loader Class Initialized
DEBUG - 2013-08-29 15:21:42 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:21:43 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:21:43 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:21:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:21:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:21:43 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:21:43 --> Session Class Initialized
DEBUG - 2013-08-29 15:21:43 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:21:43 --> Session routines successfully run
DEBUG - 2013-08-29 15:21:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:21:43 --> Controller Class Initialized
ERROR - 2013-08-29 15:21:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:21:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:21:43 --> Model Class Initialized
DEBUG - 2013-08-29 15:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:21:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:21:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:21:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:21:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:21:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:21:43 --> Model Class Initialized
DEBUG - 2013-08-29 15:21:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:21:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:21:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:21:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:21:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:21:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:21:43 --> File loaded: application/views/group_privileges/edit.php
DEBUG - 2013-08-29 15:21:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:21:43 --> Final output sent to browser
DEBUG - 2013-08-29 15:21:43 --> Total execution time: 1.3951
DEBUG - 2013-08-29 15:21:44 --> Config Class Initialized
DEBUG - 2013-08-29 15:21:44 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:21:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:21:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:21:44 --> URI Class Initialized
DEBUG - 2013-08-29 15:21:44 --> Router Class Initialized
ERROR - 2013-08-29 15:21:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:21:54 --> Config Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:21:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:21:54 --> URI Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Router Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Output Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Security Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Input Class Initialized
DEBUG - 2013-08-29 15:21:54 --> XSS Filtering completed
DEBUG - 2013-08-29 15:21:54 --> XSS Filtering completed
DEBUG - 2013-08-29 15:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:21:54 --> Language Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Loader Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:21:54 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:21:54 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:21:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:21:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:21:54 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Session Class Initialized
DEBUG - 2013-08-29 15:21:54 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:21:54 --> Session routines successfully run
DEBUG - 2013-08-29 15:21:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:21:55 --> Controller Class Initialized
ERROR - 2013-08-29 15:21:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:21:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:21:55 --> Model Class Initialized
DEBUG - 2013-08-29 15:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:21:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:21:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:21:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:21:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:21:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:21:55 --> Model Class Initialized
DEBUG - 2013-08-29 15:21:55 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:21:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:21:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:21:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:21:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:21:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:21:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:21:55 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-29 15:21:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:21:55 --> Final output sent to browser
DEBUG - 2013-08-29 15:21:55 --> Total execution time: 1.7691
DEBUG - 2013-08-29 15:21:56 --> Config Class Initialized
DEBUG - 2013-08-29 15:21:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:21:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:21:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:21:56 --> URI Class Initialized
DEBUG - 2013-08-29 15:21:56 --> Router Class Initialized
ERROR - 2013-08-29 15:21:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:24:55 --> Config Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:24:55 --> URI Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Router Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Output Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Security Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Input Class Initialized
DEBUG - 2013-08-29 15:24:55 --> XSS Filtering completed
DEBUG - 2013-08-29 15:24:55 --> XSS Filtering completed
DEBUG - 2013-08-29 15:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:24:55 --> Language Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Loader Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:24:55 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:24:55 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:24:55 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:24:55 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:24:55 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Session Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:24:55 --> Session routines successfully run
DEBUG - 2013-08-29 15:24:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Controller Class Initialized
ERROR - 2013-08-29 15:24:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:24:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:24:55 --> Model Class Initialized
DEBUG - 2013-08-29 15:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:24:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:24:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:24:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:24:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:24:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:24:56 --> Model Class Initialized
DEBUG - 2013-08-29 15:24:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:24:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:24:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:24:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:24:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:24:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:24:56 --> File loaded: application/views/group_privileges/edit.php
DEBUG - 2013-08-29 15:24:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:24:56 --> Final output sent to browser
DEBUG - 2013-08-29 15:24:56 --> Total execution time: 1.4511
DEBUG - 2013-08-29 15:24:56 --> Config Class Initialized
DEBUG - 2013-08-29 15:24:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:24:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:24:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:24:56 --> URI Class Initialized
DEBUG - 2013-08-29 15:24:56 --> Router Class Initialized
ERROR - 2013-08-29 15:24:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:25:02 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:02 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:03 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Router Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Output Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Security Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Input Class Initialized
DEBUG - 2013-08-29 15:25:03 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:03 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:25:03 --> Language Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Loader Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:25:03 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:25:03 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:25:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:25:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:25:03 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Session Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:25:03 --> Session routines successfully run
DEBUG - 2013-08-29 15:25:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Controller Class Initialized
ERROR - 2013-08-29 15:25:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:03 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:25:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:25:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:25:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:25:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:04 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:25:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:25:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:25:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:25:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:25:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:25:04 --> File loaded: application/views/group_privileges/show.php
DEBUG - 2013-08-29 15:25:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:25:04 --> Final output sent to browser
DEBUG - 2013-08-29 15:25:04 --> Total execution time: 1.4811
DEBUG - 2013-08-29 15:25:04 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:04 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:04 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:04 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:04 --> Router Class Initialized
ERROR - 2013-08-29 15:25:04 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:25:09 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:09 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Router Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Output Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Security Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Input Class Initialized
DEBUG - 2013-08-29 15:25:09 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:09 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:25:09 --> Language Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Loader Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:25:09 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:25:09 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:25:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:25:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:25:09 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Session Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:25:09 --> Session routines successfully run
DEBUG - 2013-08-29 15:25:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:25:09 --> Controller Class Initialized
ERROR - 2013-08-29 15:25:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:10 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:25:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:25:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:25:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:25:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:10 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:10 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:25:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:25:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:25:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:25:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:25:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:25:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:25:10 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:25:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:25:10 --> Final output sent to browser
DEBUG - 2013-08-29 15:25:10 --> Total execution time: 1.6271
DEBUG - 2013-08-29 15:25:11 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:11 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:11 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:11 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:11 --> Router Class Initialized
ERROR - 2013-08-29 15:25:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:25:13 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:13 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:13 --> Router Class Initialized
DEBUG - 2013-08-29 15:25:13 --> Output Class Initialized
DEBUG - 2013-08-29 15:25:13 --> Security Class Initialized
DEBUG - 2013-08-29 15:25:13 --> Input Class Initialized
DEBUG - 2013-08-29 15:25:13 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:14 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:25:14 --> Language Class Initialized
DEBUG - 2013-08-29 15:25:14 --> Loader Class Initialized
DEBUG - 2013-08-29 15:25:14 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:25:14 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:25:14 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:25:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:25:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:25:14 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:25:14 --> Session Class Initialized
DEBUG - 2013-08-29 15:25:14 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:25:14 --> Session routines successfully run
DEBUG - 2013-08-29 15:25:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:25:14 --> Controller Class Initialized
ERROR - 2013-08-29 15:25:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:14 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:25:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:25:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:25:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:25:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:15 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:25:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:25:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:25:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:25:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:25:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:25:15 --> File loaded: application/views/group_privileges/edit.php
DEBUG - 2013-08-29 15:25:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:25:15 --> Final output sent to browser
DEBUG - 2013-08-29 15:25:15 --> Total execution time: 1.6991
DEBUG - 2013-08-29 15:25:15 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:15 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:15 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:15 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:15 --> Router Class Initialized
ERROR - 2013-08-29 15:25:15 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:25:23 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:23 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:24 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Router Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Output Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Security Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Input Class Initialized
DEBUG - 2013-08-29 15:25:24 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:24 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:24 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:24 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:24 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:25:24 --> Language Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Loader Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:25:24 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:25:24 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:25:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:25:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:25:24 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Session Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:25:24 --> Session routines successfully run
DEBUG - 2013-08-29 15:25:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Controller Class Initialized
ERROR - 2013-08-29 15:25:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:24 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:25:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:25:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:25:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:25:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:25 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:25:25 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:25 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Router Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Output Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Security Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Input Class Initialized
DEBUG - 2013-08-29 15:25:25 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:25 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:25:25 --> Language Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Loader Class Initialized
DEBUG - 2013-08-29 15:25:25 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:25:25 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:25:25 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:25:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:25:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:25:26 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:25:26 --> Session Class Initialized
DEBUG - 2013-08-29 15:25:26 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:25:26 --> Session routines successfully run
DEBUG - 2013-08-29 15:25:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:25:26 --> Controller Class Initialized
ERROR - 2013-08-29 15:25:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:26 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:25:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:25:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:25:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:25:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:26 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:25:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:25:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:25:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:25:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:25:27 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:25:27 --> File loaded: application/views/group_privileges/show.php
DEBUG - 2013-08-29 15:25:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:25:27 --> Final output sent to browser
DEBUG - 2013-08-29 15:25:27 --> Total execution time: 1.7851
DEBUG - 2013-08-29 15:25:27 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:27 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:27 --> Router Class Initialized
ERROR - 2013-08-29 15:25:27 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:25:31 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:31 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:31 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:31 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:31 --> Router Class Initialized
DEBUG - 2013-08-29 15:25:31 --> Output Class Initialized
DEBUG - 2013-08-29 15:25:31 --> Security Class Initialized
DEBUG - 2013-08-29 15:25:31 --> Input Class Initialized
DEBUG - 2013-08-29 15:25:31 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:31 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:25:32 --> Language Class Initialized
DEBUG - 2013-08-29 15:25:32 --> Loader Class Initialized
DEBUG - 2013-08-29 15:25:32 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:25:32 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:25:32 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:25:32 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:25:32 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:25:32 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:25:32 --> Session Class Initialized
DEBUG - 2013-08-29 15:25:32 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:25:32 --> Session garbage collection performed.
DEBUG - 2013-08-29 15:25:32 --> Session routines successfully run
DEBUG - 2013-08-29 15:25:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:25:32 --> Controller Class Initialized
ERROR - 2013-08-29 15:25:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:32 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:25:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:25:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:25:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:25:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:32 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:32 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:25:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:25:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:25:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:25:33 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:25:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:25:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:25:33 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:25:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:25:33 --> Final output sent to browser
DEBUG - 2013-08-29 15:25:33 --> Total execution time: 1.5921
DEBUG - 2013-08-29 15:25:33 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:33 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:33 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:33 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:33 --> Router Class Initialized
ERROR - 2013-08-29 15:25:33 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:25:42 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:42 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Router Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Output Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Security Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Input Class Initialized
DEBUG - 2013-08-29 15:25:42 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:42 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:25:42 --> Language Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Loader Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:25:42 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:25:42 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:25:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:25:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:25:42 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Session Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:25:42 --> Session routines successfully run
DEBUG - 2013-08-29 15:25:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:25:42 --> Controller Class Initialized
ERROR - 2013-08-29 15:25:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:43 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:25:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:25:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:25:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:25:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:43 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:25:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:25:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:25:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:25:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:25:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:25:43 --> File loaded: application/views/group_privileges/new.php
DEBUG - 2013-08-29 15:25:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:25:43 --> Final output sent to browser
DEBUG - 2013-08-29 15:25:43 --> Total execution time: 1.4341
DEBUG - 2013-08-29 15:25:43 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:43 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:44 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:44 --> Router Class Initialized
ERROR - 2013-08-29 15:25:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:25:50 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:50 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Router Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Output Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Security Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Input Class Initialized
DEBUG - 2013-08-29 15:25:50 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:50 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:50 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:50 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:50 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:25:50 --> Language Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Loader Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:25:50 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:25:50 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:25:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:25:50 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:25:50 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Session Class Initialized
DEBUG - 2013-08-29 15:25:50 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:25:50 --> Session routines successfully run
DEBUG - 2013-08-29 15:25:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Controller Class Initialized
ERROR - 2013-08-29 15:25:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:51 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:25:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:25:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:25:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:25:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:51 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:25:51 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:51 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Router Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Output Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Security Class Initialized
DEBUG - 2013-08-29 15:25:51 --> Input Class Initialized
DEBUG - 2013-08-29 15:25:51 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:52 --> XSS Filtering completed
DEBUG - 2013-08-29 15:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:25:52 --> Language Class Initialized
DEBUG - 2013-08-29 15:25:52 --> Loader Class Initialized
DEBUG - 2013-08-29 15:25:52 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:25:52 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:25:52 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:25:52 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:25:52 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:25:52 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:25:52 --> Session Class Initialized
DEBUG - 2013-08-29 15:25:52 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:25:52 --> Session routines successfully run
DEBUG - 2013-08-29 15:25:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:25:52 --> Controller Class Initialized
ERROR - 2013-08-29 15:25:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:52 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:25:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:25:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:25:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:25:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:25:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:25:53 --> Model Class Initialized
DEBUG - 2013-08-29 15:25:53 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:25:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:25:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:25:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:25:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:25:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:25:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:25:53 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:25:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:25:53 --> Final output sent to browser
DEBUG - 2013-08-29 15:25:53 --> Total execution time: 2.0111
DEBUG - 2013-08-29 15:25:53 --> Config Class Initialized
DEBUG - 2013-08-29 15:25:53 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:25:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:25:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:25:53 --> URI Class Initialized
DEBUG - 2013-08-29 15:25:54 --> Router Class Initialized
ERROR - 2013-08-29 15:25:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:26:49 --> Config Class Initialized
DEBUG - 2013-08-29 15:26:49 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:26:49 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:26:49 --> URI Class Initialized
DEBUG - 2013-08-29 15:26:49 --> Router Class Initialized
DEBUG - 2013-08-29 15:26:49 --> Output Class Initialized
DEBUG - 2013-08-29 15:26:49 --> Security Class Initialized
DEBUG - 2013-08-29 15:26:49 --> Input Class Initialized
DEBUG - 2013-08-29 15:26:50 --> XSS Filtering completed
DEBUG - 2013-08-29 15:26:50 --> XSS Filtering completed
DEBUG - 2013-08-29 15:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:26:50 --> Language Class Initialized
DEBUG - 2013-08-29 15:26:50 --> Loader Class Initialized
DEBUG - 2013-08-29 15:26:50 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:26:50 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:26:50 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:26:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:26:50 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:26:50 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:26:50 --> Session Class Initialized
DEBUG - 2013-08-29 15:26:50 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:26:50 --> Session routines successfully run
DEBUG - 2013-08-29 15:26:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:26:50 --> Controller Class Initialized
ERROR - 2013-08-29 15:26:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:26:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:26:50 --> Model Class Initialized
DEBUG - 2013-08-29 15:26:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:26:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:26:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:26:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:26:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:26:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:26:50 --> Model Class Initialized
DEBUG - 2013-08-29 15:26:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:26:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:26:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:26:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:26:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:26:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:26:51 --> File loaded: application/views/group_privileges/new.php
DEBUG - 2013-08-29 15:26:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:26:51 --> Final output sent to browser
DEBUG - 2013-08-29 15:26:51 --> Total execution time: 1.5651
DEBUG - 2013-08-29 15:26:51 --> Config Class Initialized
DEBUG - 2013-08-29 15:26:51 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:26:51 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:26:51 --> URI Class Initialized
DEBUG - 2013-08-29 15:26:51 --> Router Class Initialized
ERROR - 2013-08-29 15:26:51 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:26:56 --> Config Class Initialized
DEBUG - 2013-08-29 15:26:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:26:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:26:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:26:56 --> URI Class Initialized
DEBUG - 2013-08-29 15:26:56 --> Router Class Initialized
DEBUG - 2013-08-29 15:26:56 --> Output Class Initialized
DEBUG - 2013-08-29 15:26:56 --> Security Class Initialized
DEBUG - 2013-08-29 15:26:56 --> Input Class Initialized
DEBUG - 2013-08-29 15:26:56 --> XSS Filtering completed
DEBUG - 2013-08-29 15:26:56 --> XSS Filtering completed
DEBUG - 2013-08-29 15:26:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:26:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:26:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:26:57 --> Language Class Initialized
DEBUG - 2013-08-29 15:26:57 --> Loader Class Initialized
DEBUG - 2013-08-29 15:26:57 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:26:57 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:26:57 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:26:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:26:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:26:57 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:26:57 --> Session Class Initialized
DEBUG - 2013-08-29 15:26:57 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:26:57 --> Session routines successfully run
DEBUG - 2013-08-29 15:26:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:26:57 --> Controller Class Initialized
ERROR - 2013-08-29 15:26:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:26:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:26:57 --> Model Class Initialized
DEBUG - 2013-08-29 15:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:26:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:26:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:26:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:26:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:26:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:26:57 --> Model Class Initialized
DEBUG - 2013-08-29 15:26:57 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:26:58 --> Config Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:26:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:26:58 --> URI Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Router Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Output Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Security Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Input Class Initialized
DEBUG - 2013-08-29 15:26:58 --> XSS Filtering completed
DEBUG - 2013-08-29 15:26:58 --> XSS Filtering completed
DEBUG - 2013-08-29 15:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:26:58 --> Language Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Loader Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:26:58 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:26:58 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:26:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:26:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:26:58 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Session Class Initialized
DEBUG - 2013-08-29 15:26:58 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:26:59 --> Session routines successfully run
DEBUG - 2013-08-29 15:26:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:26:59 --> Controller Class Initialized
ERROR - 2013-08-29 15:26:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:26:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:26:59 --> Model Class Initialized
DEBUG - 2013-08-29 15:26:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:26:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:26:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:26:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:26:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:26:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:26:59 --> Model Class Initialized
DEBUG - 2013-08-29 15:26:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:26:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:26:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:26:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:26:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:26:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:26:59 --> File loaded: application/views/group_privileges/new.php
DEBUG - 2013-08-29 15:26:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:26:59 --> Final output sent to browser
DEBUG - 2013-08-29 15:26:59 --> Total execution time: 1.8441
DEBUG - 2013-08-29 15:27:00 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:00 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:00 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:00 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:00 --> Router Class Initialized
ERROR - 2013-08-29 15:27:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:27:05 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:05 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:05 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:05 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:05 --> Router Class Initialized
DEBUG - 2013-08-29 15:27:05 --> Output Class Initialized
DEBUG - 2013-08-29 15:27:05 --> Security Class Initialized
DEBUG - 2013-08-29 15:27:05 --> Input Class Initialized
DEBUG - 2013-08-29 15:27:05 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:05 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:27:05 --> Language Class Initialized
DEBUG - 2013-08-29 15:27:05 --> Loader Class Initialized
DEBUG - 2013-08-29 15:27:05 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:27:05 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:27:05 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:27:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:27:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:27:06 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:27:06 --> Session Class Initialized
DEBUG - 2013-08-29 15:27:06 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:27:06 --> Session routines successfully run
DEBUG - 2013-08-29 15:27:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:27:06 --> Controller Class Initialized
ERROR - 2013-08-29 15:27:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:06 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:27:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:27:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:27:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:27:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:06 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:06 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:27:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:27:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:27:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:27:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:27:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:27:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:27:06 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:27:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:27:06 --> Final output sent to browser
DEBUG - 2013-08-29 15:27:07 --> Total execution time: 1.5291
DEBUG - 2013-08-29 15:27:07 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:07 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:07 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:07 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:07 --> Router Class Initialized
ERROR - 2013-08-29 15:27:07 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:27:14 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:14 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:14 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:14 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:14 --> Router Class Initialized
DEBUG - 2013-08-29 15:27:14 --> Output Class Initialized
DEBUG - 2013-08-29 15:27:14 --> Security Class Initialized
DEBUG - 2013-08-29 15:27:14 --> Input Class Initialized
DEBUG - 2013-08-29 15:27:14 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:14 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:27:14 --> Language Class Initialized
DEBUG - 2013-08-29 15:27:14 --> Loader Class Initialized
DEBUG - 2013-08-29 15:27:14 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:27:14 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:27:14 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:27:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:27:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:27:14 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:27:14 --> Session Class Initialized
DEBUG - 2013-08-29 15:27:15 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:27:15 --> Session routines successfully run
DEBUG - 2013-08-29 15:27:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:27:15 --> Controller Class Initialized
ERROR - 2013-08-29 15:27:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:15 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:27:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:27:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:27:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:27:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:15 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:27:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:27:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:27:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:27:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:27:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:27:15 --> File loaded: application/views/group_privileges/edit.php
DEBUG - 2013-08-29 15:27:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:27:15 --> Final output sent to browser
DEBUG - 2013-08-29 15:27:15 --> Total execution time: 1.6761
DEBUG - 2013-08-29 15:27:16 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:16 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:16 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:16 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:16 --> Router Class Initialized
ERROR - 2013-08-29 15:27:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:27:23 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:23 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:23 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:23 --> Router Class Initialized
DEBUG - 2013-08-29 15:27:23 --> Output Class Initialized
DEBUG - 2013-08-29 15:27:23 --> Security Class Initialized
DEBUG - 2013-08-29 15:27:23 --> Input Class Initialized
DEBUG - 2013-08-29 15:27:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:27:24 --> Language Class Initialized
DEBUG - 2013-08-29 15:27:24 --> Loader Class Initialized
DEBUG - 2013-08-29 15:27:24 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:27:24 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:27:24 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:27:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:27:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:27:24 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:27:24 --> Session Class Initialized
DEBUG - 2013-08-29 15:27:24 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:27:24 --> Session garbage collection performed.
DEBUG - 2013-08-29 15:27:24 --> Session routines successfully run
DEBUG - 2013-08-29 15:27:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:27:24 --> Controller Class Initialized
ERROR - 2013-08-29 15:27:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:24 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:27:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:27:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:27:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:27:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:24 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:27:25 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:25 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Router Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Output Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Security Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Input Class Initialized
DEBUG - 2013-08-29 15:27:25 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:25 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:27:25 --> Language Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Loader Class Initialized
DEBUG - 2013-08-29 15:27:25 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:27:25 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:27:25 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:27:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:27:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:27:25 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:27:26 --> Session Class Initialized
DEBUG - 2013-08-29 15:27:26 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:27:26 --> Session routines successfully run
DEBUG - 2013-08-29 15:27:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:27:26 --> Controller Class Initialized
ERROR - 2013-08-29 15:27:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:26 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:27:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:27:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:27:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:27:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:26 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:27:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:27:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:27:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:27:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:27:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:27:26 --> File loaded: application/views/group_privileges/edit.php
DEBUG - 2013-08-29 15:27:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:27:27 --> Final output sent to browser
DEBUG - 2013-08-29 15:27:27 --> Total execution time: 1.8641
DEBUG - 2013-08-29 15:27:27 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:27 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:27 --> Router Class Initialized
ERROR - 2013-08-29 15:27:27 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:27:30 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:30 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:30 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:30 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:30 --> Router Class Initialized
DEBUG - 2013-08-29 15:27:30 --> Output Class Initialized
DEBUG - 2013-08-29 15:27:31 --> Security Class Initialized
DEBUG - 2013-08-29 15:27:31 --> Input Class Initialized
DEBUG - 2013-08-29 15:27:31 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:31 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:27:31 --> Language Class Initialized
DEBUG - 2013-08-29 15:27:31 --> Loader Class Initialized
DEBUG - 2013-08-29 15:27:31 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:27:31 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:27:31 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:27:31 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:27:31 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:27:31 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:27:31 --> Session Class Initialized
DEBUG - 2013-08-29 15:27:31 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:27:31 --> Session garbage collection performed.
DEBUG - 2013-08-29 15:27:31 --> Session routines successfully run
DEBUG - 2013-08-29 15:27:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:27:31 --> Controller Class Initialized
ERROR - 2013-08-29 15:27:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:31 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:27:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:27:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:27:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:27:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:32 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:27:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:27:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:27:32 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:27:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:27:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:27:32 --> File loaded: application/views/group_privileges/show.php
DEBUG - 2013-08-29 15:27:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:27:32 --> Final output sent to browser
DEBUG - 2013-08-29 15:27:32 --> Total execution time: 1.6931
DEBUG - 2013-08-29 15:27:32 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:32 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:32 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:32 --> Router Class Initialized
ERROR - 2013-08-29 15:27:32 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:27:36 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:36 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Router Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Output Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Security Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Input Class Initialized
DEBUG - 2013-08-29 15:27:36 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:36 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:27:36 --> Language Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Loader Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:27:36 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:27:36 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:27:36 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:27:36 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:27:36 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Session Class Initialized
DEBUG - 2013-08-29 15:27:36 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:27:37 --> Session routines successfully run
DEBUG - 2013-08-29 15:27:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:27:37 --> Controller Class Initialized
ERROR - 2013-08-29 15:27:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:37 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:27:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:27:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:27:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:27:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:37 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:37 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:27:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:27:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:27:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:27:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:27:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:27:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:27:37 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:27:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:27:37 --> Final output sent to browser
DEBUG - 2013-08-29 15:27:38 --> Total execution time: 1.7901
DEBUG - 2013-08-29 15:27:38 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:38 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:38 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:38 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:38 --> Router Class Initialized
ERROR - 2013-08-29 15:27:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:27:43 --> Config Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:27:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:27:43 --> URI Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Router Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Output Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Security Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Input Class Initialized
DEBUG - 2013-08-29 15:27:43 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:43 --> XSS Filtering completed
DEBUG - 2013-08-29 15:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:27:43 --> Language Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Loader Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:27:43 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:27:43 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:27:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:27:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:27:43 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Session Class Initialized
DEBUG - 2013-08-29 15:27:43 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:27:43 --> Session routines successfully run
DEBUG - 2013-08-29 15:27:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:27:44 --> Controller Class Initialized
ERROR - 2013-08-29 15:27:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:44 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:27:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:27:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:27:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:27:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:27:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:27:44 --> Model Class Initialized
DEBUG - 2013-08-29 15:27:44 --> DB Transaction Failure
ERROR - 2013-08-29 15:27:44 --> Query error: Unknown column 'id' in 'where clause'
DEBUG - 2013-08-29 15:27:44 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 15:29:03 --> Config Class Initialized
DEBUG - 2013-08-29 15:29:03 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:29:03 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:29:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:29:03 --> URI Class Initialized
DEBUG - 2013-08-29 15:29:03 --> Router Class Initialized
DEBUG - 2013-08-29 15:29:03 --> Output Class Initialized
DEBUG - 2013-08-29 15:29:03 --> Security Class Initialized
DEBUG - 2013-08-29 15:29:03 --> Input Class Initialized
DEBUG - 2013-08-29 15:29:04 --> XSS Filtering completed
DEBUG - 2013-08-29 15:29:04 --> XSS Filtering completed
DEBUG - 2013-08-29 15:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:29:04 --> Language Class Initialized
DEBUG - 2013-08-29 15:29:04 --> Loader Class Initialized
DEBUG - 2013-08-29 15:29:04 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:29:04 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:29:04 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:29:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:29:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:29:04 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:29:04 --> Session Class Initialized
DEBUG - 2013-08-29 15:29:04 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:29:04 --> Session routines successfully run
DEBUG - 2013-08-29 15:29:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:29:04 --> Controller Class Initialized
ERROR - 2013-08-29 15:29:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:29:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:29:04 --> Model Class Initialized
DEBUG - 2013-08-29 15:29:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:29:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:29:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:29:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:29:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:29:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:29:05 --> Model Class Initialized
DEBUG - 2013-08-29 15:29:05 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:29:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:29:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:29:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:29:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:29:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:29:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:29:05 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:29:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:29:05 --> Final output sent to browser
DEBUG - 2013-08-29 15:29:05 --> Total execution time: 1.7571
DEBUG - 2013-08-29 15:29:05 --> Config Class Initialized
DEBUG - 2013-08-29 15:29:05 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:29:05 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:29:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:29:05 --> URI Class Initialized
DEBUG - 2013-08-29 15:29:05 --> Router Class Initialized
ERROR - 2013-08-29 15:29:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:29:59 --> Config Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:30:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:30:00 --> URI Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Router Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Output Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Security Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Input Class Initialized
DEBUG - 2013-08-29 15:30:00 --> XSS Filtering completed
DEBUG - 2013-08-29 15:30:00 --> XSS Filtering completed
DEBUG - 2013-08-29 15:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:30:00 --> Language Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Loader Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:30:00 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:30:00 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:30:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:30:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:30:00 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Session Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:30:00 --> Session routines successfully run
DEBUG - 2013-08-29 15:30:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:30:00 --> Controller Class Initialized
ERROR - 2013-08-29 15:30:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:30:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:30:00 --> Model Class Initialized
DEBUG - 2013-08-29 15:30:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:30:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:30:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:30:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:30:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:30:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:30:01 --> Model Class Initialized
DEBUG - 2013-08-29 15:30:01 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:30:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:30:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:30:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:30:01 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:30:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:30:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:30:01 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-29 15:30:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:30:01 --> Final output sent to browser
DEBUG - 2013-08-29 15:30:01 --> Total execution time: 1.7291
DEBUG - 2013-08-29 15:30:02 --> Config Class Initialized
DEBUG - 2013-08-29 15:30:02 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:30:02 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:30:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:30:02 --> URI Class Initialized
DEBUG - 2013-08-29 15:30:02 --> Router Class Initialized
ERROR - 2013-08-29 15:30:02 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:34:34 --> Config Class Initialized
DEBUG - 2013-08-29 15:34:34 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:34:34 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:34:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:34:34 --> URI Class Initialized
DEBUG - 2013-08-29 15:34:34 --> Router Class Initialized
DEBUG - 2013-08-29 15:34:35 --> Output Class Initialized
DEBUG - 2013-08-29 15:34:35 --> Security Class Initialized
DEBUG - 2013-08-29 15:34:35 --> Input Class Initialized
DEBUG - 2013-08-29 15:34:35 --> XSS Filtering completed
DEBUG - 2013-08-29 15:34:35 --> XSS Filtering completed
DEBUG - 2013-08-29 15:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:34:35 --> Language Class Initialized
DEBUG - 2013-08-29 15:34:35 --> Loader Class Initialized
DEBUG - 2013-08-29 15:34:35 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:34:35 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:34:35 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:34:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:34:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:34:35 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:34:35 --> Session Class Initialized
DEBUG - 2013-08-29 15:34:35 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:34:35 --> Session routines successfully run
DEBUG - 2013-08-29 15:34:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:34:35 --> Controller Class Initialized
ERROR - 2013-08-29 15:34:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:34:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:34:35 --> Model Class Initialized
DEBUG - 2013-08-29 15:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:34:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:34:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:34:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:34:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:34:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:34:36 --> Model Class Initialized
DEBUG - 2013-08-29 15:34:36 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:34:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:34:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:34:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:34:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:34:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:34:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:34:36 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-29 15:34:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:34:36 --> Final output sent to browser
DEBUG - 2013-08-29 15:34:36 --> Total execution time: 1.7391
DEBUG - 2013-08-29 15:34:36 --> Config Class Initialized
DEBUG - 2013-08-29 15:34:37 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:34:37 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:34:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:34:37 --> URI Class Initialized
DEBUG - 2013-08-29 15:34:37 --> Router Class Initialized
ERROR - 2013-08-29 15:34:37 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:34:39 --> Config Class Initialized
DEBUG - 2013-08-29 15:34:39 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:34:39 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:34:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:34:39 --> URI Class Initialized
DEBUG - 2013-08-29 15:34:39 --> Router Class Initialized
DEBUG - 2013-08-29 15:34:39 --> Output Class Initialized
DEBUG - 2013-08-29 15:34:39 --> Security Class Initialized
DEBUG - 2013-08-29 15:34:39 --> Input Class Initialized
DEBUG - 2013-08-29 15:34:39 --> XSS Filtering completed
DEBUG - 2013-08-29 15:34:39 --> XSS Filtering completed
DEBUG - 2013-08-29 15:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:34:39 --> Language Class Initialized
DEBUG - 2013-08-29 15:34:39 --> Loader Class Initialized
DEBUG - 2013-08-29 15:34:39 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:34:39 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:34:39 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:34:40 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:34:40 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:34:40 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:34:40 --> Session Class Initialized
DEBUG - 2013-08-29 15:34:40 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:34:40 --> Session routines successfully run
DEBUG - 2013-08-29 15:34:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:34:40 --> Controller Class Initialized
ERROR - 2013-08-29 15:34:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:34:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:34:40 --> Model Class Initialized
DEBUG - 2013-08-29 15:34:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:34:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:34:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:34:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:34:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:34:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:34:40 --> Model Class Initialized
DEBUG - 2013-08-29 15:34:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:34:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:34:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:34:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:34:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:34:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:34:40 --> File loaded: application/views/group_privileges/edit.php
DEBUG - 2013-08-29 15:34:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:34:41 --> Final output sent to browser
DEBUG - 2013-08-29 15:34:41 --> Total execution time: 1.8551
DEBUG - 2013-08-29 15:34:41 --> Config Class Initialized
DEBUG - 2013-08-29 15:34:41 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:34:41 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:34:41 --> URI Class Initialized
DEBUG - 2013-08-29 15:34:41 --> Router Class Initialized
ERROR - 2013-08-29 15:34:41 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:34:44 --> Config Class Initialized
DEBUG - 2013-08-29 15:34:44 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:34:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:34:44 --> URI Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Router Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Output Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Security Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Input Class Initialized
DEBUG - 2013-08-29 15:34:45 --> XSS Filtering completed
DEBUG - 2013-08-29 15:34:45 --> XSS Filtering completed
DEBUG - 2013-08-29 15:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:34:45 --> Language Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Loader Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:34:45 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:34:45 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:34:45 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:34:45 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:34:45 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Session Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:34:45 --> Session routines successfully run
DEBUG - 2013-08-29 15:34:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Controller Class Initialized
ERROR - 2013-08-29 15:34:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:34:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:34:45 --> Model Class Initialized
DEBUG - 2013-08-29 15:34:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:34:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:34:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:34:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:34:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:34:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:34:46 --> Model Class Initialized
DEBUG - 2013-08-29 15:34:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:34:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:34:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:34:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:34:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:34:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:34:46 --> File loaded: application/views/group_privileges/show.php
DEBUG - 2013-08-29 15:34:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:34:46 --> Final output sent to browser
DEBUG - 2013-08-29 15:34:46 --> Total execution time: 1.7581
DEBUG - 2013-08-29 15:34:46 --> Config Class Initialized
DEBUG - 2013-08-29 15:34:46 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:34:46 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:34:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:34:46 --> URI Class Initialized
DEBUG - 2013-08-29 15:34:47 --> Router Class Initialized
ERROR - 2013-08-29 15:34:47 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:39:23 --> Config Class Initialized
DEBUG - 2013-08-29 15:39:23 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:39:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:39:23 --> URI Class Initialized
DEBUG - 2013-08-29 15:39:23 --> Router Class Initialized
DEBUG - 2013-08-29 15:39:23 --> Output Class Initialized
DEBUG - 2013-08-29 15:39:23 --> Security Class Initialized
DEBUG - 2013-08-29 15:39:23 --> Input Class Initialized
DEBUG - 2013-08-29 15:39:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:39:23 --> Language Class Initialized
DEBUG - 2013-08-29 15:39:23 --> Loader Class Initialized
DEBUG - 2013-08-29 15:39:23 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:39:23 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:39:23 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:39:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:39:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:39:23 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:39:23 --> Session Class Initialized
DEBUG - 2013-08-29 15:39:24 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:39:24 --> Session routines successfully run
DEBUG - 2013-08-29 15:39:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:39:24 --> Controller Class Initialized
ERROR - 2013-08-29 15:39:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:39:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:39:24 --> Model Class Initialized
DEBUG - 2013-08-29 15:39:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:39:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:39:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:39:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:39:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:39:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:39:24 --> Model Class Initialized
DEBUG - 2013-08-29 15:39:24 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:39:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:39:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:39:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:39:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:39:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:39:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:39:24 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:39:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:39:24 --> Final output sent to browser
DEBUG - 2013-08-29 15:39:25 --> Total execution time: 1.7251
DEBUG - 2013-08-29 15:39:25 --> Config Class Initialized
DEBUG - 2013-08-29 15:39:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:39:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:39:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:39:25 --> URI Class Initialized
DEBUG - 2013-08-29 15:39:25 --> Router Class Initialized
ERROR - 2013-08-29 15:39:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:39:43 --> Config Class Initialized
DEBUG - 2013-08-29 15:39:43 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:39:43 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:39:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:39:43 --> URI Class Initialized
DEBUG - 2013-08-29 15:39:43 --> Router Class Initialized
DEBUG - 2013-08-29 15:39:43 --> Output Class Initialized
DEBUG - 2013-08-29 15:39:43 --> Security Class Initialized
DEBUG - 2013-08-29 15:39:43 --> Input Class Initialized
DEBUG - 2013-08-29 15:39:44 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:44 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:44 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:44 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:44 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:39:44 --> Language Class Initialized
DEBUG - 2013-08-29 15:39:44 --> Loader Class Initialized
DEBUG - 2013-08-29 15:39:44 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:39:44 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:39:44 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:39:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:39:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:39:44 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:39:44 --> Session Class Initialized
DEBUG - 2013-08-29 15:39:44 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:39:44 --> Session routines successfully run
DEBUG - 2013-08-29 15:39:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:39:44 --> Controller Class Initialized
ERROR - 2013-08-29 15:39:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:39:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:39:44 --> Model Class Initialized
DEBUG - 2013-08-29 15:39:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:39:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:39:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:39:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:39:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:39:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:39:45 --> Model Class Initialized
DEBUG - 2013-08-29 15:39:45 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:39:45 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:45 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:45 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:45 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:45 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:45 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:45 --> XSS Filtering completed
DEBUG - 2013-08-29 15:39:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:39:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:39:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:39:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:39:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:39:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:39:45 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:39:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:39:46 --> Final output sent to browser
DEBUG - 2013-08-29 15:39:46 --> Total execution time: 2.4181
DEBUG - 2013-08-29 15:39:46 --> Config Class Initialized
DEBUG - 2013-08-29 15:39:46 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:39:46 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:39:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:39:46 --> URI Class Initialized
DEBUG - 2013-08-29 15:39:46 --> Router Class Initialized
ERROR - 2013-08-29 15:39:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:43:41 --> Config Class Initialized
DEBUG - 2013-08-29 15:43:41 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:43:41 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:43:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:43:41 --> URI Class Initialized
DEBUG - 2013-08-29 15:43:41 --> Router Class Initialized
DEBUG - 2013-08-29 15:43:41 --> Output Class Initialized
DEBUG - 2013-08-29 15:43:41 --> Security Class Initialized
DEBUG - 2013-08-29 15:43:41 --> Input Class Initialized
DEBUG - 2013-08-29 15:43:41 --> XSS Filtering completed
DEBUG - 2013-08-29 15:43:41 --> XSS Filtering completed
DEBUG - 2013-08-29 15:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:43:41 --> Language Class Initialized
DEBUG - 2013-08-29 15:43:41 --> Loader Class Initialized
DEBUG - 2013-08-29 15:43:41 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:43:41 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:43:41 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:43:41 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:43:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:43:42 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:43:42 --> Session Class Initialized
DEBUG - 2013-08-29 15:43:42 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:43:42 --> Session routines successfully run
DEBUG - 2013-08-29 15:43:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:43:42 --> Controller Class Initialized
ERROR - 2013-08-29 15:43:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:43:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:43:42 --> Model Class Initialized
DEBUG - 2013-08-29 15:43:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:43:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:43:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:43:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:43:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:43:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:43:42 --> Model Class Initialized
DEBUG - 2013-08-29 15:46:10 --> Config Class Initialized
DEBUG - 2013-08-29 15:46:10 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:46:10 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:46:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:46:10 --> URI Class Initialized
DEBUG - 2013-08-29 15:46:10 --> Router Class Initialized
DEBUG - 2013-08-29 15:46:10 --> Output Class Initialized
DEBUG - 2013-08-29 15:46:10 --> Security Class Initialized
DEBUG - 2013-08-29 15:46:10 --> Input Class Initialized
DEBUG - 2013-08-29 15:46:10 --> XSS Filtering completed
DEBUG - 2013-08-29 15:46:10 --> XSS Filtering completed
DEBUG - 2013-08-29 15:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:46:11 --> Language Class Initialized
DEBUG - 2013-08-29 15:46:11 --> Loader Class Initialized
DEBUG - 2013-08-29 15:46:11 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:46:11 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:46:11 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:46:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:46:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:46:11 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:46:11 --> Session Class Initialized
DEBUG - 2013-08-29 15:46:11 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:46:11 --> Session routines successfully run
DEBUG - 2013-08-29 15:46:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:46:11 --> Controller Class Initialized
ERROR - 2013-08-29 15:46:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:46:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:46:11 --> Model Class Initialized
DEBUG - 2013-08-29 15:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:46:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:46:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:46:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:46:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:46:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:46:11 --> Model Class Initialized
DEBUG - 2013-08-29 15:46:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:46:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:46:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:46:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:46:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:46:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:46:12 --> File loaded: application/views/user_privileges/new.php
DEBUG - 2013-08-29 15:46:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:46:12 --> Final output sent to browser
DEBUG - 2013-08-29 15:46:12 --> Total execution time: 1.7381
DEBUG - 2013-08-29 15:46:12 --> Config Class Initialized
DEBUG - 2013-08-29 15:46:12 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:46:12 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:46:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:46:12 --> URI Class Initialized
DEBUG - 2013-08-29 15:46:12 --> Router Class Initialized
ERROR - 2013-08-29 15:46:12 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:50:06 --> Config Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:50:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:50:06 --> URI Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Router Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Output Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Security Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Input Class Initialized
DEBUG - 2013-08-29 15:50:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:50:06 --> Language Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Loader Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:50:06 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:50:06 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:50:06 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:50:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:50:06 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Session Class Initialized
DEBUG - 2013-08-29 15:50:06 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:50:07 --> Session routines successfully run
DEBUG - 2013-08-29 15:50:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:50:07 --> Controller Class Initialized
ERROR - 2013-08-29 15:50:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:50:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:50:07 --> Model Class Initialized
DEBUG - 2013-08-29 15:50:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:50:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:50:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:50:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:50:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:50:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:50:07 --> Model Class Initialized
DEBUG - 2013-08-29 15:50:07 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:50:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:50:07 --> DB Transaction Failure
ERROR - 2013-08-29 15:50:07 --> Query error: Unknown column 'upriv_groups_upriv_fk' in 'where clause'
DEBUG - 2013-08-29 15:50:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 15:50:54 --> Config Class Initialized
DEBUG - 2013-08-29 15:50:54 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:50:54 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:50:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:50:54 --> URI Class Initialized
DEBUG - 2013-08-29 15:50:54 --> Router Class Initialized
DEBUG - 2013-08-29 15:50:54 --> Output Class Initialized
DEBUG - 2013-08-29 15:50:54 --> Security Class Initialized
DEBUG - 2013-08-29 15:50:54 --> Input Class Initialized
DEBUG - 2013-08-29 15:50:54 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:54 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:54 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:54 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:54 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:50:54 --> Language Class Initialized
DEBUG - 2013-08-29 15:50:54 --> Loader Class Initialized
DEBUG - 2013-08-29 15:50:54 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:50:54 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:50:54 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:50:55 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:50:55 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:50:55 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:50:55 --> Session Class Initialized
DEBUG - 2013-08-29 15:50:55 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:50:55 --> Session routines successfully run
DEBUG - 2013-08-29 15:50:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:50:55 --> Controller Class Initialized
ERROR - 2013-08-29 15:50:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:50:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:50:55 --> Model Class Initialized
DEBUG - 2013-08-29 15:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:50:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:50:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:50:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:50:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:50:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:50:55 --> Model Class Initialized
DEBUG - 2013-08-29 15:50:55 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:50:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:50:55 --> Config Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:50:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:50:56 --> URI Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Router Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Output Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Security Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Input Class Initialized
DEBUG - 2013-08-29 15:50:56 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:56 --> XSS Filtering completed
DEBUG - 2013-08-29 15:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:50:56 --> Language Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Loader Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:50:56 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:50:56 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:50:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:50:56 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:50:56 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Session Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:50:56 --> Session routines successfully run
DEBUG - 2013-08-29 15:50:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:50:56 --> Controller Class Initialized
ERROR - 2013-08-29 15:50:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:50:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:50:57 --> Model Class Initialized
DEBUG - 2013-08-29 15:50:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:50:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:50:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:50:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:50:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:50:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:50:57 --> Model Class Initialized
DEBUG - 2013-08-29 15:50:57 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:50:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:50:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:50:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:50:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:50:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:50:57 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 15:50:57 --> Severity: Notice  --> Undefined index: ugrp_name C:\xampp\htdocs\school\application\views\user_privileges\index.php 85
DEBUG - 2013-08-29 15:50:57 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:50:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:50:57 --> Final output sent to browser
DEBUG - 2013-08-29 15:50:57 --> Total execution time: 1.9241
DEBUG - 2013-08-29 15:50:58 --> Config Class Initialized
DEBUG - 2013-08-29 15:50:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:50:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:50:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:50:58 --> URI Class Initialized
DEBUG - 2013-08-29 15:50:58 --> Router Class Initialized
ERROR - 2013-08-29 15:50:58 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:51:01 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:01 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:01 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:01 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:01 --> Router Class Initialized
DEBUG - 2013-08-29 15:51:01 --> Output Class Initialized
DEBUG - 2013-08-29 15:51:01 --> Security Class Initialized
DEBUG - 2013-08-29 15:51:01 --> Input Class Initialized
DEBUG - 2013-08-29 15:51:02 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:02 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:51:02 --> Language Class Initialized
DEBUG - 2013-08-29 15:51:02 --> Loader Class Initialized
DEBUG - 2013-08-29 15:51:02 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:51:02 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:51:02 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:51:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:51:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:51:02 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:51:02 --> Session Class Initialized
DEBUG - 2013-08-29 15:51:02 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:51:02 --> Session routines successfully run
DEBUG - 2013-08-29 15:51:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:51:02 --> Controller Class Initialized
ERROR - 2013-08-29 15:51:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:02 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:51:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:51:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:51:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:51:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:03 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:51:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:51:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:51:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:51:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:51:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:51:03 --> File loaded: application/views/user_privileges/new.php
DEBUG - 2013-08-29 15:51:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:51:03 --> Final output sent to browser
DEBUG - 2013-08-29 15:51:03 --> Total execution time: 1.7581
DEBUG - 2013-08-29 15:51:03 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:03 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:03 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:03 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:03 --> Router Class Initialized
ERROR - 2013-08-29 15:51:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:51:05 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:05 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:05 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:05 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:05 --> Router Class Initialized
DEBUG - 2013-08-29 15:51:06 --> Output Class Initialized
DEBUG - 2013-08-29 15:51:06 --> Security Class Initialized
DEBUG - 2013-08-29 15:51:06 --> Input Class Initialized
DEBUG - 2013-08-29 15:51:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:06 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:51:06 --> Language Class Initialized
DEBUG - 2013-08-29 15:51:06 --> Loader Class Initialized
DEBUG - 2013-08-29 15:51:06 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:51:06 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:51:06 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:51:06 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:51:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:51:06 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:51:06 --> Session Class Initialized
DEBUG - 2013-08-29 15:51:06 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:51:06 --> Session routines successfully run
DEBUG - 2013-08-29 15:51:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:51:06 --> Controller Class Initialized
ERROR - 2013-08-29 15:51:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:06 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:51:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:51:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:51:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:51:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:07 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:07 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:51:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:51:07 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:07 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:07 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:07 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:07 --> Router Class Initialized
DEBUG - 2013-08-29 15:51:07 --> Output Class Initialized
DEBUG - 2013-08-29 15:51:07 --> Security Class Initialized
DEBUG - 2013-08-29 15:51:07 --> Input Class Initialized
DEBUG - 2013-08-29 15:51:07 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:07 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:51:08 --> Language Class Initialized
DEBUG - 2013-08-29 15:51:08 --> Loader Class Initialized
DEBUG - 2013-08-29 15:51:08 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:51:08 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:51:08 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:51:08 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:51:08 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:51:08 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:51:08 --> Session Class Initialized
DEBUG - 2013-08-29 15:51:08 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:51:08 --> Session routines successfully run
DEBUG - 2013-08-29 15:51:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:51:08 --> Controller Class Initialized
ERROR - 2013-08-29 15:51:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:08 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:51:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:51:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:51:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:51:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:08 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:51:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:51:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:51:09 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:51:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:51:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:51:09 --> File loaded: application/views/user_privileges/new.php
DEBUG - 2013-08-29 15:51:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:51:09 --> Final output sent to browser
DEBUG - 2013-08-29 15:51:09 --> Total execution time: 1.9031
DEBUG - 2013-08-29 15:51:09 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:09 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:09 --> Router Class Initialized
ERROR - 2013-08-29 15:51:09 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:51:13 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:13 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:13 --> Router Class Initialized
DEBUG - 2013-08-29 15:51:13 --> Output Class Initialized
DEBUG - 2013-08-29 15:51:13 --> Security Class Initialized
DEBUG - 2013-08-29 15:51:13 --> Input Class Initialized
DEBUG - 2013-08-29 15:51:13 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:13 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:13 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:13 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:13 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:51:13 --> Language Class Initialized
DEBUG - 2013-08-29 15:51:13 --> Loader Class Initialized
DEBUG - 2013-08-29 15:51:13 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:51:14 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:51:14 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:51:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:51:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:51:14 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:51:14 --> Session Class Initialized
DEBUG - 2013-08-29 15:51:14 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:51:14 --> Session routines successfully run
DEBUG - 2013-08-29 15:51:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:51:14 --> Controller Class Initialized
ERROR - 2013-08-29 15:51:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:14 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:51:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:51:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:51:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:51:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:14 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:14 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:51:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:51:15 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:15 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:15 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:15 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:15 --> Router Class Initialized
DEBUG - 2013-08-29 15:51:15 --> Output Class Initialized
DEBUG - 2013-08-29 15:51:15 --> Security Class Initialized
DEBUG - 2013-08-29 15:51:15 --> Input Class Initialized
DEBUG - 2013-08-29 15:51:15 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:15 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:51:15 --> Language Class Initialized
DEBUG - 2013-08-29 15:51:15 --> Loader Class Initialized
DEBUG - 2013-08-29 15:51:15 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:51:15 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:51:15 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:51:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:51:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:51:15 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:51:16 --> Session Class Initialized
DEBUG - 2013-08-29 15:51:16 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:51:16 --> Session routines successfully run
DEBUG - 2013-08-29 15:51:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:51:16 --> Controller Class Initialized
ERROR - 2013-08-29 15:51:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:16 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:51:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:51:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:51:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:51:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:16 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:16 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:51:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:51:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:51:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:51:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:51:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:51:16 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 15:51:17 --> Severity: Notice  --> Undefined index: ugrp_name C:\xampp\htdocs\school\application\views\user_privileges\index.php 85
ERROR - 2013-08-29 15:51:17 --> Severity: Notice  --> Undefined index: ugrp_name C:\xampp\htdocs\school\application\views\user_privileges\index.php 85
DEBUG - 2013-08-29 15:51:17 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:51:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:51:17 --> Final output sent to browser
DEBUG - 2013-08-29 15:51:17 --> Total execution time: 2.1241
DEBUG - 2013-08-29 15:51:17 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:17 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:17 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:17 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:17 --> Router Class Initialized
ERROR - 2013-08-29 15:51:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:51:24 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:24 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:24 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:25 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Router Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Output Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Security Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Input Class Initialized
DEBUG - 2013-08-29 15:51:25 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:25 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:51:25 --> Language Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Loader Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:51:25 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:51:25 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:51:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:51:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:51:25 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Session Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:51:25 --> Session routines successfully run
DEBUG - 2013-08-29 15:51:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Controller Class Initialized
ERROR - 2013-08-29 15:51:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:25 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:51:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:51:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:51:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:51:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:26 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:51:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:51:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:51:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:51:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:51:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:51:26 --> File loaded: application/views/user_privileges/edit.php
DEBUG - 2013-08-29 15:51:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:51:26 --> Final output sent to browser
DEBUG - 2013-08-29 15:51:26 --> Total execution time: 1.8861
DEBUG - 2013-08-29 15:51:27 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:27 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:27 --> Router Class Initialized
ERROR - 2013-08-29 15:51:27 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:51:32 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:32 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:32 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:32 --> Router Class Initialized
DEBUG - 2013-08-29 15:51:32 --> Output Class Initialized
DEBUG - 2013-08-29 15:51:32 --> Security Class Initialized
DEBUG - 2013-08-29 15:51:32 --> Input Class Initialized
DEBUG - 2013-08-29 15:51:32 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:32 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:32 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:32 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:32 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:51:33 --> Language Class Initialized
DEBUG - 2013-08-29 15:51:33 --> Loader Class Initialized
DEBUG - 2013-08-29 15:51:33 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:51:33 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:51:33 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:51:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:51:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:51:33 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:51:33 --> Session Class Initialized
DEBUG - 2013-08-29 15:51:33 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:51:33 --> Session routines successfully run
DEBUG - 2013-08-29 15:51:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:51:33 --> Controller Class Initialized
ERROR - 2013-08-29 15:51:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:33 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:51:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:51:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:51:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:51:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:33 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:33 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:51:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:51:34 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:34 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:34 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:34 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:34 --> Router Class Initialized
DEBUG - 2013-08-29 15:51:34 --> Output Class Initialized
DEBUG - 2013-08-29 15:51:34 --> Security Class Initialized
DEBUG - 2013-08-29 15:51:34 --> Input Class Initialized
DEBUG - 2013-08-29 15:51:34 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:34 --> XSS Filtering completed
DEBUG - 2013-08-29 15:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:51:34 --> Language Class Initialized
DEBUG - 2013-08-29 15:51:34 --> Loader Class Initialized
DEBUG - 2013-08-29 15:51:34 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:51:34 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:51:34 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:51:34 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:51:34 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:51:35 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:51:35 --> Session Class Initialized
DEBUG - 2013-08-29 15:51:35 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:51:35 --> Session routines successfully run
DEBUG - 2013-08-29 15:51:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:51:35 --> Controller Class Initialized
ERROR - 2013-08-29 15:51:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:35 --> Model Class Initialized
DEBUG - 2013-08-29 15:51:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:51:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:51:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:51:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:51:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:51:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:51:35 --> Model Class Initialized
ERROR - 2013-08-29 15:51:35 --> Severity: Notice  --> Undefined index: uacc_id C:\xampp\htdocs\school\application\controllers\admin\user_privileges.php 127
DEBUG - 2013-08-29 15:51:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:51:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:51:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:51:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:51:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:51:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:51:36 --> File loaded: application/views/user_privileges/edit.php
DEBUG - 2013-08-29 15:51:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:51:36 --> Final output sent to browser
DEBUG - 2013-08-29 15:51:36 --> Total execution time: 2.0221
DEBUG - 2013-08-29 15:51:36 --> Config Class Initialized
DEBUG - 2013-08-29 15:51:36 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:51:36 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:51:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:51:36 --> URI Class Initialized
DEBUG - 2013-08-29 15:51:36 --> Router Class Initialized
ERROR - 2013-08-29 15:51:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:52:22 --> Config Class Initialized
DEBUG - 2013-08-29 15:52:22 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:52:22 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:52:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:52:22 --> URI Class Initialized
DEBUG - 2013-08-29 15:52:22 --> Router Class Initialized
DEBUG - 2013-08-29 15:52:23 --> Output Class Initialized
DEBUG - 2013-08-29 15:52:23 --> Security Class Initialized
DEBUG - 2013-08-29 15:52:23 --> Input Class Initialized
DEBUG - 2013-08-29 15:52:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:52:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:52:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:52:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:52:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:52:23 --> Language Class Initialized
DEBUG - 2013-08-29 15:52:23 --> Loader Class Initialized
DEBUG - 2013-08-29 15:52:23 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:52:23 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:52:23 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:52:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:52:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:52:23 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:52:23 --> Session Class Initialized
DEBUG - 2013-08-29 15:52:23 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:52:23 --> Session routines successfully run
DEBUG - 2013-08-29 15:52:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:52:23 --> Controller Class Initialized
ERROR - 2013-08-29 15:52:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:52:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:52:24 --> Model Class Initialized
DEBUG - 2013-08-29 15:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:52:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:52:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:52:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:52:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:52:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:52:24 --> Model Class Initialized
DEBUG - 2013-08-29 15:52:24 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:52:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:52:24 --> Config Class Initialized
DEBUG - 2013-08-29 15:52:24 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:52:24 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:52:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:52:24 --> URI Class Initialized
DEBUG - 2013-08-29 15:52:24 --> Router Class Initialized
DEBUG - 2013-08-29 15:52:24 --> Output Class Initialized
DEBUG - 2013-08-29 15:52:24 --> Security Class Initialized
DEBUG - 2013-08-29 15:52:24 --> Input Class Initialized
DEBUG - 2013-08-29 15:52:25 --> XSS Filtering completed
DEBUG - 2013-08-29 15:52:25 --> XSS Filtering completed
DEBUG - 2013-08-29 15:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:52:25 --> Language Class Initialized
DEBUG - 2013-08-29 15:52:25 --> Loader Class Initialized
DEBUG - 2013-08-29 15:52:25 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:52:25 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:52:25 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:52:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:52:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:52:25 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:52:25 --> Session Class Initialized
DEBUG - 2013-08-29 15:52:25 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:52:25 --> Session routines successfully run
DEBUG - 2013-08-29 15:52:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:52:25 --> Controller Class Initialized
ERROR - 2013-08-29 15:52:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:52:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:52:25 --> Model Class Initialized
DEBUG - 2013-08-29 15:52:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:52:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:52:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:52:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:52:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:52:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:52:26 --> Model Class Initialized
ERROR - 2013-08-29 15:52:26 --> Severity: Notice  --> Undefined index: uacc_id C:\xampp\htdocs\school\application\controllers\admin\user_privileges.php 127
DEBUG - 2013-08-29 15:52:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:52:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:52:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:52:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:52:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:52:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:52:26 --> File loaded: application/views/user_privileges/edit.php
DEBUG - 2013-08-29 15:52:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:52:26 --> Final output sent to browser
DEBUG - 2013-08-29 15:52:26 --> Total execution time: 2.1471
DEBUG - 2013-08-29 15:52:27 --> Config Class Initialized
DEBUG - 2013-08-29 15:52:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:52:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:52:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:52:27 --> URI Class Initialized
DEBUG - 2013-08-29 15:52:27 --> Router Class Initialized
ERROR - 2013-08-29 15:52:27 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:53:40 --> Config Class Initialized
DEBUG - 2013-08-29 15:53:40 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:53:40 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:53:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:53:41 --> URI Class Initialized
DEBUG - 2013-08-29 15:53:41 --> Router Class Initialized
DEBUG - 2013-08-29 15:53:41 --> Output Class Initialized
DEBUG - 2013-08-29 15:53:41 --> Security Class Initialized
DEBUG - 2013-08-29 15:53:41 --> Input Class Initialized
DEBUG - 2013-08-29 15:53:41 --> XSS Filtering completed
DEBUG - 2013-08-29 15:53:41 --> XSS Filtering completed
DEBUG - 2013-08-29 15:53:41 --> XSS Filtering completed
DEBUG - 2013-08-29 15:53:41 --> XSS Filtering completed
DEBUG - 2013-08-29 15:53:41 --> XSS Filtering completed
DEBUG - 2013-08-29 15:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:53:41 --> Language Class Initialized
DEBUG - 2013-08-29 15:53:41 --> Loader Class Initialized
DEBUG - 2013-08-29 15:53:41 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:53:41 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:53:41 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:53:41 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:53:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:53:41 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:53:41 --> Session Class Initialized
DEBUG - 2013-08-29 15:53:41 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:53:41 --> Session routines successfully run
DEBUG - 2013-08-29 15:53:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:53:42 --> Controller Class Initialized
ERROR - 2013-08-29 15:53:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:53:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:53:42 --> Model Class Initialized
DEBUG - 2013-08-29 15:53:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:53:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:53:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:53:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:53:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:53:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:53:42 --> Model Class Initialized
DEBUG - 2013-08-29 15:53:42 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:53:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-29 15:53:42 --> Severity: Notice  --> Undefined index: upriv_groups_id C:\xampp\htdocs\school\application\controllers\admin\user_privileges.php 260
DEBUG - 2013-08-29 15:53:42 --> Config Class Initialized
DEBUG - 2013-08-29 15:53:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:53:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:53:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:53:43 --> URI Class Initialized
DEBUG - 2013-08-29 15:53:43 --> Router Class Initialized
DEBUG - 2013-08-29 15:53:43 --> Output Class Initialized
DEBUG - 2013-08-29 15:53:43 --> Security Class Initialized
DEBUG - 2013-08-29 15:53:43 --> Input Class Initialized
DEBUG - 2013-08-29 15:53:43 --> XSS Filtering completed
DEBUG - 2013-08-29 15:53:43 --> XSS Filtering completed
DEBUG - 2013-08-29 15:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:53:43 --> Language Class Initialized
DEBUG - 2013-08-29 15:53:43 --> Loader Class Initialized
DEBUG - 2013-08-29 15:53:43 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:53:43 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:53:43 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:53:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:53:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:53:43 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:53:43 --> Session Class Initialized
DEBUG - 2013-08-29 15:53:43 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:53:43 --> Session routines successfully run
DEBUG - 2013-08-29 15:53:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:53:43 --> Controller Class Initialized
ERROR - 2013-08-29 15:53:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:53:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:53:44 --> Model Class Initialized
DEBUG - 2013-08-29 15:53:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:53:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:53:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:53:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:53:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:53:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:53:44 --> Model Class Initialized
DEBUG - 2013-08-29 15:53:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:53:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:53:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:53:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:53:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:53:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:53:44 --> File loaded: application/views/user_privileges/edit.php
DEBUG - 2013-08-29 15:53:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:53:44 --> Final output sent to browser
DEBUG - 2013-08-29 15:53:44 --> Total execution time: 1.9801
DEBUG - 2013-08-29 15:53:45 --> Config Class Initialized
DEBUG - 2013-08-29 15:53:45 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:53:45 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:53:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:53:45 --> URI Class Initialized
DEBUG - 2013-08-29 15:53:45 --> Router Class Initialized
ERROR - 2013-08-29 15:53:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:54:25 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:25 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:26 --> Router Class Initialized
DEBUG - 2013-08-29 15:54:26 --> Output Class Initialized
DEBUG - 2013-08-29 15:54:26 --> Security Class Initialized
DEBUG - 2013-08-29 15:54:26 --> Input Class Initialized
DEBUG - 2013-08-29 15:54:26 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:26 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:26 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:26 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:26 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:54:26 --> Language Class Initialized
DEBUG - 2013-08-29 15:54:26 --> Loader Class Initialized
DEBUG - 2013-08-29 15:54:26 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:54:26 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:54:26 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:54:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:54:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:54:26 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:54:26 --> Session Class Initialized
DEBUG - 2013-08-29 15:54:26 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:54:26 --> Session garbage collection performed.
DEBUG - 2013-08-29 15:54:26 --> Session routines successfully run
DEBUG - 2013-08-29 15:54:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:54:27 --> Controller Class Initialized
ERROR - 2013-08-29 15:54:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:27 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:54:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:54:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:54:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:54:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:27 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:27 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:54:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-29 15:54:27 --> Severity: Notice  --> Undefined index: upriv_groups_id C:\xampp\htdocs\school\application\controllers\admin\user_privileges.php 260
DEBUG - 2013-08-29 15:54:27 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:27 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:27 --> Router Class Initialized
DEBUG - 2013-08-29 15:54:28 --> Output Class Initialized
DEBUG - 2013-08-29 15:54:28 --> Security Class Initialized
DEBUG - 2013-08-29 15:54:28 --> Input Class Initialized
DEBUG - 2013-08-29 15:54:28 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:28 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:54:28 --> Language Class Initialized
DEBUG - 2013-08-29 15:54:28 --> Loader Class Initialized
DEBUG - 2013-08-29 15:54:28 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:54:28 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:54:28 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:54:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:54:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:54:28 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:54:28 --> Session Class Initialized
DEBUG - 2013-08-29 15:54:28 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:54:28 --> Session routines successfully run
DEBUG - 2013-08-29 15:54:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:54:28 --> Controller Class Initialized
ERROR - 2013-08-29 15:54:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:28 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:54:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:54:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:54:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:54:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:29 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:54:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:54:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:54:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:54:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:54:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:54:29 --> File loaded: application/views/user_privileges/edit.php
DEBUG - 2013-08-29 15:54:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:54:29 --> Final output sent to browser
DEBUG - 2013-08-29 15:54:29 --> Total execution time: 2.0861
DEBUG - 2013-08-29 15:54:30 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:30 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:30 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:30 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:30 --> Router Class Initialized
ERROR - 2013-08-29 15:54:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:54:36 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:36 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:36 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:36 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:36 --> Router Class Initialized
DEBUG - 2013-08-29 15:54:36 --> Output Class Initialized
DEBUG - 2013-08-29 15:54:36 --> Security Class Initialized
DEBUG - 2013-08-29 15:54:37 --> Input Class Initialized
DEBUG - 2013-08-29 15:54:37 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:37 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:54:37 --> Language Class Initialized
DEBUG - 2013-08-29 15:54:37 --> Loader Class Initialized
DEBUG - 2013-08-29 15:54:37 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:54:37 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:54:37 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:54:37 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:54:37 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:54:37 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:54:37 --> Session Class Initialized
DEBUG - 2013-08-29 15:54:37 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:54:37 --> Session routines successfully run
DEBUG - 2013-08-29 15:54:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:54:37 --> Controller Class Initialized
ERROR - 2013-08-29 15:54:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:37 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:54:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:54:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:54:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:54:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:38 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:38 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:54:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:54:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:54:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:54:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:54:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:54:38 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 15:54:38 --> Severity: Notice  --> Undefined index: ugrp_name C:\xampp\htdocs\school\application\views\user_privileges\index.php 85
ERROR - 2013-08-29 15:54:38 --> Severity: Notice  --> Undefined index: ugrp_name C:\xampp\htdocs\school\application\views\user_privileges\index.php 85
DEBUG - 2013-08-29 15:54:38 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:54:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:54:39 --> Final output sent to browser
DEBUG - 2013-08-29 15:54:39 --> Total execution time: 2.3541
DEBUG - 2013-08-29 15:54:39 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:39 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:39 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:39 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:39 --> Router Class Initialized
ERROR - 2013-08-29 15:54:39 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:54:42 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:42 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Router Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Output Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Security Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Input Class Initialized
DEBUG - 2013-08-29 15:54:42 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:42 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:54:42 --> Language Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Loader Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:54:42 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:54:42 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:54:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:54:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:54:42 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Session Class Initialized
DEBUG - 2013-08-29 15:54:42 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:54:42 --> Session routines successfully run
DEBUG - 2013-08-29 15:54:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:54:43 --> Controller Class Initialized
ERROR - 2013-08-29 15:54:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:43 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:54:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:54:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:54:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:54:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:43 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:54:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:54:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:54:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:54:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:54:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:54:43 --> File loaded: application/views/user_privileges/edit.php
DEBUG - 2013-08-29 15:54:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:54:44 --> Final output sent to browser
DEBUG - 2013-08-29 15:54:44 --> Total execution time: 1.9481
DEBUG - 2013-08-29 15:54:44 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:44 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:44 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:44 --> Router Class Initialized
ERROR - 2013-08-29 15:54:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:54:47 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:47 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:47 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:47 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:47 --> Router Class Initialized
DEBUG - 2013-08-29 15:54:47 --> Output Class Initialized
DEBUG - 2013-08-29 15:54:47 --> Security Class Initialized
DEBUG - 2013-08-29 15:54:47 --> Input Class Initialized
DEBUG - 2013-08-29 15:54:47 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:48 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:48 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:48 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:48 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:54:48 --> Language Class Initialized
DEBUG - 2013-08-29 15:54:48 --> Loader Class Initialized
DEBUG - 2013-08-29 15:54:48 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:54:48 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:54:48 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:54:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:54:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:54:48 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:54:48 --> Session Class Initialized
DEBUG - 2013-08-29 15:54:48 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:54:48 --> Session routines successfully run
DEBUG - 2013-08-29 15:54:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:54:48 --> Controller Class Initialized
ERROR - 2013-08-29 15:54:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:48 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:54:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:54:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:54:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:54:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:49 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:49 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:54:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-29 15:54:49 --> Severity: Notice  --> Undefined index: upriv_groups_id C:\xampp\htdocs\school\application\controllers\admin\user_privileges.php 260
DEBUG - 2013-08-29 15:54:49 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:49 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:49 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:49 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:49 --> Router Class Initialized
DEBUG - 2013-08-29 15:54:49 --> Output Class Initialized
DEBUG - 2013-08-29 15:54:49 --> Security Class Initialized
DEBUG - 2013-08-29 15:54:49 --> Input Class Initialized
DEBUG - 2013-08-29 15:54:49 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:50 --> XSS Filtering completed
DEBUG - 2013-08-29 15:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:54:50 --> Language Class Initialized
DEBUG - 2013-08-29 15:54:50 --> Loader Class Initialized
DEBUG - 2013-08-29 15:54:50 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:54:50 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:54:50 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:54:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:54:50 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:54:50 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:54:50 --> Session Class Initialized
DEBUG - 2013-08-29 15:54:50 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:54:50 --> Session routines successfully run
DEBUG - 2013-08-29 15:54:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:54:50 --> Controller Class Initialized
ERROR - 2013-08-29 15:54:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:50 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:54:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:54:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:54:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:54:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:54:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:54:51 --> Model Class Initialized
DEBUG - 2013-08-29 15:54:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:54:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:54:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:54:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:54:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:54:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:54:51 --> File loaded: application/views/user_privileges/edit.php
DEBUG - 2013-08-29 15:54:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:54:51 --> Final output sent to browser
DEBUG - 2013-08-29 15:54:51 --> Total execution time: 2.1161
DEBUG - 2013-08-29 15:54:51 --> Config Class Initialized
DEBUG - 2013-08-29 15:54:51 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:54:52 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:54:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:54:52 --> URI Class Initialized
DEBUG - 2013-08-29 15:54:52 --> Router Class Initialized
ERROR - 2013-08-29 15:54:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:55:27 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:27 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:27 --> Router Class Initialized
DEBUG - 2013-08-29 15:55:27 --> Output Class Initialized
DEBUG - 2013-08-29 15:55:27 --> Security Class Initialized
DEBUG - 2013-08-29 15:55:27 --> Input Class Initialized
DEBUG - 2013-08-29 15:55:27 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:27 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:27 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:27 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:27 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:55:27 --> Language Class Initialized
DEBUG - 2013-08-29 15:55:27 --> Loader Class Initialized
DEBUG - 2013-08-29 15:55:28 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:55:28 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:55:28 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:55:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:55:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:55:28 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:55:28 --> Session Class Initialized
DEBUG - 2013-08-29 15:55:28 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:55:28 --> Session routines successfully run
DEBUG - 2013-08-29 15:55:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:55:28 --> Controller Class Initialized
ERROR - 2013-08-29 15:55:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:28 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:55:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:55:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:55:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:55:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:29 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:55:29 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:29 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Router Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Output Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Security Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Input Class Initialized
DEBUG - 2013-08-29 15:55:29 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:29 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:55:29 --> Language Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Loader Class Initialized
DEBUG - 2013-08-29 15:55:29 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:55:29 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:55:29 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:55:30 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:55:30 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:55:30 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:55:30 --> Session Class Initialized
DEBUG - 2013-08-29 15:55:30 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:55:30 --> Session routines successfully run
DEBUG - 2013-08-29 15:55:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:55:30 --> Controller Class Initialized
ERROR - 2013-08-29 15:55:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:30 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:55:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:55:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:55:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:55:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:30 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:55:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:55:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:55:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:55:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:55:31 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:55:31 --> File loaded: application/views/user_privileges/show.php
DEBUG - 2013-08-29 15:55:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:55:31 --> Final output sent to browser
DEBUG - 2013-08-29 15:55:31 --> Total execution time: 2.0691
DEBUG - 2013-08-29 15:55:31 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:31 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:31 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:31 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:31 --> Router Class Initialized
ERROR - 2013-08-29 15:55:31 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:55:35 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:35 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:35 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:35 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:35 --> Router Class Initialized
DEBUG - 2013-08-29 15:55:35 --> Output Class Initialized
DEBUG - 2013-08-29 15:55:35 --> Security Class Initialized
DEBUG - 2013-08-29 15:55:35 --> Input Class Initialized
DEBUG - 2013-08-29 15:55:35 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:35 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:55:35 --> Language Class Initialized
DEBUG - 2013-08-29 15:55:35 --> Loader Class Initialized
DEBUG - 2013-08-29 15:55:35 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:55:35 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:55:35 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:55:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:55:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:55:35 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:55:36 --> Session Class Initialized
DEBUG - 2013-08-29 15:55:36 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:55:36 --> Session routines successfully run
DEBUG - 2013-08-29 15:55:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:55:36 --> Controller Class Initialized
ERROR - 2013-08-29 15:55:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:36 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:55:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:55:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:55:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:55:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:36 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:36 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:55:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:55:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:55:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:55:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:55:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:55:37 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 15:55:37 --> Severity: Notice  --> Undefined index: ugrp_name C:\xampp\htdocs\school\application\views\user_privileges\index.php 85
ERROR - 2013-08-29 15:55:37 --> Severity: Notice  --> Undefined index: ugrp_name C:\xampp\htdocs\school\application\views\user_privileges\index.php 85
DEBUG - 2013-08-29 15:55:37 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:55:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:55:37 --> Final output sent to browser
DEBUG - 2013-08-29 15:55:37 --> Total execution time: 2.2181
DEBUG - 2013-08-29 15:55:37 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:37 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:37 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:37 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:37 --> Router Class Initialized
ERROR - 2013-08-29 15:55:37 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:55:41 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:41 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:41 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:41 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:41 --> Router Class Initialized
DEBUG - 2013-08-29 15:55:41 --> Output Class Initialized
DEBUG - 2013-08-29 15:55:41 --> Security Class Initialized
DEBUG - 2013-08-29 15:55:41 --> Input Class Initialized
DEBUG - 2013-08-29 15:55:41 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:41 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:55:41 --> Language Class Initialized
DEBUG - 2013-08-29 15:55:41 --> Loader Class Initialized
DEBUG - 2013-08-29 15:55:42 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:55:42 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:55:42 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:55:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:55:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:55:42 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:55:42 --> Session Class Initialized
DEBUG - 2013-08-29 15:55:42 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:55:42 --> Session routines successfully run
DEBUG - 2013-08-29 15:55:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:55:42 --> Controller Class Initialized
ERROR - 2013-08-29 15:55:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:42 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:55:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:55:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:55:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:55:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:43 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:55:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:55:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:55:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:55:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:55:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:55:43 --> File loaded: application/views/user_privileges/edit.php
DEBUG - 2013-08-29 15:55:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:55:43 --> Final output sent to browser
DEBUG - 2013-08-29 15:55:43 --> Total execution time: 2.2821
DEBUG - 2013-08-29 15:55:43 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:43 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:44 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:44 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:44 --> Router Class Initialized
ERROR - 2013-08-29 15:55:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:55:48 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:48 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:48 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:48 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:49 --> Router Class Initialized
DEBUG - 2013-08-29 15:55:49 --> Output Class Initialized
DEBUG - 2013-08-29 15:55:49 --> Security Class Initialized
DEBUG - 2013-08-29 15:55:49 --> Input Class Initialized
DEBUG - 2013-08-29 15:55:49 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:49 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:49 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:49 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:49 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:55:49 --> Language Class Initialized
DEBUG - 2013-08-29 15:55:49 --> Loader Class Initialized
DEBUG - 2013-08-29 15:55:49 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:55:49 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:55:49 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:55:49 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:55:49 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:55:49 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:55:49 --> Session Class Initialized
DEBUG - 2013-08-29 15:55:49 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:55:49 --> Session routines successfully run
DEBUG - 2013-08-29 15:55:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:55:49 --> Controller Class Initialized
ERROR - 2013-08-29 15:55:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:50 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:55:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:55:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:55:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:55:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:50 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:50 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:55:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:55:50 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:50 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:50 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:50 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:50 --> Router Class Initialized
DEBUG - 2013-08-29 15:55:51 --> Output Class Initialized
DEBUG - 2013-08-29 15:55:51 --> Security Class Initialized
DEBUG - 2013-08-29 15:55:51 --> Input Class Initialized
DEBUG - 2013-08-29 15:55:51 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:51 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:55:51 --> Language Class Initialized
DEBUG - 2013-08-29 15:55:51 --> Loader Class Initialized
DEBUG - 2013-08-29 15:55:51 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:55:51 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:55:51 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:55:51 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:55:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:55:51 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:55:51 --> Session Class Initialized
DEBUG - 2013-08-29 15:55:51 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:55:51 --> Session routines successfully run
DEBUG - 2013-08-29 15:55:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:55:51 --> Controller Class Initialized
ERROR - 2013-08-29 15:55:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:51 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:55:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:55:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:55:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:55:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:52 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:55:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:55:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:55:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:55:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:55:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:55:52 --> File loaded: application/views/user_privileges/edit.php
DEBUG - 2013-08-29 15:55:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:55:52 --> Final output sent to browser
DEBUG - 2013-08-29 15:55:52 --> Total execution time: 2.1411
DEBUG - 2013-08-29 15:55:53 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:53 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:53 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:53 --> Router Class Initialized
ERROR - 2013-08-29 15:55:53 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:55:56 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:56 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:56 --> Router Class Initialized
DEBUG - 2013-08-29 15:55:57 --> Output Class Initialized
DEBUG - 2013-08-29 15:55:57 --> Security Class Initialized
DEBUG - 2013-08-29 15:55:57 --> Input Class Initialized
DEBUG - 2013-08-29 15:55:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:57 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:55:57 --> Language Class Initialized
DEBUG - 2013-08-29 15:55:57 --> Loader Class Initialized
DEBUG - 2013-08-29 15:55:57 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:55:57 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:55:57 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:55:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:55:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:55:57 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:55:57 --> Session Class Initialized
DEBUG - 2013-08-29 15:55:57 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:55:57 --> Session garbage collection performed.
DEBUG - 2013-08-29 15:55:57 --> Session routines successfully run
DEBUG - 2013-08-29 15:55:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:55:58 --> Controller Class Initialized
ERROR - 2013-08-29 15:55:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:58 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:55:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:55:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:55:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:55:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:55:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:55:58 --> Model Class Initialized
DEBUG - 2013-08-29 15:55:58 --> Form Validation Class Initialized
DEBUG - 2013-08-29 15:55:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 15:55:58 --> Config Class Initialized
DEBUG - 2013-08-29 15:55:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:55:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:55:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:55:59 --> URI Class Initialized
DEBUG - 2013-08-29 15:55:59 --> Router Class Initialized
DEBUG - 2013-08-29 15:55:59 --> Output Class Initialized
DEBUG - 2013-08-29 15:55:59 --> Security Class Initialized
DEBUG - 2013-08-29 15:55:59 --> Input Class Initialized
DEBUG - 2013-08-29 15:55:59 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:59 --> XSS Filtering completed
DEBUG - 2013-08-29 15:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:55:59 --> Language Class Initialized
DEBUG - 2013-08-29 15:55:59 --> Loader Class Initialized
DEBUG - 2013-08-29 15:55:59 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:55:59 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:55:59 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:55:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:55:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:55:59 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:55:59 --> Session Class Initialized
DEBUG - 2013-08-29 15:55:59 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:55:59 --> Session routines successfully run
DEBUG - 2013-08-29 15:55:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:55:59 --> Controller Class Initialized
ERROR - 2013-08-29 15:56:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:56:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:56:00 --> Model Class Initialized
DEBUG - 2013-08-29 15:56:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:56:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:56:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:56:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:56:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:56:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:56:00 --> Model Class Initialized
DEBUG - 2013-08-29 15:56:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:56:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:56:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:56:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:56:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:56:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:56:00 --> File loaded: application/views/user_privileges/show.php
DEBUG - 2013-08-29 15:56:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:56:00 --> Final output sent to browser
DEBUG - 2013-08-29 15:56:00 --> Total execution time: 2.0891
DEBUG - 2013-08-29 15:56:01 --> Config Class Initialized
DEBUG - 2013-08-29 15:56:01 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:56:01 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:56:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:56:01 --> URI Class Initialized
DEBUG - 2013-08-29 15:56:01 --> Router Class Initialized
ERROR - 2013-08-29 15:56:01 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:56:04 --> Config Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:56:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:56:05 --> URI Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Router Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Output Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Security Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Input Class Initialized
DEBUG - 2013-08-29 15:56:05 --> XSS Filtering completed
DEBUG - 2013-08-29 15:56:05 --> XSS Filtering completed
DEBUG - 2013-08-29 15:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:56:05 --> Language Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Loader Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:56:05 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:56:05 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:56:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:56:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:56:05 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Session Class Initialized
DEBUG - 2013-08-29 15:56:05 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:56:05 --> Session routines successfully run
DEBUG - 2013-08-29 15:56:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:56:06 --> Controller Class Initialized
ERROR - 2013-08-29 15:56:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:56:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:56:06 --> Model Class Initialized
DEBUG - 2013-08-29 15:56:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:56:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:56:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:56:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:56:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:56:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:56:06 --> Model Class Initialized
DEBUG - 2013-08-29 15:56:06 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:56:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:56:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:56:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:56:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:56:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:56:06 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 15:56:06 --> Severity: Notice  --> Undefined index: ugrp_name C:\xampp\htdocs\school\application\views\user_privileges\index.php 85
ERROR - 2013-08-29 15:56:07 --> Severity: Notice  --> Undefined index: ugrp_name C:\xampp\htdocs\school\application\views\user_privileges\index.php 85
DEBUG - 2013-08-29 15:56:07 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:56:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:56:07 --> Final output sent to browser
DEBUG - 2013-08-29 15:56:07 --> Total execution time: 2.1661
DEBUG - 2013-08-29 15:56:07 --> Config Class Initialized
DEBUG - 2013-08-29 15:56:07 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:56:07 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:56:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:56:07 --> URI Class Initialized
DEBUG - 2013-08-29 15:56:07 --> Router Class Initialized
ERROR - 2013-08-29 15:56:07 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:57:39 --> Config Class Initialized
DEBUG - 2013-08-29 15:57:39 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:57:39 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:57:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:57:39 --> URI Class Initialized
DEBUG - 2013-08-29 15:57:39 --> Router Class Initialized
DEBUG - 2013-08-29 15:57:39 --> Output Class Initialized
DEBUG - 2013-08-29 15:57:39 --> Security Class Initialized
DEBUG - 2013-08-29 15:57:39 --> Input Class Initialized
DEBUG - 2013-08-29 15:57:39 --> XSS Filtering completed
DEBUG - 2013-08-29 15:57:39 --> XSS Filtering completed
DEBUG - 2013-08-29 15:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:57:39 --> Language Class Initialized
DEBUG - 2013-08-29 15:57:39 --> Loader Class Initialized
DEBUG - 2013-08-29 15:57:39 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:57:39 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:57:39 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:57:39 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:57:39 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:57:39 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:57:39 --> Session Class Initialized
DEBUG - 2013-08-29 15:57:40 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:57:40 --> Session routines successfully run
DEBUG - 2013-08-29 15:57:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:57:40 --> Controller Class Initialized
ERROR - 2013-08-29 15:57:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:57:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:57:40 --> Model Class Initialized
DEBUG - 2013-08-29 15:57:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:57:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:57:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:57:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:57:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:57:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:57:40 --> Model Class Initialized
DEBUG - 2013-08-29 15:57:40 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:57:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:57:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:57:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:57:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:57:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:57:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:57:41 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:57:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:57:41 --> Final output sent to browser
DEBUG - 2013-08-29 15:57:41 --> Total execution time: 2.1981
DEBUG - 2013-08-29 15:57:41 --> Config Class Initialized
DEBUG - 2013-08-29 15:57:41 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:57:41 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:57:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:57:41 --> URI Class Initialized
DEBUG - 2013-08-29 15:57:41 --> Router Class Initialized
ERROR - 2013-08-29 15:57:42 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:57:52 --> Config Class Initialized
DEBUG - 2013-08-29 15:57:52 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:57:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:57:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:57:53 --> URI Class Initialized
DEBUG - 2013-08-29 15:57:53 --> Router Class Initialized
DEBUG - 2013-08-29 15:57:53 --> Output Class Initialized
DEBUG - 2013-08-29 15:57:53 --> Security Class Initialized
DEBUG - 2013-08-29 15:57:53 --> Input Class Initialized
DEBUG - 2013-08-29 15:57:53 --> XSS Filtering completed
DEBUG - 2013-08-29 15:57:53 --> XSS Filtering completed
DEBUG - 2013-08-29 15:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:57:53 --> Language Class Initialized
DEBUG - 2013-08-29 15:57:53 --> Loader Class Initialized
DEBUG - 2013-08-29 15:57:53 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:57:53 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:57:53 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:57:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:57:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:57:53 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:57:53 --> Session Class Initialized
DEBUG - 2013-08-29 15:57:54 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:57:54 --> Session routines successfully run
DEBUG - 2013-08-29 15:57:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:57:54 --> Controller Class Initialized
ERROR - 2013-08-29 15:57:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:57:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:57:54 --> Model Class Initialized
DEBUG - 2013-08-29 15:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:57:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:57:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:57:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:57:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:57:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:57:54 --> Model Class Initialized
DEBUG - 2013-08-29 15:57:54 --> Config Class Initialized
DEBUG - 2013-08-29 15:57:55 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:57:55 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:57:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:57:55 --> URI Class Initialized
DEBUG - 2013-08-29 15:57:55 --> Router Class Initialized
DEBUG - 2013-08-29 15:57:55 --> Output Class Initialized
DEBUG - 2013-08-29 15:57:55 --> Security Class Initialized
DEBUG - 2013-08-29 15:57:55 --> Input Class Initialized
DEBUG - 2013-08-29 15:57:55 --> XSS Filtering completed
DEBUG - 2013-08-29 15:57:55 --> XSS Filtering completed
DEBUG - 2013-08-29 15:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:57:55 --> Language Class Initialized
DEBUG - 2013-08-29 15:57:55 --> Loader Class Initialized
DEBUG - 2013-08-29 15:57:55 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:57:55 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:57:55 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:57:55 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:57:55 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:57:55 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:57:55 --> Session Class Initialized
DEBUG - 2013-08-29 15:57:56 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:57:56 --> Session garbage collection performed.
DEBUG - 2013-08-29 15:57:56 --> Session routines successfully run
DEBUG - 2013-08-29 15:57:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:57:56 --> Controller Class Initialized
ERROR - 2013-08-29 15:57:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:57:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:57:56 --> Model Class Initialized
DEBUG - 2013-08-29 15:57:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:57:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:57:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:57:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:57:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:57:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:57:56 --> Model Class Initialized
DEBUG - 2013-08-29 15:57:56 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:57:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:57:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:57:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:57:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:57:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:57:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:57:57 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:57:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:57:57 --> Final output sent to browser
DEBUG - 2013-08-29 15:57:57 --> Total execution time: 2.5141
DEBUG - 2013-08-29 15:57:57 --> Config Class Initialized
DEBUG - 2013-08-29 15:57:57 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:57:57 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:57:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:57:57 --> URI Class Initialized
DEBUG - 2013-08-29 15:57:57 --> Router Class Initialized
ERROR - 2013-08-29 15:57:58 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:59:23 --> Config Class Initialized
DEBUG - 2013-08-29 15:59:23 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:59:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:59:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:59:23 --> URI Class Initialized
DEBUG - 2013-08-29 15:59:23 --> Router Class Initialized
DEBUG - 2013-08-29 15:59:23 --> Output Class Initialized
DEBUG - 2013-08-29 15:59:23 --> Security Class Initialized
DEBUG - 2013-08-29 15:59:23 --> Input Class Initialized
DEBUG - 2013-08-29 15:59:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:59:23 --> XSS Filtering completed
DEBUG - 2013-08-29 15:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:59:23 --> Language Class Initialized
DEBUG - 2013-08-29 15:59:23 --> Loader Class Initialized
DEBUG - 2013-08-29 15:59:23 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:59:23 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:59:23 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:59:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:59:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:59:23 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:59:24 --> Session Class Initialized
DEBUG - 2013-08-29 15:59:24 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:59:24 --> Session routines successfully run
DEBUG - 2013-08-29 15:59:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:59:24 --> Controller Class Initialized
ERROR - 2013-08-29 15:59:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:59:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:59:24 --> Model Class Initialized
DEBUG - 2013-08-29 15:59:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:59:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:59:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:59:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:59:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:59:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:59:24 --> Model Class Initialized
DEBUG - 2013-08-29 15:59:24 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:59:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:59:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:59:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:59:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:59:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:59:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:59:25 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:59:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:59:25 --> Final output sent to browser
DEBUG - 2013-08-29 15:59:25 --> Total execution time: 2.0301
DEBUG - 2013-08-29 15:59:25 --> Config Class Initialized
DEBUG - 2013-08-29 15:59:25 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:59:25 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:59:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:59:25 --> URI Class Initialized
DEBUG - 2013-08-29 15:59:25 --> Router Class Initialized
ERROR - 2013-08-29 15:59:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 15:59:53 --> Config Class Initialized
DEBUG - 2013-08-29 15:59:53 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:59:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:59:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:59:53 --> URI Class Initialized
DEBUG - 2013-08-29 15:59:53 --> Router Class Initialized
DEBUG - 2013-08-29 15:59:53 --> Output Class Initialized
DEBUG - 2013-08-29 15:59:53 --> Security Class Initialized
DEBUG - 2013-08-29 15:59:53 --> Input Class Initialized
DEBUG - 2013-08-29 15:59:53 --> XSS Filtering completed
DEBUG - 2013-08-29 15:59:53 --> XSS Filtering completed
DEBUG - 2013-08-29 15:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 15:59:53 --> Language Class Initialized
DEBUG - 2013-08-29 15:59:53 --> Loader Class Initialized
DEBUG - 2013-08-29 15:59:54 --> Helper loaded: url_helper
DEBUG - 2013-08-29 15:59:54 --> Helper loaded: file_helper
DEBUG - 2013-08-29 15:59:54 --> Helper loaded: form_helper
DEBUG - 2013-08-29 15:59:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 15:59:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 15:59:54 --> Database Driver Class Initialized
DEBUG - 2013-08-29 15:59:54 --> Session Class Initialized
DEBUG - 2013-08-29 15:59:54 --> Helper loaded: string_helper
DEBUG - 2013-08-29 15:59:54 --> Session routines successfully run
DEBUG - 2013-08-29 15:59:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 15:59:54 --> Controller Class Initialized
ERROR - 2013-08-29 15:59:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:59:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:59:54 --> Model Class Initialized
DEBUG - 2013-08-29 15:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 15:59:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 15:59:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 15:59:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 15:59:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 15:59:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 15:59:55 --> Model Class Initialized
DEBUG - 2013-08-29 15:59:55 --> Pagination Class Initialized
DEBUG - 2013-08-29 15:59:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 15:59:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 15:59:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 15:59:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 15:59:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 15:59:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 15:59:55 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 15:59:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 15:59:55 --> Final output sent to browser
DEBUG - 2013-08-29 15:59:55 --> Total execution time: 2.1721
DEBUG - 2013-08-29 15:59:55 --> Config Class Initialized
DEBUG - 2013-08-29 15:59:55 --> Hooks Class Initialized
DEBUG - 2013-08-29 15:59:55 --> Utf8 Class Initialized
DEBUG - 2013-08-29 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 15:59:56 --> URI Class Initialized
DEBUG - 2013-08-29 15:59:56 --> Router Class Initialized
ERROR - 2013-08-29 15:59:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:00:09 --> Config Class Initialized
DEBUG - 2013-08-29 16:00:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:00:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:00:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:00:09 --> URI Class Initialized
DEBUG - 2013-08-29 16:00:09 --> Router Class Initialized
DEBUG - 2013-08-29 16:00:09 --> Output Class Initialized
DEBUG - 2013-08-29 16:00:09 --> Security Class Initialized
DEBUG - 2013-08-29 16:00:09 --> Input Class Initialized
DEBUG - 2013-08-29 16:00:09 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:09 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:10 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:10 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:00:10 --> Language Class Initialized
DEBUG - 2013-08-29 16:00:10 --> Loader Class Initialized
DEBUG - 2013-08-29 16:00:10 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:00:10 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:00:10 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:00:10 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:00:10 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:00:10 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:00:10 --> Session Class Initialized
DEBUG - 2013-08-29 16:00:10 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:00:10 --> Session routines successfully run
DEBUG - 2013-08-29 16:00:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:00:10 --> Controller Class Initialized
ERROR - 2013-08-29 16:00:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:11 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:00:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:00:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:00:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:00:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:11 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:11 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:11 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:11 --> Config Class Initialized
DEBUG - 2013-08-29 16:00:11 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:00:11 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:00:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:00:11 --> URI Class Initialized
DEBUG - 2013-08-29 16:00:11 --> Router Class Initialized
DEBUG - 2013-08-29 16:00:11 --> Output Class Initialized
DEBUG - 2013-08-29 16:00:12 --> Security Class Initialized
DEBUG - 2013-08-29 16:00:12 --> Input Class Initialized
DEBUG - 2013-08-29 16:00:12 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:12 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:00:12 --> Language Class Initialized
DEBUG - 2013-08-29 16:00:12 --> Loader Class Initialized
DEBUG - 2013-08-29 16:00:12 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:00:12 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:00:12 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:00:12 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:00:12 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:00:12 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:00:12 --> Session Class Initialized
DEBUG - 2013-08-29 16:00:12 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:00:12 --> Session routines successfully run
DEBUG - 2013-08-29 16:00:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:00:12 --> Controller Class Initialized
ERROR - 2013-08-29 16:00:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:12 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:00:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:00:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:00:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:00:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:13 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:13 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:00:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:00:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:00:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:00:13 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:00:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:00:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:00:13 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 16:00:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:00:13 --> Final output sent to browser
DEBUG - 2013-08-29 16:00:13 --> Total execution time: 2.2241
DEBUG - 2013-08-29 16:00:14 --> Config Class Initialized
DEBUG - 2013-08-29 16:00:14 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:00:14 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:00:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:00:14 --> URI Class Initialized
DEBUG - 2013-08-29 16:00:14 --> Router Class Initialized
ERROR - 2013-08-29 16:00:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:00:23 --> Config Class Initialized
DEBUG - 2013-08-29 16:00:23 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:00:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:00:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:00:23 --> URI Class Initialized
DEBUG - 2013-08-29 16:00:23 --> Router Class Initialized
DEBUG - 2013-08-29 16:00:23 --> Output Class Initialized
DEBUG - 2013-08-29 16:00:23 --> Security Class Initialized
DEBUG - 2013-08-29 16:00:24 --> Input Class Initialized
DEBUG - 2013-08-29 16:00:24 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:24 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:24 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:24 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:24 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:00:24 --> Language Class Initialized
DEBUG - 2013-08-29 16:00:24 --> Loader Class Initialized
DEBUG - 2013-08-29 16:00:24 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:00:24 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:00:24 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:00:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:00:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:00:24 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:00:24 --> Session Class Initialized
DEBUG - 2013-08-29 16:00:24 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:00:24 --> Session routines successfully run
DEBUG - 2013-08-29 16:00:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:00:24 --> Controller Class Initialized
ERROR - 2013-08-29 16:00:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:25 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:00:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:00:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:00:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:00:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:25 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:25 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:00:25 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:25 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:25 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:25 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:25 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:25 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:25 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:00:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:00:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:00:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:00:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:00:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:00:26 --> File loaded: application/views/user_privileges/index.php
DEBUG - 2013-08-29 16:00:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:00:26 --> Final output sent to browser
DEBUG - 2013-08-29 16:00:26 --> Total execution time: 2.6872
DEBUG - 2013-08-29 16:00:26 --> Config Class Initialized
DEBUG - 2013-08-29 16:00:26 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:00:26 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:00:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:00:26 --> URI Class Initialized
DEBUG - 2013-08-29 16:00:26 --> Router Class Initialized
ERROR - 2013-08-29 16:00:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:00:33 --> Config Class Initialized
DEBUG - 2013-08-29 16:00:33 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:00:33 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:00:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:00:33 --> URI Class Initialized
DEBUG - 2013-08-29 16:00:34 --> Router Class Initialized
DEBUG - 2013-08-29 16:00:34 --> Output Class Initialized
DEBUG - 2013-08-29 16:00:34 --> Security Class Initialized
DEBUG - 2013-08-29 16:00:34 --> Input Class Initialized
DEBUG - 2013-08-29 16:00:34 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:34 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:00:34 --> Language Class Initialized
DEBUG - 2013-08-29 16:00:34 --> Loader Class Initialized
DEBUG - 2013-08-29 16:00:34 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:00:34 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:00:34 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:00:34 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:00:34 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:00:34 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:00:34 --> Session Class Initialized
DEBUG - 2013-08-29 16:00:34 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:00:34 --> Session routines successfully run
DEBUG - 2013-08-29 16:00:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:00:34 --> Controller Class Initialized
ERROR - 2013-08-29 16:00:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:35 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:00:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:00:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:00:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:00:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:35 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:35 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:00:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:00:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:00:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:00:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:00:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:00:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:00:35 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-29 16:00:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:00:36 --> Final output sent to browser
DEBUG - 2013-08-29 16:00:36 --> Total execution time: 2.1801
DEBUG - 2013-08-29 16:00:36 --> Config Class Initialized
DEBUG - 2013-08-29 16:00:36 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:00:36 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:00:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:00:36 --> URI Class Initialized
DEBUG - 2013-08-29 16:00:36 --> Router Class Initialized
ERROR - 2013-08-29 16:00:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:00:56 --> Config Class Initialized
DEBUG - 2013-08-29 16:00:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:00:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:00:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:00:56 --> URI Class Initialized
DEBUG - 2013-08-29 16:00:56 --> Router Class Initialized
DEBUG - 2013-08-29 16:00:56 --> Output Class Initialized
DEBUG - 2013-08-29 16:00:56 --> Security Class Initialized
DEBUG - 2013-08-29 16:00:56 --> Input Class Initialized
DEBUG - 2013-08-29 16:00:56 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:56 --> XSS Filtering completed
DEBUG - 2013-08-29 16:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:00:56 --> Language Class Initialized
DEBUG - 2013-08-29 16:00:56 --> Loader Class Initialized
DEBUG - 2013-08-29 16:00:56 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:00:56 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:00:56 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:00:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:00:56 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:00:57 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:00:57 --> Session Class Initialized
DEBUG - 2013-08-29 16:00:57 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:00:57 --> Session routines successfully run
DEBUG - 2013-08-29 16:00:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:00:57 --> Controller Class Initialized
ERROR - 2013-08-29 16:00:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:57 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:00:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:00:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:00:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:00:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:00:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:00:57 --> Model Class Initialized
DEBUG - 2013-08-29 16:00:57 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:00:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:00:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:00:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:00:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:00:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:00:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:00:58 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-29 16:00:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:00:58 --> Final output sent to browser
DEBUG - 2013-08-29 16:00:58 --> Total execution time: 2.2431
DEBUG - 2013-08-29 16:00:58 --> Config Class Initialized
DEBUG - 2013-08-29 16:00:58 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:00:58 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:00:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:00:58 --> URI Class Initialized
DEBUG - 2013-08-29 16:00:58 --> Router Class Initialized
ERROR - 2013-08-29 16:00:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:02:13 --> Config Class Initialized
DEBUG - 2013-08-29 16:02:13 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:02:13 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:02:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:02:13 --> URI Class Initialized
DEBUG - 2013-08-29 16:02:13 --> Router Class Initialized
DEBUG - 2013-08-29 16:02:13 --> Output Class Initialized
DEBUG - 2013-08-29 16:02:13 --> Security Class Initialized
DEBUG - 2013-08-29 16:02:13 --> Input Class Initialized
DEBUG - 2013-08-29 16:02:13 --> XSS Filtering completed
DEBUG - 2013-08-29 16:02:13 --> XSS Filtering completed
DEBUG - 2013-08-29 16:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:02:13 --> Language Class Initialized
DEBUG - 2013-08-29 16:02:13 --> Loader Class Initialized
DEBUG - 2013-08-29 16:02:13 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:02:13 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:02:13 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:02:13 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:02:13 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:02:13 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:02:13 --> Session Class Initialized
DEBUG - 2013-08-29 16:02:14 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:02:14 --> Session routines successfully run
DEBUG - 2013-08-29 16:02:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:02:14 --> Controller Class Initialized
ERROR - 2013-08-29 16:02:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:02:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:02:14 --> Model Class Initialized
DEBUG - 2013-08-29 16:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:02:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:02:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:02:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:02:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:02:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:02:14 --> Model Class Initialized
ERROR - 2013-08-29 16:02:14 --> 404 Page Not Found --> users/index
DEBUG - 2013-08-29 16:03:15 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:15 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:15 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:15 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:15 --> Router Class Initialized
DEBUG - 2013-08-29 16:03:15 --> Output Class Initialized
DEBUG - 2013-08-29 16:03:15 --> Security Class Initialized
DEBUG - 2013-08-29 16:03:15 --> Input Class Initialized
DEBUG - 2013-08-29 16:03:15 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:15 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:03:15 --> Language Class Initialized
DEBUG - 2013-08-29 16:03:15 --> Loader Class Initialized
DEBUG - 2013-08-29 16:03:15 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:03:16 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:03:16 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:03:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:03:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:03:16 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:03:16 --> Session Class Initialized
DEBUG - 2013-08-29 16:03:16 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:03:16 --> Session routines successfully run
DEBUG - 2013-08-29 16:03:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:03:16 --> Controller Class Initialized
ERROR - 2013-08-29 16:03:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:16 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:03:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:03:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:03:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:03:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:17 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:17 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:03:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:03:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:03:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:03:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:03:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:03:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:03:17 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-08-29 16:03:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:03:17 --> Final output sent to browser
DEBUG - 2013-08-29 16:03:17 --> Total execution time: 2.3471
DEBUG - 2013-08-29 16:03:18 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:18 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:18 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:18 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:18 --> Router Class Initialized
ERROR - 2013-08-29 16:03:18 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:03:20 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:20 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:21 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:21 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:21 --> Router Class Initialized
DEBUG - 2013-08-29 16:03:21 --> Output Class Initialized
DEBUG - 2013-08-29 16:03:21 --> Security Class Initialized
DEBUG - 2013-08-29 16:03:21 --> Input Class Initialized
DEBUG - 2013-08-29 16:03:21 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:21 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:03:21 --> Language Class Initialized
DEBUG - 2013-08-29 16:03:21 --> Loader Class Initialized
DEBUG - 2013-08-29 16:03:21 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:03:21 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:03:21 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:03:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:03:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:03:21 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:03:21 --> Session Class Initialized
DEBUG - 2013-08-29 16:03:21 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:03:21 --> Session routines successfully run
DEBUG - 2013-08-29 16:03:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:03:22 --> Controller Class Initialized
ERROR - 2013-08-29 16:03:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:22 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:03:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:03:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:03:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:03:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:22 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:22 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:03:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:03:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:03:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:03:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:03:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:03:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:03:23 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-29 16:03:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:03:23 --> Final output sent to browser
DEBUG - 2013-08-29 16:03:23 --> Total execution time: 2.3601
DEBUG - 2013-08-29 16:03:23 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:23 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:23 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:23 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:23 --> Router Class Initialized
ERROR - 2013-08-29 16:03:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:03:27 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:27 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:27 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:27 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:27 --> Router Class Initialized
DEBUG - 2013-08-29 16:03:28 --> Output Class Initialized
DEBUG - 2013-08-29 16:03:28 --> Security Class Initialized
DEBUG - 2013-08-29 16:03:28 --> Input Class Initialized
DEBUG - 2013-08-29 16:03:28 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:28 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:03:28 --> Language Class Initialized
DEBUG - 2013-08-29 16:03:28 --> Loader Class Initialized
DEBUG - 2013-08-29 16:03:28 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:03:28 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:03:28 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:03:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:03:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:03:28 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:03:28 --> Session Class Initialized
DEBUG - 2013-08-29 16:03:28 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:03:28 --> Session routines successfully run
DEBUG - 2013-08-29 16:03:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:03:28 --> Controller Class Initialized
ERROR - 2013-08-29 16:03:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:29 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:03:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:03:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:03:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:03:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:29 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:29 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:03:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:03:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:03:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:03:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:03:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:03:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:03:29 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-29 16:03:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:03:29 --> Final output sent to browser
DEBUG - 2013-08-29 16:03:29 --> Total execution time: 2.2131
DEBUG - 2013-08-29 16:03:30 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:30 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:30 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:30 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:30 --> Router Class Initialized
ERROR - 2013-08-29 16:03:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:03:32 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:32 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:32 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:32 --> Router Class Initialized
DEBUG - 2013-08-29 16:03:33 --> Output Class Initialized
DEBUG - 2013-08-29 16:03:33 --> Security Class Initialized
DEBUG - 2013-08-29 16:03:33 --> Input Class Initialized
DEBUG - 2013-08-29 16:03:33 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:33 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:03:33 --> Language Class Initialized
DEBUG - 2013-08-29 16:03:33 --> Loader Class Initialized
DEBUG - 2013-08-29 16:03:33 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:03:33 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:03:33 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:03:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:03:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:03:33 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:03:33 --> Session Class Initialized
DEBUG - 2013-08-29 16:03:33 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:03:33 --> Session routines successfully run
DEBUG - 2013-08-29 16:03:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:03:34 --> Controller Class Initialized
ERROR - 2013-08-29 16:03:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:34 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:03:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:03:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:03:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:03:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:34 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:34 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:03:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:03:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:03:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:03:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:03:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:03:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:03:35 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-29 16:03:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:03:35 --> Final output sent to browser
DEBUG - 2013-08-29 16:03:35 --> Total execution time: 2.6382
DEBUG - 2013-08-29 16:03:35 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:35 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:35 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:35 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:35 --> Router Class Initialized
ERROR - 2013-08-29 16:03:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:03:47 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:47 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:47 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:48 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:48 --> Router Class Initialized
DEBUG - 2013-08-29 16:03:48 --> Output Class Initialized
DEBUG - 2013-08-29 16:03:48 --> Security Class Initialized
DEBUG - 2013-08-29 16:03:48 --> Input Class Initialized
DEBUG - 2013-08-29 16:03:48 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:48 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:03:48 --> Language Class Initialized
DEBUG - 2013-08-29 16:03:48 --> Loader Class Initialized
DEBUG - 2013-08-29 16:03:48 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:03:48 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:03:48 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:03:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:03:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:03:48 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:03:48 --> Session Class Initialized
DEBUG - 2013-08-29 16:03:48 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:03:48 --> Session routines successfully run
DEBUG - 2013-08-29 16:03:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:03:48 --> Controller Class Initialized
ERROR - 2013-08-29 16:03:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:49 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:03:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:03:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:03:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:03:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:49 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:49 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:03:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:03:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:03:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:03:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:03:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:03:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:03:49 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-29 16:03:50 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:03:50 --> Final output sent to browser
DEBUG - 2013-08-29 16:03:50 --> Total execution time: 2.1861
DEBUG - 2013-08-29 16:03:50 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:50 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:50 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:50 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:50 --> Router Class Initialized
ERROR - 2013-08-29 16:03:50 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:03:53 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:53 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:53 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:53 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:53 --> Router Class Initialized
DEBUG - 2013-08-29 16:03:53 --> Output Class Initialized
DEBUG - 2013-08-29 16:03:53 --> Security Class Initialized
DEBUG - 2013-08-29 16:03:53 --> Input Class Initialized
DEBUG - 2013-08-29 16:03:53 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:53 --> XSS Filtering completed
DEBUG - 2013-08-29 16:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:03:53 --> Language Class Initialized
DEBUG - 2013-08-29 16:03:53 --> Loader Class Initialized
DEBUG - 2013-08-29 16:03:53 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:03:53 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:03:54 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:03:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:03:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:03:54 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:03:54 --> Session Class Initialized
DEBUG - 2013-08-29 16:03:54 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:03:54 --> Session routines successfully run
DEBUG - 2013-08-29 16:03:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:03:54 --> Controller Class Initialized
ERROR - 2013-08-29 16:03:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:54 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:03:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:03:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:03:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:03:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:03:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:03:54 --> Model Class Initialized
DEBUG - 2013-08-29 16:03:55 --> Pagination Class Initialized
DEBUG - 2013-08-29 16:03:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:03:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:03:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:03:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 16:03:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 16:03:55 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-29 16:03:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-29 16:03:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-29 16:03:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-29 16:03:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-29 16:03:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-08-29 16:03:55 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-29 16:03:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:03:55 --> Final output sent to browser
DEBUG - 2013-08-29 16:03:55 --> Total execution time: 2.4521
DEBUG - 2013-08-29 16:03:56 --> Config Class Initialized
DEBUG - 2013-08-29 16:03:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:03:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:03:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:03:56 --> URI Class Initialized
DEBUG - 2013-08-29 16:03:56 --> Router Class Initialized
ERROR - 2013-08-29 16:03:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:12:46 --> Config Class Initialized
DEBUG - 2013-08-29 16:12:46 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:12:46 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:12:46 --> URI Class Initialized
DEBUG - 2013-08-29 16:12:46 --> Router Class Initialized
DEBUG - 2013-08-29 16:12:46 --> Output Class Initialized
DEBUG - 2013-08-29 16:12:46 --> Security Class Initialized
DEBUG - 2013-08-29 16:12:46 --> Input Class Initialized
DEBUG - 2013-08-29 16:12:46 --> XSS Filtering completed
DEBUG - 2013-08-29 16:12:46 --> XSS Filtering completed
DEBUG - 2013-08-29 16:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:12:46 --> Language Class Initialized
DEBUG - 2013-08-29 16:12:47 --> Loader Class Initialized
DEBUG - 2013-08-29 16:12:47 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:12:47 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:12:47 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:12:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:12:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:12:47 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:12:47 --> Session Class Initialized
DEBUG - 2013-08-29 16:12:47 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:12:47 --> Session routines successfully run
DEBUG - 2013-08-29 16:12:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:12:47 --> Controller Class Initialized
ERROR - 2013-08-29 16:12:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:12:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:12:47 --> Model Class Initialized
DEBUG - 2013-08-29 16:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:12:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:12:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:12:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:12:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:12:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:12:48 --> Config Class Initialized
DEBUG - 2013-08-29 16:12:48 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:12:48 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:12:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:12:48 --> URI Class Initialized
DEBUG - 2013-08-29 16:12:48 --> Router Class Initialized
DEBUG - 2013-08-29 16:12:48 --> Output Class Initialized
DEBUG - 2013-08-29 16:12:48 --> Security Class Initialized
DEBUG - 2013-08-29 16:12:48 --> Input Class Initialized
DEBUG - 2013-08-29 16:12:48 --> XSS Filtering completed
DEBUG - 2013-08-29 16:12:48 --> XSS Filtering completed
DEBUG - 2013-08-29 16:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:12:48 --> Language Class Initialized
DEBUG - 2013-08-29 16:12:48 --> Loader Class Initialized
DEBUG - 2013-08-29 16:12:48 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:12:49 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:12:49 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:12:49 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:12:49 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:12:49 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:12:49 --> Session Class Initialized
DEBUG - 2013-08-29 16:12:49 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:12:49 --> Session routines successfully run
DEBUG - 2013-08-29 16:12:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:12:49 --> Controller Class Initialized
ERROR - 2013-08-29 16:12:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:12:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:12:49 --> Model Class Initialized
DEBUG - 2013-08-29 16:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:12:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:12:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:12:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:12:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:12:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:12:50 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 16:12:50 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 16:12:50 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 16:12:50 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 16:12:50 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 16:12:50 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 16:12:50 --> Final output sent to browser
DEBUG - 2013-08-29 16:12:50 --> Total execution time: 2.1741
DEBUG - 2013-08-29 16:12:50 --> Config Class Initialized
DEBUG - 2013-08-29 16:12:50 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:12:50 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:12:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:12:50 --> URI Class Initialized
DEBUG - 2013-08-29 16:12:50 --> Router Class Initialized
ERROR - 2013-08-29 16:12:50 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 16:12:57 --> Config Class Initialized
DEBUG - 2013-08-29 16:12:57 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:12:57 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:12:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:12:57 --> URI Class Initialized
DEBUG - 2013-08-29 16:12:57 --> Router Class Initialized
DEBUG - 2013-08-29 16:12:57 --> Output Class Initialized
DEBUG - 2013-08-29 16:12:57 --> Security Class Initialized
DEBUG - 2013-08-29 16:12:57 --> Input Class Initialized
DEBUG - 2013-08-29 16:12:58 --> XSS Filtering completed
DEBUG - 2013-08-29 16:12:58 --> XSS Filtering completed
DEBUG - 2013-08-29 16:12:58 --> XSS Filtering completed
DEBUG - 2013-08-29 16:12:58 --> XSS Filtering completed
DEBUG - 2013-08-29 16:12:58 --> XSS Filtering completed
DEBUG - 2013-08-29 16:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:12:58 --> Language Class Initialized
DEBUG - 2013-08-29 16:12:58 --> Loader Class Initialized
DEBUG - 2013-08-29 16:12:58 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:12:58 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:12:58 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:12:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:12:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:12:58 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:12:58 --> Session Class Initialized
DEBUG - 2013-08-29 16:12:58 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:12:58 --> Session routines successfully run
DEBUG - 2013-08-29 16:12:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:12:58 --> Controller Class Initialized
ERROR - 2013-08-29 16:12:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:12:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:12:59 --> Model Class Initialized
DEBUG - 2013-08-29 16:12:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:12:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:12:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:12:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:12:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:12:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:12:59 --> Model Class Initialized
DEBUG - 2013-08-29 16:12:59 --> Form Validation Class Initialized
DEBUG - 2013-08-29 16:12:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 16:12:59 --> Config Class Initialized
DEBUG - 2013-08-29 16:12:59 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:12:59 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:13:00 --> URI Class Initialized
DEBUG - 2013-08-29 16:13:00 --> Router Class Initialized
DEBUG - 2013-08-29 16:13:00 --> Output Class Initialized
DEBUG - 2013-08-29 16:13:00 --> Security Class Initialized
DEBUG - 2013-08-29 16:13:00 --> Input Class Initialized
DEBUG - 2013-08-29 16:13:00 --> XSS Filtering completed
DEBUG - 2013-08-29 16:13:00 --> XSS Filtering completed
DEBUG - 2013-08-29 16:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:13:00 --> Language Class Initialized
DEBUG - 2013-08-29 16:13:00 --> Loader Class Initialized
DEBUG - 2013-08-29 16:13:00 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:13:00 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:13:00 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:13:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:13:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:13:00 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:13:00 --> Session Class Initialized
DEBUG - 2013-08-29 16:13:00 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:13:01 --> Session routines successfully run
DEBUG - 2013-08-29 16:13:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:13:01 --> Controller Class Initialized
ERROR - 2013-08-29 16:13:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:13:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:13:01 --> Model Class Initialized
DEBUG - 2013-08-29 16:13:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:13:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:13:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:13:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:13:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:13:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:13:01 --> Config Class Initialized
DEBUG - 2013-08-29 16:13:01 --> Hooks Class Initialized
DEBUG - 2013-08-29 16:13:01 --> Utf8 Class Initialized
DEBUG - 2013-08-29 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 16:13:01 --> URI Class Initialized
DEBUG - 2013-08-29 16:13:01 --> Router Class Initialized
DEBUG - 2013-08-29 16:13:02 --> Output Class Initialized
DEBUG - 2013-08-29 16:13:02 --> Security Class Initialized
DEBUG - 2013-08-29 16:13:02 --> Input Class Initialized
DEBUG - 2013-08-29 16:13:02 --> XSS Filtering completed
DEBUG - 2013-08-29 16:13:02 --> XSS Filtering completed
DEBUG - 2013-08-29 16:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 16:13:02 --> Language Class Initialized
DEBUG - 2013-08-29 16:13:02 --> Loader Class Initialized
DEBUG - 2013-08-29 16:13:02 --> Helper loaded: url_helper
DEBUG - 2013-08-29 16:13:02 --> Helper loaded: file_helper
DEBUG - 2013-08-29 16:13:02 --> Helper loaded: form_helper
DEBUG - 2013-08-29 16:13:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 16:13:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 16:13:02 --> Database Driver Class Initialized
DEBUG - 2013-08-29 16:13:02 --> Session Class Initialized
DEBUG - 2013-08-29 16:13:03 --> Helper loaded: string_helper
DEBUG - 2013-08-29 16:13:03 --> Session routines successfully run
DEBUG - 2013-08-29 16:13:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 16:13:03 --> Controller Class Initialized
ERROR - 2013-08-29 16:13:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:13:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:13:03 --> Model Class Initialized
DEBUG - 2013-08-29 16:13:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 16:13:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 16:13:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 16:13:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 16:13:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 16:13:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 16:13:03 --> Model Class Initialized
DEBUG - 2013-08-29 16:13:03 --> DB Transaction Failure
ERROR - 2013-08-29 16:13:03 --> Query error: Unknown column 'user_privileges.upriv_nawwme' in 'field list'
DEBUG - 2013-08-29 16:13:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 17:07:14 --> Config Class Initialized
DEBUG - 2013-08-29 17:07:14 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:07:14 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:07:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:07:14 --> URI Class Initialized
DEBUG - 2013-08-29 17:07:14 --> Router Class Initialized
DEBUG - 2013-08-29 17:07:14 --> Output Class Initialized
DEBUG - 2013-08-29 17:07:14 --> Security Class Initialized
DEBUG - 2013-08-29 17:07:14 --> Input Class Initialized
DEBUG - 2013-08-29 17:07:14 --> XSS Filtering completed
DEBUG - 2013-08-29 17:07:14 --> XSS Filtering completed
DEBUG - 2013-08-29 17:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 17:07:14 --> Language Class Initialized
DEBUG - 2013-08-29 17:07:14 --> Loader Class Initialized
DEBUG - 2013-08-29 17:07:14 --> Helper loaded: url_helper
DEBUG - 2013-08-29 17:07:15 --> Helper loaded: file_helper
DEBUG - 2013-08-29 17:07:15 --> Helper loaded: form_helper
DEBUG - 2013-08-29 17:07:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 17:07:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 17:07:15 --> Database Driver Class Initialized
DEBUG - 2013-08-29 17:07:15 --> Session Class Initialized
DEBUG - 2013-08-29 17:07:15 --> Helper loaded: string_helper
DEBUG - 2013-08-29 17:07:15 --> Session routines successfully run
DEBUG - 2013-08-29 17:07:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 17:07:15 --> Controller Class Initialized
ERROR - 2013-08-29 17:07:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:07:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:07:15 --> Model Class Initialized
DEBUG - 2013-08-29 17:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 17:07:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 17:07:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 17:07:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 17:07:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:07:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:07:16 --> Model Class Initialized
DEBUG - 2013-08-29 17:07:16 --> DB Transaction Failure
ERROR - 2013-08-29 17:07:16 --> Query error: Unknown column 'user_privileges.upriv_nawwme' in 'field list'
DEBUG - 2013-08-29 17:07:16 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-29 17:11:09 --> Config Class Initialized
DEBUG - 2013-08-29 17:11:09 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:11:09 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:11:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:11:09 --> URI Class Initialized
DEBUG - 2013-08-29 17:11:09 --> Router Class Initialized
DEBUG - 2013-08-29 17:11:09 --> Output Class Initialized
DEBUG - 2013-08-29 17:11:09 --> Security Class Initialized
DEBUG - 2013-08-29 17:11:09 --> Input Class Initialized
DEBUG - 2013-08-29 17:11:09 --> XSS Filtering completed
DEBUG - 2013-08-29 17:11:09 --> XSS Filtering completed
DEBUG - 2013-08-29 17:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 17:11:09 --> Language Class Initialized
DEBUG - 2013-08-29 17:11:09 --> Loader Class Initialized
DEBUG - 2013-08-29 17:11:09 --> Helper loaded: url_helper
DEBUG - 2013-08-29 17:11:09 --> Helper loaded: file_helper
DEBUG - 2013-08-29 17:11:09 --> Helper loaded: form_helper
DEBUG - 2013-08-29 17:11:10 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 17:11:10 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 17:11:10 --> Database Driver Class Initialized
DEBUG - 2013-08-29 17:11:10 --> Session Class Initialized
DEBUG - 2013-08-29 17:11:10 --> Helper loaded: string_helper
DEBUG - 2013-08-29 17:11:10 --> Session routines successfully run
DEBUG - 2013-08-29 17:11:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 17:11:10 --> Controller Class Initialized
ERROR - 2013-08-29 17:11:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:11:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:11:10 --> Model Class Initialized
DEBUG - 2013-08-29 17:11:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 17:11:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 17:11:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 17:11:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 17:11:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:11:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:11:11 --> Model Class Initialized
DEBUG - 2013-08-29 17:11:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 17:11:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 17:11:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 17:11:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 17:11:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 17:11:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 17:11:11 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 17:11:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 17:11:11 --> Final output sent to browser
DEBUG - 2013-08-29 17:11:11 --> Total execution time: 2.5631
DEBUG - 2013-08-29 17:11:11 --> Config Class Initialized
DEBUG - 2013-08-29 17:11:12 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:11:12 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:11:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:11:12 --> URI Class Initialized
DEBUG - 2013-08-29 17:11:12 --> Router Class Initialized
ERROR - 2013-08-29 17:11:12 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 17:12:06 --> Config Class Initialized
DEBUG - 2013-08-29 17:12:06 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:12:06 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:12:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:12:06 --> URI Class Initialized
DEBUG - 2013-08-29 17:12:06 --> Router Class Initialized
DEBUG - 2013-08-29 17:12:06 --> Output Class Initialized
DEBUG - 2013-08-29 17:12:06 --> Security Class Initialized
DEBUG - 2013-08-29 17:12:06 --> Input Class Initialized
DEBUG - 2013-08-29 17:12:06 --> XSS Filtering completed
DEBUG - 2013-08-29 17:12:06 --> XSS Filtering completed
DEBUG - 2013-08-29 17:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 17:12:06 --> Language Class Initialized
DEBUG - 2013-08-29 17:12:07 --> Loader Class Initialized
DEBUG - 2013-08-29 17:12:07 --> Helper loaded: url_helper
DEBUG - 2013-08-29 17:12:07 --> Helper loaded: file_helper
DEBUG - 2013-08-29 17:12:07 --> Helper loaded: form_helper
DEBUG - 2013-08-29 17:12:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 17:12:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 17:12:07 --> Database Driver Class Initialized
DEBUG - 2013-08-29 17:12:07 --> Session Class Initialized
DEBUG - 2013-08-29 17:12:07 --> Helper loaded: string_helper
DEBUG - 2013-08-29 17:12:07 --> Session routines successfully run
DEBUG - 2013-08-29 17:12:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 17:12:07 --> Controller Class Initialized
ERROR - 2013-08-29 17:12:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:12:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:12:07 --> Model Class Initialized
DEBUG - 2013-08-29 17:12:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 17:12:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 17:12:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 17:12:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 17:12:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:12:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:12:08 --> Config Class Initialized
DEBUG - 2013-08-29 17:12:08 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:12:08 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:12:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:12:08 --> URI Class Initialized
DEBUG - 2013-08-29 17:12:08 --> Router Class Initialized
DEBUG - 2013-08-29 17:12:08 --> Output Class Initialized
DEBUG - 2013-08-29 17:12:08 --> Security Class Initialized
DEBUG - 2013-08-29 17:12:08 --> Input Class Initialized
DEBUG - 2013-08-29 17:12:08 --> XSS Filtering completed
DEBUG - 2013-08-29 17:12:08 --> XSS Filtering completed
DEBUG - 2013-08-29 17:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 17:12:08 --> Language Class Initialized
DEBUG - 2013-08-29 17:12:08 --> Loader Class Initialized
DEBUG - 2013-08-29 17:12:08 --> Helper loaded: url_helper
DEBUG - 2013-08-29 17:12:09 --> Helper loaded: file_helper
DEBUG - 2013-08-29 17:12:09 --> Helper loaded: form_helper
DEBUG - 2013-08-29 17:12:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 17:12:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 17:12:09 --> Database Driver Class Initialized
DEBUG - 2013-08-29 17:12:09 --> Session Class Initialized
DEBUG - 2013-08-29 17:12:09 --> Helper loaded: string_helper
DEBUG - 2013-08-29 17:12:09 --> Session routines successfully run
DEBUG - 2013-08-29 17:12:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 17:12:09 --> Controller Class Initialized
ERROR - 2013-08-29 17:12:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:12:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:12:09 --> Model Class Initialized
DEBUG - 2013-08-29 17:12:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 17:12:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 17:12:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 17:12:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 17:12:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:12:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:12:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 17:12:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 17:12:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 17:12:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 17:12:10 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-29 17:12:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 17:12:10 --> Final output sent to browser
DEBUG - 2013-08-29 17:12:10 --> Total execution time: 2.2771
DEBUG - 2013-08-29 17:12:10 --> Config Class Initialized
DEBUG - 2013-08-29 17:12:10 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:12:10 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:12:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:12:10 --> URI Class Initialized
DEBUG - 2013-08-29 17:12:11 --> Router Class Initialized
ERROR - 2013-08-29 17:12:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 17:13:56 --> Config Class Initialized
DEBUG - 2013-08-29 17:13:56 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:13:56 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:13:57 --> URI Class Initialized
DEBUG - 2013-08-29 17:13:57 --> Router Class Initialized
DEBUG - 2013-08-29 17:13:57 --> Output Class Initialized
DEBUG - 2013-08-29 17:13:57 --> Security Class Initialized
DEBUG - 2013-08-29 17:13:57 --> Input Class Initialized
DEBUG - 2013-08-29 17:13:57 --> XSS Filtering completed
DEBUG - 2013-08-29 17:13:57 --> XSS Filtering completed
DEBUG - 2013-08-29 17:13:57 --> XSS Filtering completed
DEBUG - 2013-08-29 17:13:57 --> XSS Filtering completed
DEBUG - 2013-08-29 17:13:57 --> XSS Filtering completed
DEBUG - 2013-08-29 17:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 17:13:57 --> Language Class Initialized
DEBUG - 2013-08-29 17:13:57 --> Loader Class Initialized
DEBUG - 2013-08-29 17:13:57 --> Helper loaded: url_helper
DEBUG - 2013-08-29 17:13:57 --> Helper loaded: file_helper
DEBUG - 2013-08-29 17:13:57 --> Helper loaded: form_helper
DEBUG - 2013-08-29 17:13:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 17:13:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 17:13:57 --> Database Driver Class Initialized
DEBUG - 2013-08-29 17:13:58 --> Session Class Initialized
DEBUG - 2013-08-29 17:13:58 --> Helper loaded: string_helper
DEBUG - 2013-08-29 17:13:58 --> Session routines successfully run
DEBUG - 2013-08-29 17:13:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 17:13:58 --> Controller Class Initialized
ERROR - 2013-08-29 17:13:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:13:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:13:58 --> Model Class Initialized
DEBUG - 2013-08-29 17:13:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 17:13:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 17:13:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 17:13:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 17:13:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:13:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:13:58 --> Model Class Initialized
DEBUG - 2013-08-29 17:13:59 --> Form Validation Class Initialized
DEBUG - 2013-08-29 17:13:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-29 17:13:59 --> Config Class Initialized
DEBUG - 2013-08-29 17:13:59 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:13:59 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:13:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:13:59 --> URI Class Initialized
DEBUG - 2013-08-29 17:13:59 --> Router Class Initialized
DEBUG - 2013-08-29 17:13:59 --> Output Class Initialized
DEBUG - 2013-08-29 17:13:59 --> Security Class Initialized
DEBUG - 2013-08-29 17:13:59 --> Input Class Initialized
DEBUG - 2013-08-29 17:13:59 --> XSS Filtering completed
DEBUG - 2013-08-29 17:13:59 --> XSS Filtering completed
DEBUG - 2013-08-29 17:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 17:13:59 --> Language Class Initialized
DEBUG - 2013-08-29 17:13:59 --> Loader Class Initialized
DEBUG - 2013-08-29 17:14:00 --> Helper loaded: url_helper
DEBUG - 2013-08-29 17:14:00 --> Helper loaded: file_helper
DEBUG - 2013-08-29 17:14:00 --> Helper loaded: form_helper
DEBUG - 2013-08-29 17:14:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 17:14:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 17:14:00 --> Database Driver Class Initialized
DEBUG - 2013-08-29 17:14:00 --> Session Class Initialized
DEBUG - 2013-08-29 17:14:00 --> Helper loaded: string_helper
DEBUG - 2013-08-29 17:14:00 --> Session garbage collection performed.
DEBUG - 2013-08-29 17:14:00 --> Session routines successfully run
DEBUG - 2013-08-29 17:14:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 17:14:00 --> Controller Class Initialized
ERROR - 2013-08-29 17:14:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:14:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:14:00 --> Model Class Initialized
DEBUG - 2013-08-29 17:14:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 17:14:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 17:14:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 17:14:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 17:14:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:14:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:14:01 --> Config Class Initialized
DEBUG - 2013-08-29 17:14:01 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:14:01 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:14:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:14:01 --> URI Class Initialized
DEBUG - 2013-08-29 17:14:01 --> Router Class Initialized
DEBUG - 2013-08-29 17:14:01 --> Output Class Initialized
DEBUG - 2013-08-29 17:14:01 --> Security Class Initialized
DEBUG - 2013-08-29 17:14:01 --> Input Class Initialized
DEBUG - 2013-08-29 17:14:01 --> XSS Filtering completed
DEBUG - 2013-08-29 17:14:01 --> XSS Filtering completed
DEBUG - 2013-08-29 17:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 17:14:01 --> Language Class Initialized
DEBUG - 2013-08-29 17:14:01 --> Loader Class Initialized
DEBUG - 2013-08-29 17:14:02 --> Helper loaded: url_helper
DEBUG - 2013-08-29 17:14:02 --> Helper loaded: file_helper
DEBUG - 2013-08-29 17:14:02 --> Helper loaded: form_helper
DEBUG - 2013-08-29 17:14:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 17:14:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 17:14:02 --> Database Driver Class Initialized
DEBUG - 2013-08-29 17:14:02 --> Session Class Initialized
DEBUG - 2013-08-29 17:14:02 --> Helper loaded: string_helper
DEBUG - 2013-08-29 17:14:02 --> Session routines successfully run
DEBUG - 2013-08-29 17:14:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 17:14:02 --> Controller Class Initialized
ERROR - 2013-08-29 17:14:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:14:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:14:02 --> Model Class Initialized
DEBUG - 2013-08-29 17:14:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 17:14:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 17:14:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 17:14:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 17:14:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:14:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:14:03 --> Model Class Initialized
DEBUG - 2013-08-29 17:50:19 --> Config Class Initialized
DEBUG - 2013-08-29 17:50:19 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:50:19 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:50:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:50:19 --> URI Class Initialized
DEBUG - 2013-08-29 17:50:19 --> Router Class Initialized
DEBUG - 2013-08-29 17:50:20 --> Output Class Initialized
DEBUG - 2013-08-29 17:50:20 --> Security Class Initialized
DEBUG - 2013-08-29 17:50:20 --> Input Class Initialized
DEBUG - 2013-08-29 17:50:20 --> XSS Filtering completed
DEBUG - 2013-08-29 17:50:20 --> XSS Filtering completed
DEBUG - 2013-08-29 17:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 17:50:20 --> Language Class Initialized
DEBUG - 2013-08-29 17:50:20 --> Loader Class Initialized
DEBUG - 2013-08-29 17:50:20 --> Helper loaded: url_helper
DEBUG - 2013-08-29 17:50:20 --> Helper loaded: file_helper
DEBUG - 2013-08-29 17:50:20 --> Helper loaded: form_helper
DEBUG - 2013-08-29 17:50:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 17:50:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 17:50:20 --> Database Driver Class Initialized
DEBUG - 2013-08-29 17:50:20 --> Session Class Initialized
DEBUG - 2013-08-29 17:50:20 --> Helper loaded: string_helper
DEBUG - 2013-08-29 17:50:20 --> Session routines successfully run
DEBUG - 2013-08-29 17:50:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 17:50:20 --> Controller Class Initialized
ERROR - 2013-08-29 17:50:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:50:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:50:21 --> Model Class Initialized
DEBUG - 2013-08-29 17:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 17:50:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 17:50:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 17:50:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 17:50:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:50:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:50:21 --> Model Class Initialized
DEBUG - 2013-08-29 17:50:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 17:50:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 17:50:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 17:50:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 17:50:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 17:50:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 17:50:21 --> File loaded: application/views/home.php
DEBUG - 2013-08-29 17:50:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 17:50:22 --> Final output sent to browser
DEBUG - 2013-08-29 17:50:22 --> Total execution time: 2.2621
DEBUG - 2013-08-29 17:50:22 --> Config Class Initialized
DEBUG - 2013-08-29 17:50:22 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:50:22 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:50:22 --> URI Class Initialized
DEBUG - 2013-08-29 17:50:22 --> Router Class Initialized
ERROR - 2013-08-29 17:50:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-29 17:50:32 --> Config Class Initialized
DEBUG - 2013-08-29 17:50:32 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:50:32 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:50:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:50:32 --> URI Class Initialized
DEBUG - 2013-08-29 17:50:32 --> Router Class Initialized
DEBUG - 2013-08-29 17:50:32 --> Output Class Initialized
DEBUG - 2013-08-29 17:50:32 --> Security Class Initialized
DEBUG - 2013-08-29 17:50:32 --> Input Class Initialized
DEBUG - 2013-08-29 17:50:32 --> XSS Filtering completed
DEBUG - 2013-08-29 17:50:32 --> XSS Filtering completed
DEBUG - 2013-08-29 17:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-29 17:50:32 --> Language Class Initialized
DEBUG - 2013-08-29 17:50:32 --> Loader Class Initialized
DEBUG - 2013-08-29 17:50:32 --> Helper loaded: url_helper
DEBUG - 2013-08-29 17:50:32 --> Helper loaded: file_helper
DEBUG - 2013-08-29 17:50:32 --> Helper loaded: form_helper
DEBUG - 2013-08-29 17:50:32 --> Helper loaded: inflector_helper
DEBUG - 2013-08-29 17:50:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-29 17:50:33 --> Database Driver Class Initialized
DEBUG - 2013-08-29 17:50:33 --> Session Class Initialized
DEBUG - 2013-08-29 17:50:33 --> Helper loaded: string_helper
DEBUG - 2013-08-29 17:50:33 --> Session routines successfully run
DEBUG - 2013-08-29 17:50:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-29 17:50:33 --> Controller Class Initialized
ERROR - 2013-08-29 17:50:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:50:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:50:33 --> Model Class Initialized
DEBUG - 2013-08-29 17:50:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-29 17:50:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-29 17:50:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-29 17:50:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-29 17:50:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-29 17:50:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-29 17:50:34 --> Model Class Initialized
DEBUG - 2013-08-29 17:50:34 --> Pagination Class Initialized
DEBUG - 2013-08-29 17:50:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-29 17:50:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-29 17:50:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-29 17:50:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-29 17:50:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-29 17:50:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-29 17:50:34 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-29 17:50:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-29 17:50:34 --> Final output sent to browser
DEBUG - 2013-08-29 17:50:34 --> Total execution time: 2.5971
DEBUG - 2013-08-29 17:50:34 --> Config Class Initialized
DEBUG - 2013-08-29 17:50:35 --> Hooks Class Initialized
DEBUG - 2013-08-29 17:50:35 --> Utf8 Class Initialized
DEBUG - 2013-08-29 17:50:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-29 17:50:35 --> URI Class Initialized
DEBUG - 2013-08-29 17:50:35 --> Router Class Initialized
ERROR - 2013-08-29 17:50:35 --> 404 Page Not Found --> css
