<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-21 05:21:01 --> Config Class Initialized
DEBUG - 2013-08-21 05:21:01 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:21:01 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:21:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:21:01 --> URI Class Initialized
DEBUG - 2013-08-21 05:21:01 --> Router Class Initialized
DEBUG - 2013-08-21 05:21:01 --> Output Class Initialized
DEBUG - 2013-08-21 05:21:01 --> Security Class Initialized
DEBUG - 2013-08-21 05:21:01 --> Input Class Initialized
DEBUG - 2013-08-21 05:21:01 --> XSS Filtering completed
DEBUG - 2013-08-21 05:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:21:02 --> Language Class Initialized
DEBUG - 2013-08-21 05:21:02 --> Loader Class Initialized
DEBUG - 2013-08-21 05:21:02 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:21:02 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:21:02 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:21:02 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:21:02 --> Session Class Initialized
DEBUG - 2013-08-21 05:21:02 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:21:02 --> A session cookie was not found.
DEBUG - 2013-08-21 05:21:02 --> Session routines successfully run
DEBUG - 2013-08-21 05:21:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:21:02 --> Controller Class Initialized
ERROR - 2013-08-21 05:21:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:21:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:21:02 --> Model Class Initialized
DEBUG - 2013-08-21 05:21:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:21:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:21:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:21:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:21:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:21:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:21:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:21:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:21:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:21:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:21:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:21:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:21:03 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 05:21:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:21:03 --> Final output sent to browser
DEBUG - 2013-08-21 05:21:03 --> Total execution time: 2.0291
DEBUG - 2013-08-21 05:21:03 --> Config Class Initialized
DEBUG - 2013-08-21 05:21:03 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:21:03 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:21:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:21:03 --> URI Class Initialized
DEBUG - 2013-08-21 05:21:03 --> Router Class Initialized
ERROR - 2013-08-21 05:21:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:22:49 --> Config Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:22:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:22:49 --> URI Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Router Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Output Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Security Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Input Class Initialized
DEBUG - 2013-08-21 05:22:49 --> XSS Filtering completed
DEBUG - 2013-08-21 05:22:49 --> XSS Filtering completed
DEBUG - 2013-08-21 05:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:22:49 --> Language Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Loader Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:22:49 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:22:49 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:22:49 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Session Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:22:49 --> Session routines successfully run
DEBUG - 2013-08-21 05:22:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Controller Class Initialized
ERROR - 2013-08-21 05:22:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:22:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:22:49 --> Model Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:22:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:22:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:22:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:22:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:22:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:22:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:22:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:22:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:22:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:22:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:22:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:22:49 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 05:22:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:22:49 --> Final output sent to browser
DEBUG - 2013-08-21 05:22:49 --> Total execution time: 0.2080
DEBUG - 2013-08-21 05:22:49 --> Config Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:22:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:22:49 --> URI Class Initialized
DEBUG - 2013-08-21 05:22:49 --> Router Class Initialized
ERROR - 2013-08-21 05:22:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:23:29 --> Config Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:23:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:23:29 --> URI Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Router Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Output Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Security Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Input Class Initialized
DEBUG - 2013-08-21 05:23:29 --> XSS Filtering completed
DEBUG - 2013-08-21 05:23:29 --> XSS Filtering completed
DEBUG - 2013-08-21 05:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:23:29 --> Language Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Loader Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:23:29 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:23:29 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:23:29 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Session Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:23:29 --> Session routines successfully run
DEBUG - 2013-08-21 05:23:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Controller Class Initialized
ERROR - 2013-08-21 05:23:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:23:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:23:29 --> Model Class Initialized
DEBUG - 2013-08-21 05:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:23:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:23:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:23:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:23:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:23:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:23:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:23:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:23:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:23:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:23:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:23:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:23:29 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 05:23:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:23:29 --> Final output sent to browser
DEBUG - 2013-08-21 05:23:29 --> Total execution time: 0.2770
DEBUG - 2013-08-21 05:23:30 --> Config Class Initialized
DEBUG - 2013-08-21 05:23:30 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:23:30 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:23:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:23:30 --> URI Class Initialized
DEBUG - 2013-08-21 05:23:30 --> Router Class Initialized
ERROR - 2013-08-21 05:23:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:23:47 --> Config Class Initialized
DEBUG - 2013-08-21 05:23:47 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:23:47 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:23:47 --> URI Class Initialized
DEBUG - 2013-08-21 05:23:47 --> Router Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Output Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Security Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Input Class Initialized
DEBUG - 2013-08-21 05:23:48 --> XSS Filtering completed
DEBUG - 2013-08-21 05:23:48 --> XSS Filtering completed
DEBUG - 2013-08-21 05:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:23:48 --> Language Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Loader Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:23:48 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:23:48 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:23:48 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Session Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:23:48 --> Session routines successfully run
DEBUG - 2013-08-21 05:23:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Controller Class Initialized
ERROR - 2013-08-21 05:23:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:23:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:23:48 --> Model Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:23:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:23:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:23:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:23:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:23:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:23:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:23:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:23:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:23:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:23:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:23:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:23:48 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 05:23:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:23:48 --> Final output sent to browser
DEBUG - 2013-08-21 05:23:48 --> Total execution time: 0.2230
DEBUG - 2013-08-21 05:23:48 --> Config Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:23:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:23:48 --> URI Class Initialized
DEBUG - 2013-08-21 05:23:48 --> Router Class Initialized
ERROR - 2013-08-21 05:23:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:24:05 --> Config Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:24:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:24:05 --> URI Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Router Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Output Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Security Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Input Class Initialized
DEBUG - 2013-08-21 05:24:05 --> XSS Filtering completed
DEBUG - 2013-08-21 05:24:05 --> XSS Filtering completed
DEBUG - 2013-08-21 05:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:24:05 --> Language Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Loader Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:24:05 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:24:05 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:24:05 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Session Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:24:05 --> Session routines successfully run
DEBUG - 2013-08-21 05:24:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Controller Class Initialized
ERROR - 2013-08-21 05:24:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:24:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:24:05 --> Model Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:24:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:24:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:24:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:24:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:24:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:24:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:24:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:24:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:24:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:24:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:24:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:24:05 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 05:24:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:24:05 --> Final output sent to browser
DEBUG - 2013-08-21 05:24:05 --> Total execution time: 0.2660
DEBUG - 2013-08-21 05:24:05 --> Config Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:24:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:24:05 --> URI Class Initialized
DEBUG - 2013-08-21 05:24:05 --> Router Class Initialized
ERROR - 2013-08-21 05:24:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:24:13 --> Config Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:24:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:24:13 --> URI Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Router Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Output Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Security Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Input Class Initialized
DEBUG - 2013-08-21 05:24:13 --> XSS Filtering completed
DEBUG - 2013-08-21 05:24:13 --> XSS Filtering completed
DEBUG - 2013-08-21 05:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:24:13 --> Language Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Loader Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:24:13 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:24:13 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:24:13 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Session Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:24:13 --> Session routines successfully run
DEBUG - 2013-08-21 05:24:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Controller Class Initialized
ERROR - 2013-08-21 05:24:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:24:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:24:13 --> Model Class Initialized
DEBUG - 2013-08-21 05:24:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:24:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:24:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:24:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:24:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:24:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:24:13 --> 404 Page Not Found --> kelas_bagians/new
DEBUG - 2013-08-21 05:25:08 --> Config Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:25:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:25:08 --> URI Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Router Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Output Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Security Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Input Class Initialized
DEBUG - 2013-08-21 05:25:08 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:08 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:25:08 --> Language Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Loader Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:25:08 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:25:08 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:25:08 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Session Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:25:08 --> Session routines successfully run
DEBUG - 2013-08-21 05:25:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Controller Class Initialized
ERROR - 2013-08-21 05:25:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:25:08 --> Model Class Initialized
DEBUG - 2013-08-21 05:25:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:25:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:25:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:25:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:25:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:08 --> 404 Page Not Found --> kelas_bagians/new
DEBUG - 2013-08-21 05:25:11 --> Config Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:25:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:25:11 --> URI Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Router Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Output Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Security Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Input Class Initialized
DEBUG - 2013-08-21 05:25:11 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:11 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:25:11 --> Language Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Loader Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:25:11 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:25:11 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:25:11 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Session Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:25:11 --> Session routines successfully run
DEBUG - 2013-08-21 05:25:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Controller Class Initialized
ERROR - 2013-08-21 05:25:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:25:11 --> Model Class Initialized
DEBUG - 2013-08-21 05:25:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:25:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:25:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:25:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:25:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:11 --> 404 Page Not Found --> kelas_bagians/new
DEBUG - 2013-08-21 05:25:20 --> Config Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:25:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:25:20 --> URI Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Router Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Output Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Security Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Input Class Initialized
DEBUG - 2013-08-21 05:25:20 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:20 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:25:20 --> Language Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Loader Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:25:20 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:25:20 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:25:20 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Session Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:25:20 --> Session routines successfully run
DEBUG - 2013-08-21 05:25:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Controller Class Initialized
ERROR - 2013-08-21 05:25:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:25:20 --> Model Class Initialized
DEBUG - 2013-08-21 05:25:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:25:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:25:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:25:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:25:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:20 --> 404 Page Not Found --> kelas_bagians/new
DEBUG - 2013-08-21 05:25:39 --> Config Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:25:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:25:39 --> URI Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Router Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Output Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Security Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Input Class Initialized
DEBUG - 2013-08-21 05:25:39 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:39 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:25:39 --> Language Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Loader Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:25:39 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:25:39 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:25:39 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Session Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:25:39 --> Session routines successfully run
DEBUG - 2013-08-21 05:25:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Controller Class Initialized
ERROR - 2013-08-21 05:25:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:25:39 --> Model Class Initialized
DEBUG - 2013-08-21 05:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:25:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:25:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:25:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:25:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:25:45 --> Config Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:25:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:25:45 --> URI Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Router Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Output Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Security Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Input Class Initialized
DEBUG - 2013-08-21 05:25:45 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:45 --> XSS Filtering completed
DEBUG - 2013-08-21 05:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:25:45 --> Language Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Loader Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:25:45 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:25:45 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:25:45 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Session Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:25:45 --> Session routines successfully run
DEBUG - 2013-08-21 05:25:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Controller Class Initialized
ERROR - 2013-08-21 05:25:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:25:45 --> Model Class Initialized
DEBUG - 2013-08-21 05:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:25:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:25:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:25:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:25:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:25:45 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 31
DEBUG - 2013-08-21 05:25:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:25:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:25:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:25:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:25:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:25:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:25:46 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:25:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:25:46 --> Final output sent to browser
DEBUG - 2013-08-21 05:25:46 --> Total execution time: 0.3140
DEBUG - 2013-08-21 05:25:46 --> Config Class Initialized
DEBUG - 2013-08-21 05:25:46 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:25:46 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:25:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:25:46 --> URI Class Initialized
DEBUG - 2013-08-21 05:25:46 --> Router Class Initialized
ERROR - 2013-08-21 05:25:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:26:02 --> Config Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:26:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:26:02 --> URI Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Router Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Output Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Security Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Input Class Initialized
DEBUG - 2013-08-21 05:26:02 --> XSS Filtering completed
DEBUG - 2013-08-21 05:26:02 --> XSS Filtering completed
DEBUG - 2013-08-21 05:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:26:02 --> Language Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Loader Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:26:02 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:26:02 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:26:02 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Session Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:26:02 --> Session routines successfully run
DEBUG - 2013-08-21 05:26:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Controller Class Initialized
ERROR - 2013-08-21 05:26:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:26:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:26:02 --> Model Class Initialized
DEBUG - 2013-08-21 05:26:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:26:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:26:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:26:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:26:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:26:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:26:02 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 31
DEBUG - 2013-08-21 05:26:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:26:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:26:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:26:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:26:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:26:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:26:02 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:26:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:26:02 --> Final output sent to browser
DEBUG - 2013-08-21 05:26:02 --> Total execution time: 0.2820
DEBUG - 2013-08-21 05:26:03 --> Config Class Initialized
DEBUG - 2013-08-21 05:26:03 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:26:03 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:26:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:26:03 --> URI Class Initialized
DEBUG - 2013-08-21 05:26:03 --> Router Class Initialized
ERROR - 2013-08-21 05:26:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:26:05 --> Config Class Initialized
DEBUG - 2013-08-21 05:26:05 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:26:05 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:26:05 --> URI Class Initialized
DEBUG - 2013-08-21 05:26:05 --> Router Class Initialized
DEBUG - 2013-08-21 05:26:05 --> Output Class Initialized
DEBUG - 2013-08-21 05:26:05 --> Security Class Initialized
DEBUG - 2013-08-21 05:26:05 --> Input Class Initialized
DEBUG - 2013-08-21 05:26:05 --> XSS Filtering completed
DEBUG - 2013-08-21 05:26:05 --> XSS Filtering completed
DEBUG - 2013-08-21 05:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:26:05 --> Language Class Initialized
DEBUG - 2013-08-21 05:26:05 --> Loader Class Initialized
DEBUG - 2013-08-21 05:26:06 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:26:06 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:26:06 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:26:06 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:26:06 --> Session Class Initialized
DEBUG - 2013-08-21 05:26:06 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:26:06 --> Session routines successfully run
DEBUG - 2013-08-21 05:26:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:26:06 --> Controller Class Initialized
ERROR - 2013-08-21 05:26:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:26:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:26:06 --> Model Class Initialized
DEBUG - 2013-08-21 05:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:26:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:26:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:26:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:26:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:26:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:26:06 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 31
DEBUG - 2013-08-21 05:26:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:26:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:26:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:26:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:26:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:26:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:26:06 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:26:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:26:06 --> Final output sent to browser
DEBUG - 2013-08-21 05:26:06 --> Total execution time: 0.4640
DEBUG - 2013-08-21 05:26:06 --> Config Class Initialized
DEBUG - 2013-08-21 05:26:06 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:26:06 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:26:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:26:06 --> URI Class Initialized
DEBUG - 2013-08-21 05:26:06 --> Router Class Initialized
ERROR - 2013-08-21 05:26:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:26:11 --> Config Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:26:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:26:11 --> URI Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Router Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Output Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Security Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Input Class Initialized
DEBUG - 2013-08-21 05:26:11 --> XSS Filtering completed
DEBUG - 2013-08-21 05:26:11 --> XSS Filtering completed
DEBUG - 2013-08-21 05:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:26:11 --> Language Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Loader Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:26:11 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:26:11 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:26:11 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Session Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:26:11 --> Session routines successfully run
DEBUG - 2013-08-21 05:26:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Controller Class Initialized
ERROR - 2013-08-21 05:26:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:26:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:26:11 --> Model Class Initialized
DEBUG - 2013-08-21 05:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:26:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:26:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:26:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:26:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:26:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:27:40 --> Config Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:27:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:27:40 --> URI Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Router Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Output Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Security Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Input Class Initialized
DEBUG - 2013-08-21 05:27:40 --> XSS Filtering completed
DEBUG - 2013-08-21 05:27:40 --> XSS Filtering completed
DEBUG - 2013-08-21 05:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:27:40 --> Language Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Loader Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:27:40 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:27:40 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:27:40 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Session Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:27:40 --> Session routines successfully run
DEBUG - 2013-08-21 05:27:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Controller Class Initialized
ERROR - 2013-08-21 05:27:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:27:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:27:40 --> Model Class Initialized
DEBUG - 2013-08-21 05:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:27:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:27:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:27:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:27:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:27:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:27:49 --> Config Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:27:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:27:49 --> URI Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Router Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Output Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Security Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Input Class Initialized
DEBUG - 2013-08-21 05:27:49 --> XSS Filtering completed
DEBUG - 2013-08-21 05:27:49 --> XSS Filtering completed
DEBUG - 2013-08-21 05:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:27:49 --> Language Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Loader Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:27:49 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:27:49 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:27:49 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Session Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:27:49 --> Session routines successfully run
DEBUG - 2013-08-21 05:27:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:27:49 --> Controller Class Initialized
ERROR - 2013-08-21 05:27:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:27:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:27:50 --> Model Class Initialized
DEBUG - 2013-08-21 05:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:27:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:27:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:27:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:27:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:27:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:27:50 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:27:50 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:27:50 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:27:50 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:27:50 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:27:50 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:27:50 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:27:50 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:27:50 --> Final output sent to browser
DEBUG - 2013-08-21 05:27:50 --> Total execution time: 0.3090
DEBUG - 2013-08-21 05:27:50 --> Config Class Initialized
DEBUG - 2013-08-21 05:27:50 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:27:50 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:27:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:27:50 --> URI Class Initialized
DEBUG - 2013-08-21 05:27:50 --> Router Class Initialized
ERROR - 2013-08-21 05:27:50 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:28:09 --> Config Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:28:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:28:09 --> URI Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Router Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Output Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Security Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Input Class Initialized
DEBUG - 2013-08-21 05:28:09 --> XSS Filtering completed
DEBUG - 2013-08-21 05:28:09 --> XSS Filtering completed
DEBUG - 2013-08-21 05:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:28:09 --> Language Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Loader Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:28:09 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:28:09 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:28:09 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Session Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:28:09 --> Session routines successfully run
DEBUG - 2013-08-21 05:28:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:28:09 --> Controller Class Initialized
ERROR - 2013-08-21 05:28:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:28:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:28:10 --> Model Class Initialized
DEBUG - 2013-08-21 05:28:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:28:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:28:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:28:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:28:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:28:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:28:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:28:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:28:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:28:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:28:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:28:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:28:10 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:28:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:28:10 --> Final output sent to browser
DEBUG - 2013-08-21 05:28:10 --> Total execution time: 0.3580
DEBUG - 2013-08-21 05:28:10 --> Config Class Initialized
DEBUG - 2013-08-21 05:28:10 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:28:10 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:28:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:28:10 --> URI Class Initialized
DEBUG - 2013-08-21 05:28:10 --> Router Class Initialized
ERROR - 2013-08-21 05:28:10 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:28:22 --> Config Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:28:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:28:22 --> URI Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Router Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Output Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Security Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Input Class Initialized
DEBUG - 2013-08-21 05:28:22 --> XSS Filtering completed
DEBUG - 2013-08-21 05:28:22 --> XSS Filtering completed
DEBUG - 2013-08-21 05:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:28:22 --> Language Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Loader Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:28:22 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:28:22 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:28:22 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Session Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:28:22 --> Session routines successfully run
DEBUG - 2013-08-21 05:28:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Controller Class Initialized
ERROR - 2013-08-21 05:28:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:28:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:28:22 --> Model Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:28:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:28:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:28:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:28:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:28:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:28:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:28:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:28:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:28:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:28:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:28:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:28:22 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:28:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:28:22 --> Final output sent to browser
DEBUG - 2013-08-21 05:28:22 --> Total execution time: 0.3060
DEBUG - 2013-08-21 05:28:22 --> Config Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:28:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:28:22 --> URI Class Initialized
DEBUG - 2013-08-21 05:28:22 --> Router Class Initialized
ERROR - 2013-08-21 05:28:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:28:44 --> Config Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:28:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:28:44 --> URI Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Router Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Output Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Security Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Input Class Initialized
DEBUG - 2013-08-21 05:28:44 --> XSS Filtering completed
DEBUG - 2013-08-21 05:28:44 --> XSS Filtering completed
DEBUG - 2013-08-21 05:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:28:44 --> Language Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Loader Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:28:44 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:28:44 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:28:44 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Session Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:28:44 --> Session routines successfully run
DEBUG - 2013-08-21 05:28:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Controller Class Initialized
ERROR - 2013-08-21 05:28:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:28:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:28:44 --> Model Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:28:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:28:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:28:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:28:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:28:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:28:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:28:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:28:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:28:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:28:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:28:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:28:44 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:28:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:28:44 --> Final output sent to browser
DEBUG - 2013-08-21 05:28:44 --> Total execution time: 0.3260
DEBUG - 2013-08-21 05:28:44 --> Config Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:28:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:28:44 --> URI Class Initialized
DEBUG - 2013-08-21 05:28:44 --> Router Class Initialized
ERROR - 2013-08-21 05:28:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:28:57 --> Config Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:28:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:28:57 --> URI Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Router Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Output Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Security Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Input Class Initialized
DEBUG - 2013-08-21 05:28:57 --> XSS Filtering completed
DEBUG - 2013-08-21 05:28:57 --> XSS Filtering completed
DEBUG - 2013-08-21 05:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:28:57 --> Language Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Loader Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:28:57 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:28:57 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:28:57 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Session Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:28:57 --> Session routines successfully run
DEBUG - 2013-08-21 05:28:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Controller Class Initialized
ERROR - 2013-08-21 05:28:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:28:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:28:57 --> Model Class Initialized
DEBUG - 2013-08-21 05:28:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:28:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:28:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:28:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:28:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:28:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:28:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:28:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:28:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:28:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:28:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:28:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:28:58 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:28:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:28:58 --> Final output sent to browser
DEBUG - 2013-08-21 05:28:58 --> Total execution time: 0.5010
DEBUG - 2013-08-21 05:28:58 --> Config Class Initialized
DEBUG - 2013-08-21 05:28:58 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:28:58 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:28:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:28:58 --> URI Class Initialized
DEBUG - 2013-08-21 05:28:58 --> Router Class Initialized
ERROR - 2013-08-21 05:28:58 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:29:06 --> Config Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:29:06 --> URI Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Router Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Output Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Security Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Input Class Initialized
DEBUG - 2013-08-21 05:29:06 --> XSS Filtering completed
DEBUG - 2013-08-21 05:29:06 --> XSS Filtering completed
DEBUG - 2013-08-21 05:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:29:06 --> Language Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Loader Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:29:06 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:29:06 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:29:06 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Session Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:29:06 --> Session routines successfully run
DEBUG - 2013-08-21 05:29:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Controller Class Initialized
ERROR - 2013-08-21 05:29:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:29:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:29:06 --> Model Class Initialized
DEBUG - 2013-08-21 05:29:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:29:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:29:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:29:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:29:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:29:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:29:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:29:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:29:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:29:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:29:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:29:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:29:06 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:29:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:29:06 --> Final output sent to browser
DEBUG - 2013-08-21 05:29:06 --> Total execution time: 0.3360
DEBUG - 2013-08-21 05:29:07 --> Config Class Initialized
DEBUG - 2013-08-21 05:29:07 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:29:07 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:29:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:29:07 --> URI Class Initialized
DEBUG - 2013-08-21 05:29:07 --> Router Class Initialized
ERROR - 2013-08-21 05:29:07 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:30:17 --> Config Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:30:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:30:17 --> URI Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Router Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Output Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Security Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Input Class Initialized
DEBUG - 2013-08-21 05:30:17 --> XSS Filtering completed
DEBUG - 2013-08-21 05:30:17 --> XSS Filtering completed
DEBUG - 2013-08-21 05:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:30:17 --> Language Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Loader Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:30:17 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:30:17 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:30:17 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Session Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:30:17 --> Session routines successfully run
DEBUG - 2013-08-21 05:30:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Controller Class Initialized
ERROR - 2013-08-21 05:30:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:30:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:30:17 --> Model Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:30:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:30:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:30:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:30:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:30:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:30:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:30:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:30:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:30:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:30:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:30:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:30:17 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:30:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:30:17 --> Final output sent to browser
DEBUG - 2013-08-21 05:30:17 --> Total execution time: 0.3570
DEBUG - 2013-08-21 05:30:17 --> Config Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:30:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:30:17 --> URI Class Initialized
DEBUG - 2013-08-21 05:30:17 --> Router Class Initialized
ERROR - 2013-08-21 05:30:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:30:28 --> Config Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:30:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:30:28 --> URI Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Router Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Output Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Security Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Input Class Initialized
DEBUG - 2013-08-21 05:30:28 --> XSS Filtering completed
DEBUG - 2013-08-21 05:30:28 --> XSS Filtering completed
DEBUG - 2013-08-21 05:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:30:28 --> Language Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Loader Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:30:28 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:30:28 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:30:28 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Session Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:30:28 --> Session routines successfully run
DEBUG - 2013-08-21 05:30:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Controller Class Initialized
ERROR - 2013-08-21 05:30:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:30:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:30:28 --> Model Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:30:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:30:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:30:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:30:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:30:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:30:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:30:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:30:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:30:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:30:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:30:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:30:28 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:30:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:30:28 --> Final output sent to browser
DEBUG - 2013-08-21 05:30:28 --> Total execution time: 0.3800
DEBUG - 2013-08-21 05:30:28 --> Config Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:30:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:30:28 --> URI Class Initialized
DEBUG - 2013-08-21 05:30:28 --> Router Class Initialized
ERROR - 2013-08-21 05:30:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:30:38 --> Config Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:30:38 --> URI Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Router Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Output Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Security Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Input Class Initialized
DEBUG - 2013-08-21 05:30:38 --> XSS Filtering completed
DEBUG - 2013-08-21 05:30:38 --> XSS Filtering completed
DEBUG - 2013-08-21 05:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:30:38 --> Language Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Loader Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:30:38 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:30:38 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:30:38 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Session Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:30:38 --> Session routines successfully run
DEBUG - 2013-08-21 05:30:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Controller Class Initialized
ERROR - 2013-08-21 05:30:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:30:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:30:38 --> Model Class Initialized
DEBUG - 2013-08-21 05:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:30:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:30:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:30:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:30:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:30:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:30:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:30:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:30:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:30:39 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:30:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:30:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:30:39 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:30:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:30:39 --> Final output sent to browser
DEBUG - 2013-08-21 05:30:39 --> Total execution time: 0.4050
DEBUG - 2013-08-21 05:30:39 --> Config Class Initialized
DEBUG - 2013-08-21 05:30:39 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:30:39 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:30:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:30:39 --> URI Class Initialized
DEBUG - 2013-08-21 05:30:39 --> Router Class Initialized
ERROR - 2013-08-21 05:30:39 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:31:44 --> Config Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:31:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:31:44 --> URI Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Router Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Output Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Security Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Input Class Initialized
DEBUG - 2013-08-21 05:31:44 --> XSS Filtering completed
DEBUG - 2013-08-21 05:31:44 --> XSS Filtering completed
DEBUG - 2013-08-21 05:31:44 --> XSS Filtering completed
DEBUG - 2013-08-21 05:31:44 --> XSS Filtering completed
DEBUG - 2013-08-21 05:31:44 --> XSS Filtering completed
DEBUG - 2013-08-21 05:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:31:44 --> Language Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Loader Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:31:44 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:31:44 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:31:44 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Session Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:31:44 --> Session routines successfully run
DEBUG - 2013-08-21 05:31:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Controller Class Initialized
ERROR - 2013-08-21 05:31:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:31:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:31:44 --> Model Class Initialized
DEBUG - 2013-08-21 05:31:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:31:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:31:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:31:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:31:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:31:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:31:45 --> Form Validation Class Initialized
DEBUG - 2013-08-21 05:31:45 --> XSS Filtering completed
DEBUG - 2013-08-21 05:31:45 --> XSS Filtering completed
DEBUG - 2013-08-21 05:31:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-21 05:34:13 --> Config Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:34:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:34:13 --> URI Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Router Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Output Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Security Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Input Class Initialized
DEBUG - 2013-08-21 05:34:13 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:13 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:34:13 --> Language Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Loader Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:34:13 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:34:13 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:34:13 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Session Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:34:13 --> Session garbage collection performed.
DEBUG - 2013-08-21 05:34:13 --> Session routines successfully run
DEBUG - 2013-08-21 05:34:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Controller Class Initialized
ERROR - 2013-08-21 05:34:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:13 --> Model Class Initialized
DEBUG - 2013-08-21 05:34:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:34:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:34:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:34:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:34:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:13 --> Form Validation Class Initialized
ERROR - 2013-08-21 05:34:13 --> 404 Page Not Found --> 
DEBUG - 2013-08-21 05:34:19 --> Config Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:34:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:34:19 --> URI Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Router Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Output Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Security Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Input Class Initialized
DEBUG - 2013-08-21 05:34:19 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:19 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:34:19 --> Language Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Loader Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:34:19 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:34:19 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:34:19 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Session Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:34:19 --> Session routines successfully run
DEBUG - 2013-08-21 05:34:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Controller Class Initialized
ERROR - 2013-08-21 05:34:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:19 --> Model Class Initialized
DEBUG - 2013-08-21 05:34:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:34:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:34:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:34:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:34:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:34:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:34:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:34:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:34:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:34:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:34:19 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 05:34:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:34:20 --> Final output sent to browser
DEBUG - 2013-08-21 05:34:20 --> Total execution time: 0.6860
DEBUG - 2013-08-21 05:34:20 --> Config Class Initialized
DEBUG - 2013-08-21 05:34:20 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:34:20 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:34:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:34:20 --> URI Class Initialized
DEBUG - 2013-08-21 05:34:20 --> Router Class Initialized
ERROR - 2013-08-21 05:34:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:34:24 --> Config Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:34:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:34:24 --> URI Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Router Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Output Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Security Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Input Class Initialized
DEBUG - 2013-08-21 05:34:24 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:24 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:24 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:24 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:24 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:34:24 --> Language Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Loader Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:34:24 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:34:24 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:34:24 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Session Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:34:24 --> Session routines successfully run
DEBUG - 2013-08-21 05:34:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Controller Class Initialized
ERROR - 2013-08-21 05:34:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:24 --> Model Class Initialized
DEBUG - 2013-08-21 05:34:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:34:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:34:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:34:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:34:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:24 --> Form Validation Class Initialized
DEBUG - 2013-08-21 05:34:24 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:24 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-21 05:34:25 --> Config Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:34:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:34:25 --> URI Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Router Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Output Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Security Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Input Class Initialized
DEBUG - 2013-08-21 05:34:25 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:25 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:34:25 --> Language Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Loader Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:34:25 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:34:25 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:34:25 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Session Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:34:25 --> Session routines successfully run
DEBUG - 2013-08-21 05:34:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Controller Class Initialized
ERROR - 2013-08-21 05:34:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:25 --> Model Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:34:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:34:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:34:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:34:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:34:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:34:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:34:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:34:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:34:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:34:25 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 05:34:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:34:25 --> Final output sent to browser
DEBUG - 2013-08-21 05:34:25 --> Total execution time: 0.4310
DEBUG - 2013-08-21 05:34:25 --> Config Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:34:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:34:25 --> URI Class Initialized
DEBUG - 2013-08-21 05:34:25 --> Router Class Initialized
ERROR - 2013-08-21 05:34:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:34:47 --> Config Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:34:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:34:47 --> URI Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Router Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Output Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Security Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Input Class Initialized
DEBUG - 2013-08-21 05:34:47 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:47 --> XSS Filtering completed
DEBUG - 2013-08-21 05:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:34:47 --> Language Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Loader Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:34:47 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:34:47 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:34:47 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Session Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:34:47 --> Session routines successfully run
DEBUG - 2013-08-21 05:34:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Controller Class Initialized
ERROR - 2013-08-21 05:34:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:47 --> Model Class Initialized
DEBUG - 2013-08-21 05:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:34:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:34:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:34:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:34:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:34:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:34:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:34:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:34:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:34:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:34:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:34:47 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:34:48 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 05:34:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:34:48 --> Final output sent to browser
DEBUG - 2013-08-21 05:34:48 --> Total execution time: 0.7340
DEBUG - 2013-08-21 05:34:48 --> Config Class Initialized
DEBUG - 2013-08-21 05:34:48 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:34:48 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:34:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:34:48 --> URI Class Initialized
DEBUG - 2013-08-21 05:34:48 --> Router Class Initialized
ERROR - 2013-08-21 05:34:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:37:27 --> Config Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:37:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:37:27 --> URI Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Router Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Output Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Security Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Input Class Initialized
DEBUG - 2013-08-21 05:37:27 --> XSS Filtering completed
DEBUG - 2013-08-21 05:37:27 --> XSS Filtering completed
DEBUG - 2013-08-21 05:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:37:27 --> Language Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Loader Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:37:27 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:37:27 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:37:27 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Session Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:37:27 --> Session routines successfully run
DEBUG - 2013-08-21 05:37:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Controller Class Initialized
ERROR - 2013-08-21 05:37:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:37:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:37:27 --> Model Class Initialized
DEBUG - 2013-08-21 05:37:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:37:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:37:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:37:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:37:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:37:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:37:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:37:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:37:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:37:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:37:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:37:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:37:28 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 05:37:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:37:28 --> Final output sent to browser
DEBUG - 2013-08-21 05:37:28 --> Total execution time: 0.5040
DEBUG - 2013-08-21 05:37:28 --> Config Class Initialized
DEBUG - 2013-08-21 05:37:28 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:37:28 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:37:28 --> URI Class Initialized
DEBUG - 2013-08-21 05:37:28 --> Router Class Initialized
ERROR - 2013-08-21 05:37:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:38:28 --> Config Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:38:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:38:28 --> URI Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Router Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Output Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Security Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Input Class Initialized
DEBUG - 2013-08-21 05:38:28 --> XSS Filtering completed
DEBUG - 2013-08-21 05:38:28 --> XSS Filtering completed
DEBUG - 2013-08-21 05:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:38:28 --> Language Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Loader Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:38:28 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:38:28 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:38:28 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Session Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:38:28 --> Session routines successfully run
DEBUG - 2013-08-21 05:38:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Controller Class Initialized
ERROR - 2013-08-21 05:38:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:38:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:38:28 --> Model Class Initialized
DEBUG - 2013-08-21 05:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:38:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:38:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:38:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:38:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:38:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:38:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:38:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:38:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:38:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:38:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:38:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:38:28 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 05:38:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:38:28 --> Final output sent to browser
DEBUG - 2013-08-21 05:38:28 --> Total execution time: 0.4410
DEBUG - 2013-08-21 05:38:29 --> Config Class Initialized
DEBUG - 2013-08-21 05:38:29 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:38:29 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:38:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:38:29 --> URI Class Initialized
DEBUG - 2013-08-21 05:38:29 --> Router Class Initialized
ERROR - 2013-08-21 05:38:29 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:41:34 --> Config Class Initialized
DEBUG - 2013-08-21 05:41:34 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:41:34 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:41:34 --> URI Class Initialized
DEBUG - 2013-08-21 05:41:34 --> Router Class Initialized
DEBUG - 2013-08-21 05:41:35 --> Output Class Initialized
DEBUG - 2013-08-21 05:41:35 --> Security Class Initialized
DEBUG - 2013-08-21 05:41:35 --> Input Class Initialized
DEBUG - 2013-08-21 05:41:35 --> XSS Filtering completed
DEBUG - 2013-08-21 05:41:35 --> XSS Filtering completed
DEBUG - 2013-08-21 05:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:41:35 --> Language Class Initialized
DEBUG - 2013-08-21 05:41:44 --> Loader Class Initialized
DEBUG - 2013-08-21 05:41:45 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:41:45 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:41:45 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:41:46 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:41:46 --> Session Class Initialized
DEBUG - 2013-08-21 05:41:46 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:41:46 --> Session routines successfully run
DEBUG - 2013-08-21 05:41:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:41:47 --> Controller Class Initialized
ERROR - 2013-08-21 05:41:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:41:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:41:51 --> Model Class Initialized
DEBUG - 2013-08-21 05:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:41:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:41:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:41:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:41:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:41:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:41:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:41:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:41:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:41:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:41:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:41:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:41:59 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 05:41:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:41:59 --> Final output sent to browser
DEBUG - 2013-08-21 05:41:59 --> Total execution time: 30.3157
DEBUG - 2013-08-21 05:42:00 --> Config Class Initialized
DEBUG - 2013-08-21 05:42:00 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:42:00 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:42:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:42:00 --> URI Class Initialized
DEBUG - 2013-08-21 05:42:00 --> Router Class Initialized
ERROR - 2013-08-21 05:42:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:42:29 --> Config Class Initialized
DEBUG - 2013-08-21 05:42:29 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:42:29 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:42:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:42:29 --> URI Class Initialized
DEBUG - 2013-08-21 05:42:29 --> Router Class Initialized
ERROR - 2013-08-21 05:42:29 --> 404 Page Not Found --> kelasbagians
DEBUG - 2013-08-21 05:43:19 --> Config Class Initialized
DEBUG - 2013-08-21 05:43:19 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:43:19 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:43:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:43:19 --> URI Class Initialized
DEBUG - 2013-08-21 05:43:19 --> Router Class Initialized
DEBUG - 2013-08-21 05:43:20 --> Output Class Initialized
DEBUG - 2013-08-21 05:43:20 --> Security Class Initialized
DEBUG - 2013-08-21 05:43:20 --> Input Class Initialized
DEBUG - 2013-08-21 05:43:20 --> XSS Filtering completed
DEBUG - 2013-08-21 05:43:20 --> XSS Filtering completed
DEBUG - 2013-08-21 05:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:43:20 --> Language Class Initialized
DEBUG - 2013-08-21 05:43:20 --> Loader Class Initialized
DEBUG - 2013-08-21 05:43:20 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:43:20 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:43:20 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:43:20 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:43:20 --> Session Class Initialized
DEBUG - 2013-08-21 05:43:20 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:43:20 --> Session routines successfully run
DEBUG - 2013-08-21 05:43:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:43:20 --> Controller Class Initialized
ERROR - 2013-08-21 05:43:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:43:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:43:20 --> Model Class Initialized
DEBUG - 2013-08-21 05:43:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:43:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:43:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:43:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:43:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:43:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:44:46 --> Config Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:44:46 --> URI Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Router Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Output Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Security Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Input Class Initialized
DEBUG - 2013-08-21 05:44:46 --> XSS Filtering completed
DEBUG - 2013-08-21 05:44:46 --> XSS Filtering completed
DEBUG - 2013-08-21 05:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:44:46 --> Language Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Loader Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:44:46 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:44:46 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:44:46 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Session Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:44:46 --> Session routines successfully run
DEBUG - 2013-08-21 05:44:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Controller Class Initialized
ERROR - 2013-08-21 05:44:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:44:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:44:46 --> Model Class Initialized
DEBUG - 2013-08-21 05:44:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:44:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:44:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:44:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:44:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:44:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:44:46 --> 404 Page Not Found --> 
DEBUG - 2013-08-21 05:46:43 --> Config Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:46:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:46:43 --> URI Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Router Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Output Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Security Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Input Class Initialized
DEBUG - 2013-08-21 05:46:43 --> XSS Filtering completed
DEBUG - 2013-08-21 05:46:43 --> XSS Filtering completed
DEBUG - 2013-08-21 05:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:46:43 --> Language Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Loader Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:46:43 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:46:43 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:46:43 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Session Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:46:43 --> Session routines successfully run
DEBUG - 2013-08-21 05:46:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Controller Class Initialized
ERROR - 2013-08-21 05:46:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:46:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:46:43 --> Model Class Initialized
DEBUG - 2013-08-21 05:46:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:46:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:46:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:46:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:46:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:46:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:46:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:46:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:46:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:46:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:46:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:46:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:46:43 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 05:46:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:46:43 --> Final output sent to browser
DEBUG - 2013-08-21 05:46:43 --> Total execution time: 0.6600
DEBUG - 2013-08-21 05:46:44 --> Config Class Initialized
DEBUG - 2013-08-21 05:46:44 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:46:44 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:46:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:46:44 --> URI Class Initialized
DEBUG - 2013-08-21 05:46:44 --> Router Class Initialized
ERROR - 2013-08-21 05:46:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:47:10 --> Config Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:47:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:47:10 --> URI Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Router Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Output Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Security Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Input Class Initialized
DEBUG - 2013-08-21 05:47:10 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:10 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:47:10 --> Language Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Loader Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:47:10 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:47:10 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:47:10 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Session Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:47:10 --> Session routines successfully run
DEBUG - 2013-08-21 05:47:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Controller Class Initialized
ERROR - 2013-08-21 05:47:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:47:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:47:10 --> Model Class Initialized
DEBUG - 2013-08-21 05:47:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:47:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:47:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:47:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:47:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:47:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:47:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:47:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:47:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:47:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:47:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:47:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:47:11 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 05:47:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:47:11 --> Final output sent to browser
DEBUG - 2013-08-21 05:47:11 --> Total execution time: 0.4440
DEBUG - 2013-08-21 05:47:11 --> Config Class Initialized
DEBUG - 2013-08-21 05:47:11 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:47:11 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:47:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:47:11 --> URI Class Initialized
DEBUG - 2013-08-21 05:47:11 --> Router Class Initialized
ERROR - 2013-08-21 05:47:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:47:52 --> Config Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:47:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:47:52 --> URI Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Router Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Output Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Security Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Input Class Initialized
DEBUG - 2013-08-21 05:47:52 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:52 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:52 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:52 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:52 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:47:52 --> Language Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Loader Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:47:52 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:47:52 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:47:52 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Session Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:47:52 --> Session routines successfully run
DEBUG - 2013-08-21 05:47:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Controller Class Initialized
ERROR - 2013-08-21 05:47:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:47:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:47:52 --> Model Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:47:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:47:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:47:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:47:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:47:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:47:52 --> Form Validation Class Initialized
DEBUG - 2013-08-21 05:47:52 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:52 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-21 05:47:52 --> Severity: Warning  --> Missing argument 3 for kelas_bagians::nama_check_update(), called in C:\xampp\htdocs\school\system\libraries\Form_validation.php on line 593 and defined C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 185
ERROR - 2013-08-21 05:47:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 189
DEBUG - 2013-08-21 05:47:52 --> Config Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:47:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:47:52 --> URI Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Router Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Output Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Security Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Input Class Initialized
DEBUG - 2013-08-21 05:47:52 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:52 --> XSS Filtering completed
DEBUG - 2013-08-21 05:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:47:52 --> Language Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Loader Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:47:52 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:47:52 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:47:52 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Session Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:47:52 --> Session routines successfully run
DEBUG - 2013-08-21 05:47:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Controller Class Initialized
ERROR - 2013-08-21 05:47:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:47:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:47:52 --> Model Class Initialized
DEBUG - 2013-08-21 05:47:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:47:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:47:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:47:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:47:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:47:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:47:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 05:47:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 05:47:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 05:47:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 05:47:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 05:47:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 05:47:53 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 05:47:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 05:47:53 --> Final output sent to browser
DEBUG - 2013-08-21 05:47:53 --> Total execution time: 0.4800
DEBUG - 2013-08-21 05:47:53 --> Config Class Initialized
DEBUG - 2013-08-21 05:47:53 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:47:53 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:47:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:47:53 --> URI Class Initialized
DEBUG - 2013-08-21 05:47:53 --> Router Class Initialized
ERROR - 2013-08-21 05:47:53 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 05:49:55 --> Config Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Hooks Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Utf8 Class Initialized
DEBUG - 2013-08-21 05:49:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 05:49:55 --> URI Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Router Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Output Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Security Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Input Class Initialized
DEBUG - 2013-08-21 05:49:55 --> XSS Filtering completed
DEBUG - 2013-08-21 05:49:55 --> XSS Filtering completed
DEBUG - 2013-08-21 05:49:55 --> XSS Filtering completed
DEBUG - 2013-08-21 05:49:55 --> XSS Filtering completed
DEBUG - 2013-08-21 05:49:55 --> XSS Filtering completed
DEBUG - 2013-08-21 05:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 05:49:55 --> Language Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Loader Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Helper loaded: url_helper
DEBUG - 2013-08-21 05:49:55 --> Helper loaded: file_helper
DEBUG - 2013-08-21 05:49:55 --> Helper loaded: form_helper
DEBUG - 2013-08-21 05:49:55 --> Database Driver Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Session Class Initialized
DEBUG - 2013-08-21 05:49:55 --> Helper loaded: string_helper
DEBUG - 2013-08-21 05:49:56 --> Session routines successfully run
DEBUG - 2013-08-21 05:49:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 05:49:56 --> Controller Class Initialized
ERROR - 2013-08-21 05:49:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:49:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:49:56 --> Model Class Initialized
DEBUG - 2013-08-21 05:49:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 05:49:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 05:49:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 05:49:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 05:49:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 05:49:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 05:49:56 --> Form Validation Class Initialized
DEBUG - 2013-08-21 05:49:56 --> XSS Filtering completed
DEBUG - 2013-08-21 05:49:56 --> XSS Filtering completed
DEBUG - 2013-08-21 05:49:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-21 05:49:56 --> Severity: Warning  --> Missing argument 3 for kelas_bagians::nama_check_update(), called in C:\xampp\htdocs\school\system\libraries\Form_validation.php on line 593 and defined C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 185
ERROR - 2013-08-21 05:49:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 189
DEBUG - 2013-08-21 06:15:40 --> Config Class Initialized
DEBUG - 2013-08-21 06:15:40 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:15:40 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:15:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:15:41 --> URI Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Router Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Output Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Security Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Input Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:15:41 --> Language Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Loader Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:15:41 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:15:41 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:15:41 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Session Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:15:41 --> A session cookie was not found.
DEBUG - 2013-08-21 06:15:41 --> Session routines successfully run
DEBUG - 2013-08-21 06:15:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Controller Class Initialized
ERROR - 2013-08-21 06:15:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:15:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:15:41 --> Model Class Initialized
DEBUG - 2013-08-21 06:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:15:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:15:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:15:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:15:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:15:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:15:41 --> Pagination Class Initialized
DEBUG - 2013-08-21 06:15:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:15:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:15:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:15:42 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:15:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:15:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:15:42 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-21 06:15:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:15:42 --> Final output sent to browser
DEBUG - 2013-08-21 06:15:42 --> Total execution time: 1.8051
DEBUG - 2013-08-21 06:15:42 --> Config Class Initialized
DEBUG - 2013-08-21 06:15:42 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:15:42 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:15:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:15:42 --> URI Class Initialized
DEBUG - 2013-08-21 06:15:42 --> Router Class Initialized
ERROR - 2013-08-21 06:15:42 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:16:00 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:00 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:00 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:00 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:00 --> Router Class Initialized
ERROR - 2013-08-21 06:16:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:16:07 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:07 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Router Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Output Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Security Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Input Class Initialized
DEBUG - 2013-08-21 06:16:07 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:16:07 --> Language Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Loader Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:16:07 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:16:07 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:16:07 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Session Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:16:07 --> Session routines successfully run
DEBUG - 2013-08-21 06:16:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Controller Class Initialized
ERROR - 2013-08-21 06:16:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:07 --> Model Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:16:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:16:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:16:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:16:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:07 --> Pagination Class Initialized
DEBUG - 2013-08-21 06:16:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:16:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:16:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:16:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:16:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:16:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:16:07 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-21 06:16:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:16:07 --> Final output sent to browser
DEBUG - 2013-08-21 06:16:07 --> Total execution time: 0.5850
DEBUG - 2013-08-21 06:16:07 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:07 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:07 --> Router Class Initialized
ERROR - 2013-08-21 06:16:07 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:16:44 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:44 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Router Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Output Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Security Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Input Class Initialized
DEBUG - 2013-08-21 06:16:44 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:44 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:16:44 --> Language Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Loader Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:16:44 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:16:44 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:16:44 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Session Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:16:44 --> Session routines successfully run
DEBUG - 2013-08-21 06:16:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Controller Class Initialized
ERROR - 2013-08-21 06:16:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:44 --> Model Class Initialized
DEBUG - 2013-08-21 06:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:16:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:16:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:16:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:16:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:16:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:16:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:16:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:16:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:16:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:16:44 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 06:16:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:16:44 --> Final output sent to browser
DEBUG - 2013-08-21 06:16:44 --> Total execution time: 0.5740
DEBUG - 2013-08-21 06:16:45 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:45 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:45 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:45 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:45 --> Router Class Initialized
ERROR - 2013-08-21 06:16:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:16:48 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:48 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Router Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Output Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Security Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Input Class Initialized
DEBUG - 2013-08-21 06:16:48 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:48 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:16:48 --> Language Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Loader Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:16:48 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:16:48 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:16:48 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Session Class Initialized
DEBUG - 2013-08-21 06:16:48 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:16:48 --> Session routines successfully run
DEBUG - 2013-08-21 06:16:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:16:49 --> Controller Class Initialized
ERROR - 2013-08-21 06:16:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:49 --> Model Class Initialized
DEBUG - 2013-08-21 06:16:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:16:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:16:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:16:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:16:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:16:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:16:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:16:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:16:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:16:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:16:49 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 06:16:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:16:49 --> Final output sent to browser
DEBUG - 2013-08-21 06:16:49 --> Total execution time: 0.6070
DEBUG - 2013-08-21 06:16:49 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:49 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:49 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:49 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:49 --> Router Class Initialized
ERROR - 2013-08-21 06:16:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:16:53 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:53 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Router Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Output Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Security Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Input Class Initialized
DEBUG - 2013-08-21 06:16:53 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:53 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:16:53 --> Language Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Loader Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:16:53 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:16:53 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:16:53 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Session Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:16:53 --> Session routines successfully run
DEBUG - 2013-08-21 06:16:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Controller Class Initialized
ERROR - 2013-08-21 06:16:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:53 --> Model Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:16:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:16:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:16:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:16:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:16:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:16:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:16:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:16:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:16:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:16:53 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 06:16:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:16:53 --> Final output sent to browser
DEBUG - 2013-08-21 06:16:53 --> Total execution time: 0.5550
DEBUG - 2013-08-21 06:16:53 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:53 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:53 --> Router Class Initialized
ERROR - 2013-08-21 06:16:53 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:16:55 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:55 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:55 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:55 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:55 --> Router Class Initialized
DEBUG - 2013-08-21 06:16:55 --> Output Class Initialized
DEBUG - 2013-08-21 06:16:55 --> Security Class Initialized
DEBUG - 2013-08-21 06:16:55 --> Input Class Initialized
DEBUG - 2013-08-21 06:16:55 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:55 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:55 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:55 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:55 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:16:56 --> Language Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Loader Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:16:56 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Session Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:16:56 --> Session routines successfully run
DEBUG - 2013-08-21 06:16:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Controller Class Initialized
ERROR - 2013-08-21 06:16:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:56 --> Model Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:16:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:16:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:16:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:56 --> Form Validation Class Initialized
DEBUG - 2013-08-21 06:16:56 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:56 --> XSS Filtering completed
ERROR - 2013-08-21 06:16:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 117
DEBUG - 2013-08-21 06:16:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-21 06:16:56 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 187
DEBUG - 2013-08-21 06:16:56 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:56 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Router Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Output Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Security Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Input Class Initialized
DEBUG - 2013-08-21 06:16:56 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:56 --> XSS Filtering completed
DEBUG - 2013-08-21 06:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:16:56 --> Language Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Loader Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:16:56 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Session Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:16:56 --> Session routines successfully run
DEBUG - 2013-08-21 06:16:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Controller Class Initialized
ERROR - 2013-08-21 06:16:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:56 --> Model Class Initialized
DEBUG - 2013-08-21 06:16:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:16:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:16:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:16:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:16:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:16:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:16:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:16:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:16:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:16:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:16:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:16:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:16:57 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:16:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:16:57 --> Final output sent to browser
DEBUG - 2013-08-21 06:16:57 --> Total execution time: 0.6370
DEBUG - 2013-08-21 06:16:57 --> Config Class Initialized
DEBUG - 2013-08-21 06:16:57 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:16:57 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:16:57 --> URI Class Initialized
DEBUG - 2013-08-21 06:16:57 --> Router Class Initialized
ERROR - 2013-08-21 06:16:57 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:18:50 --> Config Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:18:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:18:50 --> URI Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Router Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Output Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Security Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Input Class Initialized
DEBUG - 2013-08-21 06:18:50 --> XSS Filtering completed
DEBUG - 2013-08-21 06:18:50 --> XSS Filtering completed
DEBUG - 2013-08-21 06:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:18:50 --> Language Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Loader Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:18:50 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:18:50 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:18:50 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Session Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:18:50 --> Session routines successfully run
DEBUG - 2013-08-21 06:18:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Controller Class Initialized
ERROR - 2013-08-21 06:18:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:18:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:18:50 --> Model Class Initialized
DEBUG - 2013-08-21 06:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:18:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:18:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:18:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:18:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:18:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:18:50 --> Pagination Class Initialized
DEBUG - 2013-08-21 06:18:50 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:18:50 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:18:50 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:18:50 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:18:50 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:18:50 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:18:50 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-21 06:18:50 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:18:50 --> Final output sent to browser
DEBUG - 2013-08-21 06:18:50 --> Total execution time: 0.5710
DEBUG - 2013-08-21 06:18:51 --> Config Class Initialized
DEBUG - 2013-08-21 06:18:51 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:18:51 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:18:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:18:51 --> URI Class Initialized
DEBUG - 2013-08-21 06:18:51 --> Router Class Initialized
ERROR - 2013-08-21 06:18:51 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:18:54 --> Config Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:18:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:18:54 --> URI Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Router Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Output Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Security Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Input Class Initialized
DEBUG - 2013-08-21 06:18:54 --> XSS Filtering completed
DEBUG - 2013-08-21 06:18:54 --> XSS Filtering completed
DEBUG - 2013-08-21 06:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:18:54 --> Language Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Loader Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:18:54 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:18:54 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:18:54 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Session Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:18:54 --> Session routines successfully run
DEBUG - 2013-08-21 06:18:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Controller Class Initialized
ERROR - 2013-08-21 06:18:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:18:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:18:54 --> Model Class Initialized
DEBUG - 2013-08-21 06:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:18:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:18:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:18:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:18:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:18:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:18:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:18:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:18:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:18:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:18:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:18:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:18:55 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 06:18:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:18:55 --> Final output sent to browser
DEBUG - 2013-08-21 06:18:55 --> Total execution time: 0.6420
DEBUG - 2013-08-21 06:18:55 --> Config Class Initialized
DEBUG - 2013-08-21 06:18:55 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:18:55 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:18:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:18:55 --> URI Class Initialized
DEBUG - 2013-08-21 06:18:55 --> Router Class Initialized
ERROR - 2013-08-21 06:18:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:18:59 --> Config Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:18:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:18:59 --> URI Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Router Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Output Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Security Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Input Class Initialized
DEBUG - 2013-08-21 06:18:59 --> XSS Filtering completed
DEBUG - 2013-08-21 06:18:59 --> XSS Filtering completed
DEBUG - 2013-08-21 06:18:59 --> XSS Filtering completed
DEBUG - 2013-08-21 06:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:18:59 --> Language Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Loader Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:18:59 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:18:59 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:18:59 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Session Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:18:59 --> Session routines successfully run
DEBUG - 2013-08-21 06:18:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Controller Class Initialized
ERROR - 2013-08-21 06:18:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:18:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:18:59 --> Model Class Initialized
DEBUG - 2013-08-21 06:18:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:18:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:18:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:18:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:18:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:18:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:00 --> Form Validation Class Initialized
DEBUG - 2013-08-21 06:19:00 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-21 06:19:00 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:00 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Router Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Output Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Security Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Input Class Initialized
DEBUG - 2013-08-21 06:19:00 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:00 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:19:00 --> Language Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Loader Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:19:00 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:19:00 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:19:00 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Session Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:19:00 --> Session routines successfully run
DEBUG - 2013-08-21 06:19:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Controller Class Initialized
ERROR - 2013-08-21 06:19:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:00 --> Model Class Initialized
DEBUG - 2013-08-21 06:19:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:19:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:19:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:19:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:19:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:19:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:19:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:19:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:19:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:19:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:19:00 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:19:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:19:00 --> Final output sent to browser
DEBUG - 2013-08-21 06:19:00 --> Total execution time: 0.6280
DEBUG - 2013-08-21 06:19:00 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:01 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:01 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:01 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:01 --> Router Class Initialized
ERROR - 2013-08-21 06:19:01 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:19:14 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:14 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Router Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Output Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Security Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Input Class Initialized
DEBUG - 2013-08-21 06:19:14 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:14 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:19:14 --> Language Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Loader Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:19:14 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:19:14 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:19:14 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Session Class Initialized
DEBUG - 2013-08-21 06:19:14 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:19:15 --> Session routines successfully run
DEBUG - 2013-08-21 06:19:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:19:15 --> Controller Class Initialized
ERROR - 2013-08-21 06:19:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:15 --> Model Class Initialized
DEBUG - 2013-08-21 06:19:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:19:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:19:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:19:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:19:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:15 --> Pagination Class Initialized
DEBUG - 2013-08-21 06:19:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:19:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:19:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:19:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:19:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:19:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:19:15 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-21 06:19:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:19:15 --> Final output sent to browser
DEBUG - 2013-08-21 06:19:15 --> Total execution time: 0.6830
DEBUG - 2013-08-21 06:19:15 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:15 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:15 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:15 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:15 --> Router Class Initialized
ERROR - 2013-08-21 06:19:15 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:19:19 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:19 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Router Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Output Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Security Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Input Class Initialized
DEBUG - 2013-08-21 06:19:19 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:19 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:19:19 --> Language Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Loader Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:19:19 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:19:19 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:19:19 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Session Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:19:19 --> Session routines successfully run
DEBUG - 2013-08-21 06:19:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Controller Class Initialized
ERROR - 2013-08-21 06:19:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:19 --> Model Class Initialized
DEBUG - 2013-08-21 06:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:19:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:19:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:19:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:19:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:19:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:19:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:19:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:19:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:19:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:19:20 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 06:19:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:19:20 --> Final output sent to browser
DEBUG - 2013-08-21 06:19:20 --> Total execution time: 0.6030
DEBUG - 2013-08-21 06:19:20 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:20 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:20 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:20 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:20 --> Router Class Initialized
ERROR - 2013-08-21 06:19:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:19:22 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:22 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Router Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Output Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Security Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Input Class Initialized
DEBUG - 2013-08-21 06:19:22 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:22 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:19:22 --> Language Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Loader Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:19:22 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:19:22 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:19:22 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Session Class Initialized
DEBUG - 2013-08-21 06:19:22 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:19:22 --> Session routines successfully run
DEBUG - 2013-08-21 06:19:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:19:23 --> Controller Class Initialized
ERROR - 2013-08-21 06:19:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:23 --> Model Class Initialized
DEBUG - 2013-08-21 06:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:19:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:19:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:19:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:19:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:19:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:19:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:19:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:19:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:19:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:19:23 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 06:19:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:19:23 --> Final output sent to browser
DEBUG - 2013-08-21 06:19:23 --> Total execution time: 0.6320
DEBUG - 2013-08-21 06:19:23 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:23 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:23 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:23 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:23 --> Router Class Initialized
ERROR - 2013-08-21 06:19:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:19:25 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:25 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:25 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:25 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:25 --> Router Class Initialized
DEBUG - 2013-08-21 06:19:25 --> Output Class Initialized
DEBUG - 2013-08-21 06:19:25 --> Security Class Initialized
DEBUG - 2013-08-21 06:19:25 --> Input Class Initialized
DEBUG - 2013-08-21 06:19:25 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:25 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:25 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:25 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:25 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:19:25 --> Language Class Initialized
DEBUG - 2013-08-21 06:19:25 --> Loader Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:19:26 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Session Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:19:26 --> Session routines successfully run
DEBUG - 2013-08-21 06:19:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Controller Class Initialized
ERROR - 2013-08-21 06:19:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:26 --> Model Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:19:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:19:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:19:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:26 --> Form Validation Class Initialized
DEBUG - 2013-08-21 06:19:26 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:26 --> XSS Filtering completed
ERROR - 2013-08-21 06:19:26 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 117
DEBUG - 2013-08-21 06:19:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-21 06:19:26 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 187
DEBUG - 2013-08-21 06:19:26 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:26 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Router Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Output Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Security Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Input Class Initialized
DEBUG - 2013-08-21 06:19:26 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:26 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:19:26 --> Language Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Loader Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:19:26 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Session Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:19:26 --> Session routines successfully run
DEBUG - 2013-08-21 06:19:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Controller Class Initialized
ERROR - 2013-08-21 06:19:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:26 --> Model Class Initialized
DEBUG - 2013-08-21 06:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:19:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:19:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:19:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:19:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:19:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:19:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:19:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:19:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:19:27 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:19:27 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:19:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:19:27 --> Final output sent to browser
DEBUG - 2013-08-21 06:19:27 --> Total execution time: 0.6940
DEBUG - 2013-08-21 06:19:27 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:27 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:27 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:27 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:27 --> Router Class Initialized
ERROR - 2013-08-21 06:19:27 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:19:33 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:33 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Router Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Output Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Security Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Input Class Initialized
DEBUG - 2013-08-21 06:19:33 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:33 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:19:33 --> Language Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Loader Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:19:33 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:19:33 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:19:33 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Session Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:19:33 --> Session routines successfully run
DEBUG - 2013-08-21 06:19:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Controller Class Initialized
ERROR - 2013-08-21 06:19:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:33 --> Model Class Initialized
DEBUG - 2013-08-21 06:19:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:19:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:19:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:19:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:19:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:33 --> Pagination Class Initialized
DEBUG - 2013-08-21 06:19:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:19:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:19:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:19:33 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:19:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:19:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:19:33 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-21 06:19:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:19:33 --> Final output sent to browser
DEBUG - 2013-08-21 06:19:33 --> Total execution time: 0.7740
DEBUG - 2013-08-21 06:19:34 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:34 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:34 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:34 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:34 --> Router Class Initialized
ERROR - 2013-08-21 06:19:34 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:19:55 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:55 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Router Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Output Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Security Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Input Class Initialized
DEBUG - 2013-08-21 06:19:55 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:55 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:19:55 --> Language Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Loader Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:19:55 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:19:55 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:19:55 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Session Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:19:55 --> Session routines successfully run
DEBUG - 2013-08-21 06:19:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:19:55 --> Controller Class Initialized
ERROR - 2013-08-21 06:19:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:55 --> Model Class Initialized
DEBUG - 2013-08-21 06:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:19:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:19:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:19:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:19:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:19:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:19:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:19:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:19:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:19:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:19:56 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 06:19:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:19:56 --> Final output sent to browser
DEBUG - 2013-08-21 06:19:56 --> Total execution time: 0.7680
DEBUG - 2013-08-21 06:19:56 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:56 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:56 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:56 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:56 --> Router Class Initialized
ERROR - 2013-08-21 06:19:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:19:59 --> Config Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:19:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:19:59 --> URI Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Router Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Output Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Security Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Input Class Initialized
DEBUG - 2013-08-21 06:19:59 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:59 --> XSS Filtering completed
DEBUG - 2013-08-21 06:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:19:59 --> Language Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Loader Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:19:59 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:19:59 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:19:59 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Session Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:19:59 --> Session garbage collection performed.
DEBUG - 2013-08-21 06:19:59 --> Session routines successfully run
DEBUG - 2013-08-21 06:19:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Controller Class Initialized
ERROR - 2013-08-21 06:19:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:59 --> Model Class Initialized
DEBUG - 2013-08-21 06:19:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:19:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:19:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:19:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:19:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:19:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:19:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:19:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:19:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:19:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:19:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:19:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:19:59 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 06:19:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:19:59 --> Final output sent to browser
DEBUG - 2013-08-21 06:19:59 --> Total execution time: 0.6660
DEBUG - 2013-08-21 06:20:00 --> Config Class Initialized
DEBUG - 2013-08-21 06:20:00 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:20:00 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:20:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:20:00 --> URI Class Initialized
DEBUG - 2013-08-21 06:20:00 --> Router Class Initialized
ERROR - 2013-08-21 06:20:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:20:04 --> Config Class Initialized
DEBUG - 2013-08-21 06:20:04 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:20:04 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:20:04 --> URI Class Initialized
DEBUG - 2013-08-21 06:20:04 --> Router Class Initialized
DEBUG - 2013-08-21 06:20:04 --> Output Class Initialized
DEBUG - 2013-08-21 06:20:04 --> Security Class Initialized
DEBUG - 2013-08-21 06:20:04 --> Input Class Initialized
DEBUG - 2013-08-21 06:20:04 --> XSS Filtering completed
DEBUG - 2013-08-21 06:20:04 --> XSS Filtering completed
DEBUG - 2013-08-21 06:20:04 --> XSS Filtering completed
DEBUG - 2013-08-21 06:20:04 --> XSS Filtering completed
DEBUG - 2013-08-21 06:20:04 --> XSS Filtering completed
DEBUG - 2013-08-21 06:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:20:04 --> Language Class Initialized
DEBUG - 2013-08-21 06:20:04 --> Loader Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:20:05 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:20:05 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:20:05 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Session Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:20:05 --> Session routines successfully run
DEBUG - 2013-08-21 06:20:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Controller Class Initialized
ERROR - 2013-08-21 06:20:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:20:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:20:05 --> Model Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:20:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:20:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:20:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:20:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:20:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:20:05 --> Form Validation Class Initialized
DEBUG - 2013-08-21 06:20:05 --> XSS Filtering completed
DEBUG - 2013-08-21 06:20:05 --> XSS Filtering completed
ERROR - 2013-08-21 06:20:05 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 117
DEBUG - 2013-08-21 06:20:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-21 06:20:05 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 187
DEBUG - 2013-08-21 06:20:05 --> Config Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:20:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:20:05 --> URI Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Router Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Output Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Security Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Input Class Initialized
DEBUG - 2013-08-21 06:20:05 --> XSS Filtering completed
DEBUG - 2013-08-21 06:20:05 --> XSS Filtering completed
DEBUG - 2013-08-21 06:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:20:05 --> Language Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Loader Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:20:05 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:20:05 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:20:05 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Session Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:20:05 --> Session routines successfully run
DEBUG - 2013-08-21 06:20:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:20:05 --> Controller Class Initialized
ERROR - 2013-08-21 06:20:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:20:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:20:06 --> Model Class Initialized
DEBUG - 2013-08-21 06:20:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:20:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:20:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:20:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:20:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:20:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:20:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:20:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:20:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:20:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:20:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:20:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:20:06 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:20:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:20:06 --> Final output sent to browser
DEBUG - 2013-08-21 06:20:06 --> Total execution time: 0.7090
DEBUG - 2013-08-21 06:20:06 --> Config Class Initialized
DEBUG - 2013-08-21 06:20:06 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:20:06 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:20:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:20:06 --> URI Class Initialized
DEBUG - 2013-08-21 06:20:06 --> Router Class Initialized
ERROR - 2013-08-21 06:20:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:21:59 --> Config Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:21:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:21:59 --> URI Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Router Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Output Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Security Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Input Class Initialized
DEBUG - 2013-08-21 06:21:59 --> XSS Filtering completed
DEBUG - 2013-08-21 06:21:59 --> XSS Filtering completed
DEBUG - 2013-08-21 06:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:21:59 --> Language Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Loader Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:21:59 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:21:59 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:21:59 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Session Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:21:59 --> Session routines successfully run
DEBUG - 2013-08-21 06:21:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Controller Class Initialized
ERROR - 2013-08-21 06:21:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:21:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:21:59 --> Model Class Initialized
DEBUG - 2013-08-21 06:21:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:21:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:21:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:21:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:21:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:21:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:21:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:21:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:21:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:21:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:21:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:21:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:21:59 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:21:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:21:59 --> Final output sent to browser
DEBUG - 2013-08-21 06:21:59 --> Total execution time: 0.7080
DEBUG - 2013-08-21 06:22:00 --> Config Class Initialized
DEBUG - 2013-08-21 06:22:00 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:22:00 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:22:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:22:00 --> URI Class Initialized
DEBUG - 2013-08-21 06:22:00 --> Router Class Initialized
ERROR - 2013-08-21 06:22:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:22:16 --> Config Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:22:16 --> URI Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Router Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Output Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Security Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Input Class Initialized
DEBUG - 2013-08-21 06:22:16 --> XSS Filtering completed
DEBUG - 2013-08-21 06:22:16 --> XSS Filtering completed
DEBUG - 2013-08-21 06:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:22:16 --> Language Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Loader Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:22:16 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:22:16 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:22:16 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Session Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:22:16 --> Session routines successfully run
DEBUG - 2013-08-21 06:22:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Controller Class Initialized
ERROR - 2013-08-21 06:22:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:22:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:22:16 --> Model Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:22:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:22:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:22:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:22:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:22:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:22:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:22:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:22:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:22:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:22:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:22:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:22:16 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:22:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:22:16 --> Final output sent to browser
DEBUG - 2013-08-21 06:22:16 --> Total execution time: 0.6590
DEBUG - 2013-08-21 06:22:16 --> Config Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:22:16 --> URI Class Initialized
DEBUG - 2013-08-21 06:22:16 --> Router Class Initialized
ERROR - 2013-08-21 06:22:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:22:46 --> Config Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:22:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:22:46 --> URI Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Router Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Output Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Security Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Input Class Initialized
DEBUG - 2013-08-21 06:22:46 --> XSS Filtering completed
DEBUG - 2013-08-21 06:22:46 --> XSS Filtering completed
DEBUG - 2013-08-21 06:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:22:46 --> Language Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Loader Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:22:46 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:22:46 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:22:46 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Session Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:22:46 --> Session routines successfully run
DEBUG - 2013-08-21 06:22:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Controller Class Initialized
ERROR - 2013-08-21 06:22:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:22:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:22:46 --> Model Class Initialized
DEBUG - 2013-08-21 06:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:22:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:22:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:22:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:22:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:22:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:22:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:22:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:22:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:22:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:22:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:22:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:22:46 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:22:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:22:46 --> Final output sent to browser
DEBUG - 2013-08-21 06:22:46 --> Total execution time: 0.6600
DEBUG - 2013-08-21 06:22:47 --> Config Class Initialized
DEBUG - 2013-08-21 06:22:47 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:22:47 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:22:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:22:47 --> URI Class Initialized
DEBUG - 2013-08-21 06:22:47 --> Router Class Initialized
ERROR - 2013-08-21 06:22:47 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:23:05 --> Config Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:23:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:23:05 --> URI Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Router Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Output Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Security Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Input Class Initialized
DEBUG - 2013-08-21 06:23:05 --> XSS Filtering completed
DEBUG - 2013-08-21 06:23:05 --> XSS Filtering completed
DEBUG - 2013-08-21 06:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:23:05 --> Language Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Loader Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:23:05 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:23:05 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:23:05 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Session Class Initialized
DEBUG - 2013-08-21 06:23:05 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:23:06 --> Session routines successfully run
DEBUG - 2013-08-21 06:23:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:23:06 --> Controller Class Initialized
ERROR - 2013-08-21 06:23:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:23:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:23:06 --> Model Class Initialized
DEBUG - 2013-08-21 06:23:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:23:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:23:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:23:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:23:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:23:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:23:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:23:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:23:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:23:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:23:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:23:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:23:06 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:23:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:23:06 --> Final output sent to browser
DEBUG - 2013-08-21 06:23:06 --> Total execution time: 0.6750
DEBUG - 2013-08-21 06:23:06 --> Config Class Initialized
DEBUG - 2013-08-21 06:23:06 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:23:06 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:23:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:23:06 --> URI Class Initialized
DEBUG - 2013-08-21 06:23:06 --> Router Class Initialized
ERROR - 2013-08-21 06:23:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:24:13 --> Config Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:24:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:24:13 --> URI Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Router Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Output Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Security Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Input Class Initialized
DEBUG - 2013-08-21 06:24:13 --> XSS Filtering completed
DEBUG - 2013-08-21 06:24:13 --> XSS Filtering completed
DEBUG - 2013-08-21 06:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:24:13 --> Language Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Loader Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:24:13 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:24:13 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:24:13 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Session Class Initialized
DEBUG - 2013-08-21 06:24:13 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:24:14 --> Session routines successfully run
DEBUG - 2013-08-21 06:24:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:24:14 --> Controller Class Initialized
ERROR - 2013-08-21 06:24:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:24:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:24:14 --> Model Class Initialized
DEBUG - 2013-08-21 06:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:24:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:24:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:24:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:24:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:24:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:24:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:24:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:24:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:24:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:24:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:24:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:24:14 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:24:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:24:14 --> Final output sent to browser
DEBUG - 2013-08-21 06:24:14 --> Total execution time: 0.6780
DEBUG - 2013-08-21 06:24:14 --> Config Class Initialized
DEBUG - 2013-08-21 06:24:14 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:24:14 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:24:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:24:14 --> URI Class Initialized
DEBUG - 2013-08-21 06:24:14 --> Router Class Initialized
ERROR - 2013-08-21 06:24:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:24:33 --> Config Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:24:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:24:33 --> URI Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Router Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Output Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Security Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Input Class Initialized
DEBUG - 2013-08-21 06:24:33 --> XSS Filtering completed
DEBUG - 2013-08-21 06:24:33 --> XSS Filtering completed
DEBUG - 2013-08-21 06:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:24:33 --> Language Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Loader Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:24:33 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:24:33 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:24:33 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Session Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:24:33 --> Session routines successfully run
DEBUG - 2013-08-21 06:24:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Controller Class Initialized
ERROR - 2013-08-21 06:24:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:24:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:24:33 --> Model Class Initialized
DEBUG - 2013-08-21 06:24:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:24:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:24:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:24:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:24:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:24:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:24:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:24:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:24:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:24:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:24:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:24:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:24:34 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:24:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:24:34 --> Final output sent to browser
DEBUG - 2013-08-21 06:24:34 --> Total execution time: 0.6730
DEBUG - 2013-08-21 06:24:34 --> Config Class Initialized
DEBUG - 2013-08-21 06:24:34 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:24:34 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:24:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:24:34 --> URI Class Initialized
DEBUG - 2013-08-21 06:24:34 --> Router Class Initialized
ERROR - 2013-08-21 06:24:34 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:24:53 --> Config Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:24:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:24:53 --> URI Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Router Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Output Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Security Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Input Class Initialized
DEBUG - 2013-08-21 06:24:53 --> XSS Filtering completed
DEBUG - 2013-08-21 06:24:53 --> XSS Filtering completed
DEBUG - 2013-08-21 06:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:24:53 --> Language Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Loader Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:24:53 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:24:53 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:24:53 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Session Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:24:53 --> Session routines successfully run
DEBUG - 2013-08-21 06:24:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Controller Class Initialized
ERROR - 2013-08-21 06:24:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:24:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:24:53 --> Model Class Initialized
DEBUG - 2013-08-21 06:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:24:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:24:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:24:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:24:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:24:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:24:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:24:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:24:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:24:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:24:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:24:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:24:54 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:24:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:24:54 --> Final output sent to browser
DEBUG - 2013-08-21 06:24:54 --> Total execution time: 0.6870
DEBUG - 2013-08-21 06:24:54 --> Config Class Initialized
DEBUG - 2013-08-21 06:24:54 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:24:54 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:24:54 --> URI Class Initialized
DEBUG - 2013-08-21 06:24:54 --> Router Class Initialized
ERROR - 2013-08-21 06:24:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:25:07 --> Config Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:25:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:25:07 --> URI Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Router Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Output Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Security Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Input Class Initialized
DEBUG - 2013-08-21 06:25:07 --> XSS Filtering completed
DEBUG - 2013-08-21 06:25:07 --> XSS Filtering completed
DEBUG - 2013-08-21 06:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:25:07 --> Language Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Loader Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:25:07 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:25:07 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:25:07 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Session Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:25:07 --> Session routines successfully run
DEBUG - 2013-08-21 06:25:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:25:07 --> Controller Class Initialized
ERROR - 2013-08-21 06:25:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:25:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:25:08 --> Model Class Initialized
DEBUG - 2013-08-21 06:25:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:25:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:25:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:25:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:25:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:25:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:25:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:25:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:25:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:25:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:25:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:25:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:25:08 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:25:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:25:08 --> Final output sent to browser
DEBUG - 2013-08-21 06:25:08 --> Total execution time: 0.7510
DEBUG - 2013-08-21 06:25:08 --> Config Class Initialized
DEBUG - 2013-08-21 06:25:08 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:25:08 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:25:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:25:08 --> URI Class Initialized
DEBUG - 2013-08-21 06:25:08 --> Router Class Initialized
ERROR - 2013-08-21 06:25:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:25:56 --> Config Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:25:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:25:56 --> URI Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Router Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Output Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Security Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Input Class Initialized
DEBUG - 2013-08-21 06:25:56 --> XSS Filtering completed
DEBUG - 2013-08-21 06:25:56 --> XSS Filtering completed
DEBUG - 2013-08-21 06:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:25:56 --> Language Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Loader Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:25:56 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:25:56 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:25:56 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Session Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:25:56 --> Session routines successfully run
DEBUG - 2013-08-21 06:25:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Controller Class Initialized
ERROR - 2013-08-21 06:25:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:25:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:25:56 --> Model Class Initialized
DEBUG - 2013-08-21 06:25:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:25:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:25:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:25:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:25:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:25:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:25:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:25:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:25:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:25:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:25:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:25:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:25:57 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:25:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:25:57 --> Final output sent to browser
DEBUG - 2013-08-21 06:25:57 --> Total execution time: 0.7590
DEBUG - 2013-08-21 06:25:57 --> Config Class Initialized
DEBUG - 2013-08-21 06:25:57 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:25:57 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:25:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:25:57 --> URI Class Initialized
DEBUG - 2013-08-21 06:25:57 --> Router Class Initialized
ERROR - 2013-08-21 06:25:57 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:26:23 --> Config Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:26:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:26:23 --> URI Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Router Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Output Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Security Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Input Class Initialized
DEBUG - 2013-08-21 06:26:23 --> XSS Filtering completed
DEBUG - 2013-08-21 06:26:23 --> XSS Filtering completed
DEBUG - 2013-08-21 06:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:26:23 --> Language Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Loader Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:26:23 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:26:23 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:26:23 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Session Class Initialized
DEBUG - 2013-08-21 06:26:23 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:26:23 --> Session routines successfully run
DEBUG - 2013-08-21 06:26:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:26:24 --> Controller Class Initialized
ERROR - 2013-08-21 06:26:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:26:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:26:24 --> Model Class Initialized
DEBUG - 2013-08-21 06:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:26:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:26:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:26:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:26:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:26:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:26:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:26:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:26:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:26:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:26:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:26:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:26:24 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:26:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:26:24 --> Final output sent to browser
DEBUG - 2013-08-21 06:26:24 --> Total execution time: 0.7420
DEBUG - 2013-08-21 06:26:24 --> Config Class Initialized
DEBUG - 2013-08-21 06:26:24 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:26:24 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:26:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:26:24 --> URI Class Initialized
DEBUG - 2013-08-21 06:26:24 --> Router Class Initialized
ERROR - 2013-08-21 06:26:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:26:34 --> Config Class Initialized
DEBUG - 2013-08-21 06:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:26:34 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:26:34 --> URI Class Initialized
DEBUG - 2013-08-21 06:26:34 --> Router Class Initialized
DEBUG - 2013-08-21 06:26:34 --> Output Class Initialized
DEBUG - 2013-08-21 06:26:34 --> Security Class Initialized
DEBUG - 2013-08-21 06:26:34 --> Input Class Initialized
DEBUG - 2013-08-21 06:26:34 --> XSS Filtering completed
DEBUG - 2013-08-21 06:26:34 --> XSS Filtering completed
DEBUG - 2013-08-21 06:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:26:35 --> Language Class Initialized
DEBUG - 2013-08-21 06:26:35 --> Loader Class Initialized
DEBUG - 2013-08-21 06:26:35 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:26:35 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:26:35 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:26:35 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:26:35 --> Session Class Initialized
DEBUG - 2013-08-21 06:26:35 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:26:35 --> Session routines successfully run
DEBUG - 2013-08-21 06:26:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:26:35 --> Controller Class Initialized
ERROR - 2013-08-21 06:26:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:26:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:26:35 --> Model Class Initialized
DEBUG - 2013-08-21 06:26:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:26:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:26:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:26:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:26:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:26:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:26:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:26:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:26:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:26:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:26:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:26:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:26:35 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:26:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:26:35 --> Final output sent to browser
DEBUG - 2013-08-21 06:26:35 --> Total execution time: 0.8210
DEBUG - 2013-08-21 06:26:35 --> Config Class Initialized
DEBUG - 2013-08-21 06:26:35 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:26:35 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:26:35 --> URI Class Initialized
DEBUG - 2013-08-21 06:26:35 --> Router Class Initialized
ERROR - 2013-08-21 06:26:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:26:56 --> Config Class Initialized
DEBUG - 2013-08-21 06:26:56 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:26:56 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:26:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:26:56 --> URI Class Initialized
DEBUG - 2013-08-21 06:26:56 --> Router Class Initialized
DEBUG - 2013-08-21 06:26:56 --> Output Class Initialized
DEBUG - 2013-08-21 06:26:56 --> Security Class Initialized
DEBUG - 2013-08-21 06:26:56 --> Input Class Initialized
DEBUG - 2013-08-21 06:26:56 --> XSS Filtering completed
DEBUG - 2013-08-21 06:26:56 --> XSS Filtering completed
DEBUG - 2013-08-21 06:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:26:56 --> Language Class Initialized
DEBUG - 2013-08-21 06:26:56 --> Loader Class Initialized
DEBUG - 2013-08-21 06:26:56 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:26:56 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:26:56 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:26:56 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:26:57 --> Session Class Initialized
DEBUG - 2013-08-21 06:26:57 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:26:57 --> Session routines successfully run
DEBUG - 2013-08-21 06:26:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:26:57 --> Controller Class Initialized
ERROR - 2013-08-21 06:26:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:26:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:26:57 --> Model Class Initialized
DEBUG - 2013-08-21 06:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:26:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:26:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:26:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:26:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:26:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:26:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:26:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:26:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:26:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:26:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:26:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:26:57 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:26:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:26:57 --> Final output sent to browser
DEBUG - 2013-08-21 06:26:57 --> Total execution time: 0.9491
DEBUG - 2013-08-21 06:26:57 --> Config Class Initialized
DEBUG - 2013-08-21 06:26:57 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:26:57 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:26:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:26:57 --> URI Class Initialized
DEBUG - 2013-08-21 06:26:57 --> Router Class Initialized
ERROR - 2013-08-21 06:26:57 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:27:07 --> Config Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:27:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:27:07 --> URI Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Router Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Output Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Security Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Input Class Initialized
DEBUG - 2013-08-21 06:27:07 --> XSS Filtering completed
DEBUG - 2013-08-21 06:27:07 --> XSS Filtering completed
DEBUG - 2013-08-21 06:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:27:07 --> Language Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Loader Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:27:07 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:27:07 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:27:07 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Session Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:27:07 --> Session routines successfully run
DEBUG - 2013-08-21 06:27:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Controller Class Initialized
ERROR - 2013-08-21 06:27:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:27:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:27:07 --> Model Class Initialized
DEBUG - 2013-08-21 06:27:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:27:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:27:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:27:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:27:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:27:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:27:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:27:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:27:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:27:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:27:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:27:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:27:07 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:27:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:27:07 --> Final output sent to browser
DEBUG - 2013-08-21 06:27:07 --> Total execution time: 0.8010
DEBUG - 2013-08-21 06:27:08 --> Config Class Initialized
DEBUG - 2013-08-21 06:27:08 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:27:08 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:27:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:27:08 --> URI Class Initialized
DEBUG - 2013-08-21 06:27:08 --> Router Class Initialized
ERROR - 2013-08-21 06:27:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:27:18 --> Config Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:27:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:27:18 --> URI Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Router Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Output Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Security Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Input Class Initialized
DEBUG - 2013-08-21 06:27:18 --> XSS Filtering completed
DEBUG - 2013-08-21 06:27:18 --> XSS Filtering completed
DEBUG - 2013-08-21 06:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:27:18 --> Language Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Loader Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:27:18 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:27:18 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:27:18 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Session Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:27:18 --> Session routines successfully run
DEBUG - 2013-08-21 06:27:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Controller Class Initialized
ERROR - 2013-08-21 06:27:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:27:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:27:18 --> Model Class Initialized
DEBUG - 2013-08-21 06:27:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:27:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:27:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:27:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:27:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:27:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:27:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:27:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:27:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:27:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:27:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:27:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:27:19 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:27:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:27:19 --> Final output sent to browser
DEBUG - 2013-08-21 06:27:19 --> Total execution time: 0.8200
DEBUG - 2013-08-21 06:27:19 --> Config Class Initialized
DEBUG - 2013-08-21 06:27:19 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:27:19 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:27:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:27:19 --> URI Class Initialized
DEBUG - 2013-08-21 06:27:19 --> Router Class Initialized
ERROR - 2013-08-21 06:27:19 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:27:32 --> Config Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:27:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:27:32 --> URI Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Router Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Output Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Security Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Input Class Initialized
DEBUG - 2013-08-21 06:27:32 --> XSS Filtering completed
DEBUG - 2013-08-21 06:27:32 --> XSS Filtering completed
DEBUG - 2013-08-21 06:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:27:32 --> Language Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Loader Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:27:32 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:27:32 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:27:32 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Session Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:27:32 --> Session routines successfully run
DEBUG - 2013-08-21 06:27:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Controller Class Initialized
ERROR - 2013-08-21 06:27:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:27:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:27:32 --> Model Class Initialized
DEBUG - 2013-08-21 06:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:27:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:27:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:27:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:27:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:27:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:27:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:27:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:27:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:27:32 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:27:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:27:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:27:32 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:27:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:27:32 --> Final output sent to browser
DEBUG - 2013-08-21 06:27:32 --> Total execution time: 0.8300
DEBUG - 2013-08-21 06:27:33 --> Config Class Initialized
DEBUG - 2013-08-21 06:27:33 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:27:33 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:27:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:27:33 --> URI Class Initialized
DEBUG - 2013-08-21 06:27:33 --> Router Class Initialized
ERROR - 2013-08-21 06:27:33 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:27:57 --> Config Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:27:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:27:57 --> URI Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Router Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Output Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Security Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Input Class Initialized
DEBUG - 2013-08-21 06:27:57 --> XSS Filtering completed
DEBUG - 2013-08-21 06:27:57 --> XSS Filtering completed
DEBUG - 2013-08-21 06:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:27:57 --> Language Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Loader Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:27:57 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:27:57 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:27:57 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Session Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:27:57 --> Session routines successfully run
DEBUG - 2013-08-21 06:27:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Controller Class Initialized
ERROR - 2013-08-21 06:27:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:27:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:27:57 --> Model Class Initialized
DEBUG - 2013-08-21 06:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:27:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:27:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:27:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:27:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:27:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:27:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:27:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:27:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:27:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:27:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:27:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:27:57 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:27:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:27:57 --> Final output sent to browser
DEBUG - 2013-08-21 06:27:57 --> Total execution time: 0.8680
DEBUG - 2013-08-21 06:27:58 --> Config Class Initialized
DEBUG - 2013-08-21 06:27:58 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:27:58 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:27:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:27:58 --> URI Class Initialized
DEBUG - 2013-08-21 06:27:58 --> Router Class Initialized
ERROR - 2013-08-21 06:27:58 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:29:09 --> Config Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:29:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:29:09 --> URI Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Router Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Output Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Security Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Input Class Initialized
DEBUG - 2013-08-21 06:29:09 --> XSS Filtering completed
DEBUG - 2013-08-21 06:29:09 --> XSS Filtering completed
DEBUG - 2013-08-21 06:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:29:09 --> Language Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Loader Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:29:09 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:29:09 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:29:09 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Session Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:29:09 --> Session routines successfully run
DEBUG - 2013-08-21 06:29:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Controller Class Initialized
ERROR - 2013-08-21 06:29:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:29:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:29:09 --> Model Class Initialized
DEBUG - 2013-08-21 06:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:29:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:29:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:29:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:29:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:29:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:29:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:29:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:29:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:29:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:29:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:29:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:29:10 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:29:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:29:10 --> Final output sent to browser
DEBUG - 2013-08-21 06:29:10 --> Total execution time: 0.8911
DEBUG - 2013-08-21 06:29:10 --> Config Class Initialized
DEBUG - 2013-08-21 06:29:10 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:29:10 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:29:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:29:10 --> URI Class Initialized
DEBUG - 2013-08-21 06:29:10 --> Router Class Initialized
ERROR - 2013-08-21 06:29:10 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:29:13 --> Config Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:29:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:29:13 --> URI Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Router Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Output Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Security Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Input Class Initialized
DEBUG - 2013-08-21 06:29:13 --> XSS Filtering completed
DEBUG - 2013-08-21 06:29:13 --> XSS Filtering completed
DEBUG - 2013-08-21 06:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:29:13 --> Language Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Loader Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:29:13 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:29:13 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:29:13 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Session Class Initialized
DEBUG - 2013-08-21 06:29:13 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:29:14 --> Session routines successfully run
DEBUG - 2013-08-21 06:29:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:29:14 --> Controller Class Initialized
ERROR - 2013-08-21 06:29:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:29:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:29:14 --> Model Class Initialized
DEBUG - 2013-08-21 06:29:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:29:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:29:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:29:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:29:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:29:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:29:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:29:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:29:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:29:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:29:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:29:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:29:14 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 06:29:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:29:14 --> Final output sent to browser
DEBUG - 2013-08-21 06:29:14 --> Total execution time: 0.9011
DEBUG - 2013-08-21 06:29:14 --> Config Class Initialized
DEBUG - 2013-08-21 06:29:14 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:29:14 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:29:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:29:14 --> URI Class Initialized
DEBUG - 2013-08-21 06:29:14 --> Router Class Initialized
ERROR - 2013-08-21 06:29:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:36:04 --> Config Class Initialized
DEBUG - 2013-08-21 06:36:04 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:36:04 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:36:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:36:04 --> URI Class Initialized
DEBUG - 2013-08-21 06:36:04 --> Router Class Initialized
DEBUG - 2013-08-21 06:36:04 --> Output Class Initialized
DEBUG - 2013-08-21 06:36:04 --> Security Class Initialized
DEBUG - 2013-08-21 06:36:04 --> Input Class Initialized
DEBUG - 2013-08-21 06:36:04 --> XSS Filtering completed
DEBUG - 2013-08-21 06:36:04 --> XSS Filtering completed
DEBUG - 2013-08-21 06:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:36:04 --> Language Class Initialized
DEBUG - 2013-08-21 06:36:04 --> Loader Class Initialized
DEBUG - 2013-08-21 06:36:04 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:36:04 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:36:04 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:36:05 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:36:05 --> Session Class Initialized
DEBUG - 2013-08-21 06:36:05 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:36:05 --> Session routines successfully run
DEBUG - 2013-08-21 06:36:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:36:05 --> Controller Class Initialized
ERROR - 2013-08-21 06:36:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:36:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:36:05 --> Model Class Initialized
DEBUG - 2013-08-21 06:36:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:36:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:36:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:36:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:36:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:36:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:36:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:36:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:36:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:36:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:36:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:36:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:36:06 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:36:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:36:06 --> Final output sent to browser
DEBUG - 2013-08-21 06:36:06 --> Total execution time: 3.1532
DEBUG - 2013-08-21 06:36:06 --> Config Class Initialized
DEBUG - 2013-08-21 06:36:06 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:36:06 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:36:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:36:06 --> URI Class Initialized
DEBUG - 2013-08-21 06:36:06 --> Router Class Initialized
ERROR - 2013-08-21 06:36:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:44:26 --> Config Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:44:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:44:26 --> URI Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Router Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Output Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Security Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Input Class Initialized
DEBUG - 2013-08-21 06:44:26 --> XSS Filtering completed
DEBUG - 2013-08-21 06:44:26 --> XSS Filtering completed
DEBUG - 2013-08-21 06:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:44:26 --> Language Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Loader Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:44:26 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:44:26 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:44:26 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Session Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:44:26 --> Session routines successfully run
DEBUG - 2013-08-21 06:44:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:44:26 --> Controller Class Initialized
ERROR - 2013-08-21 06:44:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:44:27 --> Model Class Initialized
DEBUG - 2013-08-21 06:44:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:44:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:44:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:44:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:44:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:44:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:44:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:44:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:44:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:44:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:44:27 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:44:27 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 06:44:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:44:27 --> Final output sent to browser
DEBUG - 2013-08-21 06:44:27 --> Total execution time: 2.4221
DEBUG - 2013-08-21 06:44:27 --> Config Class Initialized
DEBUG - 2013-08-21 06:44:27 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:44:27 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:44:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:44:28 --> URI Class Initialized
DEBUG - 2013-08-21 06:44:28 --> Router Class Initialized
ERROR - 2013-08-21 06:44:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:44:39 --> Config Class Initialized
DEBUG - 2013-08-21 06:44:39 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:44:39 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:44:39 --> URI Class Initialized
DEBUG - 2013-08-21 06:44:39 --> Router Class Initialized
DEBUG - 2013-08-21 06:44:39 --> Output Class Initialized
DEBUG - 2013-08-21 06:44:39 --> Security Class Initialized
DEBUG - 2013-08-21 06:44:39 --> Input Class Initialized
DEBUG - 2013-08-21 06:44:39 --> XSS Filtering completed
DEBUG - 2013-08-21 06:44:40 --> XSS Filtering completed
DEBUG - 2013-08-21 06:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:44:40 --> Language Class Initialized
DEBUG - 2013-08-21 06:44:40 --> Loader Class Initialized
DEBUG - 2013-08-21 06:44:40 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:44:40 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:44:40 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:44:40 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:44:40 --> Session Class Initialized
DEBUG - 2013-08-21 06:44:40 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:44:40 --> Session routines successfully run
DEBUG - 2013-08-21 06:44:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:44:40 --> Controller Class Initialized
ERROR - 2013-08-21 06:44:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:44:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:44:40 --> Model Class Initialized
DEBUG - 2013-08-21 06:44:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:44:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:44:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:44:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:44:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:44:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:44:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:44:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:44:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:44:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:44:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:44:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:44:40 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 06:44:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:44:40 --> Final output sent to browser
DEBUG - 2013-08-21 06:44:40 --> Total execution time: 0.9711
DEBUG - 2013-08-21 06:44:41 --> Config Class Initialized
DEBUG - 2013-08-21 06:44:41 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:44:41 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:44:41 --> URI Class Initialized
DEBUG - 2013-08-21 06:44:41 --> Router Class Initialized
ERROR - 2013-08-21 06:44:41 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:44:51 --> Config Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:44:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:44:51 --> URI Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Router Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Output Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Security Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Input Class Initialized
DEBUG - 2013-08-21 06:44:51 --> XSS Filtering completed
DEBUG - 2013-08-21 06:44:51 --> XSS Filtering completed
DEBUG - 2013-08-21 06:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:44:51 --> Language Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Loader Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:44:51 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:44:51 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:44:51 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Session Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:44:51 --> Session routines successfully run
DEBUG - 2013-08-21 06:44:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Controller Class Initialized
ERROR - 2013-08-21 06:44:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:44:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:44:51 --> Model Class Initialized
DEBUG - 2013-08-21 06:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:44:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:44:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:44:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:44:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:44:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:44:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:44:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:44:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:44:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:44:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:44:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:44:52 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 06:44:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:44:52 --> Final output sent to browser
DEBUG - 2013-08-21 06:44:52 --> Total execution time: 0.9011
DEBUG - 2013-08-21 06:44:52 --> Config Class Initialized
DEBUG - 2013-08-21 06:44:52 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:44:52 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:44:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:44:52 --> URI Class Initialized
DEBUG - 2013-08-21 06:44:52 --> Router Class Initialized
ERROR - 2013-08-21 06:44:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:45:32 --> Config Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:45:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:45:32 --> URI Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Router Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Output Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Security Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Input Class Initialized
DEBUG - 2013-08-21 06:45:32 --> XSS Filtering completed
DEBUG - 2013-08-21 06:45:32 --> XSS Filtering completed
DEBUG - 2013-08-21 06:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:45:32 --> Language Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Loader Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:45:32 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:45:32 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:45:32 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Session Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:45:32 --> Session routines successfully run
DEBUG - 2013-08-21 06:45:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Controller Class Initialized
ERROR - 2013-08-21 06:45:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:45:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:45:32 --> Model Class Initialized
DEBUG - 2013-08-21 06:45:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:45:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:45:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:45:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:45:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:45:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:45:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:45:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:45:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:45:32 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:45:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:45:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:45:33 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-21 06:45:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:45:33 --> Final output sent to browser
DEBUG - 2013-08-21 06:45:33 --> Total execution time: 0.8150
DEBUG - 2013-08-21 06:45:33 --> Config Class Initialized
DEBUG - 2013-08-21 06:45:33 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:45:33 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:45:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:45:33 --> URI Class Initialized
DEBUG - 2013-08-21 06:45:33 --> Router Class Initialized
ERROR - 2013-08-21 06:45:33 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:48:16 --> Config Class Initialized
DEBUG - 2013-08-21 06:48:16 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:48:16 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:48:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:48:16 --> URI Class Initialized
DEBUG - 2013-08-21 06:48:16 --> Router Class Initialized
DEBUG - 2013-08-21 06:48:16 --> Output Class Initialized
DEBUG - 2013-08-21 06:48:16 --> Security Class Initialized
DEBUG - 2013-08-21 06:48:16 --> Input Class Initialized
DEBUG - 2013-08-21 06:48:16 --> XSS Filtering completed
DEBUG - 2013-08-21 06:48:16 --> XSS Filtering completed
DEBUG - 2013-08-21 06:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:48:16 --> Language Class Initialized
DEBUG - 2013-08-21 06:48:16 --> Loader Class Initialized
DEBUG - 2013-08-21 06:48:16 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:48:16 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:48:16 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:48:16 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:48:17 --> Session Class Initialized
DEBUG - 2013-08-21 06:48:17 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:48:17 --> Session routines successfully run
DEBUG - 2013-08-21 06:48:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:48:17 --> Controller Class Initialized
ERROR - 2013-08-21 06:48:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:48:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:48:17 --> Model Class Initialized
DEBUG - 2013-08-21 06:48:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:48:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:48:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:48:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:48:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:48:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:48:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:48:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:48:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:48:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:48:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:48:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:48:17 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-21 06:48:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:48:17 --> Final output sent to browser
DEBUG - 2013-08-21 06:48:17 --> Total execution time: 0.8610
DEBUG - 2013-08-21 06:48:17 --> Config Class Initialized
DEBUG - 2013-08-21 06:48:17 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:48:17 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:48:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:48:17 --> URI Class Initialized
DEBUG - 2013-08-21 06:48:17 --> Router Class Initialized
ERROR - 2013-08-21 06:48:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:48:19 --> Config Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:48:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:48:19 --> URI Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Router Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Output Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Security Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Input Class Initialized
DEBUG - 2013-08-21 06:48:19 --> XSS Filtering completed
DEBUG - 2013-08-21 06:48:19 --> XSS Filtering completed
DEBUG - 2013-08-21 06:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:48:19 --> Language Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Loader Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:48:19 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:48:19 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:48:19 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Session Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:48:19 --> Session routines successfully run
DEBUG - 2013-08-21 06:48:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Controller Class Initialized
ERROR - 2013-08-21 06:48:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:48:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:48:19 --> Model Class Initialized
DEBUG - 2013-08-21 06:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:48:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:48:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:48:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:48:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:48:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:48:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:48:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:48:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:48:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:48:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:48:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:48:19 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-21 06:48:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:48:19 --> Final output sent to browser
DEBUG - 2013-08-21 06:48:19 --> Total execution time: 0.8670
DEBUG - 2013-08-21 06:48:20 --> Config Class Initialized
DEBUG - 2013-08-21 06:48:20 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:48:20 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:48:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:48:20 --> URI Class Initialized
DEBUG - 2013-08-21 06:48:20 --> Router Class Initialized
ERROR - 2013-08-21 06:48:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 06:49:09 --> Config Class Initialized
DEBUG - 2013-08-21 06:49:09 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:49:09 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:49:09 --> URI Class Initialized
DEBUG - 2013-08-21 06:49:09 --> Router Class Initialized
DEBUG - 2013-08-21 06:49:09 --> Output Class Initialized
DEBUG - 2013-08-21 06:49:09 --> Security Class Initialized
DEBUG - 2013-08-21 06:49:09 --> Input Class Initialized
DEBUG - 2013-08-21 06:49:09 --> XSS Filtering completed
DEBUG - 2013-08-21 06:49:09 --> XSS Filtering completed
DEBUG - 2013-08-21 06:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 06:49:09 --> Language Class Initialized
DEBUG - 2013-08-21 06:49:09 --> Loader Class Initialized
DEBUG - 2013-08-21 06:49:09 --> Helper loaded: url_helper
DEBUG - 2013-08-21 06:49:09 --> Helper loaded: file_helper
DEBUG - 2013-08-21 06:49:09 --> Helper loaded: form_helper
DEBUG - 2013-08-21 06:49:09 --> Database Driver Class Initialized
DEBUG - 2013-08-21 06:49:09 --> Session Class Initialized
DEBUG - 2013-08-21 06:49:10 --> Helper loaded: string_helper
DEBUG - 2013-08-21 06:49:10 --> Session routines successfully run
DEBUG - 2013-08-21 06:49:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 06:49:10 --> Controller Class Initialized
ERROR - 2013-08-21 06:49:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:49:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:49:10 --> Model Class Initialized
DEBUG - 2013-08-21 06:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 06:49:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 06:49:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 06:49:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 06:49:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 06:49:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 06:49:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 06:49:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 06:49:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 06:49:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 06:49:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 06:49:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 06:49:10 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-21 06:49:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 06:49:10 --> Final output sent to browser
DEBUG - 2013-08-21 06:49:10 --> Total execution time: 0.8390
DEBUG - 2013-08-21 06:49:10 --> Config Class Initialized
DEBUG - 2013-08-21 06:49:10 --> Hooks Class Initialized
DEBUG - 2013-08-21 06:49:10 --> Utf8 Class Initialized
DEBUG - 2013-08-21 06:49:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 06:49:10 --> URI Class Initialized
DEBUG - 2013-08-21 06:49:10 --> Router Class Initialized
ERROR - 2013-08-21 06:49:10 --> 404 Page Not Found --> css
DEBUG - 2013-08-21 11:26:15 --> Config Class Initialized
DEBUG - 2013-08-21 11:26:15 --> Hooks Class Initialized
DEBUG - 2013-08-21 11:26:15 --> Utf8 Class Initialized
DEBUG - 2013-08-21 11:26:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 11:26:15 --> URI Class Initialized
DEBUG - 2013-08-21 11:26:16 --> Router Class Initialized
DEBUG - 2013-08-21 11:26:16 --> Output Class Initialized
DEBUG - 2013-08-21 11:26:16 --> Security Class Initialized
DEBUG - 2013-08-21 11:26:16 --> Input Class Initialized
DEBUG - 2013-08-21 11:26:16 --> XSS Filtering completed
DEBUG - 2013-08-21 11:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-21 11:26:16 --> Language Class Initialized
DEBUG - 2013-08-21 11:26:16 --> Loader Class Initialized
DEBUG - 2013-08-21 11:26:16 --> Helper loaded: url_helper
DEBUG - 2013-08-21 11:26:16 --> Helper loaded: file_helper
DEBUG - 2013-08-21 11:26:16 --> Helper loaded: form_helper
DEBUG - 2013-08-21 11:26:16 --> Database Driver Class Initialized
DEBUG - 2013-08-21 11:26:16 --> Session Class Initialized
DEBUG - 2013-08-21 11:26:17 --> Helper loaded: string_helper
DEBUG - 2013-08-21 11:26:17 --> A session cookie was not found.
DEBUG - 2013-08-21 11:26:17 --> Session routines successfully run
DEBUG - 2013-08-21 11:26:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-21 11:26:17 --> Controller Class Initialized
ERROR - 2013-08-21 11:26:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 11:26:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 11:26:17 --> Model Class Initialized
DEBUG - 2013-08-21 11:26:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-21 11:26:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-21 11:26:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-21 11:26:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-21 11:26:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-21 11:26:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-21 11:26:18 --> Pagination Class Initialized
DEBUG - 2013-08-21 11:26:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-21 11:26:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-21 11:26:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-21 11:26:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-21 11:26:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-21 11:26:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-21 11:26:19 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-21 11:26:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-21 11:26:19 --> Final output sent to browser
DEBUG - 2013-08-21 11:26:19 --> Total execution time: 5.1663
DEBUG - 2013-08-21 11:26:20 --> Config Class Initialized
DEBUG - 2013-08-21 11:26:20 --> Hooks Class Initialized
DEBUG - 2013-08-21 11:26:20 --> Utf8 Class Initialized
DEBUG - 2013-08-21 11:26:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-21 11:26:20 --> URI Class Initialized
DEBUG - 2013-08-21 11:26:20 --> Router Class Initialized
ERROR - 2013-08-21 11:26:20 --> 404 Page Not Found --> css
