<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-03 04:48:18 --> Config Class Initialized
DEBUG - 2013-09-03 04:48:18 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:48:18 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:48:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:48:18 --> URI Class Initialized
DEBUG - 2013-09-03 04:48:18 --> Router Class Initialized
DEBUG - 2013-09-03 04:48:18 --> Output Class Initialized
DEBUG - 2013-09-03 04:48:18 --> Security Class Initialized
DEBUG - 2013-09-03 04:48:18 --> Input Class Initialized
DEBUG - 2013-09-03 04:48:18 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 04:48:18 --> Language Class Initialized
DEBUG - 2013-09-03 04:48:18 --> Loader Class Initialized
DEBUG - 2013-09-03 04:48:18 --> Helper loaded: url_helper
DEBUG - 2013-09-03 04:48:19 --> Helper loaded: file_helper
DEBUG - 2013-09-03 04:48:19 --> Helper loaded: form_helper
DEBUG - 2013-09-03 04:48:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 04:48:19 --> Helper loaded: application_helper
DEBUG - 2013-09-03 04:48:19 --> Database Driver Class Initialized
DEBUG - 2013-09-03 04:48:19 --> Session Class Initialized
DEBUG - 2013-09-03 04:48:19 --> Helper loaded: string_helper
DEBUG - 2013-09-03 04:48:19 --> A session cookie was not found.
DEBUG - 2013-09-03 04:48:20 --> Session routines successfully run
DEBUG - 2013-09-03 04:48:20 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Controller Class Initialized
ERROR - 2013-09-03 04:48:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:20 --> Model Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 04:48:20 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 04:48:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 04:48:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 04:48:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:20 --> Config Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:48:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:48:20 --> URI Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Router Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Output Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Security Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Input Class Initialized
DEBUG - 2013-09-03 04:48:20 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:20 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 04:48:20 --> Language Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Loader Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Helper loaded: url_helper
DEBUG - 2013-09-03 04:48:20 --> Helper loaded: file_helper
DEBUG - 2013-09-03 04:48:20 --> Helper loaded: form_helper
DEBUG - 2013-09-03 04:48:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 04:48:20 --> Helper loaded: application_helper
DEBUG - 2013-09-03 04:48:20 --> Database Driver Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Session Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Helper loaded: string_helper
DEBUG - 2013-09-03 04:48:20 --> Session routines successfully run
DEBUG - 2013-09-03 04:48:20 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Controller Class Initialized
ERROR - 2013-09-03 04:48:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:20 --> Model Class Initialized
DEBUG - 2013-09-03 04:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 04:48:20 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 04:48:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 04:48:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 04:48:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 04:48:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 04:48:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 04:48:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-03 04:48:21 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-03 04:48:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 04:48:21 --> Final output sent to browser
DEBUG - 2013-09-03 04:48:21 --> Total execution time: 0.4520
DEBUG - 2013-09-03 04:48:21 --> Config Class Initialized
DEBUG - 2013-09-03 04:48:21 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:48:21 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:48:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:48:21 --> URI Class Initialized
DEBUG - 2013-09-03 04:48:21 --> Router Class Initialized
ERROR - 2013-09-03 04:48:21 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 04:48:39 --> Config Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:48:39 --> URI Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Router Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Output Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Security Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Input Class Initialized
DEBUG - 2013-09-03 04:48:39 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:39 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:39 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:39 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:39 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:39 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 04:48:39 --> Language Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Loader Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Helper loaded: url_helper
DEBUG - 2013-09-03 04:48:39 --> Helper loaded: file_helper
DEBUG - 2013-09-03 04:48:39 --> Helper loaded: form_helper
DEBUG - 2013-09-03 04:48:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 04:48:39 --> Helper loaded: application_helper
DEBUG - 2013-09-03 04:48:39 --> Database Driver Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Session Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Helper loaded: string_helper
DEBUG - 2013-09-03 04:48:39 --> Session routines successfully run
DEBUG - 2013-09-03 04:48:39 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Controller Class Initialized
ERROR - 2013-09-03 04:48:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:39 --> Model Class Initialized
DEBUG - 2013-09-03 04:48:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 04:48:39 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 04:48:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 04:48:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 04:48:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:39 --> Model Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Form Validation Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-03 04:48:40 --> Config Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:48:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:48:40 --> URI Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Router Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Output Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Security Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Input Class Initialized
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 04:48:40 --> Language Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Loader Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: url_helper
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: file_helper
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: form_helper
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: application_helper
DEBUG - 2013-09-03 04:48:40 --> Database Driver Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Session Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: string_helper
DEBUG - 2013-09-03 04:48:40 --> Session routines successfully run
DEBUG - 2013-09-03 04:48:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Controller Class Initialized
ERROR - 2013-09-03 04:48:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:40 --> Model Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 04:48:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 04:48:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 04:48:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:40 --> Config Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:48:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:48:40 --> URI Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Router Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Output Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Security Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Input Class Initialized
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 04:48:40 --> Language Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Loader Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: url_helper
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: file_helper
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: form_helper
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: application_helper
DEBUG - 2013-09-03 04:48:40 --> Database Driver Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Session Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: string_helper
DEBUG - 2013-09-03 04:48:40 --> Session routines successfully run
DEBUG - 2013-09-03 04:48:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Controller Class Initialized
ERROR - 2013-09-03 04:48:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:40 --> Model Class Initialized
DEBUG - 2013-09-03 04:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 04:48:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 04:48:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 04:48:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 04:48:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:40 --> Model Class Initialized
DEBUG - 2013-09-03 04:48:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 04:48:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 04:48:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 04:48:41 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 04:48:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 04:48:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 04:48:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-03 04:48:41 --> File loaded: application/views/home.php
DEBUG - 2013-09-03 04:48:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 04:48:41 --> Final output sent to browser
DEBUG - 2013-09-03 04:48:41 --> Total execution time: 0.4690
DEBUG - 2013-09-03 04:48:41 --> Config Class Initialized
DEBUG - 2013-09-03 04:48:41 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:48:41 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:48:41 --> URI Class Initialized
DEBUG - 2013-09-03 04:48:41 --> Router Class Initialized
ERROR - 2013-09-03 04:48:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 04:48:53 --> Config Class Initialized
DEBUG - 2013-09-03 04:48:53 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:48:53 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:48:53 --> URI Class Initialized
DEBUG - 2013-09-03 04:48:53 --> Router Class Initialized
DEBUG - 2013-09-03 04:48:53 --> Output Class Initialized
DEBUG - 2013-09-03 04:48:53 --> Security Class Initialized
DEBUG - 2013-09-03 04:48:53 --> Input Class Initialized
DEBUG - 2013-09-03 04:48:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 04:48:53 --> Language Class Initialized
DEBUG - 2013-09-03 04:48:53 --> Loader Class Initialized
DEBUG - 2013-09-03 04:48:53 --> Helper loaded: url_helper
DEBUG - 2013-09-03 04:48:53 --> Helper loaded: file_helper
DEBUG - 2013-09-03 04:48:53 --> Helper loaded: form_helper
DEBUG - 2013-09-03 04:48:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 04:48:53 --> Helper loaded: application_helper
DEBUG - 2013-09-03 04:48:53 --> Database Driver Class Initialized
DEBUG - 2013-09-03 04:48:54 --> Session Class Initialized
DEBUG - 2013-09-03 04:48:54 --> Helper loaded: string_helper
DEBUG - 2013-09-03 04:48:54 --> Session routines successfully run
DEBUG - 2013-09-03 04:48:54 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 04:48:54 --> Controller Class Initialized
ERROR - 2013-09-03 04:48:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:54 --> Model Class Initialized
DEBUG - 2013-09-03 04:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 04:48:54 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 04:48:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 04:48:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 04:48:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:48:54 --> Model Class Initialized
DEBUG - 2013-09-03 04:48:54 --> Pagination Class Initialized
ERROR - 2013-09-03 04:48:54 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:48:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:49:53 --> Config Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:49:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:49:53 --> URI Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Router Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Output Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Security Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Input Class Initialized
DEBUG - 2013-09-03 04:49:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:49:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:49:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:49:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:49:53 --> XSS Filtering completed
DEBUG - 2013-09-03 04:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 04:49:53 --> Language Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Loader Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Helper loaded: url_helper
DEBUG - 2013-09-03 04:49:53 --> Helper loaded: file_helper
DEBUG - 2013-09-03 04:49:53 --> Helper loaded: form_helper
DEBUG - 2013-09-03 04:49:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 04:49:53 --> Helper loaded: application_helper
DEBUG - 2013-09-03 04:49:53 --> Database Driver Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Session Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Helper loaded: string_helper
DEBUG - 2013-09-03 04:49:53 --> Session routines successfully run
DEBUG - 2013-09-03 04:49:53 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Controller Class Initialized
ERROR - 2013-09-03 04:49:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:49:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:49:53 --> Model Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 04:49:53 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 04:49:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 04:49:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 04:49:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:49:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:49:53 --> Model Class Initialized
DEBUG - 2013-09-03 04:49:53 --> Pagination Class Initialized
ERROR - 2013-09-03 04:49:53 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:49:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:50:54 --> Config Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:50:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:50:54 --> URI Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Router Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Output Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Security Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Input Class Initialized
DEBUG - 2013-09-03 04:50:54 --> XSS Filtering completed
DEBUG - 2013-09-03 04:50:54 --> XSS Filtering completed
DEBUG - 2013-09-03 04:50:54 --> XSS Filtering completed
DEBUG - 2013-09-03 04:50:54 --> XSS Filtering completed
DEBUG - 2013-09-03 04:50:54 --> XSS Filtering completed
DEBUG - 2013-09-03 04:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 04:50:54 --> Language Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Loader Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Helper loaded: url_helper
DEBUG - 2013-09-03 04:50:54 --> Helper loaded: file_helper
DEBUG - 2013-09-03 04:50:54 --> Helper loaded: form_helper
DEBUG - 2013-09-03 04:50:54 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 04:50:54 --> Helper loaded: application_helper
DEBUG - 2013-09-03 04:50:54 --> Database Driver Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Session Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Helper loaded: string_helper
DEBUG - 2013-09-03 04:50:54 --> Session routines successfully run
DEBUG - 2013-09-03 04:50:54 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Controller Class Initialized
ERROR - 2013-09-03 04:50:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:50:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:50:54 --> Model Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 04:50:54 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 04:50:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 04:50:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 04:50:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:50:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:50:54 --> Model Class Initialized
DEBUG - 2013-09-03 04:50:54 --> Pagination Class Initialized
ERROR - 2013-09-03 04:50:54 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 04:50:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 04:50:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 04:50:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 04:50:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 04:50:55 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 04:50:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 04:50:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 04:50:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-03 04:50:55 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-03 04:50:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 04:50:55 --> Final output sent to browser
DEBUG - 2013-09-03 04:50:55 --> Total execution time: 0.3780
DEBUG - 2013-09-03 04:50:55 --> Config Class Initialized
DEBUG - 2013-09-03 04:50:55 --> Hooks Class Initialized
DEBUG - 2013-09-03 04:50:55 --> Utf8 Class Initialized
DEBUG - 2013-09-03 04:50:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 04:50:55 --> URI Class Initialized
DEBUG - 2013-09-03 04:50:55 --> Router Class Initialized
ERROR - 2013-09-03 04:50:55 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 05:07:42 --> Config Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Hooks Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Utf8 Class Initialized
DEBUG - 2013-09-03 05:07:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 05:07:42 --> URI Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Router Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Output Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Security Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Input Class Initialized
DEBUG - 2013-09-03 05:07:42 --> XSS Filtering completed
DEBUG - 2013-09-03 05:07:42 --> XSS Filtering completed
DEBUG - 2013-09-03 05:07:42 --> XSS Filtering completed
DEBUG - 2013-09-03 05:07:42 --> XSS Filtering completed
DEBUG - 2013-09-03 05:07:42 --> XSS Filtering completed
DEBUG - 2013-09-03 05:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 05:07:42 --> Language Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Loader Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Helper loaded: url_helper
DEBUG - 2013-09-03 05:07:42 --> Helper loaded: file_helper
DEBUG - 2013-09-03 05:07:42 --> Helper loaded: form_helper
DEBUG - 2013-09-03 05:07:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 05:07:42 --> Helper loaded: application_helper
DEBUG - 2013-09-03 05:07:42 --> Database Driver Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Session Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Helper loaded: string_helper
DEBUG - 2013-09-03 05:07:42 --> Session routines successfully run
DEBUG - 2013-09-03 05:07:42 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Controller Class Initialized
ERROR - 2013-09-03 05:07:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 05:07:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 05:07:42 --> Model Class Initialized
DEBUG - 2013-09-03 05:07:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 05:07:42 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 05:07:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 05:07:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 05:07:43 --> Model Class Initialized
DEBUG - 2013-09-03 05:07:43 --> Pagination Class Initialized
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 05:07:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 05:07:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 05:07:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 05:07:43 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 05:07:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 05:07:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 05:07:43 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 05:07:43 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 05:07:43 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 05:07:43 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 05:07:43 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 05:07:43 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 05:07:43 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 05:07:43 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 05:07:43 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 05:07:43 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
DEBUG - 2013-09-03 05:07:43 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-03 05:07:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 05:07:43 --> Final output sent to browser
DEBUG - 2013-09-03 05:07:43 --> Total execution time: 1.3761
DEBUG - 2013-09-03 05:07:43 --> Config Class Initialized
DEBUG - 2013-09-03 05:07:43 --> Hooks Class Initialized
DEBUG - 2013-09-03 05:07:43 --> Utf8 Class Initialized
DEBUG - 2013-09-03 05:07:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 05:07:43 --> URI Class Initialized
DEBUG - 2013-09-03 05:07:43 --> Router Class Initialized
ERROR - 2013-09-03 05:07:43 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:50:21 --> Config Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:50:21 --> URI Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Router Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Output Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Security Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Input Class Initialized
DEBUG - 2013-09-03 09:50:21 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:21 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:21 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:21 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:50:21 --> Language Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Loader Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:50:21 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:50:21 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:50:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:50:21 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:50:21 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Session Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:50:21 --> A session cookie was not found.
DEBUG - 2013-09-03 09:50:21 --> Session routines successfully run
DEBUG - 2013-09-03 09:50:21 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Controller Class Initialized
ERROR - 2013-09-03 09:50:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:21 --> Model Class Initialized
DEBUG - 2013-09-03 09:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:50:21 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:50:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:50:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:50:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:22 --> Config Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:50:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:50:22 --> URI Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Router Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Output Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Security Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Input Class Initialized
DEBUG - 2013-09-03 09:50:22 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:22 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:50:22 --> Language Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Loader Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:50:22 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:50:22 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:50:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:50:22 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:50:22 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Session Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:50:22 --> Session routines successfully run
DEBUG - 2013-09-03 09:50:22 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Controller Class Initialized
ERROR - 2013-09-03 09:50:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:22 --> Model Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:50:22 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:50:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:50:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:50:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:50:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:50:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:50:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-03 09:50:22 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-03 09:50:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:50:22 --> Final output sent to browser
DEBUG - 2013-09-03 09:50:22 --> Total execution time: 0.3680
DEBUG - 2013-09-03 09:50:22 --> Config Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:50:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:50:22 --> URI Class Initialized
DEBUG - 2013-09-03 09:50:22 --> Router Class Initialized
ERROR - 2013-09-03 09:50:22 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:50:33 --> Config Class Initialized
DEBUG - 2013-09-03 09:50:33 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:50:33 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:50:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:50:33 --> URI Class Initialized
DEBUG - 2013-09-03 09:50:33 --> Router Class Initialized
DEBUG - 2013-09-03 09:50:33 --> Output Class Initialized
DEBUG - 2013-09-03 09:50:33 --> Security Class Initialized
DEBUG - 2013-09-03 09:50:33 --> Input Class Initialized
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:50:34 --> Language Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Loader Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:50:34 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Session Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:50:34 --> Session routines successfully run
DEBUG - 2013-09-03 09:50:34 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Controller Class Initialized
ERROR - 2013-09-03 09:50:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:34 --> Model Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:50:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:50:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:50:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:34 --> Model Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Form Validation Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-03 09:50:34 --> Config Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:50:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:50:34 --> URI Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Router Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Output Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Security Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Input Class Initialized
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:50:34 --> Language Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Loader Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:50:34 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Session Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:50:34 --> Session routines successfully run
DEBUG - 2013-09-03 09:50:34 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Controller Class Initialized
ERROR - 2013-09-03 09:50:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:34 --> Model Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:50:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:50:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:50:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:34 --> Config Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:50:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:50:34 --> URI Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Router Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Output Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Security Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Input Class Initialized
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> XSS Filtering completed
DEBUG - 2013-09-03 09:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:50:34 --> Language Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Loader Class Initialized
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:50:34 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:50:35 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:50:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:50:35 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:50:35 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:50:35 --> Session Class Initialized
DEBUG - 2013-09-03 09:50:35 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:50:35 --> Session routines successfully run
DEBUG - 2013-09-03 09:50:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:50:35 --> Controller Class Initialized
ERROR - 2013-09-03 09:50:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:35 --> Model Class Initialized
DEBUG - 2013-09-03 09:50:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:50:35 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:50:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:50:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:50:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:50:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:50:35 --> Model Class Initialized
DEBUG - 2013-09-03 09:50:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:50:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:50:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:50:35 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 09:50:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 09:50:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 09:50:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-03 09:50:35 --> File loaded: application/views/home.php
DEBUG - 2013-09-03 09:50:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:50:35 --> Final output sent to browser
DEBUG - 2013-09-03 09:50:35 --> Total execution time: 0.5840
DEBUG - 2013-09-03 09:50:35 --> Config Class Initialized
DEBUG - 2013-09-03 09:50:35 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:50:35 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:50:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:50:35 --> URI Class Initialized
DEBUG - 2013-09-03 09:50:35 --> Router Class Initialized
ERROR - 2013-09-03 09:50:35 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:51:02 --> Config Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:51:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:51:02 --> URI Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Router Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Output Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Security Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Input Class Initialized
DEBUG - 2013-09-03 09:51:02 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:02 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:02 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:02 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:02 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:51:02 --> Language Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Loader Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:51:02 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:51:02 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:51:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:51:02 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:51:02 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Session Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:51:02 --> Session routines successfully run
DEBUG - 2013-09-03 09:51:02 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Controller Class Initialized
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:51:02 --> Model Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:51:02 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:51:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:51:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:51:02 --> Model Class Initialized
DEBUG - 2013-09-03 09:51:02 --> Pagination Class Initialized
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:51:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:51:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:51:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:51:02 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 09:51:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 09:51:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 09:51:02 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:02 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:02 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:02 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:02 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:02 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:02 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:02 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:02 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:02 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
DEBUG - 2013-09-03 09:51:02 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-03 09:51:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:51:02 --> Final output sent to browser
DEBUG - 2013-09-03 09:51:02 --> Total execution time: 0.7110
DEBUG - 2013-09-03 09:51:03 --> Config Class Initialized
DEBUG - 2013-09-03 09:51:03 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:51:03 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:51:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:51:03 --> URI Class Initialized
DEBUG - 2013-09-03 09:51:03 --> Router Class Initialized
ERROR - 2013-09-03 09:51:03 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:51:22 --> Config Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:51:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:51:22 --> URI Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Router Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Output Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Security Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Input Class Initialized
DEBUG - 2013-09-03 09:51:22 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:22 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:22 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:22 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:22 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:51:22 --> Language Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Loader Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:51:22 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:51:22 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:51:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:51:22 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:51:22 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Session Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:51:22 --> Session routines successfully run
DEBUG - 2013-09-03 09:51:22 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Controller Class Initialized
ERROR - 2013-09-03 09:51:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:51:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:51:22 --> Model Class Initialized
DEBUG - 2013-09-03 09:51:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:51:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:51:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:51:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:51:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:51:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:51:23 --> Model Class Initialized
DEBUG - 2013-09-03 09:51:23 --> Pagination Class Initialized
DEBUG - 2013-09-03 09:51:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:51:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:51:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:51:23 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 09:51:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 09:51:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 09:51:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-03 09:51:23 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-09-03 09:51:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:51:23 --> Final output sent to browser
DEBUG - 2013-09-03 09:51:23 --> Total execution time: 0.4580
DEBUG - 2013-09-03 09:51:23 --> Config Class Initialized
DEBUG - 2013-09-03 09:51:23 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:51:23 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:51:23 --> URI Class Initialized
DEBUG - 2013-09-03 09:51:23 --> Router Class Initialized
ERROR - 2013-09-03 09:51:23 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:51:26 --> Config Class Initialized
DEBUG - 2013-09-03 09:51:26 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:51:26 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:51:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:51:26 --> URI Class Initialized
DEBUG - 2013-09-03 09:51:26 --> Router Class Initialized
DEBUG - 2013-09-03 09:51:26 --> Output Class Initialized
DEBUG - 2013-09-03 09:51:26 --> Security Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Input Class Initialized
DEBUG - 2013-09-03 09:51:27 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:27 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:27 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:27 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:27 --> XSS Filtering completed
DEBUG - 2013-09-03 09:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:51:27 --> Language Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Loader Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:51:27 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:51:27 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:51:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:51:27 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:51:27 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Session Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:51:27 --> Session routines successfully run
DEBUG - 2013-09-03 09:51:27 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Controller Class Initialized
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:51:27 --> Model Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:51:27 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:51:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:51:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:51:27 --> Model Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Pagination Class Initialized
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:51:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:51:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:51:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:51:27 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 09:51:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 09:51:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 09:51:27 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:51:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:51:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
DEBUG - 2013-09-03 09:51:27 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-03 09:51:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:51:27 --> Final output sent to browser
DEBUG - 2013-09-03 09:51:27 --> Total execution time: 0.5060
DEBUG - 2013-09-03 09:51:27 --> Config Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:51:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:51:27 --> URI Class Initialized
DEBUG - 2013-09-03 09:51:27 --> Router Class Initialized
ERROR - 2013-09-03 09:51:27 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:53:23 --> Config Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:53:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:53:23 --> URI Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Router Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Output Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Security Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Input Class Initialized
DEBUG - 2013-09-03 09:53:23 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:23 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:23 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:23 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:23 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:53:23 --> Language Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Loader Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:53:23 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:53:23 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:53:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:53:23 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:53:23 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Session Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:53:23 --> Session garbage collection performed.
DEBUG - 2013-09-03 09:53:23 --> Session routines successfully run
DEBUG - 2013-09-03 09:53:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Controller Class Initialized
ERROR - 2013-09-03 09:53:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:53:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:53:23 --> Model Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:53:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:53:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:53:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:53:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:53:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:53:23 --> Model Class Initialized
DEBUG - 2013-09-03 09:53:23 --> Pagination Class Initialized
DEBUG - 2013-09-03 09:53:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:53:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:53:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:53:24 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 09:53:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 09:53:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 09:53:24 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 09:53:24 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-03 09:53:24 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-03 09:53:24 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-03 09:53:24 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-03 09:53:24 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-03 09:53:24 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-03 09:53:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:53:24 --> Final output sent to browser
DEBUG - 2013-09-03 09:53:24 --> Total execution time: 0.5820
DEBUG - 2013-09-03 09:53:24 --> Config Class Initialized
DEBUG - 2013-09-03 09:53:24 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:53:24 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:53:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:53:24 --> URI Class Initialized
DEBUG - 2013-09-03 09:53:24 --> Router Class Initialized
ERROR - 2013-09-03 09:53:24 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:53:26 --> Config Class Initialized
DEBUG - 2013-09-03 09:53:26 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:53:26 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:53:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:53:26 --> URI Class Initialized
DEBUG - 2013-09-03 09:53:26 --> Router Class Initialized
DEBUG - 2013-09-03 09:53:26 --> Output Class Initialized
DEBUG - 2013-09-03 09:53:26 --> Security Class Initialized
DEBUG - 2013-09-03 09:53:26 --> Input Class Initialized
DEBUG - 2013-09-03 09:53:26 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:26 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:26 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:26 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:26 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:53:27 --> Language Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Loader Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:53:27 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:53:27 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:53:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:53:27 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:53:27 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Session Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:53:27 --> Session garbage collection performed.
DEBUG - 2013-09-03 09:53:27 --> Session routines successfully run
DEBUG - 2013-09-03 09:53:27 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Controller Class Initialized
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:53:27 --> Model Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:53:27 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:53:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:53:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:53:27 --> Model Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Pagination Class Initialized
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> join() expects at least 1 parameter, 0 given C:\xampp\htdocs\school\application\models\absensi_model.php 45
DEBUG - 2013-09-03 09:53:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:53:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:53:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:53:27 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 09:53:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 09:53:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 09:53:27 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:53:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:53:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:53:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:53:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:53:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:53:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:53:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:53:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:53:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
DEBUG - 2013-09-03 09:53:27 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-03 09:53:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:53:27 --> Final output sent to browser
DEBUG - 2013-09-03 09:53:27 --> Total execution time: 0.6130
DEBUG - 2013-09-03 09:53:27 --> Config Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:53:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:53:27 --> URI Class Initialized
DEBUG - 2013-09-03 09:53:27 --> Router Class Initialized
ERROR - 2013-09-03 09:53:27 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:53:57 --> Config Class Initialized
DEBUG - 2013-09-03 09:53:57 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:53:57 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:53:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:53:57 --> URI Class Initialized
DEBUG - 2013-09-03 09:53:57 --> Router Class Initialized
DEBUG - 2013-09-03 09:53:57 --> Output Class Initialized
DEBUG - 2013-09-03 09:53:57 --> Security Class Initialized
DEBUG - 2013-09-03 09:53:57 --> Input Class Initialized
DEBUG - 2013-09-03 09:53:57 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:57 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:57 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:57 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:57 --> XSS Filtering completed
DEBUG - 2013-09-03 09:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:53:57 --> Language Class Initialized
DEBUG - 2013-09-03 09:53:57 --> Loader Class Initialized
DEBUG - 2013-09-03 09:53:57 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:53:58 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:53:58 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:53:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:53:58 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:53:58 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:53:58 --> Session Class Initialized
DEBUG - 2013-09-03 09:53:58 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:53:58 --> Session routines successfully run
DEBUG - 2013-09-03 09:53:58 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:53:58 --> Controller Class Initialized
ERROR - 2013-09-03 09:53:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:53:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:53:58 --> Model Class Initialized
DEBUG - 2013-09-03 09:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:53:58 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:53:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:53:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:53:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:53:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:53:58 --> Model Class Initialized
DEBUG - 2013-09-03 09:53:58 --> Pagination Class Initialized
DEBUG - 2013-09-03 09:53:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:53:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:53:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:53:58 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 09:53:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 09:53:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 09:53:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-03 09:53:58 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-09-03 09:53:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:53:58 --> Final output sent to browser
DEBUG - 2013-09-03 09:53:58 --> Total execution time: 0.5530
DEBUG - 2013-09-03 09:53:58 --> Config Class Initialized
DEBUG - 2013-09-03 09:53:58 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:53:58 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:53:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:53:58 --> URI Class Initialized
DEBUG - 2013-09-03 09:53:58 --> Router Class Initialized
ERROR - 2013-09-03 09:53:58 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:54:00 --> Config Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:54:00 --> URI Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Router Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Output Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Security Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Input Class Initialized
DEBUG - 2013-09-03 09:54:00 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:00 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:00 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:00 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:00 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:54:00 --> Language Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Loader Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:54:00 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:54:00 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:54:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:54:00 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:54:00 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Session Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:54:00 --> Session routines successfully run
DEBUG - 2013-09-03 09:54:00 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Controller Class Initialized
ERROR - 2013-09-03 09:54:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:54:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:54:00 --> Model Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:54:00 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:54:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:54:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:54:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:54:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:54:00 --> Model Class Initialized
DEBUG - 2013-09-03 09:54:00 --> Pagination Class Initialized
ERROR - 2013-09-03 09:54:00 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:54:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:54:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:54:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:54:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:54:01 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 09:54:01 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 09:54:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 09:54:01 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 09:54:01 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:01 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:01 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:01 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:01 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:01 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:01 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:01 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
DEBUG - 2013-09-03 09:54:01 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-03 09:54:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:54:01 --> Final output sent to browser
DEBUG - 2013-09-03 09:54:01 --> Total execution time: 0.6180
DEBUG - 2013-09-03 09:54:01 --> Config Class Initialized
DEBUG - 2013-09-03 09:54:01 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:54:01 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:54:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:54:01 --> URI Class Initialized
DEBUG - 2013-09-03 09:54:01 --> Router Class Initialized
ERROR - 2013-09-03 09:54:01 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 09:54:36 --> Config Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:54:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:54:36 --> URI Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Router Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Output Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Security Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Input Class Initialized
DEBUG - 2013-09-03 09:54:36 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:36 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:36 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:36 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:36 --> XSS Filtering completed
DEBUG - 2013-09-03 09:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 09:54:36 --> Language Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Loader Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Helper loaded: url_helper
DEBUG - 2013-09-03 09:54:36 --> Helper loaded: file_helper
DEBUG - 2013-09-03 09:54:36 --> Helper loaded: form_helper
DEBUG - 2013-09-03 09:54:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 09:54:36 --> Helper loaded: application_helper
DEBUG - 2013-09-03 09:54:36 --> Database Driver Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Session Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Helper loaded: string_helper
DEBUG - 2013-09-03 09:54:36 --> Session routines successfully run
DEBUG - 2013-09-03 09:54:36 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Controller Class Initialized
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:54:36 --> Model Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 09:54:36 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 09:54:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 09:54:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:54:36 --> Model Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Pagination Class Initialized
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 09:54:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 09:54:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 09:54:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 09:54:36 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 09:54:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 09:54:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 09:54:36 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 14
ERROR - 2013-09-03 09:54:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 16
ERROR - 2013-09-03 09:54:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 16
DEBUG - 2013-09-03 09:54:36 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-03 09:54:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 09:54:36 --> Final output sent to browser
DEBUG - 2013-09-03 09:54:36 --> Total execution time: 0.6250
DEBUG - 2013-09-03 09:54:36 --> Config Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Hooks Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Utf8 Class Initialized
DEBUG - 2013-09-03 09:54:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 09:54:36 --> URI Class Initialized
DEBUG - 2013-09-03 09:54:36 --> Router Class Initialized
ERROR - 2013-09-03 09:54:36 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 10:07:24 --> Config Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Hooks Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Utf8 Class Initialized
DEBUG - 2013-09-03 10:07:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 10:07:24 --> URI Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Router Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Output Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Security Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Input Class Initialized
DEBUG - 2013-09-03 10:07:24 --> XSS Filtering completed
DEBUG - 2013-09-03 10:07:24 --> XSS Filtering completed
DEBUG - 2013-09-03 10:07:24 --> XSS Filtering completed
DEBUG - 2013-09-03 10:07:24 --> XSS Filtering completed
DEBUG - 2013-09-03 10:07:24 --> XSS Filtering completed
DEBUG - 2013-09-03 10:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 10:07:24 --> Language Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Loader Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Helper loaded: url_helper
DEBUG - 2013-09-03 10:07:24 --> Helper loaded: file_helper
DEBUG - 2013-09-03 10:07:24 --> Helper loaded: form_helper
DEBUG - 2013-09-03 10:07:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 10:07:24 --> Helper loaded: application_helper
DEBUG - 2013-09-03 10:07:24 --> Database Driver Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Session Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Helper loaded: string_helper
DEBUG - 2013-09-03 10:07:24 --> Session routines successfully run
DEBUG - 2013-09-03 10:07:24 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Controller Class Initialized
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 10:07:24 --> Model Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 10:07:24 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 10:07:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 10:07:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 10:07:24 --> Model Class Initialized
DEBUG - 2013-09-03 10:07:24 --> Pagination Class Initialized
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 10:07:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 10:07:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 10:07:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 10:07:24 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 10:07:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 10:07:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 10:07:24 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:07:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:07:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:07:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:07:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:07:24 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:07:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:07:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:07:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
ERROR - 2013-09-03 10:07:25 --> Severity: Notice  --> Undefined variable: bulan C:\xampp\htdocs\school\application\views\absensis\index.php 35
DEBUG - 2013-09-03 10:07:25 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-03 10:07:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 10:07:25 --> Final output sent to browser
DEBUG - 2013-09-03 10:07:25 --> Total execution time: 0.9631
DEBUG - 2013-09-03 10:07:25 --> Config Class Initialized
DEBUG - 2013-09-03 10:07:25 --> Hooks Class Initialized
DEBUG - 2013-09-03 10:07:25 --> Utf8 Class Initialized
DEBUG - 2013-09-03 10:07:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 10:07:25 --> URI Class Initialized
DEBUG - 2013-09-03 10:07:25 --> Router Class Initialized
ERROR - 2013-09-03 10:07:25 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 10:08:17 --> Config Class Initialized
DEBUG - 2013-09-03 10:08:17 --> Hooks Class Initialized
DEBUG - 2013-09-03 10:08:17 --> Utf8 Class Initialized
DEBUG - 2013-09-03 10:08:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 10:08:17 --> URI Class Initialized
DEBUG - 2013-09-03 10:08:17 --> Router Class Initialized
DEBUG - 2013-09-03 10:08:17 --> Output Class Initialized
DEBUG - 2013-09-03 10:08:17 --> Security Class Initialized
DEBUG - 2013-09-03 10:08:17 --> Input Class Initialized
DEBUG - 2013-09-03 10:08:17 --> XSS Filtering completed
DEBUG - 2013-09-03 10:08:17 --> XSS Filtering completed
DEBUG - 2013-09-03 10:08:17 --> XSS Filtering completed
DEBUG - 2013-09-03 10:08:17 --> XSS Filtering completed
DEBUG - 2013-09-03 10:08:17 --> XSS Filtering completed
DEBUG - 2013-09-03 10:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 10:08:17 --> Language Class Initialized
DEBUG - 2013-09-03 10:08:17 --> Loader Class Initialized
DEBUG - 2013-09-03 10:08:17 --> Helper loaded: url_helper
DEBUG - 2013-09-03 10:08:17 --> Helper loaded: file_helper
DEBUG - 2013-09-03 10:08:17 --> Helper loaded: form_helper
DEBUG - 2013-09-03 10:08:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 10:08:17 --> Helper loaded: application_helper
DEBUG - 2013-09-03 10:08:17 --> Database Driver Class Initialized
DEBUG - 2013-09-03 10:08:18 --> Session Class Initialized
DEBUG - 2013-09-03 10:08:18 --> Helper loaded: string_helper
DEBUG - 2013-09-03 10:08:18 --> Session routines successfully run
DEBUG - 2013-09-03 10:08:18 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 10:08:18 --> Controller Class Initialized
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 10:08:18 --> Model Class Initialized
DEBUG - 2013-09-03 10:08:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 10:08:18 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 10:08:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 10:08:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 10:08:18 --> Model Class Initialized
DEBUG - 2013-09-03 10:08:18 --> Pagination Class Initialized
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 10:08:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 10:08:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 10:08:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 10:08:18 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 10:08:18 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 10:08:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 10:08:18 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:08:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:08:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:08:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:08:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:08:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:08:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:08:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 18
ERROR - 2013-09-03 10:08:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 20
ERROR - 2013-09-03 10:08:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 20
DEBUG - 2013-09-03 10:08:18 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-03 10:08:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 10:08:18 --> Final output sent to browser
DEBUG - 2013-09-03 10:08:18 --> Total execution time: 0.7280
DEBUG - 2013-09-03 10:08:18 --> Config Class Initialized
DEBUG - 2013-09-03 10:08:18 --> Hooks Class Initialized
DEBUG - 2013-09-03 10:08:18 --> Utf8 Class Initialized
DEBUG - 2013-09-03 10:08:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 10:08:18 --> URI Class Initialized
DEBUG - 2013-09-03 10:08:18 --> Router Class Initialized
ERROR - 2013-09-03 10:08:18 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 11:35:05 --> Config Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:35:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:35:05 --> URI Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Router Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Output Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Security Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Input Class Initialized
DEBUG - 2013-09-03 11:35:05 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:05 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:05 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:05 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:05 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 11:35:05 --> Language Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Loader Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Helper loaded: url_helper
DEBUG - 2013-09-03 11:35:05 --> Helper loaded: file_helper
DEBUG - 2013-09-03 11:35:05 --> Helper loaded: form_helper
DEBUG - 2013-09-03 11:35:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 11:35:05 --> Helper loaded: application_helper
DEBUG - 2013-09-03 11:35:05 --> Database Driver Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Session Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Helper loaded: string_helper
DEBUG - 2013-09-03 11:35:05 --> Session garbage collection performed.
DEBUG - 2013-09-03 11:35:05 --> Session routines successfully run
DEBUG - 2013-09-03 11:35:05 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Controller Class Initialized
ERROR - 2013-09-03 11:35:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:35:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:35:05 --> Model Class Initialized
DEBUG - 2013-09-03 11:35:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 11:35:05 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 11:35:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 11:35:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 11:35:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:35:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:35:05 --> Model Class Initialized
ERROR - 2013-09-03 11:35:05 --> Severity: Notice  --> Undefined property: absensis::$mata_pelajaran_model C:\xampp\htdocs\school\application\controllers\guru\absensis.php 137
DEBUG - 2013-09-03 11:35:22 --> Config Class Initialized
DEBUG - 2013-09-03 11:35:22 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:35:22 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:35:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:35:22 --> URI Class Initialized
DEBUG - 2013-09-03 11:35:22 --> Router Class Initialized
DEBUG - 2013-09-03 11:35:22 --> Output Class Initialized
DEBUG - 2013-09-03 11:35:22 --> Security Class Initialized
DEBUG - 2013-09-03 11:35:22 --> Input Class Initialized
DEBUG - 2013-09-03 11:35:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 11:35:22 --> Language Class Initialized
DEBUG - 2013-09-03 11:35:22 --> Loader Class Initialized
DEBUG - 2013-09-03 11:35:22 --> Helper loaded: url_helper
DEBUG - 2013-09-03 11:35:22 --> Helper loaded: file_helper
DEBUG - 2013-09-03 11:35:22 --> Helper loaded: form_helper
DEBUG - 2013-09-03 11:35:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 11:35:23 --> Helper loaded: application_helper
DEBUG - 2013-09-03 11:35:23 --> Database Driver Class Initialized
DEBUG - 2013-09-03 11:35:23 --> Session Class Initialized
DEBUG - 2013-09-03 11:35:23 --> Helper loaded: string_helper
DEBUG - 2013-09-03 11:35:23 --> Session routines successfully run
DEBUG - 2013-09-03 11:35:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 11:35:23 --> Controller Class Initialized
ERROR - 2013-09-03 11:35:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:35:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:35:23 --> Model Class Initialized
DEBUG - 2013-09-03 11:35:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 11:35:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 11:35:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 11:35:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 11:35:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:35:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:35:23 --> Model Class Initialized
ERROR - 2013-09-03 11:35:23 --> Severity: Notice  --> Undefined property: absensis::$mata_pelajaran_model C:\xampp\htdocs\school\application\controllers\guru\absensis.php 137
DEBUG - 2013-09-03 11:35:43 --> Config Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:35:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:35:43 --> URI Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Router Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Output Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Security Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Input Class Initialized
DEBUG - 2013-09-03 11:35:43 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:43 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:43 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:43 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:43 --> XSS Filtering completed
DEBUG - 2013-09-03 11:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 11:35:43 --> Language Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Loader Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Helper loaded: url_helper
DEBUG - 2013-09-03 11:35:43 --> Helper loaded: file_helper
DEBUG - 2013-09-03 11:35:43 --> Helper loaded: form_helper
DEBUG - 2013-09-03 11:35:43 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 11:35:43 --> Helper loaded: application_helper
DEBUG - 2013-09-03 11:35:43 --> Database Driver Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Session Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Helper loaded: string_helper
DEBUG - 2013-09-03 11:35:43 --> Session routines successfully run
DEBUG - 2013-09-03 11:35:43 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Controller Class Initialized
ERROR - 2013-09-03 11:35:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:35:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:35:43 --> Model Class Initialized
DEBUG - 2013-09-03 11:35:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 11:35:43 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 11:35:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 11:35:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 11:35:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:35:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:35:43 --> Model Class Initialized
DEBUG - 2013-09-03 11:35:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 11:35:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 11:35:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 11:35:44 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 11:35:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 11:35:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 11:35:44 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:35:44 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:35:44 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:35:44 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:35:44 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: mata_pelajaran_id C:\xampp\htdocs\school\application\views\absensis\new.php 37
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: tahun_ajaran_id C:\xampp\htdocs\school\application\views\absensis\new.php 72
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: absensi C:\xampp\htdocs\school\application\views\absensis\new.php 84
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: absensi C:\xampp\htdocs\school\application\views\absensis\new.php 84
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: absensi C:\xampp\htdocs\school\application\views\absensis\new.php 84
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: absensi C:\xampp\htdocs\school\application\views\absensis\new.php 84
ERROR - 2013-09-03 11:35:44 --> Severity: Notice  --> Undefined variable: keterangan C:\xampp\htdocs\school\application\views\absensis\new.php 92
DEBUG - 2013-09-03 11:35:44 --> File loaded: application/views/absensis/new.php
DEBUG - 2013-09-03 11:35:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 11:35:44 --> Final output sent to browser
DEBUG - 2013-09-03 11:35:44 --> Total execution time: 1.0431
DEBUG - 2013-09-03 11:35:44 --> Config Class Initialized
DEBUG - 2013-09-03 11:35:44 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:35:44 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:35:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:35:44 --> URI Class Initialized
DEBUG - 2013-09-03 11:35:44 --> Router Class Initialized
ERROR - 2013-09-03 11:35:44 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 11:36:39 --> Config Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:36:39 --> URI Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Router Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Output Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Security Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Input Class Initialized
DEBUG - 2013-09-03 11:36:39 --> XSS Filtering completed
DEBUG - 2013-09-03 11:36:39 --> XSS Filtering completed
DEBUG - 2013-09-03 11:36:39 --> XSS Filtering completed
DEBUG - 2013-09-03 11:36:39 --> XSS Filtering completed
DEBUG - 2013-09-03 11:36:39 --> XSS Filtering completed
DEBUG - 2013-09-03 11:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 11:36:39 --> Language Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Loader Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Helper loaded: url_helper
DEBUG - 2013-09-03 11:36:39 --> Helper loaded: file_helper
DEBUG - 2013-09-03 11:36:39 --> Helper loaded: form_helper
DEBUG - 2013-09-03 11:36:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 11:36:39 --> Helper loaded: application_helper
DEBUG - 2013-09-03 11:36:39 --> Database Driver Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Session Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Helper loaded: string_helper
DEBUG - 2013-09-03 11:36:39 --> Session routines successfully run
DEBUG - 2013-09-03 11:36:39 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Controller Class Initialized
ERROR - 2013-09-03 11:36:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:36:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:36:39 --> Model Class Initialized
DEBUG - 2013-09-03 11:36:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 11:36:39 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 11:36:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 11:36:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 11:36:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:36:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:36:39 --> Model Class Initialized
DEBUG - 2013-09-03 11:36:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 11:36:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 11:36:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 11:36:40 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 11:36:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 11:36:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 11:36:40 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: siswa_id C:\xampp\htdocs\school\application\views\absensis\new.php 11
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:36:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:36:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:36:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: kelas_bagian_id C:\xampp\htdocs\school\application\views\absensis\new.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:36:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: mata_pelajaran_id C:\xampp\htdocs\school\application\views\absensis\new.php 37
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: tahun_ajaran_id C:\xampp\htdocs\school\application\views\absensis\new.php 72
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: absensi C:\xampp\htdocs\school\application\views\absensis\new.php 84
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: absensi C:\xampp\htdocs\school\application\views\absensis\new.php 84
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: absensi C:\xampp\htdocs\school\application\views\absensis\new.php 84
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: absensi C:\xampp\htdocs\school\application\views\absensis\new.php 84
ERROR - 2013-09-03 11:36:40 --> Severity: Notice  --> Undefined variable: keterangan C:\xampp\htdocs\school\application\views\absensis\new.php 92
DEBUG - 2013-09-03 11:36:40 --> File loaded: application/views/absensis/new.php
DEBUG - 2013-09-03 11:36:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 11:36:40 --> Final output sent to browser
DEBUG - 2013-09-03 11:36:40 --> Total execution time: 1.0651
DEBUG - 2013-09-03 11:36:40 --> Config Class Initialized
DEBUG - 2013-09-03 11:36:40 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:36:40 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:36:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:36:40 --> URI Class Initialized
DEBUG - 2013-09-03 11:36:40 --> Router Class Initialized
ERROR - 2013-09-03 11:36:40 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 11:38:46 --> Config Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:38:46 --> URI Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Router Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Output Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Security Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Input Class Initialized
DEBUG - 2013-09-03 11:38:46 --> XSS Filtering completed
DEBUG - 2013-09-03 11:38:46 --> XSS Filtering completed
DEBUG - 2013-09-03 11:38:46 --> XSS Filtering completed
DEBUG - 2013-09-03 11:38:46 --> XSS Filtering completed
DEBUG - 2013-09-03 11:38:46 --> XSS Filtering completed
DEBUG - 2013-09-03 11:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 11:38:46 --> Language Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Loader Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Helper loaded: url_helper
DEBUG - 2013-09-03 11:38:46 --> Helper loaded: file_helper
DEBUG - 2013-09-03 11:38:46 --> Helper loaded: form_helper
DEBUG - 2013-09-03 11:38:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 11:38:46 --> Helper loaded: application_helper
DEBUG - 2013-09-03 11:38:46 --> Database Driver Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Session Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Helper loaded: string_helper
DEBUG - 2013-09-03 11:38:46 --> Session routines successfully run
DEBUG - 2013-09-03 11:38:46 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Controller Class Initialized
ERROR - 2013-09-03 11:38:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:38:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:38:46 --> Model Class Initialized
DEBUG - 2013-09-03 11:38:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 11:38:46 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 11:38:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 11:38:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 11:38:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:38:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:38:46 --> Model Class Initialized
DEBUG - 2013-09-03 11:38:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 11:38:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 11:38:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 11:38:46 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 11:38:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 11:38:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 11:38:46 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 11:38:46 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:38:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:38:46 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:38:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:38:46 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:38:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:38:46 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:38:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:38:46 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:38:47 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:38:47 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:38:47 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:38:47 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:38:47 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:38:47 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:38:47 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
DEBUG - 2013-09-03 11:38:47 --> File loaded: application/views/absensis/new.php
DEBUG - 2013-09-03 11:38:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 11:38:47 --> Final output sent to browser
DEBUG - 2013-09-03 11:38:47 --> Total execution time: 0.9501
DEBUG - 2013-09-03 11:38:47 --> Config Class Initialized
DEBUG - 2013-09-03 11:38:47 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:38:47 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:38:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:38:47 --> URI Class Initialized
DEBUG - 2013-09-03 11:38:47 --> Router Class Initialized
ERROR - 2013-09-03 11:38:47 --> 404 Page Not Found --> css
DEBUG - 2013-09-03 11:39:22 --> Config Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:39:22 --> URI Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Router Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Output Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Security Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Input Class Initialized
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 11:39:22 --> Language Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Loader Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Helper loaded: url_helper
DEBUG - 2013-09-03 11:39:22 --> Helper loaded: file_helper
DEBUG - 2013-09-03 11:39:22 --> Helper loaded: form_helper
DEBUG - 2013-09-03 11:39:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 11:39:22 --> Helper loaded: application_helper
DEBUG - 2013-09-03 11:39:22 --> Database Driver Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Session Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Helper loaded: string_helper
DEBUG - 2013-09-03 11:39:22 --> Session routines successfully run
DEBUG - 2013-09-03 11:39:22 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Controller Class Initialized
ERROR - 2013-09-03 11:39:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:39:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:39:22 --> Model Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 11:39:22 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 11:39:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 11:39:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 11:39:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:39:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:39:22 --> Model Class Initialized
DEBUG - 2013-09-03 11:39:22 --> Form Validation Class Initialized
DEBUG - 2013-09-03 11:39:22 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-03 11:39:23 --> Config Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:39:23 --> URI Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Router Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Output Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Security Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Input Class Initialized
DEBUG - 2013-09-03 11:39:23 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:23 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:23 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:23 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:23 --> XSS Filtering completed
DEBUG - 2013-09-03 11:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 11:39:23 --> Language Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Loader Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Helper loaded: url_helper
DEBUG - 2013-09-03 11:39:23 --> Helper loaded: file_helper
DEBUG - 2013-09-03 11:39:23 --> Helper loaded: form_helper
DEBUG - 2013-09-03 11:39:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 11:39:23 --> Helper loaded: application_helper
DEBUG - 2013-09-03 11:39:23 --> Database Driver Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Session Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Helper loaded: string_helper
DEBUG - 2013-09-03 11:39:23 --> Session routines successfully run
DEBUG - 2013-09-03 11:39:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Controller Class Initialized
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:39:23 --> Model Class Initialized
DEBUG - 2013-09-03 11:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-03 11:39:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-03 11:39:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-03 11:39:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-03 11:39:23 --> Model Class Initialized
DEBUG - 2013-09-03 11:39:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-03 11:39:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-03 11:39:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-03 11:39:23 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-03 11:39:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-03 11:39:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-03 11:39:23 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:39:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:39:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:39:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:39:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:39:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:39:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:39:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-03 11:39:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-03 11:39:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
DEBUG - 2013-09-03 11:39:23 --> File loaded: application/views/absensis/new.php
DEBUG - 2013-09-03 11:39:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-03 11:39:24 --> Final output sent to browser
DEBUG - 2013-09-03 11:39:24 --> Total execution time: 0.9631
DEBUG - 2013-09-03 11:39:24 --> Config Class Initialized
DEBUG - 2013-09-03 11:39:24 --> Hooks Class Initialized
DEBUG - 2013-09-03 11:39:24 --> Utf8 Class Initialized
DEBUG - 2013-09-03 11:39:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 11:39:24 --> URI Class Initialized
DEBUG - 2013-09-03 11:39:24 --> Router Class Initialized
ERROR - 2013-09-03 11:39:24 --> 404 Page Not Found --> css
