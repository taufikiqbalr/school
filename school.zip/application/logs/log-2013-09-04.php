<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-04 05:12:41 --> Config Class Initialized
DEBUG - 2013-09-04 05:12:41 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:12:41 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:12:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:12:41 --> URI Class Initialized
DEBUG - 2013-09-04 05:12:41 --> Router Class Initialized
DEBUG - 2013-09-04 05:12:41 --> Output Class Initialized
DEBUG - 2013-09-04 05:12:41 --> Security Class Initialized
DEBUG - 2013-09-04 05:12:41 --> Input Class Initialized
DEBUG - 2013-09-04 05:12:41 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:41 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:41 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:12:41 --> Language Class Initialized
DEBUG - 2013-09-04 05:12:41 --> Loader Class Initialized
DEBUG - 2013-09-04 05:12:42 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:12:42 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:12:42 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:12:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:12:42 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:12:42 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:12:42 --> Session Class Initialized
DEBUG - 2013-09-04 05:12:42 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:12:42 --> A session cookie was not found.
DEBUG - 2013-09-04 05:12:42 --> Session routines successfully run
DEBUG - 2013-09-04 05:12:42 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:12:42 --> Controller Class Initialized
ERROR - 2013-09-04 05:12:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:43 --> Model Class Initialized
DEBUG - 2013-09-04 05:12:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:12:43 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:12:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:12:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:12:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:44 --> Config Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:12:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:12:44 --> URI Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Router Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Output Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Security Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Input Class Initialized
DEBUG - 2013-09-04 05:12:44 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:44 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:12:44 --> Language Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Loader Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:12:44 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:12:44 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:12:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:12:44 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:12:44 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Session Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:12:44 --> Session routines successfully run
DEBUG - 2013-09-04 05:12:44 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Controller Class Initialized
ERROR - 2013-09-04 05:12:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:44 --> Model Class Initialized
DEBUG - 2013-09-04 05:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:12:44 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:12:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:12:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:12:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:12:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:12:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:12:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 05:12:44 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-04 05:12:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:12:44 --> Final output sent to browser
DEBUG - 2013-09-04 05:12:44 --> Total execution time: 0.4080
DEBUG - 2013-09-04 05:12:45 --> Config Class Initialized
DEBUG - 2013-09-04 05:12:45 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:12:45 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:12:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:12:45 --> URI Class Initialized
DEBUG - 2013-09-04 05:12:45 --> Router Class Initialized
ERROR - 2013-09-04 05:12:45 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:12:52 --> Config Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:12:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:12:52 --> URI Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Router Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Output Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Security Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Input Class Initialized
DEBUG - 2013-09-04 05:12:52 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:52 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:52 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:52 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:52 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:52 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:12:52 --> Language Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Loader Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:12:52 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:12:52 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:12:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:12:52 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:12:52 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Session Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:12:52 --> Session routines successfully run
DEBUG - 2013-09-04 05:12:52 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Controller Class Initialized
ERROR - 2013-09-04 05:12:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:52 --> Model Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:12:52 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:12:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:12:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:12:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:52 --> Model Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Form Validation Class Initialized
DEBUG - 2013-09-04 05:12:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-04 05:12:53 --> Config Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:12:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:12:53 --> URI Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Router Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Output Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Security Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Input Class Initialized
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:12:53 --> Language Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Loader Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:12:53 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Session Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:12:53 --> Session routines successfully run
DEBUG - 2013-09-04 05:12:53 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Controller Class Initialized
ERROR - 2013-09-04 05:12:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:53 --> Model Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:12:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:12:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:12:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:53 --> Config Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:12:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:12:53 --> URI Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Router Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Output Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Security Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Input Class Initialized
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:12:53 --> Language Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Loader Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:12:53 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Session Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:12:53 --> Session routines successfully run
DEBUG - 2013-09-04 05:12:53 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Controller Class Initialized
ERROR - 2013-09-04 05:12:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:53 --> Model Class Initialized
DEBUG - 2013-09-04 05:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:12:53 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:12:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:12:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:12:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:12:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:12:53 --> Model Class Initialized
DEBUG - 2013-09-04 05:12:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:12:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:12:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:12:53 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:12:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:12:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:12:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 05:12:54 --> File loaded: application/views/home.php
DEBUG - 2013-09-04 05:12:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:12:54 --> Final output sent to browser
DEBUG - 2013-09-04 05:12:54 --> Total execution time: 0.6300
DEBUG - 2013-09-04 05:12:54 --> Config Class Initialized
DEBUG - 2013-09-04 05:12:54 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:12:54 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:12:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:12:54 --> URI Class Initialized
DEBUG - 2013-09-04 05:12:54 --> Router Class Initialized
ERROR - 2013-09-04 05:12:54 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:13:05 --> Config Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:13:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:13:05 --> URI Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Router Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Output Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Security Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Input Class Initialized
DEBUG - 2013-09-04 05:13:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:13:05 --> Language Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Loader Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:13:05 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:13:05 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:13:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:13:05 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:13:05 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Session Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:13:05 --> Session routines successfully run
DEBUG - 2013-09-04 05:13:05 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Controller Class Initialized
ERROR - 2013-09-04 05:13:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:05 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:13:05 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:13:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:13:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:13:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:05 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:06 --> Pagination Class Initialized
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:13:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:13:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:13:06 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:13:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:13:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:13:06 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:06 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:06 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:06 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:06 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:06 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:06 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:06 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:06 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:06 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
DEBUG - 2013-09-04 05:13:06 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 05:13:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:13:06 --> Final output sent to browser
DEBUG - 2013-09-04 05:13:06 --> Total execution time: 0.8320
DEBUG - 2013-09-04 05:13:06 --> Config Class Initialized
DEBUG - 2013-09-04 05:13:06 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:13:06 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:13:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:13:06 --> URI Class Initialized
DEBUG - 2013-09-04 05:13:06 --> Router Class Initialized
ERROR - 2013-09-04 05:13:06 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:13:23 --> Config Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:13:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:13:23 --> URI Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Router Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Output Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Security Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Input Class Initialized
DEBUG - 2013-09-04 05:13:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:13:23 --> Language Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Loader Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:13:23 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:13:23 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:13:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:13:23 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:13:23 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Session Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:13:23 --> Session routines successfully run
DEBUG - 2013-09-04 05:13:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Controller Class Initialized
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:23 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:13:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:13:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:13:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:23 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:13:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:13:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:13:23 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:13:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:13:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:13:23 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
DEBUG - 2013-09-04 05:13:23 --> File loaded: application/views/absensis/new.php
DEBUG - 2013-09-04 05:13:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:13:23 --> Final output sent to browser
DEBUG - 2013-09-04 05:13:23 --> Total execution time: 0.4570
DEBUG - 2013-09-04 05:13:23 --> Config Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:13:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:13:23 --> URI Class Initialized
DEBUG - 2013-09-04 05:13:23 --> Router Class Initialized
ERROR - 2013-09-04 05:13:23 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:13:26 --> Config Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:13:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:13:26 --> URI Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Router Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Output Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Security Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Input Class Initialized
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:13:26 --> Language Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Loader Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:13:26 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Session Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:13:26 --> Session garbage collection performed.
DEBUG - 2013-09-04 05:13:26 --> Session routines successfully run
DEBUG - 2013-09-04 05:13:26 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Controller Class Initialized
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:26 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:13:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:13:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:26 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Form Validation Class Initialized
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-04 05:13:26 --> Config Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:13:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:13:26 --> URI Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Router Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Output Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Security Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Input Class Initialized
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:13:26 --> Language Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Loader Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:13:26 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Session Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:13:26 --> Session garbage collection performed.
DEBUG - 2013-09-04 05:13:26 --> Session routines successfully run
DEBUG - 2013-09-04 05:13:26 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Controller Class Initialized
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:26 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:13:26 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:13:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:13:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:26 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:13:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:13:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:13:26 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:13:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:13:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:13:26 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:26 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:13:27 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:13:27 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
DEBUG - 2013-09-04 05:13:27 --> File loaded: application/views/absensis/new.php
DEBUG - 2013-09-04 05:13:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:13:27 --> Final output sent to browser
DEBUG - 2013-09-04 05:13:27 --> Total execution time: 0.4740
DEBUG - 2013-09-04 05:13:27 --> Config Class Initialized
DEBUG - 2013-09-04 05:13:27 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:13:27 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:13:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:13:27 --> URI Class Initialized
DEBUG - 2013-09-04 05:13:27 --> Router Class Initialized
ERROR - 2013-09-04 05:13:27 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:13:56 --> Config Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:13:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:13:56 --> URI Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Router Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Output Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Security Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Input Class Initialized
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:13:56 --> Language Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Loader Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:13:56 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:13:56 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:13:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:13:56 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:13:56 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Session Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:13:56 --> Session routines successfully run
DEBUG - 2013-09-04 05:13:56 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Controller Class Initialized
ERROR - 2013-09-04 05:13:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:56 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:13:56 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:13:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:13:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:13:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:13:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:13:56 --> Model Class Initialized
DEBUG - 2013-09-04 05:13:56 --> Form Validation Class Initialized
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:13:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-04 05:13:56 --> DB Transaction Failure
ERROR - 2013-09-04 05:13:56 --> Query error: Field 'id' doesn't have a default value
DEBUG - 2013-09-04 05:13:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-04 05:14:29 --> Config Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:14:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:14:29 --> URI Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Router Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Output Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Security Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Input Class Initialized
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:14:29 --> Language Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Loader Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:14:29 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Session Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:14:29 --> Session garbage collection performed.
DEBUG - 2013-09-04 05:14:29 --> Session routines successfully run
DEBUG - 2013-09-04 05:14:29 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Controller Class Initialized
ERROR - 2013-09-04 05:14:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:14:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:14:29 --> Model Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:14:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:14:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:14:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:14:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:14:29 --> Model Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Form Validation Class Initialized
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-04 05:14:29 --> Config Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:14:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:14:29 --> URI Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Router Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Output Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Security Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Input Class Initialized
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> XSS Filtering completed
DEBUG - 2013-09-04 05:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:14:29 --> Language Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Loader Class Initialized
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:14:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:14:30 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:14:30 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:14:30 --> Session Class Initialized
DEBUG - 2013-09-04 05:14:30 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:14:30 --> Session routines successfully run
DEBUG - 2013-09-04 05:14:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:14:30 --> Controller Class Initialized
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:14:30 --> Model Class Initialized
DEBUG - 2013-09-04 05:14:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:14:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:14:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:14:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:14:30 --> Model Class Initialized
DEBUG - 2013-09-04 05:14:30 --> Pagination Class Initialized
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:14:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:14:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:14:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:14:30 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:14:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:14:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:14:30 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:14:30 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:14:30 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:14:30 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:14:30 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:14:30 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:14:30 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:14:30 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:14:30 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:14:30 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
DEBUG - 2013-09-04 05:14:30 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 05:14:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:14:30 --> Final output sent to browser
DEBUG - 2013-09-04 05:14:30 --> Total execution time: 0.5770
DEBUG - 2013-09-04 05:14:30 --> Config Class Initialized
DEBUG - 2013-09-04 05:14:30 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:14:30 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:14:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:14:30 --> URI Class Initialized
DEBUG - 2013-09-04 05:14:30 --> Router Class Initialized
ERROR - 2013-09-04 05:14:30 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:16:05 --> Config Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:16:05 --> URI Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Router Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Output Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Security Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Input Class Initialized
DEBUG - 2013-09-04 05:16:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:05 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:16:05 --> Language Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Loader Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:16:05 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:16:05 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:16:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:16:05 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:16:05 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Session Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:16:05 --> Session routines successfully run
DEBUG - 2013-09-04 05:16:05 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Controller Class Initialized
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:16:05 --> Model Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:16:05 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:16:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:16:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:16:05 --> Model Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Pagination Class Initialized
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:16:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:16:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:16:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:16:05 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:16:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:16:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:16:05 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:05 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\absensis\index.php 106
ERROR - 2013-09-04 05:16:05 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\absensis\index.php 129
DEBUG - 2013-09-04 05:16:05 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 05:16:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:16:05 --> Final output sent to browser
DEBUG - 2013-09-04 05:16:05 --> Total execution time: 0.6380
DEBUG - 2013-09-04 05:16:05 --> Config Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:16:05 --> URI Class Initialized
DEBUG - 2013-09-04 05:16:05 --> Router Class Initialized
ERROR - 2013-09-04 05:16:05 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:16:38 --> Config Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:16:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:16:38 --> URI Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Router Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Output Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Security Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Input Class Initialized
DEBUG - 2013-09-04 05:16:38 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:38 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:38 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:38 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:38 --> XSS Filtering completed
DEBUG - 2013-09-04 05:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:16:38 --> Language Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Loader Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:16:38 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:16:38 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:16:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:16:38 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:16:38 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Session Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:16:38 --> Session routines successfully run
DEBUG - 2013-09-04 05:16:38 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Controller Class Initialized
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:16:38 --> Model Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:16:38 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:16:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:16:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:16:38 --> Model Class Initialized
DEBUG - 2013-09-04 05:16:38 --> Pagination Class Initialized
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:16:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:16:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:16:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:16:38 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:16:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:16:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:16:38 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:38 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:38 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:38 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:38 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:38 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:38 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:38 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 22
ERROR - 2013-09-04 05:16:38 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:38 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 24
ERROR - 2013-09-04 05:16:38 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\absensis\index.php 129
DEBUG - 2013-09-04 05:16:38 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 05:16:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:16:39 --> Final output sent to browser
DEBUG - 2013-09-04 05:16:39 --> Total execution time: 0.5820
DEBUG - 2013-09-04 05:16:39 --> Config Class Initialized
DEBUG - 2013-09-04 05:16:39 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:16:39 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:16:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:16:39 --> URI Class Initialized
DEBUG - 2013-09-04 05:16:39 --> Router Class Initialized
ERROR - 2013-09-04 05:16:39 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:19:34 --> Config Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:19:34 --> URI Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Router Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Output Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Security Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Input Class Initialized
DEBUG - 2013-09-04 05:19:34 --> XSS Filtering completed
DEBUG - 2013-09-04 05:19:34 --> XSS Filtering completed
DEBUG - 2013-09-04 05:19:34 --> XSS Filtering completed
DEBUG - 2013-09-04 05:19:34 --> XSS Filtering completed
DEBUG - 2013-09-04 05:19:34 --> XSS Filtering completed
DEBUG - 2013-09-04 05:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:19:34 --> Language Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Loader Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:19:34 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:19:34 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:19:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:19:34 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:19:34 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Session Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:19:34 --> Session routines successfully run
DEBUG - 2013-09-04 05:19:34 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Controller Class Initialized
ERROR - 2013-09-04 05:19:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:19:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:19:34 --> Model Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:19:34 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:19:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:19:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:19:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:19:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:19:34 --> Model Class Initialized
DEBUG - 2013-09-04 05:19:34 --> Pagination Class Initialized
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:19:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:19:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:19:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:19:35 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:19:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:19:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:19:35 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 42
ERROR - 2013-09-04 05:19:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 42
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 44
ERROR - 2013-09-04 05:19:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 44
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 42
ERROR - 2013-09-04 05:19:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 42
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 44
ERROR - 2013-09-04 05:19:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 44
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 42
ERROR - 2013-09-04 05:19:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 42
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 44
ERROR - 2013-09-04 05:19:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 44
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 42
ERROR - 2013-09-04 05:19:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 42
ERROR - 2013-09-04 05:19:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 44
ERROR - 2013-09-04 05:19:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 44
ERROR - 2013-09-04 05:19:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\absensis\index.php 130
DEBUG - 2013-09-04 05:19:35 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 05:19:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:19:35 --> Final output sent to browser
DEBUG - 2013-09-04 05:19:35 --> Total execution time: 0.6640
DEBUG - 2013-09-04 05:19:35 --> Config Class Initialized
DEBUG - 2013-09-04 05:19:35 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:19:35 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:19:35 --> URI Class Initialized
DEBUG - 2013-09-04 05:19:35 --> Router Class Initialized
ERROR - 2013-09-04 05:19:35 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:22:56 --> Config Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:22:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:22:56 --> URI Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Router Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Output Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Security Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Input Class Initialized
DEBUG - 2013-09-04 05:22:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:22:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:22:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:22:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:22:56 --> XSS Filtering completed
DEBUG - 2013-09-04 05:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:22:56 --> Language Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Loader Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:22:56 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:22:56 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:22:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:22:56 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:22:56 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Session Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:22:56 --> Session routines successfully run
DEBUG - 2013-09-04 05:22:56 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Controller Class Initialized
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:22:56 --> Model Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:22:56 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:22:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:22:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:22:56 --> Model Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Pagination Class Initialized
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:22:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:22:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:22:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:22:56 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:22:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:22:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:22:56 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:22:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:22:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:22:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:22:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:22:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:22:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:22:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:22:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:22:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:22:56 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\absensis\index.php 130
DEBUG - 2013-09-04 05:22:56 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 05:22:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:22:56 --> Final output sent to browser
DEBUG - 2013-09-04 05:22:56 --> Total execution time: 0.8260
DEBUG - 2013-09-04 05:22:56 --> Config Class Initialized
DEBUG - 2013-09-04 05:22:56 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:22:57 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:22:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:22:57 --> URI Class Initialized
DEBUG - 2013-09-04 05:22:57 --> Router Class Initialized
ERROR - 2013-09-04 05:22:57 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:24:20 --> Config Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:24:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:24:20 --> URI Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Router Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Output Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Security Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Input Class Initialized
DEBUG - 2013-09-04 05:24:20 --> XSS Filtering completed
DEBUG - 2013-09-04 05:24:20 --> XSS Filtering completed
DEBUG - 2013-09-04 05:24:20 --> XSS Filtering completed
DEBUG - 2013-09-04 05:24:20 --> XSS Filtering completed
DEBUG - 2013-09-04 05:24:20 --> XSS Filtering completed
DEBUG - 2013-09-04 05:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:24:20 --> Language Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Loader Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:24:20 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:24:20 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:24:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:24:20 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:24:20 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Session Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:24:20 --> Session routines successfully run
DEBUG - 2013-09-04 05:24:20 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Controller Class Initialized
ERROR - 2013-09-04 05:24:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:24:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:24:20 --> Model Class Initialized
DEBUG - 2013-09-04 05:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:24:20 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:24:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:24:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:24:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:24:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:24:20 --> Model Class Initialized
DEBUG - 2013-09-04 05:24:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:24:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:24:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:24:21 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:24:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:24:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:24:21 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:24:21 --> Severity: Notice  --> Undefined index: kode C:\xampp\htdocs\school\application\views\absensis\show.php 18
ERROR - 2013-09-04 05:24:21 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\absensis\show.php 27
DEBUG - 2013-09-04 05:24:21 --> File loaded: application/views/absensis/show.php
DEBUG - 2013-09-04 05:24:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:24:21 --> Final output sent to browser
DEBUG - 2013-09-04 05:24:21 --> Total execution time: 1.0691
DEBUG - 2013-09-04 05:24:21 --> Config Class Initialized
DEBUG - 2013-09-04 05:24:21 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:24:21 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:24:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:24:21 --> URI Class Initialized
DEBUG - 2013-09-04 05:24:21 --> Router Class Initialized
ERROR - 2013-09-04 05:24:21 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:35:52 --> Config Class Initialized
DEBUG - 2013-09-04 05:35:52 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:35:52 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:35:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:35:52 --> URI Class Initialized
DEBUG - 2013-09-04 05:35:52 --> Router Class Initialized
DEBUG - 2013-09-04 05:35:52 --> Output Class Initialized
DEBUG - 2013-09-04 05:35:52 --> Security Class Initialized
DEBUG - 2013-09-04 05:35:53 --> Input Class Initialized
DEBUG - 2013-09-04 05:35:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:35:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:35:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:35:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:35:53 --> XSS Filtering completed
DEBUG - 2013-09-04 05:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:35:53 --> Language Class Initialized
DEBUG - 2013-09-04 05:35:53 --> Loader Class Initialized
DEBUG - 2013-09-04 05:35:53 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:35:53 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:35:53 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:35:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:35:53 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:35:53 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:35:53 --> Session Class Initialized
DEBUG - 2013-09-04 05:35:53 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:35:53 --> Session routines successfully run
DEBUG - 2013-09-04 05:35:53 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:35:53 --> Controller Class Initialized
ERROR - 2013-09-04 05:35:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:35:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:35:53 --> Model Class Initialized
DEBUG - 2013-09-04 05:35:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:35:53 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:35:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:35:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:35:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:35:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:35:53 --> Model Class Initialized
DEBUG - 2013-09-04 05:35:54 --> DB Transaction Failure
ERROR - 2013-09-04 05:35:54 --> Query error: Column 'id' in where clause is ambiguous
DEBUG - 2013-09-04 05:35:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-04 05:36:48 --> Config Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:36:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:36:48 --> URI Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Router Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Output Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Security Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Input Class Initialized
DEBUG - 2013-09-04 05:36:48 --> XSS Filtering completed
DEBUG - 2013-09-04 05:36:48 --> XSS Filtering completed
DEBUG - 2013-09-04 05:36:48 --> XSS Filtering completed
DEBUG - 2013-09-04 05:36:48 --> XSS Filtering completed
DEBUG - 2013-09-04 05:36:48 --> XSS Filtering completed
DEBUG - 2013-09-04 05:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:36:48 --> Language Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Loader Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:36:48 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:36:48 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:36:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:36:48 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:36:48 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Session Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:36:48 --> Session routines successfully run
DEBUG - 2013-09-04 05:36:48 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Controller Class Initialized
ERROR - 2013-09-04 05:36:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:36:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:36:48 --> Model Class Initialized
DEBUG - 2013-09-04 05:36:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:36:48 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:36:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:36:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:36:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:36:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:36:48 --> Model Class Initialized
DEBUG - 2013-09-04 05:36:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:36:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:36:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:36:49 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:36:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:36:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:36:49 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:36:49 --> Severity: Notice  --> Undefined index: kode_siswa C:\xampp\htdocs\school\application\views\absensis\show.php 45
DEBUG - 2013-09-04 05:36:49 --> File loaded: application/views/absensis/show.php
DEBUG - 2013-09-04 05:36:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:36:49 --> Final output sent to browser
DEBUG - 2013-09-04 05:36:49 --> Total execution time: 1.0451
DEBUG - 2013-09-04 05:36:49 --> Config Class Initialized
DEBUG - 2013-09-04 05:36:49 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:36:49 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:36:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:36:49 --> URI Class Initialized
DEBUG - 2013-09-04 05:36:49 --> Router Class Initialized
ERROR - 2013-09-04 05:36:49 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:37:14 --> Config Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:37:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:37:14 --> URI Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Router Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Output Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Security Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Input Class Initialized
DEBUG - 2013-09-04 05:37:14 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:14 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:14 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:14 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:14 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:37:14 --> Language Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Loader Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:37:14 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:37:14 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:37:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:37:14 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:37:14 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Session Class Initialized
DEBUG - 2013-09-04 05:37:14 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:37:15 --> Session routines successfully run
DEBUG - 2013-09-04 05:37:15 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:37:15 --> Controller Class Initialized
ERROR - 2013-09-04 05:37:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:37:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:37:15 --> Model Class Initialized
DEBUG - 2013-09-04 05:37:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:37:15 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:37:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:37:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:37:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:37:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:37:15 --> Model Class Initialized
DEBUG - 2013-09-04 05:37:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:37:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:37:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:37:15 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:37:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:37:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:37:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 05:37:15 --> File loaded: application/views/absensis/show.php
DEBUG - 2013-09-04 05:37:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:37:15 --> Final output sent to browser
DEBUG - 2013-09-04 05:37:15 --> Total execution time: 0.5570
DEBUG - 2013-09-04 05:37:15 --> Config Class Initialized
DEBUG - 2013-09-04 05:37:15 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:37:15 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:37:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:37:15 --> URI Class Initialized
DEBUG - 2013-09-04 05:37:15 --> Router Class Initialized
ERROR - 2013-09-04 05:37:15 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:37:36 --> Config Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:37:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:37:36 --> URI Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Router Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Output Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Security Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Input Class Initialized
DEBUG - 2013-09-04 05:37:36 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:36 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:36 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:36 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:36 --> XSS Filtering completed
DEBUG - 2013-09-04 05:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:37:36 --> Language Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Loader Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:37:36 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:37:36 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:37:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:37:36 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:37:36 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Session Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:37:36 --> Session routines successfully run
DEBUG - 2013-09-04 05:37:36 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:37:36 --> Controller Class Initialized
ERROR - 2013-09-04 05:37:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:37:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:37:36 --> Model Class Initialized
DEBUG - 2013-09-04 05:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:37:37 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:37:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:37:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:37:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:37:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:37:37 --> Model Class Initialized
DEBUG - 2013-09-04 05:37:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:37:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:37:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:37:37 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:37:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:37:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:37:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 05:37:37 --> File loaded: application/views/absensis/show.php
DEBUG - 2013-09-04 05:37:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:37:37 --> Final output sent to browser
DEBUG - 2013-09-04 05:37:37 --> Total execution time: 0.6010
DEBUG - 2013-09-04 05:37:37 --> Config Class Initialized
DEBUG - 2013-09-04 05:37:37 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:37:37 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:37:37 --> URI Class Initialized
DEBUG - 2013-09-04 05:37:37 --> Router Class Initialized
ERROR - 2013-09-04 05:37:37 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:38:02 --> Config Class Initialized
DEBUG - 2013-09-04 05:38:02 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:38:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:38:03 --> URI Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Router Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Output Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Security Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Input Class Initialized
DEBUG - 2013-09-04 05:38:03 --> XSS Filtering completed
DEBUG - 2013-09-04 05:38:03 --> XSS Filtering completed
DEBUG - 2013-09-04 05:38:03 --> XSS Filtering completed
DEBUG - 2013-09-04 05:38:03 --> XSS Filtering completed
DEBUG - 2013-09-04 05:38:03 --> XSS Filtering completed
DEBUG - 2013-09-04 05:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:38:03 --> Language Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Loader Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:38:03 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:38:03 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:38:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:38:03 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:38:03 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Session Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:38:03 --> Session routines successfully run
DEBUG - 2013-09-04 05:38:03 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Controller Class Initialized
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:38:03 --> Model Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:38:03 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:38:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:38:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:38:03 --> Model Class Initialized
DEBUG - 2013-09-04 05:38:03 --> Pagination Class Initialized
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:38:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:38:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:38:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:38:03 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:38:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:38:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:38:03 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:38:03 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:38:03 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:38:03 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:38:03 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:38:03 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:38:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:38:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:38:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:38:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:38:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:38:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:38:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:38:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:38:04 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\absensis\index.php 130
DEBUG - 2013-09-04 05:38:04 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 05:38:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:38:04 --> Final output sent to browser
DEBUG - 2013-09-04 05:38:04 --> Total execution time: 1.1401
DEBUG - 2013-09-04 05:38:04 --> Config Class Initialized
DEBUG - 2013-09-04 05:38:04 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:38:04 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:38:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:38:04 --> URI Class Initialized
DEBUG - 2013-09-04 05:38:04 --> Router Class Initialized
ERROR - 2013-09-04 05:38:04 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:58:12 --> Config Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:58:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:58:12 --> URI Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Router Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Output Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Security Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Input Class Initialized
DEBUG - 2013-09-04 05:58:12 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:12 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:12 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:12 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:12 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:58:12 --> Language Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Loader Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:58:12 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:58:12 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:58:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:58:12 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:58:12 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Session Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:58:12 --> Session routines successfully run
DEBUG - 2013-09-04 05:58:12 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:58:12 --> Controller Class Initialized
ERROR - 2013-09-04 05:58:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:58:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:58:13 --> Model Class Initialized
DEBUG - 2013-09-04 05:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:58:13 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:58:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:58:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:58:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:58:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:58:13 --> Model Class Initialized
DEBUG - 2013-09-04 05:58:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:58:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:58:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:58:13 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:58:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:58:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:58:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 05:58:14 --> File loaded: application/views/absensis/show.php
DEBUG - 2013-09-04 05:58:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:58:14 --> Final output sent to browser
DEBUG - 2013-09-04 05:58:14 --> Total execution time: 2.2971
DEBUG - 2013-09-04 05:58:14 --> Config Class Initialized
DEBUG - 2013-09-04 05:58:14 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:58:14 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:58:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:58:14 --> URI Class Initialized
DEBUG - 2013-09-04 05:58:14 --> Router Class Initialized
ERROR - 2013-09-04 05:58:14 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 05:58:23 --> Config Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:58:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:58:23 --> URI Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Router Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Output Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Security Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Input Class Initialized
DEBUG - 2013-09-04 05:58:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:23 --> XSS Filtering completed
DEBUG - 2013-09-04 05:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 05:58:23 --> Language Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Loader Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Helper loaded: url_helper
DEBUG - 2013-09-04 05:58:23 --> Helper loaded: file_helper
DEBUG - 2013-09-04 05:58:23 --> Helper loaded: form_helper
DEBUG - 2013-09-04 05:58:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 05:58:23 --> Helper loaded: application_helper
DEBUG - 2013-09-04 05:58:23 --> Database Driver Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Session Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Helper loaded: string_helper
DEBUG - 2013-09-04 05:58:23 --> Session routines successfully run
DEBUG - 2013-09-04 05:58:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Controller Class Initialized
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:58:23 --> Model Class Initialized
DEBUG - 2013-09-04 05:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 05:58:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 05:58:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 05:58:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 05:58:23 --> Model Class Initialized
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Undefined index: siswa_id C:\xampp\htdocs\school\application\controllers\guru\absensis.php 182
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Undefined index: tahun_ajaran_id C:\xampp\htdocs\school\application\controllers\guru\absensis.php 188
DEBUG - 2013-09-04 05:58:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 05:58:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 05:58:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 05:58:23 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 05:58:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 05:58:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 05:58:23 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 05:58:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 05:58:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-04 05:58:23 --> File loaded: application/views/absensis/edit.php
DEBUG - 2013-09-04 05:58:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 05:58:23 --> Final output sent to browser
DEBUG - 2013-09-04 05:58:23 --> Total execution time: 0.8651
DEBUG - 2013-09-04 05:58:24 --> Config Class Initialized
DEBUG - 2013-09-04 05:58:24 --> Hooks Class Initialized
DEBUG - 2013-09-04 05:58:24 --> Utf8 Class Initialized
DEBUG - 2013-09-04 05:58:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 05:58:24 --> URI Class Initialized
DEBUG - 2013-09-04 05:58:24 --> Router Class Initialized
ERROR - 2013-09-04 05:58:24 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:00:36 --> Config Class Initialized
DEBUG - 2013-09-04 06:00:36 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:00:36 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:00:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:00:36 --> URI Class Initialized
DEBUG - 2013-09-04 06:00:36 --> Router Class Initialized
DEBUG - 2013-09-04 06:00:36 --> Output Class Initialized
DEBUG - 2013-09-04 06:00:36 --> Security Class Initialized
DEBUG - 2013-09-04 06:00:36 --> Input Class Initialized
DEBUG - 2013-09-04 06:00:37 --> XSS Filtering completed
DEBUG - 2013-09-04 06:00:37 --> XSS Filtering completed
DEBUG - 2013-09-04 06:00:37 --> XSS Filtering completed
DEBUG - 2013-09-04 06:00:37 --> XSS Filtering completed
DEBUG - 2013-09-04 06:00:37 --> XSS Filtering completed
DEBUG - 2013-09-04 06:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:00:37 --> Language Class Initialized
DEBUG - 2013-09-04 06:00:37 --> Loader Class Initialized
DEBUG - 2013-09-04 06:00:37 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:00:37 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:00:37 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:00:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:00:37 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:00:37 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:00:37 --> Session Class Initialized
DEBUG - 2013-09-04 06:00:37 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:00:37 --> Session routines successfully run
DEBUG - 2013-09-04 06:00:37 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:00:37 --> Controller Class Initialized
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:00:37 --> Model Class Initialized
DEBUG - 2013-09-04 06:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:00:37 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:00:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:00:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:00:37 --> Model Class Initialized
DEBUG - 2013-09-04 06:00:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:00:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:00:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:00:37 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:00:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:00:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:00:37 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:00:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:00:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:00:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:00:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:00:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:00:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:00:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:00:37 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:00:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-04 06:00:37 --> File loaded: application/views/absensis/edit.php
DEBUG - 2013-09-04 06:00:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:00:37 --> Final output sent to browser
DEBUG - 2013-09-04 06:00:37 --> Total execution time: 0.8791
DEBUG - 2013-09-04 06:00:37 --> Config Class Initialized
DEBUG - 2013-09-04 06:00:37 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:00:37 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:00:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:00:37 --> URI Class Initialized
DEBUG - 2013-09-04 06:00:37 --> Router Class Initialized
ERROR - 2013-09-04 06:00:37 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:01:17 --> Config Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:01:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:01:17 --> URI Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Router Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Output Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Security Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Input Class Initialized
DEBUG - 2013-09-04 06:01:17 --> XSS Filtering completed
DEBUG - 2013-09-04 06:01:17 --> XSS Filtering completed
DEBUG - 2013-09-04 06:01:17 --> XSS Filtering completed
DEBUG - 2013-09-04 06:01:17 --> XSS Filtering completed
DEBUG - 2013-09-04 06:01:17 --> XSS Filtering completed
DEBUG - 2013-09-04 06:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:01:17 --> Language Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Loader Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:01:17 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:01:17 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:01:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:01:17 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:01:17 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Session Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:01:17 --> Session routines successfully run
DEBUG - 2013-09-04 06:01:17 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Controller Class Initialized
ERROR - 2013-09-04 06:01:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:01:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:01:17 --> Model Class Initialized
DEBUG - 2013-09-04 06:01:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:01:17 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:01:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:01:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:01:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:01:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:01:17 --> Model Class Initialized
DEBUG - 2013-09-04 06:01:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:01:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:01:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:01:17 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:01:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:01:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:01:17 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 06:01:17 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:01:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:01:17 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:01:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:01:17 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:01:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:01:17 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:01:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:01:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:01:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:01:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:01:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:01:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:01:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:01:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:01:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-04 06:01:18 --> File loaded: application/views/absensis/edit.php
DEBUG - 2013-09-04 06:01:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:01:18 --> Final output sent to browser
DEBUG - 2013-09-04 06:01:18 --> Total execution time: 0.9351
DEBUG - 2013-09-04 06:01:18 --> Config Class Initialized
DEBUG - 2013-09-04 06:01:18 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:01:18 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:01:18 --> URI Class Initialized
DEBUG - 2013-09-04 06:01:18 --> Router Class Initialized
ERROR - 2013-09-04 06:01:18 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:02:30 --> Config Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:02:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:02:30 --> URI Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Router Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Output Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Security Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Input Class Initialized
DEBUG - 2013-09-04 06:02:30 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:30 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:30 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:30 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:30 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:02:30 --> Language Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Loader Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:02:30 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:02:30 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:02:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:02:30 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:02:30 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Session Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:02:30 --> Session routines successfully run
DEBUG - 2013-09-04 06:02:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Controller Class Initialized
ERROR - 2013-09-04 06:02:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:02:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:02:30 --> Model Class Initialized
DEBUG - 2013-09-04 06:02:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:02:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:02:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:02:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:02:31 --> Model Class Initialized
DEBUG - 2013-09-04 06:02:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:02:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:02:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:02:31 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:02:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:02:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:02:31 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:31 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-04 06:02:31 --> File loaded: application/views/absensis/edit.php
DEBUG - 2013-09-04 06:02:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:02:31 --> Final output sent to browser
DEBUG - 2013-09-04 06:02:31 --> Total execution time: 0.8721
DEBUG - 2013-09-04 06:02:31 --> Config Class Initialized
DEBUG - 2013-09-04 06:02:31 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:02:31 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:02:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:02:31 --> URI Class Initialized
DEBUG - 2013-09-04 06:02:31 --> Router Class Initialized
ERROR - 2013-09-04 06:02:31 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:02:34 --> Config Class Initialized
DEBUG - 2013-09-04 06:02:34 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:02:34 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:02:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:02:34 --> URI Class Initialized
DEBUG - 2013-09-04 06:02:34 --> Router Class Initialized
DEBUG - 2013-09-04 06:02:34 --> Output Class Initialized
DEBUG - 2013-09-04 06:02:34 --> Security Class Initialized
DEBUG - 2013-09-04 06:02:34 --> Input Class Initialized
DEBUG - 2013-09-04 06:02:34 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:34 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:34 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:34 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:34 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:02:34 --> Language Class Initialized
DEBUG - 2013-09-04 06:02:34 --> Loader Class Initialized
DEBUG - 2013-09-04 06:02:34 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:02:34 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:02:34 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:02:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:02:34 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:02:34 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:02:35 --> Session Class Initialized
DEBUG - 2013-09-04 06:02:35 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:02:35 --> Session garbage collection performed.
DEBUG - 2013-09-04 06:02:35 --> Session routines successfully run
DEBUG - 2013-09-04 06:02:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:02:35 --> Controller Class Initialized
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:02:35 --> Model Class Initialized
DEBUG - 2013-09-04 06:02:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:02:35 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:02:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:02:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:02:35 --> Model Class Initialized
DEBUG - 2013-09-04 06:02:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:02:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:02:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:02:35 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:02:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:02:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:02:35 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-04 06:02:35 --> File loaded: application/views/absensis/edit.php
DEBUG - 2013-09-04 06:02:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:02:35 --> Final output sent to browser
DEBUG - 2013-09-04 06:02:35 --> Total execution time: 0.9171
DEBUG - 2013-09-04 06:02:35 --> Config Class Initialized
DEBUG - 2013-09-04 06:02:35 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:02:35 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:02:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:02:35 --> URI Class Initialized
DEBUG - 2013-09-04 06:02:35 --> Router Class Initialized
ERROR - 2013-09-04 06:02:35 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:02:39 --> Config Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:02:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:02:40 --> URI Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Router Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Output Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Security Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Input Class Initialized
DEBUG - 2013-09-04 06:02:40 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:40 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:40 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:40 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:40 --> XSS Filtering completed
DEBUG - 2013-09-04 06:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:02:40 --> Language Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Loader Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:02:40 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:02:40 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:02:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:02:40 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:02:40 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Session Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:02:40 --> Session routines successfully run
DEBUG - 2013-09-04 06:02:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Controller Class Initialized
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:02:40 --> Model Class Initialized
DEBUG - 2013-09-04 06:02:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:02:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:02:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:02:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:02:40 --> Model Class Initialized
DEBUG - 2013-09-04 06:02:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:02:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:02:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:02:40 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:02:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:02:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:02:40 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:02:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:02:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-04 06:02:40 --> File loaded: application/views/absensis/edit.php
DEBUG - 2013-09-04 06:02:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:02:40 --> Final output sent to browser
DEBUG - 2013-09-04 06:02:40 --> Total execution time: 0.9121
DEBUG - 2013-09-04 06:02:41 --> Config Class Initialized
DEBUG - 2013-09-04 06:02:41 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:02:41 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:02:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:02:41 --> URI Class Initialized
DEBUG - 2013-09-04 06:02:41 --> Router Class Initialized
ERROR - 2013-09-04 06:02:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:05:24 --> Config Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:05:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:05:24 --> URI Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Router Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Output Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Security Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Input Class Initialized
DEBUG - 2013-09-04 06:05:24 --> XSS Filtering completed
DEBUG - 2013-09-04 06:05:24 --> XSS Filtering completed
DEBUG - 2013-09-04 06:05:24 --> XSS Filtering completed
DEBUG - 2013-09-04 06:05:24 --> XSS Filtering completed
DEBUG - 2013-09-04 06:05:24 --> XSS Filtering completed
DEBUG - 2013-09-04 06:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:05:24 --> Language Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Loader Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:05:24 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:05:24 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:05:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:05:24 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:05:24 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Session Class Initialized
DEBUG - 2013-09-04 06:05:24 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:05:25 --> Session routines successfully run
DEBUG - 2013-09-04 06:05:25 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:05:25 --> Controller Class Initialized
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:05:25 --> Model Class Initialized
DEBUG - 2013-09-04 06:05:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:05:25 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:05:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:05:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:05:25 --> Model Class Initialized
DEBUG - 2013-09-04 06:05:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:05:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:05:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:05:25 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:05:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:05:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:05:25 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:05:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:05:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:05:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:05:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:05:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:05:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:05:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:05:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:05:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-04 06:05:25 --> File loaded: application/views/absensis/edit.php
DEBUG - 2013-09-04 06:05:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:05:25 --> Final output sent to browser
DEBUG - 2013-09-04 06:05:25 --> Total execution time: 0.9761
DEBUG - 2013-09-04 06:05:25 --> Config Class Initialized
DEBUG - 2013-09-04 06:05:25 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:05:25 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:05:25 --> URI Class Initialized
DEBUG - 2013-09-04 06:05:25 --> Router Class Initialized
ERROR - 2013-09-04 06:05:25 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:06:03 --> Config Class Initialized
DEBUG - 2013-09-04 06:06:03 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:06:03 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:06:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:06:03 --> URI Class Initialized
DEBUG - 2013-09-04 06:06:03 --> Router Class Initialized
DEBUG - 2013-09-04 06:06:03 --> Output Class Initialized
DEBUG - 2013-09-04 06:06:03 --> Security Class Initialized
DEBUG - 2013-09-04 06:06:03 --> Input Class Initialized
DEBUG - 2013-09-04 06:06:03 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:03 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:03 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:03 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:03 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:06:03 --> Language Class Initialized
DEBUG - 2013-09-04 06:06:03 --> Loader Class Initialized
DEBUG - 2013-09-04 06:06:03 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:06:04 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:06:04 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:06:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:06:04 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:06:04 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:06:04 --> Session Class Initialized
DEBUG - 2013-09-04 06:06:04 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:06:04 --> Session routines successfully run
DEBUG - 2013-09-04 06:06:04 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:06:04 --> Controller Class Initialized
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:04 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:06:04 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:06:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:06:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:04 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:06:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:06:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:06:04 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:06:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:06:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:06:04 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-04 06:06:04 --> File loaded: application/views/absensis/edit.php
DEBUG - 2013-09-04 06:06:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:06:04 --> Final output sent to browser
DEBUG - 2013-09-04 06:06:04 --> Total execution time: 0.9931
DEBUG - 2013-09-04 06:06:04 --> Config Class Initialized
DEBUG - 2013-09-04 06:06:04 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:06:04 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:06:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:06:04 --> URI Class Initialized
DEBUG - 2013-09-04 06:06:04 --> Router Class Initialized
ERROR - 2013-09-04 06:06:04 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:06:08 --> Config Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:06:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:06:08 --> URI Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Router Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Output Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Security Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Input Class Initialized
DEBUG - 2013-09-04 06:06:08 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:08 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:08 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:08 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:08 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:06:08 --> Language Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Loader Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:06:08 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:06:08 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:06:08 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:06:08 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:06:08 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Session Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:06:08 --> Session routines successfully run
DEBUG - 2013-09-04 06:06:08 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Controller Class Initialized
ERROR - 2013-09-04 06:06:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:08 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:06:09 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:06:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:06:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:09 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:06:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:06:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:06:09 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:06:09 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:06:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:06:09 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:09 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:09 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:09 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:09 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:09 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:09 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:09 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:09 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:09 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-04 06:06:09 --> File loaded: application/views/absensis/edit.php
DEBUG - 2013-09-04 06:06:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:06:09 --> Final output sent to browser
DEBUG - 2013-09-04 06:06:09 --> Total execution time: 1.2391
DEBUG - 2013-09-04 06:06:09 --> Config Class Initialized
DEBUG - 2013-09-04 06:06:09 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:06:09 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:06:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:06:09 --> URI Class Initialized
DEBUG - 2013-09-04 06:06:09 --> Router Class Initialized
ERROR - 2013-09-04 06:06:09 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:06:20 --> Config Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:06:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:06:20 --> URI Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Router Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Output Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Security Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Input Class Initialized
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:06:20 --> Language Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Loader Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:06:20 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:06:20 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:06:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:06:20 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:06:20 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Session Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:06:20 --> Session routines successfully run
DEBUG - 2013-09-04 06:06:20 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:06:20 --> Controller Class Initialized
ERROR - 2013-09-04 06:06:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:21 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:06:21 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:06:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:06:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:06:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:21 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Form Validation Class Initialized
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-04 06:06:21 --> Config Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:06:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:06:21 --> URI Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Router Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Output Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Security Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Input Class Initialized
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:06:21 --> Language Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Loader Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:06:21 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:06:21 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:06:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:06:21 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:06:21 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Session Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:06:21 --> Session routines successfully run
DEBUG - 2013-09-04 06:06:21 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Controller Class Initialized
ERROR - 2013-09-04 06:06:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:21 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:06:22 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:06:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:06:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:06:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:22 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:06:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:06:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:06:22 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:06:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:06:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:06:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 06:06:22 --> File loaded: application/views/absensis/show.php
DEBUG - 2013-09-04 06:06:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:06:22 --> Final output sent to browser
DEBUG - 2013-09-04 06:06:22 --> Total execution time: 0.9381
DEBUG - 2013-09-04 06:06:22 --> Config Class Initialized
DEBUG - 2013-09-04 06:06:22 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:06:22 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:06:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:06:22 --> URI Class Initialized
DEBUG - 2013-09-04 06:06:22 --> Router Class Initialized
ERROR - 2013-09-04 06:06:22 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 06:06:27 --> Config Class Initialized
DEBUG - 2013-09-04 06:06:27 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:06:27 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:06:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:06:27 --> URI Class Initialized
DEBUG - 2013-09-04 06:06:27 --> Router Class Initialized
DEBUG - 2013-09-04 06:06:27 --> Output Class Initialized
DEBUG - 2013-09-04 06:06:27 --> Security Class Initialized
DEBUG - 2013-09-04 06:06:27 --> Input Class Initialized
DEBUG - 2013-09-04 06:06:27 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:27 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:27 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:27 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:28 --> XSS Filtering completed
DEBUG - 2013-09-04 06:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 06:06:28 --> Language Class Initialized
DEBUG - 2013-09-04 06:06:28 --> Loader Class Initialized
DEBUG - 2013-09-04 06:06:28 --> Helper loaded: url_helper
DEBUG - 2013-09-04 06:06:28 --> Helper loaded: file_helper
DEBUG - 2013-09-04 06:06:28 --> Helper loaded: form_helper
DEBUG - 2013-09-04 06:06:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 06:06:28 --> Helper loaded: application_helper
DEBUG - 2013-09-04 06:06:28 --> Database Driver Class Initialized
DEBUG - 2013-09-04 06:06:28 --> Session Class Initialized
DEBUG - 2013-09-04 06:06:28 --> Helper loaded: string_helper
DEBUG - 2013-09-04 06:06:28 --> Session routines successfully run
DEBUG - 2013-09-04 06:06:28 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 06:06:28 --> Controller Class Initialized
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:28 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 06:06:28 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 06:06:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 06:06:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:28 --> Model Class Initialized
DEBUG - 2013-09-04 06:06:28 --> Pagination Class Initialized
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 06:06:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 06:06:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 06:06:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 06:06:28 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 06:06:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 06:06:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 06:06:28 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 06:06:28 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 06:06:28 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\absensis\index.php 130
DEBUG - 2013-09-04 06:06:28 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 06:06:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 06:06:29 --> Final output sent to browser
DEBUG - 2013-09-04 06:06:29 --> Total execution time: 1.2021
DEBUG - 2013-09-04 06:06:29 --> Config Class Initialized
DEBUG - 2013-09-04 06:06:29 --> Hooks Class Initialized
DEBUG - 2013-09-04 06:06:29 --> Utf8 Class Initialized
DEBUG - 2013-09-04 06:06:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 06:06:29 --> URI Class Initialized
DEBUG - 2013-09-04 06:06:29 --> Router Class Initialized
ERROR - 2013-09-04 06:06:29 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 10:42:17 --> Config Class Initialized
DEBUG - 2013-09-04 10:42:17 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:42:17 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:42:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:42:17 --> URI Class Initialized
DEBUG - 2013-09-04 10:42:17 --> Router Class Initialized
DEBUG - 2013-09-04 10:42:17 --> Output Class Initialized
DEBUG - 2013-09-04 10:42:17 --> Security Class Initialized
DEBUG - 2013-09-04 10:42:17 --> Input Class Initialized
DEBUG - 2013-09-04 10:42:17 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:17 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:17 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:17 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 10:42:17 --> Language Class Initialized
DEBUG - 2013-09-04 10:42:17 --> Loader Class Initialized
DEBUG - 2013-09-04 10:42:18 --> Helper loaded: url_helper
DEBUG - 2013-09-04 10:42:18 --> Helper loaded: file_helper
DEBUG - 2013-09-04 10:42:18 --> Helper loaded: form_helper
DEBUG - 2013-09-04 10:42:18 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 10:42:18 --> Helper loaded: application_helper
DEBUG - 2013-09-04 10:42:18 --> Database Driver Class Initialized
DEBUG - 2013-09-04 10:42:18 --> Session Class Initialized
DEBUG - 2013-09-04 10:42:19 --> Helper loaded: string_helper
DEBUG - 2013-09-04 10:42:19 --> A session cookie was not found.
DEBUG - 2013-09-04 10:42:19 --> Session routines successfully run
DEBUG - 2013-09-04 10:42:19 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 10:42:19 --> Controller Class Initialized
ERROR - 2013-09-04 10:42:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:19 --> Model Class Initialized
DEBUG - 2013-09-04 10:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 10:42:19 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 10:42:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 10:42:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 10:42:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:20 --> Config Class Initialized
DEBUG - 2013-09-04 10:42:20 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:42:20 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:42:20 --> URI Class Initialized
DEBUG - 2013-09-04 10:42:20 --> Router Class Initialized
DEBUG - 2013-09-04 10:42:20 --> Output Class Initialized
DEBUG - 2013-09-04 10:42:20 --> Security Class Initialized
DEBUG - 2013-09-04 10:42:20 --> Input Class Initialized
DEBUG - 2013-09-04 10:42:20 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:20 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 10:42:20 --> Language Class Initialized
DEBUG - 2013-09-04 10:42:20 --> Loader Class Initialized
DEBUG - 2013-09-04 10:42:21 --> Helper loaded: url_helper
DEBUG - 2013-09-04 10:42:21 --> Helper loaded: file_helper
DEBUG - 2013-09-04 10:42:21 --> Helper loaded: form_helper
DEBUG - 2013-09-04 10:42:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 10:42:21 --> Helper loaded: application_helper
DEBUG - 2013-09-04 10:42:21 --> Database Driver Class Initialized
DEBUG - 2013-09-04 10:42:21 --> Session Class Initialized
DEBUG - 2013-09-04 10:42:21 --> Helper loaded: string_helper
DEBUG - 2013-09-04 10:42:21 --> Session routines successfully run
DEBUG - 2013-09-04 10:42:21 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 10:42:21 --> Controller Class Initialized
ERROR - 2013-09-04 10:42:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:21 --> Model Class Initialized
DEBUG - 2013-09-04 10:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 10:42:21 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 10:42:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 10:42:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 10:42:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 10:42:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 10:42:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 10:42:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 10:42:21 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-04 10:42:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 10:42:21 --> Final output sent to browser
DEBUG - 2013-09-04 10:42:21 --> Total execution time: 1.6741
DEBUG - 2013-09-04 10:42:21 --> Config Class Initialized
DEBUG - 2013-09-04 10:42:21 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:42:21 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:42:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:42:21 --> URI Class Initialized
DEBUG - 2013-09-04 10:42:21 --> Router Class Initialized
ERROR - 2013-09-04 10:42:21 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 10:42:28 --> Config Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:42:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:42:28 --> URI Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Router Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Output Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Security Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Input Class Initialized
DEBUG - 2013-09-04 10:42:28 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:28 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:28 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:28 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:28 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:28 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 10:42:28 --> Language Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Loader Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Helper loaded: url_helper
DEBUG - 2013-09-04 10:42:28 --> Helper loaded: file_helper
DEBUG - 2013-09-04 10:42:28 --> Helper loaded: form_helper
DEBUG - 2013-09-04 10:42:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 10:42:28 --> Helper loaded: application_helper
DEBUG - 2013-09-04 10:42:28 --> Database Driver Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Session Class Initialized
DEBUG - 2013-09-04 10:42:28 --> Helper loaded: string_helper
DEBUG - 2013-09-04 10:42:28 --> Session routines successfully run
DEBUG - 2013-09-04 10:42:28 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Controller Class Initialized
ERROR - 2013-09-04 10:42:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:29 --> Model Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 10:42:29 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 10:42:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 10:42:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 10:42:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:29 --> Model Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Form Validation Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-04 10:42:29 --> Config Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:42:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:42:29 --> URI Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Router Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Output Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Security Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Input Class Initialized
DEBUG - 2013-09-04 10:42:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 10:42:29 --> Language Class Initialized
DEBUG - 2013-09-04 10:42:29 --> Loader Class Initialized
DEBUG - 2013-09-04 10:42:30 --> Helper loaded: url_helper
DEBUG - 2013-09-04 10:42:30 --> Helper loaded: file_helper
DEBUG - 2013-09-04 10:42:30 --> Helper loaded: form_helper
DEBUG - 2013-09-04 10:42:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 10:42:30 --> Helper loaded: application_helper
DEBUG - 2013-09-04 10:42:30 --> Database Driver Class Initialized
DEBUG - 2013-09-04 10:42:30 --> Session Class Initialized
DEBUG - 2013-09-04 10:42:30 --> Helper loaded: string_helper
DEBUG - 2013-09-04 10:42:30 --> Session routines successfully run
DEBUG - 2013-09-04 10:42:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 10:42:30 --> Controller Class Initialized
ERROR - 2013-09-04 10:42:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:30 --> Model Class Initialized
DEBUG - 2013-09-04 10:42:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 10:42:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 10:42:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 10:42:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 10:42:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:30 --> Config Class Initialized
DEBUG - 2013-09-04 10:42:30 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:42:30 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:42:30 --> URI Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Router Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Output Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Security Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Input Class Initialized
DEBUG - 2013-09-04 10:42:31 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:31 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:31 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:31 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:31 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 10:42:31 --> Language Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Loader Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Helper loaded: url_helper
DEBUG - 2013-09-04 10:42:31 --> Helper loaded: file_helper
DEBUG - 2013-09-04 10:42:31 --> Helper loaded: form_helper
DEBUG - 2013-09-04 10:42:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 10:42:31 --> Helper loaded: application_helper
DEBUG - 2013-09-04 10:42:31 --> Database Driver Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Session Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Helper loaded: string_helper
DEBUG - 2013-09-04 10:42:31 --> Session garbage collection performed.
DEBUG - 2013-09-04 10:42:31 --> Session routines successfully run
DEBUG - 2013-09-04 10:42:31 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Controller Class Initialized
ERROR - 2013-09-04 10:42:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:31 --> Model Class Initialized
DEBUG - 2013-09-04 10:42:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 10:42:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 10:42:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 10:42:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 10:42:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:31 --> Model Class Initialized
DEBUG - 2013-09-04 10:42:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 10:42:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 10:42:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 10:42:32 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 10:42:32 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 10:42:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 10:42:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 10:42:32 --> File loaded: application/views/home.php
DEBUG - 2013-09-04 10:42:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 10:42:32 --> Final output sent to browser
DEBUG - 2013-09-04 10:42:32 --> Total execution time: 1.3341
DEBUG - 2013-09-04 10:42:32 --> Config Class Initialized
DEBUG - 2013-09-04 10:42:32 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:42:32 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:42:32 --> URI Class Initialized
DEBUG - 2013-09-04 10:42:32 --> Router Class Initialized
ERROR - 2013-09-04 10:42:32 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 10:42:40 --> Config Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:42:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:42:40 --> URI Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Router Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Output Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Security Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Input Class Initialized
DEBUG - 2013-09-04 10:42:40 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:40 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:40 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:40 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:40 --> XSS Filtering completed
DEBUG - 2013-09-04 10:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 10:42:40 --> Language Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Loader Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Helper loaded: url_helper
DEBUG - 2013-09-04 10:42:40 --> Helper loaded: file_helper
DEBUG - 2013-09-04 10:42:40 --> Helper loaded: form_helper
DEBUG - 2013-09-04 10:42:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 10:42:40 --> Helper loaded: application_helper
DEBUG - 2013-09-04 10:42:40 --> Database Driver Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Session Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Helper loaded: string_helper
DEBUG - 2013-09-04 10:42:40 --> Session routines successfully run
DEBUG - 2013-09-04 10:42:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Controller Class Initialized
ERROR - 2013-09-04 10:42:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:40 --> Model Class Initialized
DEBUG - 2013-09-04 10:42:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 10:42:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 10:42:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 10:42:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:41 --> Model Class Initialized
DEBUG - 2013-09-04 10:42:41 --> Pagination Class Initialized
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:42:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 10:42:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 10:42:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 10:42:41 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 10:42:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 10:42:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 10:42:41 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 10:42:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 10:42:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 10:42:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 10:42:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 10:42:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 10:42:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 10:42:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 10:42:41 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 10:42:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 10:42:42 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\absensis\index.php 138
DEBUG - 2013-09-04 10:42:42 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 10:42:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 10:42:42 --> Final output sent to browser
DEBUG - 2013-09-04 10:42:42 --> Total execution time: 1.8031
DEBUG - 2013-09-04 10:42:42 --> Config Class Initialized
DEBUG - 2013-09-04 10:42:42 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:42:42 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:42:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:42:42 --> URI Class Initialized
DEBUG - 2013-09-04 10:42:42 --> Router Class Initialized
ERROR - 2013-09-04 10:42:42 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 10:46:28 --> Config Class Initialized
DEBUG - 2013-09-04 10:46:28 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:46:28 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:46:28 --> URI Class Initialized
DEBUG - 2013-09-04 10:46:28 --> Router Class Initialized
ERROR - 2013-09-04 10:46:28 --> 404 Page Not Found --> absensis
DEBUG - 2013-09-04 10:47:06 --> Config Class Initialized
DEBUG - 2013-09-04 10:47:06 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:47:06 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:47:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:47:06 --> URI Class Initialized
DEBUG - 2013-09-04 10:47:06 --> Router Class Initialized
DEBUG - 2013-09-04 10:47:06 --> Output Class Initialized
DEBUG - 2013-09-04 10:47:07 --> Security Class Initialized
DEBUG - 2013-09-04 10:47:07 --> Input Class Initialized
DEBUG - 2013-09-04 10:47:07 --> XSS Filtering completed
DEBUG - 2013-09-04 10:47:07 --> XSS Filtering completed
DEBUG - 2013-09-04 10:47:07 --> XSS Filtering completed
DEBUG - 2013-09-04 10:47:07 --> XSS Filtering completed
DEBUG - 2013-09-04 10:47:07 --> XSS Filtering completed
DEBUG - 2013-09-04 10:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 10:47:07 --> Language Class Initialized
DEBUG - 2013-09-04 10:47:07 --> Loader Class Initialized
DEBUG - 2013-09-04 10:47:07 --> Helper loaded: url_helper
DEBUG - 2013-09-04 10:47:07 --> Helper loaded: file_helper
DEBUG - 2013-09-04 10:47:07 --> Helper loaded: form_helper
DEBUG - 2013-09-04 10:47:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 10:47:07 --> Helper loaded: application_helper
DEBUG - 2013-09-04 10:47:07 --> Database Driver Class Initialized
DEBUG - 2013-09-04 10:47:07 --> Session Class Initialized
DEBUG - 2013-09-04 10:47:07 --> Helper loaded: string_helper
DEBUG - 2013-09-04 10:47:07 --> Session routines successfully run
DEBUG - 2013-09-04 10:47:07 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 10:47:07 --> Controller Class Initialized
ERROR - 2013-09-04 10:47:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:47:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:47:07 --> Model Class Initialized
DEBUG - 2013-09-04 10:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 10:47:07 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 10:47:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 10:47:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 10:47:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:47:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:47:07 --> Model Class Initialized
DEBUG - 2013-09-04 10:47:07 --> Upload Class Initialized
DEBUG - 2013-09-04 10:58:29 --> Config Class Initialized
DEBUG - 2013-09-04 10:58:29 --> Hooks Class Initialized
DEBUG - 2013-09-04 10:58:29 --> Utf8 Class Initialized
DEBUG - 2013-09-04 10:58:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 10:58:29 --> URI Class Initialized
DEBUG - 2013-09-04 10:58:29 --> Router Class Initialized
DEBUG - 2013-09-04 10:58:29 --> Output Class Initialized
DEBUG - 2013-09-04 10:58:29 --> Security Class Initialized
DEBUG - 2013-09-04 10:58:29 --> Input Class Initialized
DEBUG - 2013-09-04 10:58:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:58:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:58:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:58:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:58:29 --> XSS Filtering completed
DEBUG - 2013-09-04 10:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 10:58:29 --> Language Class Initialized
DEBUG - 2013-09-04 10:58:29 --> Loader Class Initialized
DEBUG - 2013-09-04 10:58:29 --> Helper loaded: url_helper
DEBUG - 2013-09-04 10:58:30 --> Helper loaded: file_helper
DEBUG - 2013-09-04 10:58:30 --> Helper loaded: form_helper
DEBUG - 2013-09-04 10:58:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 10:58:30 --> Helper loaded: application_helper
DEBUG - 2013-09-04 10:58:30 --> Database Driver Class Initialized
DEBUG - 2013-09-04 10:58:30 --> Session Class Initialized
DEBUG - 2013-09-04 10:58:30 --> Helper loaded: string_helper
DEBUG - 2013-09-04 10:58:30 --> Session routines successfully run
DEBUG - 2013-09-04 10:58:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 10:58:30 --> Controller Class Initialized
ERROR - 2013-09-04 10:58:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:58:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:58:31 --> Model Class Initialized
DEBUG - 2013-09-04 10:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 10:58:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 10:58:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 10:58:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 10:58:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 10:58:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 10:58:31 --> Model Class Initialized
DEBUG - 2013-09-04 10:58:31 --> Upload Class Initialized
ERROR - 2013-09-04 10:58:31 --> Severity: Notice  --> Undefined property: absensis::$excel_reader C:\xampp\htdocs\school\application\controllers\guru\absensis.php 48
DEBUG - 2013-09-04 11:00:08 --> Config Class Initialized
DEBUG - 2013-09-04 11:00:08 --> Hooks Class Initialized
DEBUG - 2013-09-04 11:00:08 --> Utf8 Class Initialized
DEBUG - 2013-09-04 11:00:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 11:00:08 --> URI Class Initialized
DEBUG - 2013-09-04 11:00:08 --> Router Class Initialized
DEBUG - 2013-09-04 11:00:08 --> Output Class Initialized
DEBUG - 2013-09-04 11:00:08 --> Security Class Initialized
DEBUG - 2013-09-04 11:00:08 --> Input Class Initialized
DEBUG - 2013-09-04 11:00:08 --> XSS Filtering completed
DEBUG - 2013-09-04 11:00:08 --> XSS Filtering completed
DEBUG - 2013-09-04 11:00:08 --> XSS Filtering completed
DEBUG - 2013-09-04 11:00:08 --> XSS Filtering completed
DEBUG - 2013-09-04 11:00:08 --> XSS Filtering completed
DEBUG - 2013-09-04 11:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 11:00:08 --> Language Class Initialized
DEBUG - 2013-09-04 11:00:08 --> Loader Class Initialized
DEBUG - 2013-09-04 11:00:08 --> Helper loaded: url_helper
DEBUG - 2013-09-04 11:00:08 --> Helper loaded: file_helper
DEBUG - 2013-09-04 11:00:09 --> Helper loaded: form_helper
DEBUG - 2013-09-04 11:00:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 11:00:09 --> Helper loaded: application_helper
DEBUG - 2013-09-04 11:00:09 --> Database Driver Class Initialized
DEBUG - 2013-09-04 11:00:09 --> Session Class Initialized
DEBUG - 2013-09-04 11:00:09 --> Helper loaded: string_helper
DEBUG - 2013-09-04 11:00:09 --> Session routines successfully run
DEBUG - 2013-09-04 11:00:09 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 11:00:09 --> Controller Class Initialized
ERROR - 2013-09-04 11:00:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:00:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:00:09 --> Model Class Initialized
DEBUG - 2013-09-04 11:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 11:00:09 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 11:00:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 11:00:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 11:00:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:00:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:00:09 --> Model Class Initialized
ERROR - 2013-09-04 11:00:09 --> Severity: Notice  --> Undefined variable: config C:\xampp\htdocs\school\application\controllers\guru\absensis.php 29
DEBUG - 2013-09-04 11:00:09 --> Upload Class Initialized
ERROR - 2013-09-04 11:00:09 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:00:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:00:09 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-09-04 11:00:09 --> The upload path does not appear to be valid.
DEBUG - 2013-09-04 11:01:38 --> Config Class Initialized
DEBUG - 2013-09-04 11:01:38 --> Hooks Class Initialized
DEBUG - 2013-09-04 11:01:38 --> Utf8 Class Initialized
DEBUG - 2013-09-04 11:01:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 11:01:38 --> URI Class Initialized
DEBUG - 2013-09-04 11:01:38 --> Router Class Initialized
DEBUG - 2013-09-04 11:01:38 --> Output Class Initialized
DEBUG - 2013-09-04 11:01:38 --> Security Class Initialized
DEBUG - 2013-09-04 11:01:38 --> Input Class Initialized
DEBUG - 2013-09-04 11:01:38 --> XSS Filtering completed
DEBUG - 2013-09-04 11:01:38 --> XSS Filtering completed
DEBUG - 2013-09-04 11:01:38 --> XSS Filtering completed
DEBUG - 2013-09-04 11:01:38 --> XSS Filtering completed
DEBUG - 2013-09-04 11:01:38 --> XSS Filtering completed
DEBUG - 2013-09-04 11:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 11:01:38 --> Language Class Initialized
DEBUG - 2013-09-04 11:01:39 --> Loader Class Initialized
DEBUG - 2013-09-04 11:01:39 --> Helper loaded: url_helper
DEBUG - 2013-09-04 11:01:39 --> Helper loaded: file_helper
DEBUG - 2013-09-04 11:01:39 --> Helper loaded: form_helper
DEBUG - 2013-09-04 11:01:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 11:01:39 --> Helper loaded: application_helper
DEBUG - 2013-09-04 11:01:39 --> Database Driver Class Initialized
DEBUG - 2013-09-04 11:01:39 --> Session Class Initialized
DEBUG - 2013-09-04 11:01:39 --> Helper loaded: string_helper
DEBUG - 2013-09-04 11:01:39 --> Session routines successfully run
DEBUG - 2013-09-04 11:01:39 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 11:01:39 --> Controller Class Initialized
ERROR - 2013-09-04 11:01:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:01:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:01:39 --> Model Class Initialized
DEBUG - 2013-09-04 11:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 11:01:39 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 11:01:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 11:01:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 11:01:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:01:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:01:39 --> Model Class Initialized
DEBUG - 2013-09-04 11:01:39 --> Upload Class Initialized
ERROR - 2013-09-04 11:01:39 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:01:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:01:39 --> Severity: Warning  --> is_readable() expects parameter 1 to be a valid path, array given C:\xampp\htdocs\school\system\libraries\oleread.inc.php 49
ERROR - 2013-09-04 11:01:39 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\system\libraries\Excel_reader.php 388
DEBUG - 2013-09-04 11:03:14 --> Config Class Initialized
DEBUG - 2013-09-04 11:03:14 --> Hooks Class Initialized
DEBUG - 2013-09-04 11:03:14 --> Utf8 Class Initialized
DEBUG - 2013-09-04 11:03:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 11:03:14 --> URI Class Initialized
DEBUG - 2013-09-04 11:03:14 --> Router Class Initialized
DEBUG - 2013-09-04 11:03:14 --> Output Class Initialized
DEBUG - 2013-09-04 11:03:14 --> Security Class Initialized
DEBUG - 2013-09-04 11:03:14 --> Input Class Initialized
DEBUG - 2013-09-04 11:03:14 --> XSS Filtering completed
DEBUG - 2013-09-04 11:03:14 --> XSS Filtering completed
DEBUG - 2013-09-04 11:03:14 --> XSS Filtering completed
DEBUG - 2013-09-04 11:03:14 --> XSS Filtering completed
DEBUG - 2013-09-04 11:03:14 --> XSS Filtering completed
DEBUG - 2013-09-04 11:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 11:03:14 --> Language Class Initialized
DEBUG - 2013-09-04 11:03:14 --> Loader Class Initialized
DEBUG - 2013-09-04 11:03:14 --> Helper loaded: url_helper
DEBUG - 2013-09-04 11:03:15 --> Helper loaded: file_helper
DEBUG - 2013-09-04 11:03:15 --> Helper loaded: form_helper
DEBUG - 2013-09-04 11:03:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 11:03:15 --> Helper loaded: application_helper
DEBUG - 2013-09-04 11:03:15 --> Database Driver Class Initialized
DEBUG - 2013-09-04 11:03:15 --> Session Class Initialized
DEBUG - 2013-09-04 11:03:15 --> Helper loaded: string_helper
DEBUG - 2013-09-04 11:03:15 --> Session routines successfully run
DEBUG - 2013-09-04 11:03:15 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 11:03:15 --> Controller Class Initialized
ERROR - 2013-09-04 11:03:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:03:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:03:15 --> Model Class Initialized
DEBUG - 2013-09-04 11:03:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 11:03:15 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 11:03:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 11:03:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 11:03:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:03:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:03:15 --> Model Class Initialized
DEBUG - 2013-09-04 11:03:15 --> Upload Class Initialized
ERROR - 2013-09-04 11:03:15 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:03:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:03:15 --> Severity: Warning  --> is_readable() expects parameter 1 to be a valid path, array given C:\xampp\htdocs\school\system\libraries\oleread.inc.php 49
ERROR - 2013-09-04 11:03:15 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\system\libraries\Excel_reader.php 388
DEBUG - 2013-09-04 11:04:51 --> Config Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Hooks Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Utf8 Class Initialized
DEBUG - 2013-09-04 11:04:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 11:04:51 --> URI Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Router Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Output Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Security Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Input Class Initialized
DEBUG - 2013-09-04 11:04:51 --> XSS Filtering completed
DEBUG - 2013-09-04 11:04:51 --> XSS Filtering completed
DEBUG - 2013-09-04 11:04:51 --> XSS Filtering completed
DEBUG - 2013-09-04 11:04:51 --> XSS Filtering completed
DEBUG - 2013-09-04 11:04:51 --> XSS Filtering completed
DEBUG - 2013-09-04 11:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 11:04:51 --> Language Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Loader Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Helper loaded: url_helper
DEBUG - 2013-09-04 11:04:51 --> Helper loaded: file_helper
DEBUG - 2013-09-04 11:04:51 --> Helper loaded: form_helper
DEBUG - 2013-09-04 11:04:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 11:04:51 --> Helper loaded: application_helper
DEBUG - 2013-09-04 11:04:51 --> Database Driver Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Session Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Helper loaded: string_helper
DEBUG - 2013-09-04 11:04:51 --> Session routines successfully run
DEBUG - 2013-09-04 11:04:51 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 11:04:51 --> Controller Class Initialized
ERROR - 2013-09-04 11:04:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:04:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:04:51 --> Model Class Initialized
DEBUG - 2013-09-04 11:04:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 11:04:52 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 11:04:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 11:04:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 11:04:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:04:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:04:52 --> Model Class Initialized
DEBUG - 2013-09-04 11:04:52 --> Upload Class Initialized
ERROR - 2013-09-04 11:04:52 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:04:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:04:52 --> Severity: Notice  --> Undefined index: full_path C:\xampp\htdocs\school\application\controllers\guru\absensis.php 53
DEBUG - 2013-09-04 11:05:39 --> Config Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Hooks Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Utf8 Class Initialized
DEBUG - 2013-09-04 11:05:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 11:05:39 --> URI Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Router Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Output Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Security Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Input Class Initialized
DEBUG - 2013-09-04 11:05:39 --> XSS Filtering completed
DEBUG - 2013-09-04 11:05:39 --> XSS Filtering completed
DEBUG - 2013-09-04 11:05:39 --> XSS Filtering completed
DEBUG - 2013-09-04 11:05:39 --> XSS Filtering completed
DEBUG - 2013-09-04 11:05:39 --> XSS Filtering completed
DEBUG - 2013-09-04 11:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 11:05:39 --> Language Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Loader Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Helper loaded: url_helper
DEBUG - 2013-09-04 11:05:39 --> Helper loaded: file_helper
DEBUG - 2013-09-04 11:05:39 --> Helper loaded: form_helper
DEBUG - 2013-09-04 11:05:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 11:05:39 --> Helper loaded: application_helper
DEBUG - 2013-09-04 11:05:39 --> Database Driver Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Session Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Helper loaded: string_helper
DEBUG - 2013-09-04 11:05:39 --> Session routines successfully run
DEBUG - 2013-09-04 11:05:39 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 11:05:39 --> Controller Class Initialized
ERROR - 2013-09-04 11:05:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:05:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:05:39 --> Model Class Initialized
DEBUG - 2013-09-04 11:05:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 11:05:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 11:05:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 11:05:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 11:05:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:05:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:05:40 --> Model Class Initialized
DEBUG - 2013-09-04 11:05:40 --> Upload Class Initialized
ERROR - 2013-09-04 11:05:40 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:05:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:00 --> Config Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Hooks Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Utf8 Class Initialized
DEBUG - 2013-09-04 11:06:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 11:06:00 --> URI Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Router Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Output Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Security Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Input Class Initialized
DEBUG - 2013-09-04 11:06:00 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:00 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:00 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:00 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:00 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 11:06:00 --> Language Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Loader Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Helper loaded: url_helper
DEBUG - 2013-09-04 11:06:00 --> Helper loaded: file_helper
DEBUG - 2013-09-04 11:06:00 --> Helper loaded: form_helper
DEBUG - 2013-09-04 11:06:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 11:06:00 --> Helper loaded: application_helper
DEBUG - 2013-09-04 11:06:00 --> Database Driver Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Session Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Helper loaded: string_helper
DEBUG - 2013-09-04 11:06:00 --> Session routines successfully run
DEBUG - 2013-09-04 11:06:00 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Controller Class Initialized
ERROR - 2013-09-04 11:06:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:00 --> Model Class Initialized
DEBUG - 2013-09-04 11:06:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 11:06:00 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 11:06:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 11:06:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 11:06:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:01 --> Model Class Initialized
DEBUG - 2013-09-04 11:06:01 --> Upload Class Initialized
ERROR - 2013-09-04 11:06:01 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:01 --> Severity: Notice  --> Undefined index: file_path C:\xampp\htdocs\school\application\controllers\guru\absensis.php 47
DEBUG - 2013-09-04 11:06:15 --> Config Class Initialized
DEBUG - 2013-09-04 11:06:15 --> Hooks Class Initialized
DEBUG - 2013-09-04 11:06:15 --> Utf8 Class Initialized
DEBUG - 2013-09-04 11:06:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 11:06:15 --> URI Class Initialized
DEBUG - 2013-09-04 11:06:15 --> Router Class Initialized
DEBUG - 2013-09-04 11:06:15 --> Output Class Initialized
DEBUG - 2013-09-04 11:06:15 --> Security Class Initialized
DEBUG - 2013-09-04 11:06:15 --> Input Class Initialized
DEBUG - 2013-09-04 11:06:15 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:15 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:15 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:15 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:15 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 11:06:15 --> Language Class Initialized
DEBUG - 2013-09-04 11:06:15 --> Loader Class Initialized
DEBUG - 2013-09-04 11:06:15 --> Helper loaded: url_helper
DEBUG - 2013-09-04 11:06:15 --> Helper loaded: file_helper
DEBUG - 2013-09-04 11:06:15 --> Helper loaded: form_helper
DEBUG - 2013-09-04 11:06:16 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 11:06:16 --> Helper loaded: application_helper
DEBUG - 2013-09-04 11:06:16 --> Database Driver Class Initialized
DEBUG - 2013-09-04 11:06:16 --> Session Class Initialized
DEBUG - 2013-09-04 11:06:16 --> Helper loaded: string_helper
DEBUG - 2013-09-04 11:06:16 --> Session routines successfully run
DEBUG - 2013-09-04 11:06:16 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 11:06:16 --> Controller Class Initialized
ERROR - 2013-09-04 11:06:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:16 --> Model Class Initialized
DEBUG - 2013-09-04 11:06:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 11:06:16 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 11:06:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 11:06:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 11:06:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:16 --> Model Class Initialized
DEBUG - 2013-09-04 11:06:16 --> Upload Class Initialized
ERROR - 2013-09-04 11:06:16 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:42 --> Config Class Initialized
DEBUG - 2013-09-04 11:06:42 --> Hooks Class Initialized
DEBUG - 2013-09-04 11:06:42 --> Utf8 Class Initialized
DEBUG - 2013-09-04 11:06:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 11:06:42 --> URI Class Initialized
DEBUG - 2013-09-04 11:06:42 --> Router Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Output Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Security Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Input Class Initialized
DEBUG - 2013-09-04 11:06:43 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:43 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:43 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:43 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:43 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 11:06:43 --> Language Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Loader Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Helper loaded: url_helper
DEBUG - 2013-09-04 11:06:43 --> Helper loaded: file_helper
DEBUG - 2013-09-04 11:06:43 --> Helper loaded: form_helper
DEBUG - 2013-09-04 11:06:43 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 11:06:43 --> Helper loaded: application_helper
DEBUG - 2013-09-04 11:06:43 --> Database Driver Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Session Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Helper loaded: string_helper
DEBUG - 2013-09-04 11:06:43 --> Session routines successfully run
DEBUG - 2013-09-04 11:06:43 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Controller Class Initialized
ERROR - 2013-09-04 11:06:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:43 --> Model Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 11:06:43 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 11:06:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 11:06:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 11:06:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:43 --> Model Class Initialized
DEBUG - 2013-09-04 11:06:43 --> Upload Class Initialized
ERROR - 2013-09-04 11:06:43 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:56 --> Config Class Initialized
DEBUG - 2013-09-04 11:06:56 --> Hooks Class Initialized
DEBUG - 2013-09-04 11:06:56 --> Utf8 Class Initialized
DEBUG - 2013-09-04 11:06:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 11:06:57 --> URI Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Router Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Output Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Security Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Input Class Initialized
DEBUG - 2013-09-04 11:06:57 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:57 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:57 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:57 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:57 --> XSS Filtering completed
DEBUG - 2013-09-04 11:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 11:06:57 --> Language Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Loader Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Helper loaded: url_helper
DEBUG - 2013-09-04 11:06:57 --> Helper loaded: file_helper
DEBUG - 2013-09-04 11:06:57 --> Helper loaded: form_helper
DEBUG - 2013-09-04 11:06:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 11:06:57 --> Helper loaded: application_helper
DEBUG - 2013-09-04 11:06:57 --> Database Driver Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Session Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Helper loaded: string_helper
DEBUG - 2013-09-04 11:06:57 --> Session routines successfully run
DEBUG - 2013-09-04 11:06:57 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Controller Class Initialized
ERROR - 2013-09-04 11:06:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:57 --> Model Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 11:06:57 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 11:06:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 11:06:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 11:06:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 11:06:57 --> Model Class Initialized
DEBUG - 2013-09-04 11:06:57 --> Upload Class Initialized
ERROR - 2013-09-04 11:06:57 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 11:06:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:05 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:06 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:06 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:06 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:06 --> Router Class Initialized
DEBUG - 2013-09-04 14:47:06 --> Output Class Initialized
DEBUG - 2013-09-04 14:47:06 --> Security Class Initialized
DEBUG - 2013-09-04 14:47:06 --> Input Class Initialized
DEBUG - 2013-09-04 14:47:06 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:06 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:06 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:06 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 14:47:06 --> Language Class Initialized
DEBUG - 2013-09-04 14:47:06 --> Loader Class Initialized
DEBUG - 2013-09-04 14:47:06 --> Helper loaded: url_helper
DEBUG - 2013-09-04 14:47:06 --> Helper loaded: file_helper
DEBUG - 2013-09-04 14:47:06 --> Helper loaded: form_helper
DEBUG - 2013-09-04 14:47:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 14:47:06 --> Helper loaded: application_helper
DEBUG - 2013-09-04 14:47:06 --> Database Driver Class Initialized
DEBUG - 2013-09-04 14:47:07 --> Session Class Initialized
DEBUG - 2013-09-04 14:47:07 --> Helper loaded: string_helper
DEBUG - 2013-09-04 14:47:07 --> A session cookie was not found.
DEBUG - 2013-09-04 14:47:07 --> Session garbage collection performed.
DEBUG - 2013-09-04 14:47:07 --> Session routines successfully run
DEBUG - 2013-09-04 14:47:07 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 14:47:07 --> Controller Class Initialized
ERROR - 2013-09-04 14:47:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:07 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 14:47:07 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 14:47:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 14:47:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 14:47:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:08 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:08 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Router Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Output Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Security Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Input Class Initialized
DEBUG - 2013-09-04 14:47:08 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:08 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 14:47:08 --> Language Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Loader Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Helper loaded: url_helper
DEBUG - 2013-09-04 14:47:08 --> Helper loaded: file_helper
DEBUG - 2013-09-04 14:47:08 --> Helper loaded: form_helper
DEBUG - 2013-09-04 14:47:08 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 14:47:08 --> Helper loaded: application_helper
DEBUG - 2013-09-04 14:47:08 --> Database Driver Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Session Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Helper loaded: string_helper
DEBUG - 2013-09-04 14:47:08 --> Session routines successfully run
DEBUG - 2013-09-04 14:47:08 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Controller Class Initialized
ERROR - 2013-09-04 14:47:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:08 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 14:47:08 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 14:47:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 14:47:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 14:47:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 14:47:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 14:47:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 14:47:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 14:47:09 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-04 14:47:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 14:47:09 --> Final output sent to browser
DEBUG - 2013-09-04 14:47:09 --> Total execution time: 0.8801
DEBUG - 2013-09-04 14:47:09 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:09 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:09 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:09 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:09 --> Router Class Initialized
ERROR - 2013-09-04 14:47:09 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 14:47:20 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:20 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:20 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:21 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Router Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Output Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Security Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Input Class Initialized
DEBUG - 2013-09-04 14:47:21 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:21 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:21 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:21 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:21 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:21 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 14:47:21 --> Language Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Loader Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Helper loaded: url_helper
DEBUG - 2013-09-04 14:47:21 --> Helper loaded: file_helper
DEBUG - 2013-09-04 14:47:21 --> Helper loaded: form_helper
DEBUG - 2013-09-04 14:47:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 14:47:21 --> Helper loaded: application_helper
DEBUG - 2013-09-04 14:47:21 --> Database Driver Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Session Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Helper loaded: string_helper
DEBUG - 2013-09-04 14:47:21 --> Session routines successfully run
DEBUG - 2013-09-04 14:47:21 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Controller Class Initialized
ERROR - 2013-09-04 14:47:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:21 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 14:47:21 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 14:47:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 14:47:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 14:47:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:21 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Form Validation Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-04 14:47:21 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:21 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:22 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Router Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Output Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Security Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Input Class Initialized
DEBUG - 2013-09-04 14:47:22 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:22 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:22 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:22 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:22 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 14:47:22 --> Language Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Loader Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Helper loaded: url_helper
DEBUG - 2013-09-04 14:47:22 --> Helper loaded: file_helper
DEBUG - 2013-09-04 14:47:22 --> Helper loaded: form_helper
DEBUG - 2013-09-04 14:47:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 14:47:22 --> Helper loaded: application_helper
DEBUG - 2013-09-04 14:47:22 --> Database Driver Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Session Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Helper loaded: string_helper
DEBUG - 2013-09-04 14:47:22 --> Session routines successfully run
DEBUG - 2013-09-04 14:47:22 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Controller Class Initialized
ERROR - 2013-09-04 14:47:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:22 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 14:47:22 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 14:47:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 14:47:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 14:47:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:22 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:22 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Router Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Output Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Security Class Initialized
DEBUG - 2013-09-04 14:47:22 --> Input Class Initialized
DEBUG - 2013-09-04 14:47:23 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:23 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:23 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:23 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:23 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 14:47:23 --> Language Class Initialized
DEBUG - 2013-09-04 14:47:23 --> Loader Class Initialized
DEBUG - 2013-09-04 14:47:23 --> Helper loaded: url_helper
DEBUG - 2013-09-04 14:47:23 --> Helper loaded: file_helper
DEBUG - 2013-09-04 14:47:23 --> Helper loaded: form_helper
DEBUG - 2013-09-04 14:47:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 14:47:23 --> Helper loaded: application_helper
DEBUG - 2013-09-04 14:47:23 --> Database Driver Class Initialized
DEBUG - 2013-09-04 14:47:23 --> Session Class Initialized
DEBUG - 2013-09-04 14:47:23 --> Helper loaded: string_helper
DEBUG - 2013-09-04 14:47:23 --> Session routines successfully run
DEBUG - 2013-09-04 14:47:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 14:47:23 --> Controller Class Initialized
ERROR - 2013-09-04 14:47:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:23 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 14:47:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 14:47:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 14:47:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 14:47:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:23 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 14:47:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 14:47:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 14:47:23 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 14:47:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 14:47:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 14:47:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-04 14:47:24 --> File loaded: application/views/home.php
DEBUG - 2013-09-04 14:47:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 14:47:24 --> Final output sent to browser
DEBUG - 2013-09-04 14:47:24 --> Total execution time: 1.2761
DEBUG - 2013-09-04 14:47:24 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:24 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:24 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:24 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:24 --> Router Class Initialized
ERROR - 2013-09-04 14:47:24 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 14:47:30 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:30 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Router Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Output Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Security Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Input Class Initialized
DEBUG - 2013-09-04 14:47:30 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:30 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:30 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:30 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:30 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 14:47:30 --> Language Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Loader Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Helper loaded: url_helper
DEBUG - 2013-09-04 14:47:30 --> Helper loaded: file_helper
DEBUG - 2013-09-04 14:47:30 --> Helper loaded: form_helper
DEBUG - 2013-09-04 14:47:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 14:47:30 --> Helper loaded: application_helper
DEBUG - 2013-09-04 14:47:30 --> Database Driver Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Session Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Helper loaded: string_helper
DEBUG - 2013-09-04 14:47:30 --> Session routines successfully run
DEBUG - 2013-09-04 14:47:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Controller Class Initialized
ERROR - 2013-09-04 14:47:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:30 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 14:47:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 14:47:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 14:47:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 14:47:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:31 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:31 --> Pagination Class Initialized
ERROR - 2013-09-04 14:47:31 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-04 14:47:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-04 14:47:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-04 14:47:31 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-04 14:47:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-04 14:47:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-04 14:47:31 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-04 14:47:31 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 14:47:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 14:47:31 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 14:47:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 14:47:31 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 14:47:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 14:47:31 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 14:47:31 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 14:47:32 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 14:47:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 14:47:32 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 14:47:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 14:47:32 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 14:47:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-04 14:47:32 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 14:47:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-04 14:47:32 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\absensis\index.php 138
DEBUG - 2013-09-04 14:47:32 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-04 14:47:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-04 14:47:32 --> Final output sent to browser
DEBUG - 2013-09-04 14:47:32 --> Total execution time: 1.8251
DEBUG - 2013-09-04 14:47:32 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:32 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:32 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:32 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:32 --> Router Class Initialized
ERROR - 2013-09-04 14:47:32 --> 404 Page Not Found --> css
DEBUG - 2013-09-04 14:47:35 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:35 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Router Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Output Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Security Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Input Class Initialized
DEBUG - 2013-09-04 14:47:35 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:35 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:35 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:35 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:35 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 14:47:35 --> Language Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Loader Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Helper loaded: url_helper
DEBUG - 2013-09-04 14:47:35 --> Helper loaded: file_helper
DEBUG - 2013-09-04 14:47:35 --> Helper loaded: form_helper
DEBUG - 2013-09-04 14:47:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 14:47:35 --> Helper loaded: application_helper
DEBUG - 2013-09-04 14:47:35 --> Database Driver Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Session Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Helper loaded: string_helper
DEBUG - 2013-09-04 14:47:35 --> Session garbage collection performed.
DEBUG - 2013-09-04 14:47:35 --> Session routines successfully run
DEBUG - 2013-09-04 14:47:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 14:47:35 --> Controller Class Initialized
ERROR - 2013-09-04 14:47:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:36 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 14:47:36 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 14:47:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 14:47:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 14:47:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:36 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:36 --> Upload Class Initialized
ERROR - 2013-09-04 14:47:36 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:36 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-09-04 14:47:36 --> You did not select a file to upload.
DEBUG - 2013-09-04 14:47:48 --> Config Class Initialized
DEBUG - 2013-09-04 14:47:48 --> Hooks Class Initialized
DEBUG - 2013-09-04 14:47:48 --> Utf8 Class Initialized
DEBUG - 2013-09-04 14:47:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-04 14:47:48 --> URI Class Initialized
DEBUG - 2013-09-04 14:47:48 --> Router Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Output Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Security Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Input Class Initialized
DEBUG - 2013-09-04 14:47:49 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:49 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:49 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:49 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:49 --> XSS Filtering completed
DEBUG - 2013-09-04 14:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-04 14:47:49 --> Language Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Loader Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Helper loaded: url_helper
DEBUG - 2013-09-04 14:47:49 --> Helper loaded: file_helper
DEBUG - 2013-09-04 14:47:49 --> Helper loaded: form_helper
DEBUG - 2013-09-04 14:47:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-04 14:47:49 --> Helper loaded: application_helper
DEBUG - 2013-09-04 14:47:49 --> Database Driver Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Session Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Helper loaded: string_helper
DEBUG - 2013-09-04 14:47:49 --> Session routines successfully run
DEBUG - 2013-09-04 14:47:49 --> XML-RPC Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Controller Class Initialized
ERROR - 2013-09-04 14:47:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:49 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-04 14:47:49 --> Helper loaded: cookie_helper
DEBUG - 2013-09-04 14:47:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-04 14:47:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-04 14:47:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-04 14:47:49 --> Model Class Initialized
DEBUG - 2013-09-04 14:47:49 --> Upload Class Initialized
ERROR - 2013-09-04 14:47:49 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-04 14:47:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
