<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-18 05:47:56 --> Config Class Initialized
DEBUG - 2013-08-18 05:47:56 --> Hooks Class Initialized
DEBUG - 2013-08-18 05:47:56 --> Utf8 Class Initialized
DEBUG - 2013-08-18 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 05:47:56 --> URI Class Initialized
DEBUG - 2013-08-18 05:47:56 --> Router Class Initialized
DEBUG - 2013-08-18 05:47:56 --> Output Class Initialized
DEBUG - 2013-08-18 05:47:56 --> Security Class Initialized
DEBUG - 2013-08-18 05:47:56 --> Input Class Initialized
DEBUG - 2013-08-18 05:47:56 --> XSS Filtering completed
DEBUG - 2013-08-18 05:47:56 --> XSS Filtering completed
DEBUG - 2013-08-18 05:47:56 --> XSS Filtering completed
DEBUG - 2013-08-18 05:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 05:47:56 --> Language Class Initialized
DEBUG - 2013-08-18 05:47:56 --> Loader Class Initialized
DEBUG - 2013-08-18 05:47:56 --> Helper loaded: url_helper
DEBUG - 2013-08-18 05:47:56 --> Helper loaded: file_helper
DEBUG - 2013-08-18 05:47:56 --> Helper loaded: form_helper
DEBUG - 2013-08-18 05:47:56 --> Database Driver Class Initialized
DEBUG - 2013-08-18 05:47:57 --> Session Class Initialized
DEBUG - 2013-08-18 05:47:57 --> Helper loaded: string_helper
DEBUG - 2013-08-18 05:47:57 --> A session cookie was not found.
DEBUG - 2013-08-18 05:47:57 --> Session routines successfully run
DEBUG - 2013-08-18 05:47:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 05:47:57 --> Controller Class Initialized
ERROR - 2013-08-18 05:47:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 05:47:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 05:47:57 --> Model Class Initialized
DEBUG - 2013-08-18 05:47:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 05:47:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 05:47:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 05:47:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 05:47:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 05:47:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 05:47:57 --> Pagination Class Initialized
DEBUG - 2013-08-18 05:47:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 05:47:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 05:47:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 05:47:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 05:47:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 05:47:58 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 05:47:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 05:47:58 --> Final output sent to browser
DEBUG - 2013-08-18 05:47:58 --> Total execution time: 2.2211
DEBUG - 2013-08-18 05:47:58 --> Config Class Initialized
DEBUG - 2013-08-18 05:47:58 --> Hooks Class Initialized
DEBUG - 2013-08-18 05:47:58 --> Utf8 Class Initialized
DEBUG - 2013-08-18 05:47:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 05:47:58 --> URI Class Initialized
DEBUG - 2013-08-18 05:47:58 --> Router Class Initialized
ERROR - 2013-08-18 05:47:58 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 06:47:57 --> Config Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:47:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:47:57 --> URI Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Router Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Output Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Security Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Input Class Initialized
DEBUG - 2013-08-18 06:47:57 --> XSS Filtering completed
DEBUG - 2013-08-18 06:47:57 --> XSS Filtering completed
DEBUG - 2013-08-18 06:47:57 --> XSS Filtering completed
DEBUG - 2013-08-18 06:47:57 --> XSS Filtering completed
DEBUG - 2013-08-18 06:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 06:47:57 --> Language Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Loader Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Helper loaded: url_helper
DEBUG - 2013-08-18 06:47:57 --> Helper loaded: file_helper
DEBUG - 2013-08-18 06:47:57 --> Helper loaded: form_helper
DEBUG - 2013-08-18 06:47:57 --> Database Driver Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Session Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Helper loaded: string_helper
DEBUG - 2013-08-18 06:47:57 --> Session routines successfully run
DEBUG - 2013-08-18 06:47:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 06:47:57 --> Controller Class Initialized
ERROR - 2013-08-18 06:47:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:47:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:47:57 --> Model Class Initialized
DEBUG - 2013-08-18 06:47:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 06:47:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 06:47:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 06:47:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 06:47:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:47:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:47:58 --> Pagination Class Initialized
DEBUG - 2013-08-18 06:47:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 06:47:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 06:47:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 06:47:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 06:47:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 06:47:58 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 06:47:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 06:47:58 --> Final output sent to browser
DEBUG - 2013-08-18 06:47:58 --> Total execution time: 0.3030
DEBUG - 2013-08-18 06:47:58 --> Config Class Initialized
DEBUG - 2013-08-18 06:47:58 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:47:58 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:47:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:47:58 --> URI Class Initialized
DEBUG - 2013-08-18 06:47:58 --> Router Class Initialized
ERROR - 2013-08-18 06:47:58 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 06:48:07 --> Config Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:48:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:48:07 --> URI Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Router Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Output Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Security Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Input Class Initialized
DEBUG - 2013-08-18 06:48:07 --> XSS Filtering completed
DEBUG - 2013-08-18 06:48:07 --> XSS Filtering completed
DEBUG - 2013-08-18 06:48:07 --> XSS Filtering completed
DEBUG - 2013-08-18 06:48:07 --> XSS Filtering completed
DEBUG - 2013-08-18 06:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 06:48:07 --> Language Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Loader Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Helper loaded: url_helper
DEBUG - 2013-08-18 06:48:07 --> Helper loaded: file_helper
DEBUG - 2013-08-18 06:48:07 --> Helper loaded: form_helper
DEBUG - 2013-08-18 06:48:07 --> Database Driver Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Session Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Helper loaded: string_helper
DEBUG - 2013-08-18 06:48:07 --> Session routines successfully run
DEBUG - 2013-08-18 06:48:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Controller Class Initialized
ERROR - 2013-08-18 06:48:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:48:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:48:07 --> Model Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 06:48:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 06:48:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 06:48:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 06:48:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:48:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:48:07 --> Pagination Class Initialized
DEBUG - 2013-08-18 06:48:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 06:48:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 06:48:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 06:48:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 06:48:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 06:48:07 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 06:48:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 06:48:07 --> Final output sent to browser
DEBUG - 2013-08-18 06:48:07 --> Total execution time: 0.2100
DEBUG - 2013-08-18 06:48:07 --> Config Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:48:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:48:07 --> URI Class Initialized
DEBUG - 2013-08-18 06:48:07 --> Router Class Initialized
ERROR - 2013-08-18 06:48:07 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 06:48:14 --> Config Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:48:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:48:14 --> URI Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Router Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Output Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Security Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Input Class Initialized
DEBUG - 2013-08-18 06:48:14 --> XSS Filtering completed
DEBUG - 2013-08-18 06:48:14 --> XSS Filtering completed
DEBUG - 2013-08-18 06:48:14 --> XSS Filtering completed
DEBUG - 2013-08-18 06:48:14 --> XSS Filtering completed
DEBUG - 2013-08-18 06:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 06:48:14 --> Language Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Loader Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Helper loaded: url_helper
DEBUG - 2013-08-18 06:48:14 --> Helper loaded: file_helper
DEBUG - 2013-08-18 06:48:14 --> Helper loaded: form_helper
DEBUG - 2013-08-18 06:48:14 --> Database Driver Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Session Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Helper loaded: string_helper
DEBUG - 2013-08-18 06:48:14 --> Session routines successfully run
DEBUG - 2013-08-18 06:48:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Controller Class Initialized
ERROR - 2013-08-18 06:48:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:48:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:48:14 --> Model Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 06:48:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 06:48:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 06:48:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 06:48:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:48:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:48:14 --> Pagination Class Initialized
DEBUG - 2013-08-18 06:48:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 06:48:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 06:48:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 06:48:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 06:48:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 06:48:14 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 06:48:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 06:48:14 --> Final output sent to browser
DEBUG - 2013-08-18 06:48:14 --> Total execution time: 0.2180
DEBUG - 2013-08-18 06:48:14 --> Config Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:48:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:48:14 --> URI Class Initialized
DEBUG - 2013-08-18 06:48:14 --> Router Class Initialized
ERROR - 2013-08-18 06:48:14 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 06:49:58 --> Config Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:49:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:49:58 --> URI Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Router Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Output Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Security Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Input Class Initialized
DEBUG - 2013-08-18 06:49:58 --> XSS Filtering completed
DEBUG - 2013-08-18 06:49:58 --> XSS Filtering completed
DEBUG - 2013-08-18 06:49:58 --> XSS Filtering completed
DEBUG - 2013-08-18 06:49:58 --> XSS Filtering completed
DEBUG - 2013-08-18 06:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 06:49:58 --> Language Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Loader Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Helper loaded: url_helper
DEBUG - 2013-08-18 06:49:58 --> Helper loaded: file_helper
DEBUG - 2013-08-18 06:49:58 --> Helper loaded: form_helper
DEBUG - 2013-08-18 06:49:58 --> Database Driver Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Session Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Helper loaded: string_helper
DEBUG - 2013-08-18 06:49:58 --> Session garbage collection performed.
DEBUG - 2013-08-18 06:49:58 --> Session routines successfully run
DEBUG - 2013-08-18 06:49:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Controller Class Initialized
ERROR - 2013-08-18 06:49:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:49:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:49:58 --> Model Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 06:49:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 06:49:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 06:49:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 06:49:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:49:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:49:58 --> Pagination Class Initialized
DEBUG - 2013-08-18 06:49:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 06:49:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 06:49:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 06:49:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 06:49:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 06:49:58 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 06:49:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 06:49:58 --> Final output sent to browser
DEBUG - 2013-08-18 06:49:58 --> Total execution time: 0.2690
DEBUG - 2013-08-18 06:49:58 --> Config Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:49:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:49:58 --> URI Class Initialized
DEBUG - 2013-08-18 06:49:58 --> Router Class Initialized
ERROR - 2013-08-18 06:49:58 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 06:52:17 --> Config Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:52:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:52:17 --> URI Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Router Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Output Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Security Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Input Class Initialized
DEBUG - 2013-08-18 06:52:17 --> XSS Filtering completed
DEBUG - 2013-08-18 06:52:17 --> XSS Filtering completed
DEBUG - 2013-08-18 06:52:17 --> XSS Filtering completed
DEBUG - 2013-08-18 06:52:17 --> XSS Filtering completed
DEBUG - 2013-08-18 06:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 06:52:17 --> Language Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Loader Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Helper loaded: url_helper
DEBUG - 2013-08-18 06:52:17 --> Helper loaded: file_helper
DEBUG - 2013-08-18 06:52:17 --> Helper loaded: form_helper
DEBUG - 2013-08-18 06:52:17 --> Database Driver Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Session Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Helper loaded: string_helper
DEBUG - 2013-08-18 06:52:17 --> Session routines successfully run
DEBUG - 2013-08-18 06:52:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Controller Class Initialized
ERROR - 2013-08-18 06:52:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:52:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:52:17 --> Model Class Initialized
DEBUG - 2013-08-18 06:52:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 06:52:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 06:52:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 06:52:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 06:52:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:52:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:52:17 --> Pagination Class Initialized
DEBUG - 2013-08-18 06:52:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 06:52:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 06:52:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 06:52:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 06:52:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 06:52:17 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 06:52:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 06:52:18 --> Final output sent to browser
DEBUG - 2013-08-18 06:52:18 --> Total execution time: 0.2150
DEBUG - 2013-08-18 06:52:18 --> Config Class Initialized
DEBUG - 2013-08-18 06:52:18 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:52:18 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:52:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:52:18 --> URI Class Initialized
DEBUG - 2013-08-18 06:52:18 --> Router Class Initialized
ERROR - 2013-08-18 06:52:18 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 06:52:54 --> Config Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:52:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:52:54 --> URI Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Router Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Output Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Security Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Input Class Initialized
DEBUG - 2013-08-18 06:52:54 --> XSS Filtering completed
DEBUG - 2013-08-18 06:52:54 --> XSS Filtering completed
DEBUG - 2013-08-18 06:52:54 --> XSS Filtering completed
DEBUG - 2013-08-18 06:52:54 --> XSS Filtering completed
DEBUG - 2013-08-18 06:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 06:52:54 --> Language Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Loader Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Helper loaded: url_helper
DEBUG - 2013-08-18 06:52:54 --> Helper loaded: file_helper
DEBUG - 2013-08-18 06:52:54 --> Helper loaded: form_helper
DEBUG - 2013-08-18 06:52:54 --> Database Driver Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Session Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Helper loaded: string_helper
DEBUG - 2013-08-18 06:52:54 --> Session routines successfully run
DEBUG - 2013-08-18 06:52:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Controller Class Initialized
ERROR - 2013-08-18 06:52:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:52:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:52:54 --> Model Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 06:52:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 06:52:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 06:52:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 06:52:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:52:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:52:54 --> Pagination Class Initialized
DEBUG - 2013-08-18 06:52:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 06:52:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 06:52:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 06:52:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 06:52:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 06:52:54 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 06:52:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 06:52:54 --> Final output sent to browser
DEBUG - 2013-08-18 06:52:54 --> Total execution time: 0.2610
DEBUG - 2013-08-18 06:52:54 --> Config Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:52:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:52:54 --> URI Class Initialized
DEBUG - 2013-08-18 06:52:54 --> Router Class Initialized
ERROR - 2013-08-18 06:52:54 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 06:53:02 --> Config Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:53:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:53:02 --> URI Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Router Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Output Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Security Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Input Class Initialized
DEBUG - 2013-08-18 06:53:02 --> XSS Filtering completed
DEBUG - 2013-08-18 06:53:02 --> XSS Filtering completed
DEBUG - 2013-08-18 06:53:02 --> XSS Filtering completed
DEBUG - 2013-08-18 06:53:02 --> XSS Filtering completed
DEBUG - 2013-08-18 06:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 06:53:02 --> Language Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Loader Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Helper loaded: url_helper
DEBUG - 2013-08-18 06:53:02 --> Helper loaded: file_helper
DEBUG - 2013-08-18 06:53:02 --> Helper loaded: form_helper
DEBUG - 2013-08-18 06:53:02 --> Database Driver Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Session Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Helper loaded: string_helper
DEBUG - 2013-08-18 06:53:02 --> Session routines successfully run
DEBUG - 2013-08-18 06:53:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Controller Class Initialized
ERROR - 2013-08-18 06:53:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:53:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:53:02 --> Model Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 06:53:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 06:53:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 06:53:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 06:53:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 06:53:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 06:53:02 --> Pagination Class Initialized
DEBUG - 2013-08-18 06:53:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 06:53:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 06:53:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 06:53:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 06:53:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 06:53:02 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 06:53:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 06:53:02 --> Final output sent to browser
DEBUG - 2013-08-18 06:53:02 --> Total execution time: 0.2880
DEBUG - 2013-08-18 06:53:02 --> Config Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Hooks Class Initialized
DEBUG - 2013-08-18 06:53:02 --> Utf8 Class Initialized
DEBUG - 2013-08-18 06:53:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 06:53:02 --> URI Class Initialized
DEBUG - 2013-08-18 06:53:03 --> Router Class Initialized
ERROR - 2013-08-18 06:53:03 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:27:06 --> Config Class Initialized
DEBUG - 2013-08-18 07:27:06 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:27:06 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:27:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:27:06 --> URI Class Initialized
DEBUG - 2013-08-18 07:27:06 --> Router Class Initialized
DEBUG - 2013-08-18 07:27:06 --> Output Class Initialized
DEBUG - 2013-08-18 07:27:06 --> Security Class Initialized
DEBUG - 2013-08-18 07:27:06 --> Input Class Initialized
DEBUG - 2013-08-18 07:27:06 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:06 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:06 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:06 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:27:06 --> Language Class Initialized
DEBUG - 2013-08-18 07:27:06 --> Loader Class Initialized
DEBUG - 2013-08-18 07:27:06 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:27:06 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:27:06 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:27:07 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:27:07 --> Session Class Initialized
DEBUG - 2013-08-18 07:27:07 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:27:07 --> Session routines successfully run
DEBUG - 2013-08-18 07:27:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:27:07 --> Controller Class Initialized
ERROR - 2013-08-18 07:27:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:27:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:27:07 --> Model Class Initialized
DEBUG - 2013-08-18 07:27:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:27:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:27:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:27:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:27:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:27:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:27:07 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:27:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:27:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:27:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:27:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:27:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:27:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:27:07 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:27:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:27:08 --> Final output sent to browser
DEBUG - 2013-08-18 07:27:08 --> Total execution time: 1.7061
DEBUG - 2013-08-18 07:27:08 --> Config Class Initialized
DEBUG - 2013-08-18 07:27:08 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:27:08 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:27:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:27:08 --> URI Class Initialized
DEBUG - 2013-08-18 07:27:08 --> Router Class Initialized
ERROR - 2013-08-18 07:27:08 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:27:30 --> Config Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:27:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:27:30 --> URI Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Router Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Output Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Security Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Input Class Initialized
DEBUG - 2013-08-18 07:27:30 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:30 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:30 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:30 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:27:30 --> Language Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Loader Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:27:30 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:27:30 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:27:30 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Session Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:27:30 --> Session routines successfully run
DEBUG - 2013-08-18 07:27:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Controller Class Initialized
ERROR - 2013-08-18 07:27:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:27:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:27:30 --> Model Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:27:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:27:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:27:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:27:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:27:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:27:30 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:27:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:27:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:27:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:27:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:27:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:27:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:27:30 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:27:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:27:30 --> Final output sent to browser
DEBUG - 2013-08-18 07:27:30 --> Total execution time: 0.3130
DEBUG - 2013-08-18 07:27:30 --> Config Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:27:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:27:30 --> URI Class Initialized
DEBUG - 2013-08-18 07:27:30 --> Router Class Initialized
ERROR - 2013-08-18 07:27:30 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:27:42 --> Config Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:27:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:27:42 --> URI Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Router Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Output Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Security Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Input Class Initialized
DEBUG - 2013-08-18 07:27:42 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:42 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:42 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:42 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:27:42 --> Language Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Loader Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:27:42 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:27:42 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:27:42 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Session Class Initialized
DEBUG - 2013-08-18 07:27:42 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:27:42 --> Session routines successfully run
DEBUG - 2013-08-18 07:27:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:27:43 --> Controller Class Initialized
ERROR - 2013-08-18 07:27:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:27:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:27:43 --> Model Class Initialized
DEBUG - 2013-08-18 07:27:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:27:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:27:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:27:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:27:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:27:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:27:43 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:27:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:27:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:27:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:27:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:27:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:27:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:27:43 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:27:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:27:43 --> Final output sent to browser
DEBUG - 2013-08-18 07:27:43 --> Total execution time: 0.3410
DEBUG - 2013-08-18 07:27:43 --> Config Class Initialized
DEBUG - 2013-08-18 07:27:43 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:27:43 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:27:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:27:43 --> URI Class Initialized
DEBUG - 2013-08-18 07:27:43 --> Router Class Initialized
ERROR - 2013-08-18 07:27:43 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:27:58 --> Config Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:27:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:27:58 --> URI Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Router Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Output Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Security Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Input Class Initialized
DEBUG - 2013-08-18 07:27:58 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:58 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:58 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:58 --> XSS Filtering completed
DEBUG - 2013-08-18 07:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:27:58 --> Language Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Loader Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:27:58 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:27:58 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:27:58 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Session Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:27:58 --> Session routines successfully run
DEBUG - 2013-08-18 07:27:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Controller Class Initialized
ERROR - 2013-08-18 07:27:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:27:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:27:58 --> Model Class Initialized
DEBUG - 2013-08-18 07:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:27:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:27:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:27:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:27:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:27:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:27:59 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:27:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:27:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:27:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:27:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:27:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:27:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:27:59 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:27:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:27:59 --> Final output sent to browser
DEBUG - 2013-08-18 07:27:59 --> Total execution time: 0.2900
DEBUG - 2013-08-18 07:27:59 --> Config Class Initialized
DEBUG - 2013-08-18 07:27:59 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:27:59 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:27:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:27:59 --> URI Class Initialized
DEBUG - 2013-08-18 07:27:59 --> Router Class Initialized
ERROR - 2013-08-18 07:27:59 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:28:16 --> Config Class Initialized
DEBUG - 2013-08-18 07:28:16 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:28:16 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:28:16 --> URI Class Initialized
DEBUG - 2013-08-18 07:28:16 --> Router Class Initialized
DEBUG - 2013-08-18 07:28:16 --> Output Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Security Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Input Class Initialized
DEBUG - 2013-08-18 07:28:17 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:17 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:17 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:17 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:28:17 --> Language Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Loader Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:28:17 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:28:17 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:28:17 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Session Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:28:17 --> Session routines successfully run
DEBUG - 2013-08-18 07:28:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Controller Class Initialized
ERROR - 2013-08-18 07:28:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:28:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:28:17 --> Model Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:28:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:28:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:28:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:28:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:28:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:28:17 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:28:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:28:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:28:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:28:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:28:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:28:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:28:17 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:28:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:28:17 --> Final output sent to browser
DEBUG - 2013-08-18 07:28:17 --> Total execution time: 0.3430
DEBUG - 2013-08-18 07:28:17 --> Config Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:28:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:28:17 --> URI Class Initialized
DEBUG - 2013-08-18 07:28:17 --> Router Class Initialized
ERROR - 2013-08-18 07:28:17 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:28:39 --> Config Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:28:39 --> URI Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Router Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Output Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Security Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Input Class Initialized
DEBUG - 2013-08-18 07:28:39 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:39 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:39 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:39 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:28:39 --> Language Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Loader Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:28:39 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:28:39 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:28:39 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Session Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:28:39 --> Session routines successfully run
DEBUG - 2013-08-18 07:28:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Controller Class Initialized
ERROR - 2013-08-18 07:28:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:28:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:28:39 --> Model Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:28:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:28:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:28:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:28:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:28:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:28:39 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:28:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:28:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:28:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:28:39 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:28:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:28:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:28:39 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:28:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:28:39 --> Final output sent to browser
DEBUG - 2013-08-18 07:28:39 --> Total execution time: 0.3350
DEBUG - 2013-08-18 07:28:39 --> Config Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:28:39 --> URI Class Initialized
DEBUG - 2013-08-18 07:28:39 --> Router Class Initialized
ERROR - 2013-08-18 07:28:39 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:28:54 --> Config Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:28:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:28:54 --> URI Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Router Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Output Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Security Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Input Class Initialized
DEBUG - 2013-08-18 07:28:54 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:54 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:54 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:54 --> XSS Filtering completed
DEBUG - 2013-08-18 07:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:28:54 --> Language Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Loader Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:28:54 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:28:54 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:28:54 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Session Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:28:54 --> Session routines successfully run
DEBUG - 2013-08-18 07:28:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Controller Class Initialized
ERROR - 2013-08-18 07:28:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:28:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:28:54 --> Model Class Initialized
DEBUG - 2013-08-18 07:28:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:28:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:28:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:28:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:28:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:28:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:28:54 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:28:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:28:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:28:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:28:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:28:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:28:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:28:54 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:28:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:28:54 --> Final output sent to browser
DEBUG - 2013-08-18 07:28:54 --> Total execution time: 0.3180
DEBUG - 2013-08-18 07:28:55 --> Config Class Initialized
DEBUG - 2013-08-18 07:28:55 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:28:55 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:28:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:28:55 --> URI Class Initialized
DEBUG - 2013-08-18 07:28:55 --> Router Class Initialized
ERROR - 2013-08-18 07:28:55 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:29:43 --> Config Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:29:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:29:43 --> URI Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Router Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Output Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Security Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Input Class Initialized
DEBUG - 2013-08-18 07:29:43 --> XSS Filtering completed
DEBUG - 2013-08-18 07:29:43 --> XSS Filtering completed
DEBUG - 2013-08-18 07:29:43 --> XSS Filtering completed
DEBUG - 2013-08-18 07:29:43 --> XSS Filtering completed
DEBUG - 2013-08-18 07:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:29:43 --> Language Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Loader Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:29:43 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:29:43 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:29:43 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Session Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:29:43 --> Session garbage collection performed.
DEBUG - 2013-08-18 07:29:43 --> Session routines successfully run
DEBUG - 2013-08-18 07:29:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Controller Class Initialized
ERROR - 2013-08-18 07:29:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:29:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:29:43 --> Model Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:29:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:29:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:29:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:29:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:29:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:29:43 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:29:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:29:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:29:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:29:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:29:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:29:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:29:43 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:29:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:29:43 --> Final output sent to browser
DEBUG - 2013-08-18 07:29:43 --> Total execution time: 0.3340
DEBUG - 2013-08-18 07:29:43 --> Config Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:29:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:29:43 --> URI Class Initialized
DEBUG - 2013-08-18 07:29:43 --> Router Class Initialized
ERROR - 2013-08-18 07:29:43 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:30:10 --> Config Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:30:10 --> URI Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Router Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Output Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Security Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Input Class Initialized
DEBUG - 2013-08-18 07:30:10 --> XSS Filtering completed
DEBUG - 2013-08-18 07:30:10 --> XSS Filtering completed
DEBUG - 2013-08-18 07:30:10 --> XSS Filtering completed
DEBUG - 2013-08-18 07:30:10 --> XSS Filtering completed
DEBUG - 2013-08-18 07:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:30:10 --> Language Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Loader Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:30:10 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:30:10 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:30:10 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Session Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:30:10 --> Session routines successfully run
DEBUG - 2013-08-18 07:30:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Controller Class Initialized
ERROR - 2013-08-18 07:30:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:30:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:30:10 --> Model Class Initialized
DEBUG - 2013-08-18 07:30:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:30:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:30:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:30:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:30:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:30:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:30:11 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:30:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:30:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:30:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:30:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:30:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:30:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:30:11 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:30:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:30:11 --> Final output sent to browser
DEBUG - 2013-08-18 07:30:11 --> Total execution time: 0.3430
DEBUG - 2013-08-18 07:30:11 --> Config Class Initialized
DEBUG - 2013-08-18 07:30:11 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:30:11 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:30:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:30:11 --> URI Class Initialized
DEBUG - 2013-08-18 07:30:11 --> Router Class Initialized
ERROR - 2013-08-18 07:30:11 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:32:07 --> Config Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:32:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:32:07 --> URI Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Router Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Output Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Security Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Input Class Initialized
DEBUG - 2013-08-18 07:32:07 --> XSS Filtering completed
DEBUG - 2013-08-18 07:32:07 --> XSS Filtering completed
DEBUG - 2013-08-18 07:32:07 --> XSS Filtering completed
DEBUG - 2013-08-18 07:32:07 --> XSS Filtering completed
DEBUG - 2013-08-18 07:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:32:07 --> Language Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Loader Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:32:07 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:32:07 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:32:07 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Session Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:32:07 --> Session routines successfully run
DEBUG - 2013-08-18 07:32:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Controller Class Initialized
ERROR - 2013-08-18 07:32:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:32:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:32:07 --> Model Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:32:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:32:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:32:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:32:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:32:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:32:07 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:32:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:32:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:32:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:32:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:32:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:32:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:32:07 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:32:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:32:07 --> Final output sent to browser
DEBUG - 2013-08-18 07:32:07 --> Total execution time: 0.3470
DEBUG - 2013-08-18 07:32:07 --> Config Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:32:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:32:07 --> URI Class Initialized
DEBUG - 2013-08-18 07:32:07 --> Router Class Initialized
ERROR - 2013-08-18 07:32:07 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 07:35:51 --> Config Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:35:51 --> URI Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Router Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Output Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Security Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Input Class Initialized
DEBUG - 2013-08-18 07:35:51 --> XSS Filtering completed
DEBUG - 2013-08-18 07:35:51 --> XSS Filtering completed
DEBUG - 2013-08-18 07:35:51 --> XSS Filtering completed
DEBUG - 2013-08-18 07:35:51 --> XSS Filtering completed
DEBUG - 2013-08-18 07:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 07:35:51 --> Language Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Loader Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Helper loaded: url_helper
DEBUG - 2013-08-18 07:35:51 --> Helper loaded: file_helper
DEBUG - 2013-08-18 07:35:51 --> Helper loaded: form_helper
DEBUG - 2013-08-18 07:35:51 --> Database Driver Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Session Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Helper loaded: string_helper
DEBUG - 2013-08-18 07:35:51 --> Session routines successfully run
DEBUG - 2013-08-18 07:35:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Controller Class Initialized
ERROR - 2013-08-18 07:35:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:35:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:35:51 --> Model Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 07:35:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 07:35:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 07:35:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 07:35:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 07:35:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 07:35:51 --> Pagination Class Initialized
DEBUG - 2013-08-18 07:35:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 07:35:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 07:35:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 07:35:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 07:35:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 07:35:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 07:35:51 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 07:35:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 07:35:51 --> Final output sent to browser
DEBUG - 2013-08-18 07:35:51 --> Total execution time: 0.4410
DEBUG - 2013-08-18 07:35:51 --> Config Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Hooks Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Utf8 Class Initialized
DEBUG - 2013-08-18 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 07:35:51 --> URI Class Initialized
DEBUG - 2013-08-18 07:35:51 --> Router Class Initialized
ERROR - 2013-08-18 07:35:51 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 08:08:01 --> Config Class Initialized
DEBUG - 2013-08-18 08:08:01 --> Hooks Class Initialized
DEBUG - 2013-08-18 08:08:01 --> Utf8 Class Initialized
DEBUG - 2013-08-18 08:08:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 08:08:01 --> URI Class Initialized
DEBUG - 2013-08-18 08:08:01 --> Router Class Initialized
DEBUG - 2013-08-18 08:08:01 --> Output Class Initialized
DEBUG - 2013-08-18 08:08:01 --> Security Class Initialized
DEBUG - 2013-08-18 08:08:01 --> Input Class Initialized
DEBUG - 2013-08-18 08:08:01 --> XSS Filtering completed
DEBUG - 2013-08-18 08:08:01 --> XSS Filtering completed
DEBUG - 2013-08-18 08:08:01 --> XSS Filtering completed
DEBUG - 2013-08-18 08:08:01 --> XSS Filtering completed
DEBUG - 2013-08-18 08:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 08:08:01 --> Language Class Initialized
DEBUG - 2013-08-18 08:08:02 --> Loader Class Initialized
DEBUG - 2013-08-18 08:08:02 --> Helper loaded: url_helper
DEBUG - 2013-08-18 08:08:02 --> Helper loaded: file_helper
DEBUG - 2013-08-18 08:08:02 --> Helper loaded: form_helper
DEBUG - 2013-08-18 08:08:02 --> Database Driver Class Initialized
DEBUG - 2013-08-18 08:08:02 --> Session Class Initialized
DEBUG - 2013-08-18 08:08:02 --> Helper loaded: string_helper
DEBUG - 2013-08-18 08:08:02 --> Session routines successfully run
DEBUG - 2013-08-18 08:08:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 08:08:02 --> Controller Class Initialized
ERROR - 2013-08-18 08:08:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 08:08:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 08:08:02 --> Model Class Initialized
DEBUG - 2013-08-18 08:08:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 08:08:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 08:08:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 08:08:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 08:08:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 08:08:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 08:08:02 --> Pagination Class Initialized
DEBUG - 2013-08-18 08:08:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 08:08:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 08:08:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 08:08:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 08:08:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 08:08:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 08:08:02 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 08:08:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 08:08:02 --> Final output sent to browser
DEBUG - 2013-08-18 08:08:02 --> Total execution time: 1.3281
DEBUG - 2013-08-18 08:08:03 --> Config Class Initialized
DEBUG - 2013-08-18 08:08:03 --> Hooks Class Initialized
DEBUG - 2013-08-18 08:08:03 --> Utf8 Class Initialized
DEBUG - 2013-08-18 08:08:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 08:08:03 --> URI Class Initialized
DEBUG - 2013-08-18 08:08:03 --> Router Class Initialized
ERROR - 2013-08-18 08:08:03 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 13:45:11 --> Config Class Initialized
DEBUG - 2013-08-18 13:45:11 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:45:11 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:45:11 --> URI Class Initialized
DEBUG - 2013-08-18 13:45:11 --> Router Class Initialized
DEBUG - 2013-08-18 13:45:11 --> Output Class Initialized
DEBUG - 2013-08-18 13:45:11 --> Security Class Initialized
DEBUG - 2013-08-18 13:45:11 --> Input Class Initialized
DEBUG - 2013-08-18 13:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 13:45:11 --> Language Class Initialized
DEBUG - 2013-08-18 13:45:11 --> Loader Class Initialized
DEBUG - 2013-08-18 13:45:11 --> Helper loaded: url_helper
DEBUG - 2013-08-18 13:45:11 --> Helper loaded: file_helper
DEBUG - 2013-08-18 13:45:11 --> Helper loaded: form_helper
DEBUG - 2013-08-18 13:45:11 --> Database Driver Class Initialized
DEBUG - 2013-08-18 13:45:12 --> Session Class Initialized
DEBUG - 2013-08-18 13:45:12 --> Helper loaded: string_helper
DEBUG - 2013-08-18 13:45:12 --> A session cookie was not found.
DEBUG - 2013-08-18 13:45:12 --> Session routines successfully run
DEBUG - 2013-08-18 13:45:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 13:45:12 --> Controller Class Initialized
ERROR - 2013-08-18 13:45:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:45:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:45:12 --> Model Class Initialized
DEBUG - 2013-08-18 13:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 13:45:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 13:45:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 13:45:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 13:45:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:45:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:45:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 13:45:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 13:45:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 13:45:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 13:45:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 13:45:12 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-18 13:45:13 --> Severity: Notice  --> Undefined variable: group_name C:\xampp\htdocs\school\application\views\user_groups\new.php 8
ERROR - 2013-08-18 13:45:13 --> Severity: Notice  --> Undefined variable: group_desc C:\xampp\htdocs\school\application\views\user_groups\new.php 14
ERROR - 2013-08-18 13:45:13 --> Severity: Notice  --> Undefined variable: group_admin C:\xampp\htdocs\school\application\views\user_groups\new.php 20
DEBUG - 2013-08-18 13:45:13 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-18 13:45:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 13:45:13 --> Final output sent to browser
DEBUG - 2013-08-18 13:45:13 --> Total execution time: 2.1821
DEBUG - 2013-08-18 13:45:13 --> Config Class Initialized
DEBUG - 2013-08-18 13:45:13 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:45:13 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:45:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:45:13 --> URI Class Initialized
DEBUG - 2013-08-18 13:45:13 --> Router Class Initialized
ERROR - 2013-08-18 13:45:13 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 13:50:26 --> Config Class Initialized
DEBUG - 2013-08-18 13:50:26 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:50:26 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:50:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:50:26 --> URI Class Initialized
DEBUG - 2013-08-18 13:50:26 --> Router Class Initialized
DEBUG - 2013-08-18 13:50:26 --> Output Class Initialized
DEBUG - 2013-08-18 13:50:26 --> Security Class Initialized
DEBUG - 2013-08-18 13:50:26 --> Input Class Initialized
DEBUG - 2013-08-18 13:50:26 --> XSS Filtering completed
DEBUG - 2013-08-18 13:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 13:50:26 --> Language Class Initialized
DEBUG - 2013-08-18 13:50:26 --> Loader Class Initialized
DEBUG - 2013-08-18 13:50:26 --> Helper loaded: url_helper
DEBUG - 2013-08-18 13:50:26 --> Helper loaded: file_helper
DEBUG - 2013-08-18 13:50:26 --> Helper loaded: form_helper
DEBUG - 2013-08-18 13:50:26 --> Database Driver Class Initialized
DEBUG - 2013-08-18 13:50:27 --> Session Class Initialized
DEBUG - 2013-08-18 13:50:27 --> Helper loaded: string_helper
DEBUG - 2013-08-18 13:50:27 --> Session routines successfully run
DEBUG - 2013-08-18 13:50:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 13:50:27 --> Controller Class Initialized
ERROR - 2013-08-18 13:50:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:50:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:50:27 --> Model Class Initialized
DEBUG - 2013-08-18 13:50:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 13:50:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 13:50:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 13:50:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 13:50:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:50:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:50:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 13:50:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 13:50:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 13:50:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 13:50:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 13:50:27 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 13:50:27 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-18 13:50:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 13:50:27 --> Final output sent to browser
DEBUG - 2013-08-18 13:50:27 --> Total execution time: 0.4770
DEBUG - 2013-08-18 13:50:27 --> Config Class Initialized
DEBUG - 2013-08-18 13:50:27 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:50:27 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:50:27 --> URI Class Initialized
DEBUG - 2013-08-18 13:50:27 --> Router Class Initialized
ERROR - 2013-08-18 13:50:27 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 13:51:01 --> Config Class Initialized
DEBUG - 2013-08-18 13:51:01 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:51:01 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:51:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:51:01 --> URI Class Initialized
DEBUG - 2013-08-18 13:51:01 --> Router Class Initialized
DEBUG - 2013-08-18 13:51:01 --> Output Class Initialized
DEBUG - 2013-08-18 13:51:01 --> Security Class Initialized
DEBUG - 2013-08-18 13:51:01 --> Input Class Initialized
DEBUG - 2013-08-18 13:51:01 --> XSS Filtering completed
DEBUG - 2013-08-18 13:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 13:51:01 --> Language Class Initialized
DEBUG - 2013-08-18 13:51:01 --> Loader Class Initialized
DEBUG - 2013-08-18 13:51:02 --> Helper loaded: url_helper
DEBUG - 2013-08-18 13:51:02 --> Helper loaded: file_helper
DEBUG - 2013-08-18 13:51:02 --> Helper loaded: form_helper
DEBUG - 2013-08-18 13:51:02 --> Database Driver Class Initialized
DEBUG - 2013-08-18 13:51:02 --> Session Class Initialized
DEBUG - 2013-08-18 13:51:02 --> Helper loaded: string_helper
DEBUG - 2013-08-18 13:51:02 --> Session routines successfully run
DEBUG - 2013-08-18 13:51:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 13:51:02 --> Controller Class Initialized
ERROR - 2013-08-18 13:51:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:51:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:51:02 --> Model Class Initialized
DEBUG - 2013-08-18 13:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 13:51:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 13:51:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 13:51:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 13:51:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:51:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:51:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 13:51:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 13:51:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 13:51:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 13:51:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 13:51:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 13:51:02 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-18 13:51:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 13:51:02 --> Final output sent to browser
DEBUG - 2013-08-18 13:51:02 --> Total execution time: 0.4600
DEBUG - 2013-08-18 13:51:02 --> Config Class Initialized
DEBUG - 2013-08-18 13:51:02 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:51:02 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:51:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:51:02 --> URI Class Initialized
DEBUG - 2013-08-18 13:51:02 --> Router Class Initialized
ERROR - 2013-08-18 13:51:02 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 13:57:03 --> Config Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:57:03 --> URI Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Router Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Output Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Security Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Input Class Initialized
DEBUG - 2013-08-18 13:57:03 --> XSS Filtering completed
DEBUG - 2013-08-18 13:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 13:57:03 --> Language Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Loader Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Helper loaded: url_helper
DEBUG - 2013-08-18 13:57:03 --> Helper loaded: file_helper
DEBUG - 2013-08-18 13:57:03 --> Helper loaded: form_helper
DEBUG - 2013-08-18 13:57:03 --> Database Driver Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Session Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Helper loaded: string_helper
DEBUG - 2013-08-18 13:57:03 --> Session routines successfully run
DEBUG - 2013-08-18 13:57:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Controller Class Initialized
ERROR - 2013-08-18 13:57:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:57:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:57:03 --> Model Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 13:57:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 13:57:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 13:57:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 13:57:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:57:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:57:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 13:57:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 13:57:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 13:57:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 13:57:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 13:57:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 13:57:03 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-18 13:57:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 13:57:03 --> Final output sent to browser
DEBUG - 2013-08-18 13:57:03 --> Total execution time: 0.4360
DEBUG - 2013-08-18 13:57:03 --> Config Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:57:03 --> URI Class Initialized
DEBUG - 2013-08-18 13:57:03 --> Router Class Initialized
ERROR - 2013-08-18 13:57:03 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 13:57:34 --> Config Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:57:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:57:34 --> URI Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Router Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Output Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Security Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Input Class Initialized
DEBUG - 2013-08-18 13:57:34 --> XSS Filtering completed
DEBUG - 2013-08-18 13:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 13:57:34 --> Language Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Loader Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Helper loaded: url_helper
DEBUG - 2013-08-18 13:57:34 --> Helper loaded: file_helper
DEBUG - 2013-08-18 13:57:34 --> Helper loaded: form_helper
DEBUG - 2013-08-18 13:57:34 --> Database Driver Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Session Class Initialized
DEBUG - 2013-08-18 13:57:34 --> Helper loaded: string_helper
DEBUG - 2013-08-18 13:57:34 --> Session routines successfully run
DEBUG - 2013-08-18 13:57:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 13:57:35 --> Controller Class Initialized
ERROR - 2013-08-18 13:57:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:57:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:57:35 --> Model Class Initialized
DEBUG - 2013-08-18 13:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 13:57:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 13:57:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 13:57:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 13:57:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 13:57:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 13:57:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 13:57:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 13:57:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 13:57:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 13:57:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 13:57:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 13:57:35 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-18 13:57:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 13:57:35 --> Final output sent to browser
DEBUG - 2013-08-18 13:57:35 --> Total execution time: 0.4040
DEBUG - 2013-08-18 13:57:35 --> Config Class Initialized
DEBUG - 2013-08-18 13:57:35 --> Hooks Class Initialized
DEBUG - 2013-08-18 13:57:35 --> Utf8 Class Initialized
DEBUG - 2013-08-18 13:57:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 13:57:35 --> URI Class Initialized
DEBUG - 2013-08-18 13:57:35 --> Router Class Initialized
ERROR - 2013-08-18 13:57:35 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 14:01:42 --> Config Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Hooks Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Utf8 Class Initialized
DEBUG - 2013-08-18 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 14:01:42 --> URI Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Router Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Output Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Security Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Input Class Initialized
DEBUG - 2013-08-18 14:01:42 --> XSS Filtering completed
DEBUG - 2013-08-18 14:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 14:01:42 --> Language Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Loader Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Helper loaded: url_helper
DEBUG - 2013-08-18 14:01:42 --> Helper loaded: file_helper
DEBUG - 2013-08-18 14:01:42 --> Helper loaded: form_helper
DEBUG - 2013-08-18 14:01:42 --> Database Driver Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Session Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Helper loaded: string_helper
DEBUG - 2013-08-18 14:01:42 --> Session routines successfully run
DEBUG - 2013-08-18 14:01:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Controller Class Initialized
ERROR - 2013-08-18 14:01:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 14:01:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 14:01:42 --> Model Class Initialized
DEBUG - 2013-08-18 14:01:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 14:01:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 14:01:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 14:01:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 14:01:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 14:01:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 14:01:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 14:01:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 14:01:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 14:01:42 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 14:01:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 14:01:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 14:01:42 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-18 14:01:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 14:01:42 --> Final output sent to browser
DEBUG - 2013-08-18 14:01:42 --> Total execution time: 0.4060
DEBUG - 2013-08-18 14:01:43 --> Config Class Initialized
DEBUG - 2013-08-18 14:01:43 --> Hooks Class Initialized
DEBUG - 2013-08-18 14:01:43 --> Utf8 Class Initialized
DEBUG - 2013-08-18 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 14:01:43 --> URI Class Initialized
DEBUG - 2013-08-18 14:01:43 --> Router Class Initialized
ERROR - 2013-08-18 14:01:43 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:15:57 --> Config Class Initialized
DEBUG - 2013-08-18 18:15:57 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:15:57 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:15:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:15:57 --> URI Class Initialized
DEBUG - 2013-08-18 18:15:57 --> Router Class Initialized
DEBUG - 2013-08-18 18:15:57 --> Output Class Initialized
DEBUG - 2013-08-18 18:15:57 --> Security Class Initialized
DEBUG - 2013-08-18 18:15:57 --> Input Class Initialized
DEBUG - 2013-08-18 18:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:15:57 --> Language Class Initialized
DEBUG - 2013-08-18 18:16:21 --> Config Class Initialized
DEBUG - 2013-08-18 18:16:21 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:16:21 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:16:21 --> URI Class Initialized
DEBUG - 2013-08-18 18:16:21 --> Router Class Initialized
DEBUG - 2013-08-18 18:16:21 --> Output Class Initialized
DEBUG - 2013-08-18 18:16:21 --> Security Class Initialized
DEBUG - 2013-08-18 18:16:21 --> Input Class Initialized
DEBUG - 2013-08-18 18:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:16:21 --> Language Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Config Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:28:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:28:34 --> URI Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Router Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Output Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Security Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Input Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:28:34 --> Language Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Loader Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:28:34 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:28:34 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:28:34 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Session Class Initialized
DEBUG - 2013-08-18 18:28:34 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:28:34 --> A session cookie was not found.
DEBUG - 2013-08-18 18:28:34 --> Session routines successfully run
DEBUG - 2013-08-18 18:28:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:28:35 --> Controller Class Initialized
ERROR - 2013-08-18 18:28:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:28:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:28:35 --> Model Class Initialized
DEBUG - 2013-08-18 18:28:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:28:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:28:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:28:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:28:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:28:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:28:35 --> Pagination Class Initialized
DEBUG - 2013-08-18 18:28:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:28:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:28:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:28:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:28:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:28:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:28:35 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 18:28:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:28:35 --> Final output sent to browser
DEBUG - 2013-08-18 18:28:35 --> Total execution time: 1.3260
DEBUG - 2013-08-18 18:28:35 --> Config Class Initialized
DEBUG - 2013-08-18 18:28:35 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:28:35 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:28:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:28:35 --> URI Class Initialized
DEBUG - 2013-08-18 18:28:35 --> Router Class Initialized
ERROR - 2013-08-18 18:28:35 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:28:56 --> Config Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:28:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:28:56 --> URI Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Router Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Output Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Security Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Input Class Initialized
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:28:56 --> Language Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Loader Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:28:56 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:28:56 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:28:56 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Session Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:28:56 --> Session routines successfully run
DEBUG - 2013-08-18 18:28:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Controller Class Initialized
ERROR - 2013-08-18 18:28:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:28:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:28:56 --> Model Class Initialized
DEBUG - 2013-08-18 18:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:28:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:28:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:28:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:28:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:28:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:28:56 --> Pagination Class Initialized
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> XSS Filtering completed
DEBUG - 2013-08-18 18:28:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:28:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:28:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:28:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:28:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:28:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:28:56 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 18:28:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:28:56 --> Final output sent to browser
DEBUG - 2013-08-18 18:28:56 --> Total execution time: 0.8580
DEBUG - 2013-08-18 18:28:57 --> Config Class Initialized
DEBUG - 2013-08-18 18:28:57 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:28:57 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:28:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:28:57 --> URI Class Initialized
DEBUG - 2013-08-18 18:28:57 --> Router Class Initialized
ERROR - 2013-08-18 18:28:57 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:28:59 --> Config Class Initialized
DEBUG - 2013-08-18 18:28:59 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:28:59 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:28:59 --> URI Class Initialized
DEBUG - 2013-08-18 18:28:59 --> Router Class Initialized
DEBUG - 2013-08-18 18:28:59 --> Output Class Initialized
DEBUG - 2013-08-18 18:28:59 --> Security Class Initialized
DEBUG - 2013-08-18 18:28:59 --> Input Class Initialized
DEBUG - 2013-08-18 18:28:59 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:29:00 --> Language Class Initialized
DEBUG - 2013-08-18 18:29:00 --> Loader Class Initialized
DEBUG - 2013-08-18 18:29:00 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:29:00 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:29:00 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:29:00 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:29:00 --> Session Class Initialized
DEBUG - 2013-08-18 18:29:00 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:29:00 --> Session routines successfully run
DEBUG - 2013-08-18 18:29:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:29:00 --> Controller Class Initialized
ERROR - 2013-08-18 18:29:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:00 --> Model Class Initialized
DEBUG - 2013-08-18 18:29:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:29:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:29:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:29:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:29:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:00 --> Pagination Class Initialized
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:29:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:29:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:29:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:29:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:29:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:29:01 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 18:29:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:29:01 --> Final output sent to browser
DEBUG - 2013-08-18 18:29:01 --> Total execution time: 1.2480
DEBUG - 2013-08-18 18:29:01 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:01 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:01 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:01 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:01 --> Router Class Initialized
ERROR - 2013-08-18 18:29:01 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:29:03 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:03 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Router Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Output Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Security Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Input Class Initialized
DEBUG - 2013-08-18 18:29:03 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:03 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:03 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:03 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:03 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:29:03 --> Language Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Loader Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:29:03 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:29:03 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:29:03 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Session Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:29:03 --> Session routines successfully run
DEBUG - 2013-08-18 18:29:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Controller Class Initialized
ERROR - 2013-08-18 18:29:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:03 --> Model Class Initialized
DEBUG - 2013-08-18 18:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:29:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:29:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:29:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:29:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:04 --> Pagination Class Initialized
DEBUG - 2013-08-18 18:29:04 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:04 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:04 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:04 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:04 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:04 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:04 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:04 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:04 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:29:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:29:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:29:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:29:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:29:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:29:04 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 18:29:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:29:04 --> Final output sent to browser
DEBUG - 2013-08-18 18:29:04 --> Total execution time: 0.8580
DEBUG - 2013-08-18 18:29:04 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:04 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:04 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:04 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:04 --> Router Class Initialized
ERROR - 2013-08-18 18:29:04 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:29:16 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:16 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Router Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Output Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Security Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Input Class Initialized
DEBUG - 2013-08-18 18:29:16 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:16 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:16 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:16 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:29:16 --> Language Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Loader Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:29:16 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:29:16 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:29:16 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Session Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:29:16 --> Session routines successfully run
DEBUG - 2013-08-18 18:29:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Controller Class Initialized
ERROR - 2013-08-18 18:29:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:16 --> Model Class Initialized
DEBUG - 2013-08-18 18:29:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:29:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:29:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:29:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:29:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:16 --> Pagination Class Initialized
DEBUG - 2013-08-18 18:29:17 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:17 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:17 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:17 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:17 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:17 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:17 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:29:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:29:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:29:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:29:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:29:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:29:17 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 18:29:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:29:17 --> Final output sent to browser
DEBUG - 2013-08-18 18:29:17 --> Total execution time: 1.2324
DEBUG - 2013-08-18 18:29:17 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:17 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:17 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:17 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:17 --> Router Class Initialized
ERROR - 2013-08-18 18:29:17 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:29:28 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:28 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Router Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Output Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Security Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Input Class Initialized
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:29:28 --> Language Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Loader Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:29:28 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:29:28 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:29:28 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Session Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:29:28 --> Session routines successfully run
DEBUG - 2013-08-18 18:29:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Controller Class Initialized
ERROR - 2013-08-18 18:29:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:28 --> Model Class Initialized
DEBUG - 2013-08-18 18:29:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:29:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:29:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:29:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:29:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:28 --> Pagination Class Initialized
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:28 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:29:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:29:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:29:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:29:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:29:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:29:29 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 18:29:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:29:29 --> Final output sent to browser
DEBUG - 2013-08-18 18:29:29 --> Total execution time: 1.0764
DEBUG - 2013-08-18 18:29:29 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:29 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:29 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:29 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:29 --> Router Class Initialized
ERROR - 2013-08-18 18:29:29 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:29:31 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:31 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:31 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:31 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:31 --> Router Class Initialized
DEBUG - 2013-08-18 18:29:31 --> Output Class Initialized
DEBUG - 2013-08-18 18:29:31 --> Security Class Initialized
DEBUG - 2013-08-18 18:29:31 --> Input Class Initialized
DEBUG - 2013-08-18 18:29:31 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:31 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:31 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:31 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:31 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:29:32 --> Language Class Initialized
DEBUG - 2013-08-18 18:29:32 --> Loader Class Initialized
DEBUG - 2013-08-18 18:29:32 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:29:32 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:29:32 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:29:32 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:29:32 --> Session Class Initialized
DEBUG - 2013-08-18 18:29:32 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:29:32 --> Session routines successfully run
DEBUG - 2013-08-18 18:29:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:29:32 --> Controller Class Initialized
ERROR - 2013-08-18 18:29:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:32 --> Model Class Initialized
DEBUG - 2013-08-18 18:29:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:29:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:29:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:29:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:29:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:32 --> Pagination Class Initialized
DEBUG - 2013-08-18 18:29:32 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:32 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:32 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:32 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:32 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:32 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:32 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:32 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:32 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:29:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:29:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:29:32 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:29:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:29:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:29:32 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 18:29:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:29:32 --> Final output sent to browser
DEBUG - 2013-08-18 18:29:32 --> Total execution time: 1.1232
DEBUG - 2013-08-18 18:29:32 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:32 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:32 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:33 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:33 --> Router Class Initialized
ERROR - 2013-08-18 18:29:33 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:29:36 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:36 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Router Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Output Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Security Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Input Class Initialized
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:29:36 --> Language Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Loader Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:29:36 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:29:36 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:29:36 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Session Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:29:36 --> Session routines successfully run
DEBUG - 2013-08-18 18:29:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Controller Class Initialized
ERROR - 2013-08-18 18:29:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:36 --> Model Class Initialized
DEBUG - 2013-08-18 18:29:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:29:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:29:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:29:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:29:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:36 --> Pagination Class Initialized
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:29:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:29:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:29:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:29:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:29:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:29:36 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 18:29:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:29:36 --> Final output sent to browser
DEBUG - 2013-08-18 18:29:37 --> Total execution time: 0.6708
DEBUG - 2013-08-18 18:29:37 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:37 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:37 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:37 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:37 --> Router Class Initialized
ERROR - 2013-08-18 18:29:37 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:29:41 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:41 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Router Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Output Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Security Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Input Class Initialized
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:29:41 --> Language Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Loader Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:29:41 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:29:41 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:29:41 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Session Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:29:41 --> Session routines successfully run
DEBUG - 2013-08-18 18:29:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Controller Class Initialized
ERROR - 2013-08-18 18:29:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:41 --> Model Class Initialized
DEBUG - 2013-08-18 18:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:29:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:29:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:29:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:29:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:29:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:29:41 --> Pagination Class Initialized
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:41 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:42 --> XSS Filtering completed
DEBUG - 2013-08-18 18:29:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:29:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:29:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:29:42 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:29:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:29:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:29:42 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 18:29:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:29:42 --> Final output sent to browser
DEBUG - 2013-08-18 18:29:42 --> Total execution time: 1.0764
DEBUG - 2013-08-18 18:29:42 --> Config Class Initialized
DEBUG - 2013-08-18 18:29:42 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:29:42 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:29:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:29:42 --> URI Class Initialized
DEBUG - 2013-08-18 18:29:42 --> Router Class Initialized
ERROR - 2013-08-18 18:29:42 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:47:21 --> Config Class Initialized
DEBUG - 2013-08-18 18:47:21 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:47:21 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:47:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:47:21 --> URI Class Initialized
DEBUG - 2013-08-18 18:47:21 --> Router Class Initialized
ERROR - 2013-08-18 18:47:21 --> 404 Page Not Found --> user_groups
DEBUG - 2013-08-18 18:47:24 --> Config Class Initialized
DEBUG - 2013-08-18 18:47:24 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:47:24 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:47:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:47:24 --> URI Class Initialized
DEBUG - 2013-08-18 18:47:25 --> Router Class Initialized
ERROR - 2013-08-18 18:47:25 --> 404 Page Not Found --> user_groups
DEBUG - 2013-08-18 18:47:31 --> Config Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:47:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:47:31 --> URI Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Router Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Output Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Security Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Input Class Initialized
DEBUG - 2013-08-18 18:47:31 --> XSS Filtering completed
DEBUG - 2013-08-18 18:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:47:31 --> Language Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Loader Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:47:31 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:47:31 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:47:31 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Session Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:47:31 --> Session routines successfully run
DEBUG - 2013-08-18 18:47:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Controller Class Initialized
ERROR - 2013-08-18 18:47:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:47:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:47:31 --> Model Class Initialized
DEBUG - 2013-08-18 18:47:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:47:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:47:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:47:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:47:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:47:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:47:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:47:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:47:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:47:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:47:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:47:31 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:47:31 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-18 18:47:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:47:31 --> Final output sent to browser
DEBUG - 2013-08-18 18:47:32 --> Total execution time: 0.7488
DEBUG - 2013-08-18 18:47:32 --> Config Class Initialized
DEBUG - 2013-08-18 18:47:32 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:47:32 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:47:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:47:32 --> URI Class Initialized
DEBUG - 2013-08-18 18:47:32 --> Router Class Initialized
ERROR - 2013-08-18 18:47:32 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:48:03 --> Config Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:48:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:48:03 --> URI Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Router Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Output Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Security Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Input Class Initialized
DEBUG - 2013-08-18 18:48:03 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:03 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:03 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:03 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:48:03 --> Language Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Loader Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:48:03 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:48:03 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:48:03 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Session Class Initialized
DEBUG - 2013-08-18 18:48:03 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:48:04 --> Session routines successfully run
DEBUG - 2013-08-18 18:48:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:48:04 --> Controller Class Initialized
ERROR - 2013-08-18 18:48:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:48:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:48:04 --> Model Class Initialized
DEBUG - 2013-08-18 18:48:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:48:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:48:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:48:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:48:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:48:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:48:04 --> Form Validation Class Initialized
DEBUG - 2013-08-18 18:48:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-18 18:48:04 --> Config Class Initialized
DEBUG - 2013-08-18 18:48:04 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:48:04 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:48:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:48:04 --> URI Class Initialized
DEBUG - 2013-08-18 18:48:04 --> Router Class Initialized
ERROR - 2013-08-18 18:48:04 --> 404 Page Not Found --> user_groups
DEBUG - 2013-08-18 18:48:37 --> Config Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:48:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:48:37 --> URI Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Router Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Output Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Security Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Input Class Initialized
DEBUG - 2013-08-18 18:48:37 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:48:37 --> Language Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Loader Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:48:37 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:48:37 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:48:37 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Session Class Initialized
DEBUG - 2013-08-18 18:48:37 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:48:38 --> Session routines successfully run
DEBUG - 2013-08-18 18:48:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:48:38 --> Controller Class Initialized
ERROR - 2013-08-18 18:48:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:48:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:48:38 --> Model Class Initialized
DEBUG - 2013-08-18 18:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:48:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:48:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:48:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:48:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:48:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:48:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 18:48:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 18:48:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 18:48:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 18:48:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 18:48:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 18:48:38 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-18 18:48:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 18:48:38 --> Final output sent to browser
DEBUG - 2013-08-18 18:48:38 --> Total execution time: 0.8112
DEBUG - 2013-08-18 18:48:38 --> Config Class Initialized
DEBUG - 2013-08-18 18:48:38 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:48:38 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:48:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:48:38 --> URI Class Initialized
DEBUG - 2013-08-18 18:48:38 --> Router Class Initialized
ERROR - 2013-08-18 18:48:38 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 18:48:48 --> Config Class Initialized
DEBUG - 2013-08-18 18:48:48 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:48:48 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:48:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:48:48 --> URI Class Initialized
DEBUG - 2013-08-18 18:48:48 --> Router Class Initialized
DEBUG - 2013-08-18 18:48:48 --> Output Class Initialized
DEBUG - 2013-08-18 18:48:48 --> Security Class Initialized
DEBUG - 2013-08-18 18:48:48 --> Input Class Initialized
DEBUG - 2013-08-18 18:48:49 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:49 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:49 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:49 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:48:49 --> Language Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Loader Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:48:49 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:48:49 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:48:49 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Session Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:48:49 --> Session routines successfully run
DEBUG - 2013-08-18 18:48:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Controller Class Initialized
ERROR - 2013-08-18 18:48:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:48:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:48:49 --> Model Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:48:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:48:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:48:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:48:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:48:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:48:49 --> Form Validation Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-18 18:48:49 --> Config Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Hooks Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Utf8 Class Initialized
DEBUG - 2013-08-18 18:48:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 18:48:49 --> URI Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Router Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Output Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Security Class Initialized
DEBUG - 2013-08-18 18:48:49 --> Input Class Initialized
DEBUG - 2013-08-18 18:48:49 --> XSS Filtering completed
DEBUG - 2013-08-18 18:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 18:48:50 --> Language Class Initialized
DEBUG - 2013-08-18 18:48:50 --> Loader Class Initialized
DEBUG - 2013-08-18 18:48:50 --> Helper loaded: url_helper
DEBUG - 2013-08-18 18:48:50 --> Helper loaded: file_helper
DEBUG - 2013-08-18 18:48:50 --> Helper loaded: form_helper
DEBUG - 2013-08-18 18:48:50 --> Database Driver Class Initialized
DEBUG - 2013-08-18 18:48:50 --> Session Class Initialized
DEBUG - 2013-08-18 18:48:50 --> Helper loaded: string_helper
DEBUG - 2013-08-18 18:48:50 --> Session routines successfully run
DEBUG - 2013-08-18 18:48:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 18:48:50 --> Controller Class Initialized
ERROR - 2013-08-18 18:48:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:48:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:48:50 --> Model Class Initialized
DEBUG - 2013-08-18 18:48:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 18:48:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 18:48:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 18:48:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 18:48:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 18:48:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 18:48:50 --> Final output sent to browser
DEBUG - 2013-08-18 18:48:50 --> Total execution time: 0.9048
DEBUG - 2013-08-18 19:55:22 --> Config Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Hooks Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Utf8 Class Initialized
DEBUG - 2013-08-18 19:55:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 19:55:22 --> URI Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Router Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Output Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Security Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Input Class Initialized
DEBUG - 2013-08-18 19:55:22 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 19:55:22 --> Language Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Loader Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Helper loaded: url_helper
DEBUG - 2013-08-18 19:55:22 --> Helper loaded: file_helper
DEBUG - 2013-08-18 19:55:22 --> Helper loaded: form_helper
DEBUG - 2013-08-18 19:55:22 --> Database Driver Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Session Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Helper loaded: string_helper
DEBUG - 2013-08-18 19:55:22 --> Session routines successfully run
DEBUG - 2013-08-18 19:55:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Controller Class Initialized
ERROR - 2013-08-18 19:55:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 19:55:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 19:55:22 --> Model Class Initialized
DEBUG - 2013-08-18 19:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 19:55:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 19:55:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 19:55:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 19:55:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 19:55:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 19:55:22 --> Pagination Class Initialized
DEBUG - 2013-08-18 19:55:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 19:55:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 19:55:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 19:55:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 19:55:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 19:55:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 19:55:23 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 19:55:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 19:55:23 --> Final output sent to browser
DEBUG - 2013-08-18 19:55:23 --> Total execution time: 1.0251
DEBUG - 2013-08-18 19:55:23 --> Config Class Initialized
DEBUG - 2013-08-18 19:55:23 --> Hooks Class Initialized
DEBUG - 2013-08-18 19:55:23 --> Utf8 Class Initialized
DEBUG - 2013-08-18 19:55:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 19:55:23 --> URI Class Initialized
DEBUG - 2013-08-18 19:55:23 --> Router Class Initialized
ERROR - 2013-08-18 19:55:23 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 19:55:28 --> Config Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Hooks Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Utf8 Class Initialized
DEBUG - 2013-08-18 19:55:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 19:55:28 --> URI Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Router Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Output Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Security Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Input Class Initialized
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 19:55:28 --> Language Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Loader Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Helper loaded: url_helper
DEBUG - 2013-08-18 19:55:28 --> Helper loaded: file_helper
DEBUG - 2013-08-18 19:55:28 --> Helper loaded: form_helper
DEBUG - 2013-08-18 19:55:28 --> Database Driver Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Session Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Helper loaded: string_helper
DEBUG - 2013-08-18 19:55:28 --> Session routines successfully run
DEBUG - 2013-08-18 19:55:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Controller Class Initialized
ERROR - 2013-08-18 19:55:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 19:55:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 19:55:28 --> Model Class Initialized
DEBUG - 2013-08-18 19:55:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 19:55:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 19:55:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 19:55:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 19:55:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 19:55:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 19:55:28 --> Pagination Class Initialized
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:28 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:29 --> DB Transaction Failure
ERROR - 2013-08-18 19:55:29 --> Query error: Table 'school.tingkat' doesn't exist
DEBUG - 2013-08-18 19:55:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-18 19:55:47 --> Config Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Hooks Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Utf8 Class Initialized
DEBUG - 2013-08-18 19:55:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 19:55:47 --> URI Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Router Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Output Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Security Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Input Class Initialized
DEBUG - 2013-08-18 19:55:47 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:47 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:47 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:47 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 19:55:47 --> Language Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Loader Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Helper loaded: url_helper
DEBUG - 2013-08-18 19:55:47 --> Helper loaded: file_helper
DEBUG - 2013-08-18 19:55:47 --> Helper loaded: form_helper
DEBUG - 2013-08-18 19:55:47 --> Database Driver Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Session Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Helper loaded: string_helper
DEBUG - 2013-08-18 19:55:47 --> Session routines successfully run
DEBUG - 2013-08-18 19:55:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Controller Class Initialized
ERROR - 2013-08-18 19:55:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 19:55:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 19:55:47 --> Model Class Initialized
DEBUG - 2013-08-18 19:55:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 19:55:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 19:55:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 19:55:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 19:55:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 19:55:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 19:55:48 --> Pagination Class Initialized
DEBUG - 2013-08-18 19:55:48 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:48 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:48 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:48 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:48 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:48 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:48 --> XSS Filtering completed
DEBUG - 2013-08-18 19:55:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 19:55:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 19:55:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 19:55:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 19:55:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 19:55:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 19:55:48 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 19:55:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 19:55:48 --> Final output sent to browser
DEBUG - 2013-08-18 19:55:48 --> Total execution time: 1.5631
DEBUG - 2013-08-18 19:55:48 --> Config Class Initialized
DEBUG - 2013-08-18 19:55:48 --> Hooks Class Initialized
DEBUG - 2013-08-18 19:55:48 --> Utf8 Class Initialized
DEBUG - 2013-08-18 19:55:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 19:55:48 --> URI Class Initialized
DEBUG - 2013-08-18 19:55:48 --> Router Class Initialized
ERROR - 2013-08-18 19:55:48 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 19:57:33 --> Config Class Initialized
DEBUG - 2013-08-18 19:57:33 --> Hooks Class Initialized
DEBUG - 2013-08-18 19:57:33 --> Utf8 Class Initialized
DEBUG - 2013-08-18 19:57:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 19:57:33 --> URI Class Initialized
DEBUG - 2013-08-18 19:57:33 --> Router Class Initialized
DEBUG - 2013-08-18 19:57:33 --> Output Class Initialized
DEBUG - 2013-08-18 19:57:33 --> Security Class Initialized
DEBUG - 2013-08-18 19:57:33 --> Input Class Initialized
DEBUG - 2013-08-18 19:57:33 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:33 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:33 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:33 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 19:57:33 --> Language Class Initialized
DEBUG - 2013-08-18 19:57:34 --> Loader Class Initialized
DEBUG - 2013-08-18 19:57:34 --> Helper loaded: url_helper
DEBUG - 2013-08-18 19:57:34 --> Helper loaded: file_helper
DEBUG - 2013-08-18 19:57:34 --> Helper loaded: form_helper
DEBUG - 2013-08-18 19:57:34 --> Database Driver Class Initialized
DEBUG - 2013-08-18 19:57:34 --> Session Class Initialized
DEBUG - 2013-08-18 19:57:34 --> Helper loaded: string_helper
DEBUG - 2013-08-18 19:57:34 --> Session routines successfully run
DEBUG - 2013-08-18 19:57:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 19:57:34 --> Controller Class Initialized
ERROR - 2013-08-18 19:57:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 19:57:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 19:57:34 --> Model Class Initialized
DEBUG - 2013-08-18 19:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 19:57:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 19:57:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 19:57:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 19:57:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 19:57:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 19:57:34 --> Pagination Class Initialized
DEBUG - 2013-08-18 19:57:34 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:34 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:34 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:34 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:34 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:34 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:34 --> XSS Filtering completed
DEBUG - 2013-08-18 19:57:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 19:57:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 19:57:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 19:57:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 19:57:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 19:57:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 19:57:34 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-18 19:57:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 19:57:34 --> Final output sent to browser
DEBUG - 2013-08-18 19:57:34 --> Total execution time: 0.8892
DEBUG - 2013-08-18 19:57:34 --> Config Class Initialized
DEBUG - 2013-08-18 19:57:34 --> Hooks Class Initialized
DEBUG - 2013-08-18 19:57:34 --> Utf8 Class Initialized
DEBUG - 2013-08-18 19:57:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 19:57:34 --> URI Class Initialized
DEBUG - 2013-08-18 19:57:34 --> Router Class Initialized
ERROR - 2013-08-18 19:57:34 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 20:23:17 --> Config Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:23:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:23:17 --> URI Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Router Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Output Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Security Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Input Class Initialized
DEBUG - 2013-08-18 20:23:17 --> XSS Filtering completed
DEBUG - 2013-08-18 20:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:23:17 --> Language Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Loader Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:23:17 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:23:17 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:23:17 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Session Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:23:17 --> Session routines successfully run
DEBUG - 2013-08-18 20:23:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Controller Class Initialized
ERROR - 2013-08-18 20:23:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:23:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:23:17 --> Model Class Initialized
DEBUG - 2013-08-18 20:23:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:23:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:23:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:23:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:23:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:23:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:23:17 --> Pagination Class Initialized
DEBUG - 2013-08-18 20:23:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 20:23:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 20:23:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 20:23:18 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 20:23:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 20:23:18 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-18 20:23:18 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\user_groups\index.php 56
ERROR - 2013-08-18 20:23:18 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\user_groups\index.php 69
ERROR - 2013-08-18 20:23:18 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\user_groups\index.php 70
ERROR - 2013-08-18 20:23:18 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\user_groups\index.php 71
ERROR - 2013-08-18 20:23:18 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\user_groups\index.php 73
ERROR - 2013-08-18 20:23:18 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\user_groups\index.php 83
DEBUG - 2013-08-18 20:23:18 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-18 20:23:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 20:23:18 --> Final output sent to browser
DEBUG - 2013-08-18 20:23:18 --> Total execution time: 1.0671
DEBUG - 2013-08-18 20:23:18 --> Config Class Initialized
DEBUG - 2013-08-18 20:23:18 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:23:18 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:23:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:23:18 --> URI Class Initialized
DEBUG - 2013-08-18 20:23:18 --> Router Class Initialized
ERROR - 2013-08-18 20:23:18 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 20:24:43 --> Config Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:24:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:24:43 --> URI Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Router Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Output Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Security Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Input Class Initialized
DEBUG - 2013-08-18 20:24:43 --> XSS Filtering completed
DEBUG - 2013-08-18 20:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:24:43 --> Language Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Loader Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:24:43 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:24:43 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:24:43 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Session Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:24:43 --> Session routines successfully run
DEBUG - 2013-08-18 20:24:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Controller Class Initialized
ERROR - 2013-08-18 20:24:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:24:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:24:43 --> Model Class Initialized
DEBUG - 2013-08-18 20:24:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:24:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:24:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:24:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:24:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:24:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:24:44 --> Pagination Class Initialized
DEBUG - 2013-08-18 20:24:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 20:24:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 20:24:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 20:24:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 20:24:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 20:24:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 20:24:44 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-18 20:24:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 20:24:44 --> Final output sent to browser
DEBUG - 2013-08-18 20:24:44 --> Total execution time: 0.9911
DEBUG - 2013-08-18 20:24:44 --> Config Class Initialized
DEBUG - 2013-08-18 20:24:44 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:24:44 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:24:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:24:44 --> URI Class Initialized
DEBUG - 2013-08-18 20:24:44 --> Router Class Initialized
ERROR - 2013-08-18 20:24:44 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 20:25:29 --> Config Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:25:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:25:29 --> URI Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Router Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Output Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Security Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Input Class Initialized
DEBUG - 2013-08-18 20:25:29 --> XSS Filtering completed
DEBUG - 2013-08-18 20:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:25:29 --> Language Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Loader Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:25:29 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:25:29 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:25:29 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Session Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:25:29 --> Session routines successfully run
DEBUG - 2013-08-18 20:25:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Controller Class Initialized
ERROR - 2013-08-18 20:25:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:25:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:25:29 --> Model Class Initialized
DEBUG - 2013-08-18 20:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:25:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:25:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:25:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:25:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:25:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:25:29 --> Pagination Class Initialized
DEBUG - 2013-08-18 20:25:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 20:25:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 20:25:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 20:25:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 20:25:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 20:25:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 20:25:30 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-18 20:25:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 20:25:30 --> Final output sent to browser
DEBUG - 2013-08-18 20:25:30 --> Total execution time: 0.8620
DEBUG - 2013-08-18 20:25:30 --> Config Class Initialized
DEBUG - 2013-08-18 20:25:30 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:25:30 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:25:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:25:30 --> URI Class Initialized
DEBUG - 2013-08-18 20:25:30 --> Router Class Initialized
ERROR - 2013-08-18 20:25:30 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 20:25:38 --> Config Class Initialized
DEBUG - 2013-08-18 20:25:38 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:25:38 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:25:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:25:38 --> URI Class Initialized
DEBUG - 2013-08-18 20:25:38 --> Router Class Initialized
DEBUG - 2013-08-18 20:25:38 --> Output Class Initialized
DEBUG - 2013-08-18 20:25:38 --> Security Class Initialized
DEBUG - 2013-08-18 20:25:38 --> Input Class Initialized
DEBUG - 2013-08-18 20:25:38 --> XSS Filtering completed
DEBUG - 2013-08-18 20:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:25:38 --> Language Class Initialized
DEBUG - 2013-08-18 20:25:38 --> Loader Class Initialized
DEBUG - 2013-08-18 20:25:38 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:25:38 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:25:38 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:25:38 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:25:39 --> Session Class Initialized
DEBUG - 2013-08-18 20:25:39 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:25:39 --> Session routines successfully run
DEBUG - 2013-08-18 20:25:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:25:39 --> Controller Class Initialized
ERROR - 2013-08-18 20:25:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:25:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:25:39 --> Model Class Initialized
DEBUG - 2013-08-18 20:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:25:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:25:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:25:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:25:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:25:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:25:39 --> Pagination Class Initialized
DEBUG - 2013-08-18 20:25:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 20:25:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 20:25:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 20:25:39 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 20:25:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 20:25:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 20:25:39 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-18 20:25:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 20:25:39 --> Final output sent to browser
DEBUG - 2013-08-18 20:25:39 --> Total execution time: 0.9981
DEBUG - 2013-08-18 20:25:39 --> Config Class Initialized
DEBUG - 2013-08-18 20:25:39 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:25:39 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:25:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:25:39 --> URI Class Initialized
DEBUG - 2013-08-18 20:25:39 --> Router Class Initialized
ERROR - 2013-08-18 20:25:39 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 20:26:33 --> Config Class Initialized
DEBUG - 2013-08-18 20:26:33 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:26:33 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:26:33 --> URI Class Initialized
DEBUG - 2013-08-18 20:26:33 --> Router Class Initialized
DEBUG - 2013-08-18 20:26:33 --> Output Class Initialized
DEBUG - 2013-08-18 20:26:33 --> Security Class Initialized
DEBUG - 2013-08-18 20:26:33 --> Input Class Initialized
DEBUG - 2013-08-18 20:26:33 --> XSS Filtering completed
DEBUG - 2013-08-18 20:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:26:33 --> Language Class Initialized
DEBUG - 2013-08-18 20:26:33 --> Loader Class Initialized
DEBUG - 2013-08-18 20:26:33 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:26:34 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:26:34 --> Session Class Initialized
DEBUG - 2013-08-18 20:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:26:34 --> Session routines successfully run
DEBUG - 2013-08-18 20:26:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:26:34 --> Controller Class Initialized
ERROR - 2013-08-18 20:26:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:26:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:26:34 --> Model Class Initialized
DEBUG - 2013-08-18 20:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:26:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:26:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:26:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:26:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:26:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:26:34 --> Pagination Class Initialized
DEBUG - 2013-08-18 20:26:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 20:26:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 20:26:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 20:26:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 20:26:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 20:26:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 20:26:34 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-18 20:26:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 20:26:34 --> Final output sent to browser
DEBUG - 2013-08-18 20:26:34 --> Total execution time: 1.0721
DEBUG - 2013-08-18 20:26:35 --> Config Class Initialized
DEBUG - 2013-08-18 20:26:35 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:26:35 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:26:35 --> URI Class Initialized
DEBUG - 2013-08-18 20:26:35 --> Router Class Initialized
ERROR - 2013-08-18 20:26:35 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 20:28:34 --> Config Class Initialized
DEBUG - 2013-08-18 20:28:34 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:28:34 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:28:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:28:34 --> URI Class Initialized
DEBUG - 2013-08-18 20:28:34 --> Router Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Output Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Security Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Input Class Initialized
DEBUG - 2013-08-18 20:28:35 --> XSS Filtering completed
DEBUG - 2013-08-18 20:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:28:35 --> Language Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Loader Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:28:35 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:28:35 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:28:35 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Session Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:28:35 --> Session routines successfully run
DEBUG - 2013-08-18 20:28:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Controller Class Initialized
ERROR - 2013-08-18 20:28:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:28:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:28:35 --> Model Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:28:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:28:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:28:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:28:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:28:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:28:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 20:28:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 20:28:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 20:28:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 20:28:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 20:28:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 20:28:35 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-18 20:28:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 20:28:35 --> Final output sent to browser
DEBUG - 2013-08-18 20:28:35 --> Total execution time: 0.9691
DEBUG - 2013-08-18 20:28:35 --> Config Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:28:35 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:28:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:28:36 --> URI Class Initialized
DEBUG - 2013-08-18 20:28:36 --> Router Class Initialized
ERROR - 2013-08-18 20:28:36 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 20:30:38 --> Config Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:30:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:30:38 --> URI Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Router Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Output Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Security Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Input Class Initialized
DEBUG - 2013-08-18 20:30:38 --> XSS Filtering completed
DEBUG - 2013-08-18 20:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:30:38 --> Language Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Loader Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:30:38 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:30:38 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:30:38 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Session Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:30:38 --> Session routines successfully run
DEBUG - 2013-08-18 20:30:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Controller Class Initialized
ERROR - 2013-08-18 20:30:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:30:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:30:38 --> Model Class Initialized
DEBUG - 2013-08-18 20:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:30:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:30:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:30:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:30:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:30:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:30:39 --> DB Transaction Failure
ERROR - 2013-08-18 20:30:39 --> Query error: Unknown column 'id' in 'where clause'
DEBUG - 2013-08-18 20:30:39 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-18 20:31:46 --> Config Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:31:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:31:46 --> URI Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Router Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Output Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Security Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Input Class Initialized
DEBUG - 2013-08-18 20:31:46 --> XSS Filtering completed
DEBUG - 2013-08-18 20:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:31:46 --> Language Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Loader Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:31:46 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:31:46 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:31:46 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Session Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:31:46 --> Session routines successfully run
DEBUG - 2013-08-18 20:31:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Controller Class Initialized
ERROR - 2013-08-18 20:31:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:31:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:31:46 --> Model Class Initialized
DEBUG - 2013-08-18 20:31:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:31:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:31:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:31:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:31:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:31:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:31:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 20:31:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 20:31:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 20:31:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 20:31:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 20:31:47 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 20:31:47 --> File loaded: application/views/user_groups/show.php
DEBUG - 2013-08-18 20:31:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 20:31:47 --> Final output sent to browser
DEBUG - 2013-08-18 20:31:47 --> Total execution time: 1.0961
DEBUG - 2013-08-18 20:31:47 --> Config Class Initialized
DEBUG - 2013-08-18 20:31:47 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:31:47 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:31:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:31:47 --> URI Class Initialized
DEBUG - 2013-08-18 20:31:47 --> Router Class Initialized
ERROR - 2013-08-18 20:31:47 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 20:31:59 --> Config Class Initialized
DEBUG - 2013-08-18 20:31:59 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:32:00 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:32:00 --> URI Class Initialized
DEBUG - 2013-08-18 20:32:00 --> Router Class Initialized
ERROR - 2013-08-18 20:32:00 --> 404 Page Not Found --> user_groups
DEBUG - 2013-08-18 20:32:42 --> Config Class Initialized
DEBUG - 2013-08-18 20:32:42 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:32:42 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:32:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:32:42 --> URI Class Initialized
DEBUG - 2013-08-18 20:32:42 --> Router Class Initialized
DEBUG - 2013-08-18 20:32:42 --> Output Class Initialized
DEBUG - 2013-08-18 20:32:42 --> Security Class Initialized
DEBUG - 2013-08-18 20:32:42 --> Input Class Initialized
DEBUG - 2013-08-18 20:32:42 --> XSS Filtering completed
DEBUG - 2013-08-18 20:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:32:42 --> Language Class Initialized
DEBUG - 2013-08-18 20:32:42 --> Loader Class Initialized
DEBUG - 2013-08-18 20:32:42 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:32:42 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:32:42 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:32:42 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:32:42 --> Session Class Initialized
DEBUG - 2013-08-18 20:32:43 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:32:43 --> Session routines successfully run
DEBUG - 2013-08-18 20:32:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:32:43 --> Controller Class Initialized
ERROR - 2013-08-18 20:32:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:32:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:32:43 --> Model Class Initialized
DEBUG - 2013-08-18 20:32:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:32:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:32:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:32:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:32:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:32:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:32:43 --> Pagination Class Initialized
DEBUG - 2013-08-18 20:32:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 20:32:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 20:32:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 20:32:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 20:32:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 20:32:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 20:32:43 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-18 20:32:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 20:32:43 --> Final output sent to browser
DEBUG - 2013-08-18 20:32:43 --> Total execution time: 1.2461
DEBUG - 2013-08-18 20:32:43 --> Config Class Initialized
DEBUG - 2013-08-18 20:32:43 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:32:43 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:32:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:32:43 --> URI Class Initialized
DEBUG - 2013-08-18 20:32:43 --> Router Class Initialized
ERROR - 2013-08-18 20:32:43 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 20:40:21 --> Config Class Initialized
DEBUG - 2013-08-18 20:40:21 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:40:21 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:40:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:40:21 --> URI Class Initialized
DEBUG - 2013-08-18 20:40:21 --> Router Class Initialized
DEBUG - 2013-08-18 20:40:21 --> Output Class Initialized
DEBUG - 2013-08-18 20:40:21 --> Security Class Initialized
DEBUG - 2013-08-18 20:40:21 --> Input Class Initialized
DEBUG - 2013-08-18 20:40:22 --> XSS Filtering completed
DEBUG - 2013-08-18 20:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:40:22 --> Language Class Initialized
DEBUG - 2013-08-18 20:40:22 --> Loader Class Initialized
DEBUG - 2013-08-18 20:40:22 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:40:22 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:40:22 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:40:22 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:40:22 --> Session Class Initialized
DEBUG - 2013-08-18 20:40:22 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:40:22 --> Session routines successfully run
DEBUG - 2013-08-18 20:40:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:40:22 --> Controller Class Initialized
ERROR - 2013-08-18 20:40:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:40:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:40:22 --> Model Class Initialized
DEBUG - 2013-08-18 20:40:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:40:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:40:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:40:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:40:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:40:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:40:22 --> Final output sent to browser
DEBUG - 2013-08-18 20:40:22 --> Total execution time: 1.0771
DEBUG - 2013-08-18 20:42:18 --> Config Class Initialized
DEBUG - 2013-08-18 20:42:18 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:42:18 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:42:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:42:18 --> URI Class Initialized
DEBUG - 2013-08-18 20:42:18 --> Router Class Initialized
DEBUG - 2013-08-18 20:42:18 --> Output Class Initialized
DEBUG - 2013-08-18 20:42:18 --> Security Class Initialized
DEBUG - 2013-08-18 20:42:18 --> Input Class Initialized
DEBUG - 2013-08-18 20:42:18 --> XSS Filtering completed
DEBUG - 2013-08-18 20:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:42:18 --> Language Class Initialized
DEBUG - 2013-08-18 20:42:18 --> Loader Class Initialized
DEBUG - 2013-08-18 20:42:18 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:42:18 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:42:18 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:42:18 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:42:19 --> Session Class Initialized
DEBUG - 2013-08-18 20:42:19 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:42:19 --> Session routines successfully run
DEBUG - 2013-08-18 20:42:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:42:19 --> Controller Class Initialized
ERROR - 2013-08-18 20:42:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:42:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:42:19 --> Model Class Initialized
DEBUG - 2013-08-18 20:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:42:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:42:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:42:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:42:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:42:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:42:19 --> 404 Page Not Found --> 
DEBUG - 2013-08-18 20:45:03 --> Config Class Initialized
DEBUG - 2013-08-18 20:45:03 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:45:03 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:45:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:45:03 --> URI Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Router Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Output Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Security Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Input Class Initialized
DEBUG - 2013-08-18 20:45:04 --> XSS Filtering completed
DEBUG - 2013-08-18 20:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:45:04 --> Language Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Loader Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:45:04 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:45:04 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:45:04 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Session Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:45:04 --> Session routines successfully run
DEBUG - 2013-08-18 20:45:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Controller Class Initialized
ERROR - 2013-08-18 20:45:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:45:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:45:04 --> Model Class Initialized
DEBUG - 2013-08-18 20:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:45:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:45:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:45:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:45:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:45:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:45:04 --> 404 Page Not Found --> 
DEBUG - 2013-08-18 20:46:16 --> Config Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:46:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:46:16 --> URI Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Router Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Output Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Security Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Input Class Initialized
DEBUG - 2013-08-18 20:46:16 --> XSS Filtering completed
DEBUG - 2013-08-18 20:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 20:46:16 --> Language Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Loader Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Helper loaded: url_helper
DEBUG - 2013-08-18 20:46:16 --> Helper loaded: file_helper
DEBUG - 2013-08-18 20:46:16 --> Helper loaded: form_helper
DEBUG - 2013-08-18 20:46:16 --> Database Driver Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Session Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Helper loaded: string_helper
DEBUG - 2013-08-18 20:46:16 --> Session routines successfully run
DEBUG - 2013-08-18 20:46:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Controller Class Initialized
ERROR - 2013-08-18 20:46:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:46:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:46:16 --> Model Class Initialized
DEBUG - 2013-08-18 20:46:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 20:46:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 20:46:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 20:46:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 20:46:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 20:46:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 20:46:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 20:46:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 20:46:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 20:46:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 20:46:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 20:46:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 20:46:17 --> File loaded: application/views/user_groups/edit.php
DEBUG - 2013-08-18 20:46:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 20:46:17 --> Final output sent to browser
DEBUG - 2013-08-18 20:46:17 --> Total execution time: 1.3061
DEBUG - 2013-08-18 20:46:17 --> Config Class Initialized
DEBUG - 2013-08-18 20:46:17 --> Hooks Class Initialized
DEBUG - 2013-08-18 20:46:17 --> Utf8 Class Initialized
DEBUG - 2013-08-18 20:46:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 20:46:17 --> URI Class Initialized
DEBUG - 2013-08-18 20:46:17 --> Router Class Initialized
ERROR - 2013-08-18 20:46:17 --> 404 Page Not Found --> includes
DEBUG - 2013-08-18 21:08:23 --> Config Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Hooks Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Utf8 Class Initialized
DEBUG - 2013-08-18 21:08:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 21:08:23 --> URI Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Router Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Output Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Security Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Input Class Initialized
DEBUG - 2013-08-18 21:08:23 --> XSS Filtering completed
DEBUG - 2013-08-18 21:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-18 21:08:23 --> Language Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Loader Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Helper loaded: url_helper
DEBUG - 2013-08-18 21:08:23 --> Helper loaded: file_helper
DEBUG - 2013-08-18 21:08:23 --> Helper loaded: form_helper
DEBUG - 2013-08-18 21:08:23 --> Database Driver Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Session Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Helper loaded: string_helper
DEBUG - 2013-08-18 21:08:23 --> Session routines successfully run
DEBUG - 2013-08-18 21:08:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Controller Class Initialized
ERROR - 2013-08-18 21:08:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 21:08:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 21:08:23 --> Model Class Initialized
DEBUG - 2013-08-18 21:08:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-18 21:08:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-18 21:08:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-18 21:08:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-18 21:08:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-18 21:08:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-18 21:08:23 --> Pagination Class Initialized
DEBUG - 2013-08-18 21:08:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-18 21:08:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-18 21:08:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-18 21:08:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-18 21:08:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-18 21:08:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-18 21:08:24 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-18 21:08:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-18 21:08:24 --> Final output sent to browser
DEBUG - 2013-08-18 21:08:24 --> Total execution time: 1.0341
DEBUG - 2013-08-18 21:08:24 --> Config Class Initialized
DEBUG - 2013-08-18 21:08:24 --> Hooks Class Initialized
DEBUG - 2013-08-18 21:08:24 --> Utf8 Class Initialized
DEBUG - 2013-08-18 21:08:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-18 21:08:24 --> URI Class Initialized
DEBUG - 2013-08-18 21:08:24 --> Router Class Initialized
ERROR - 2013-08-18 21:08:24 --> 404 Page Not Found --> includes
