<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-30 03:00:20 --> Config Class Initialized
DEBUG - 2013-08-30 03:00:20 --> Hooks Class Initialized
DEBUG - 2013-08-30 03:00:20 --> Utf8 Class Initialized
DEBUG - 2013-08-30 03:00:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 03:00:20 --> URI Class Initialized
DEBUG - 2013-08-30 03:00:20 --> Router Class Initialized
DEBUG - 2013-08-30 03:00:21 --> Output Class Initialized
DEBUG - 2013-08-30 03:00:21 --> Security Class Initialized
DEBUG - 2013-08-30 03:00:21 --> Input Class Initialized
DEBUG - 2013-08-30 03:00:21 --> XSS Filtering completed
DEBUG - 2013-08-30 03:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 03:00:22 --> Language Class Initialized
DEBUG - 2013-08-30 03:00:22 --> Loader Class Initialized
DEBUG - 2013-08-30 03:00:24 --> Helper loaded: url_helper
DEBUG - 2013-08-30 03:00:24 --> Helper loaded: file_helper
DEBUG - 2013-08-30 03:00:24 --> Helper loaded: form_helper
DEBUG - 2013-08-30 03:00:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 03:00:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 03:00:26 --> Database Driver Class Initialized
DEBUG - 2013-08-30 03:00:28 --> Session Class Initialized
DEBUG - 2013-08-30 03:00:28 --> Helper loaded: string_helper
DEBUG - 2013-08-30 03:00:28 --> A session cookie was not found.
DEBUG - 2013-08-30 03:00:30 --> Session routines successfully run
DEBUG - 2013-08-30 03:00:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 03:00:32 --> Controller Class Initialized
ERROR - 2013-08-30 03:00:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:00:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:00:38 --> Model Class Initialized
DEBUG - 2013-08-30 03:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 03:00:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 03:00:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 03:00:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 03:00:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:00:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:01:00 --> Config Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Hooks Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Utf8 Class Initialized
DEBUG - 2013-08-30 03:01:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 03:01:00 --> URI Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Router Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Output Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Security Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Input Class Initialized
DEBUG - 2013-08-30 03:01:00 --> XSS Filtering completed
DEBUG - 2013-08-30 03:01:00 --> XSS Filtering completed
DEBUG - 2013-08-30 03:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 03:01:00 --> Language Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Loader Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Helper loaded: url_helper
DEBUG - 2013-08-30 03:01:00 --> Helper loaded: file_helper
DEBUG - 2013-08-30 03:01:00 --> Helper loaded: form_helper
DEBUG - 2013-08-30 03:01:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 03:01:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 03:01:00 --> Database Driver Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Session Class Initialized
DEBUG - 2013-08-30 03:01:00 --> Helper loaded: string_helper
DEBUG - 2013-08-30 03:01:01 --> Session garbage collection performed.
DEBUG - 2013-08-30 03:01:01 --> Session routines successfully run
DEBUG - 2013-08-30 03:01:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 03:01:01 --> Controller Class Initialized
ERROR - 2013-08-30 03:01:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:01:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:01:01 --> Model Class Initialized
DEBUG - 2013-08-30 03:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 03:01:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 03:01:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 03:01:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 03:01:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:01:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:01:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 03:01:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 03:01:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 03:01:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 03:01:04 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-30 03:01:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 03:01:04 --> Final output sent to browser
DEBUG - 2013-08-30 03:01:04 --> Total execution time: 4.1702
DEBUG - 2013-08-30 03:01:05 --> Config Class Initialized
DEBUG - 2013-08-30 03:01:05 --> Hooks Class Initialized
DEBUG - 2013-08-30 03:01:05 --> Utf8 Class Initialized
DEBUG - 2013-08-30 03:01:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 03:01:05 --> URI Class Initialized
DEBUG - 2013-08-30 03:01:05 --> Router Class Initialized
ERROR - 2013-08-30 03:01:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 03:02:06 --> Config Class Initialized
DEBUG - 2013-08-30 03:02:06 --> Hooks Class Initialized
DEBUG - 2013-08-30 03:02:06 --> Utf8 Class Initialized
DEBUG - 2013-08-30 03:02:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 03:02:06 --> URI Class Initialized
DEBUG - 2013-08-30 03:02:06 --> Router Class Initialized
DEBUG - 2013-08-30 03:02:06 --> Output Class Initialized
DEBUG - 2013-08-30 03:02:07 --> Security Class Initialized
DEBUG - 2013-08-30 03:02:07 --> Input Class Initialized
DEBUG - 2013-08-30 03:02:07 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:07 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:07 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:07 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:07 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:07 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 03:02:07 --> Language Class Initialized
DEBUG - 2013-08-30 03:02:07 --> Loader Class Initialized
DEBUG - 2013-08-30 03:02:07 --> Helper loaded: url_helper
DEBUG - 2013-08-30 03:02:07 --> Helper loaded: file_helper
DEBUG - 2013-08-30 03:02:07 --> Helper loaded: form_helper
DEBUG - 2013-08-30 03:02:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 03:02:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 03:02:07 --> Database Driver Class Initialized
DEBUG - 2013-08-30 03:02:07 --> Session Class Initialized
DEBUG - 2013-08-30 03:02:07 --> Helper loaded: string_helper
DEBUG - 2013-08-30 03:02:07 --> Session routines successfully run
DEBUG - 2013-08-30 03:02:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 03:02:07 --> Controller Class Initialized
ERROR - 2013-08-30 03:02:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:02:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:02:07 --> Model Class Initialized
DEBUG - 2013-08-30 03:02:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 03:02:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 03:02:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 03:02:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 03:02:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:02:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:02:08 --> Model Class Initialized
DEBUG - 2013-08-30 03:02:09 --> Form Validation Class Initialized
DEBUG - 2013-08-30 03:02:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 03:02:15 --> Config Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Hooks Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Utf8 Class Initialized
DEBUG - 2013-08-30 03:02:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 03:02:15 --> URI Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Router Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Output Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Security Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Input Class Initialized
DEBUG - 2013-08-30 03:02:15 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:15 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:15 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:15 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:15 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 03:02:15 --> Language Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Loader Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Helper loaded: url_helper
DEBUG - 2013-08-30 03:02:15 --> Helper loaded: file_helper
DEBUG - 2013-08-30 03:02:15 --> Helper loaded: form_helper
DEBUG - 2013-08-30 03:02:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 03:02:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 03:02:15 --> Database Driver Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Session Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Helper loaded: string_helper
DEBUG - 2013-08-30 03:02:15 --> Session routines successfully run
DEBUG - 2013-08-30 03:02:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Controller Class Initialized
ERROR - 2013-08-30 03:02:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:02:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:02:15 --> Model Class Initialized
DEBUG - 2013-08-30 03:02:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 03:02:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 03:02:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 03:02:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 03:02:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:02:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:02:18 --> Config Class Initialized
DEBUG - 2013-08-30 03:02:18 --> Hooks Class Initialized
DEBUG - 2013-08-30 03:02:18 --> Utf8 Class Initialized
DEBUG - 2013-08-30 03:02:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 03:02:18 --> URI Class Initialized
DEBUG - 2013-08-30 03:02:18 --> Router Class Initialized
DEBUG - 2013-08-30 03:02:18 --> Output Class Initialized
DEBUG - 2013-08-30 03:02:18 --> Security Class Initialized
DEBUG - 2013-08-30 03:02:18 --> Input Class Initialized
DEBUG - 2013-08-30 03:02:18 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:18 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:18 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:18 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:18 --> XSS Filtering completed
DEBUG - 2013-08-30 03:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 03:02:18 --> Language Class Initialized
DEBUG - 2013-08-30 03:02:19 --> Loader Class Initialized
DEBUG - 2013-08-30 03:02:19 --> Helper loaded: url_helper
DEBUG - 2013-08-30 03:02:19 --> Helper loaded: file_helper
DEBUG - 2013-08-30 03:02:19 --> Helper loaded: form_helper
DEBUG - 2013-08-30 03:02:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 03:02:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 03:02:19 --> Database Driver Class Initialized
DEBUG - 2013-08-30 03:02:19 --> Session Class Initialized
DEBUG - 2013-08-30 03:02:19 --> Helper loaded: string_helper
DEBUG - 2013-08-30 03:02:20 --> Session routines successfully run
DEBUG - 2013-08-30 03:02:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 03:02:20 --> Controller Class Initialized
ERROR - 2013-08-30 03:02:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:02:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:02:20 --> Model Class Initialized
DEBUG - 2013-08-30 03:02:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 03:02:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 03:02:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 03:02:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 03:02:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 03:02:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 03:02:20 --> Model Class Initialized
DEBUG - 2013-08-30 03:02:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 03:02:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 03:02:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 03:02:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 03:02:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 03:02:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 03:02:26 --> File loaded: application/views/home.php
DEBUG - 2013-08-30 03:02:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 03:02:26 --> Final output sent to browser
DEBUG - 2013-08-30 03:02:26 --> Total execution time: 7.9835
DEBUG - 2013-08-30 03:02:28 --> Config Class Initialized
DEBUG - 2013-08-30 03:02:28 --> Hooks Class Initialized
DEBUG - 2013-08-30 03:02:28 --> Utf8 Class Initialized
DEBUG - 2013-08-30 03:02:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 03:02:28 --> URI Class Initialized
DEBUG - 2013-08-30 03:02:28 --> Router Class Initialized
ERROR - 2013-08-30 03:02:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:07:28 --> Config Class Initialized
DEBUG - 2013-08-30 04:07:28 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:07:28 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:07:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:07:28 --> URI Class Initialized
DEBUG - 2013-08-30 04:07:28 --> Router Class Initialized
DEBUG - 2013-08-30 04:07:29 --> Output Class Initialized
DEBUG - 2013-08-30 04:07:29 --> Security Class Initialized
DEBUG - 2013-08-30 04:07:29 --> Input Class Initialized
DEBUG - 2013-08-30 04:07:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:07:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:07:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:07:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:07:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:07:29 --> Language Class Initialized
DEBUG - 2013-08-30 04:07:29 --> Loader Class Initialized
DEBUG - 2013-08-30 04:07:29 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:07:29 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:07:29 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:07:29 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:07:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:07:29 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:07:29 --> Session Class Initialized
DEBUG - 2013-08-30 04:07:29 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:07:29 --> Session routines successfully run
DEBUG - 2013-08-30 04:07:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:07:29 --> Controller Class Initialized
ERROR - 2013-08-30 04:07:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:07:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:07:29 --> Model Class Initialized
DEBUG - 2013-08-30 04:07:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:07:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:07:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:07:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:07:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:07:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:07:29 --> Model Class Initialized
DEBUG - 2013-08-30 04:07:30 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:07:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:07:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:07:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:07:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:07:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:07:30 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 59
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 73
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 76
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 79
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 82
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 88
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 92
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 59
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 73
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 76
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 79
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 82
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 88
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 92
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 59
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 73
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 76
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 79
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 82
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 88
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 92
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 59
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 73
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 76
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 79
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 82
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 88
ERROR - 2013-08-30 04:07:30 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\school\application\views\users\index.php 92
DEBUG - 2013-08-30 04:07:30 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:07:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:07:30 --> Final output sent to browser
DEBUG - 2013-08-30 04:07:30 --> Total execution time: 1.8091
DEBUG - 2013-08-30 04:07:30 --> Config Class Initialized
DEBUG - 2013-08-30 04:07:30 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:07:30 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:07:30 --> URI Class Initialized
DEBUG - 2013-08-30 04:07:30 --> Router Class Initialized
ERROR - 2013-08-30 04:07:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:11:20 --> Config Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:11:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:11:20 --> URI Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Router Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Output Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Security Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Input Class Initialized
DEBUG - 2013-08-30 04:11:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:11:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:11:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:11:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:11:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:11:20 --> Language Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Loader Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:11:20 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:11:20 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:11:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:11:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:11:20 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Session Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:11:20 --> Session routines successfully run
DEBUG - 2013-08-30 04:11:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Controller Class Initialized
ERROR - 2013-08-30 04:11:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:11:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:11:20 --> Model Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:11:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:11:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:11:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:11:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:11:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:11:20 --> Model Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:11:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:11:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:11:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:11:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:11:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:11:20 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-30 04:11:20 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 88
ERROR - 2013-08-30 04:11:20 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 88
ERROR - 2013-08-30 04:11:20 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 88
ERROR - 2013-08-30 04:11:20 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 88
DEBUG - 2013-08-30 04:11:20 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:11:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:11:20 --> Final output sent to browser
DEBUG - 2013-08-30 04:11:20 --> Total execution time: 0.3560
DEBUG - 2013-08-30 04:11:20 --> Config Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:11:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:11:20 --> URI Class Initialized
DEBUG - 2013-08-30 04:11:20 --> Router Class Initialized
ERROR - 2013-08-30 04:11:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:12:21 --> Config Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:12:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:12:21 --> URI Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Router Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Output Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Security Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Input Class Initialized
DEBUG - 2013-08-30 04:12:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:12:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:12:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:12:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:12:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:12:21 --> Language Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Loader Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:12:21 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:12:21 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:12:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:12:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:12:21 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Session Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:12:21 --> Session routines successfully run
DEBUG - 2013-08-30 04:12:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Controller Class Initialized
ERROR - 2013-08-30 04:12:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:12:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:12:21 --> Model Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:12:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:12:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:12:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:12:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:12:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:12:21 --> Model Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:12:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:12:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:12:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:12:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:12:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:12:21 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-30 04:12:21 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 90
ERROR - 2013-08-30 04:12:21 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 90
ERROR - 2013-08-30 04:12:21 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 90
ERROR - 2013-08-30 04:12:21 --> Severity: Notice  --> Undefined index: nama C:\xampp\htdocs\school\application\views\users\index.php 90
DEBUG - 2013-08-30 04:12:21 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:12:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:12:21 --> Final output sent to browser
DEBUG - 2013-08-30 04:12:21 --> Total execution time: 0.4120
DEBUG - 2013-08-30 04:12:21 --> Config Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:12:21 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:12:22 --> URI Class Initialized
DEBUG - 2013-08-30 04:12:22 --> Router Class Initialized
ERROR - 2013-08-30 04:12:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:13:05 --> Config Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:13:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:13:05 --> URI Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Router Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Output Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Security Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Input Class Initialized
DEBUG - 2013-08-30 04:13:05 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:05 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:05 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:05 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:05 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:13:05 --> Language Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Loader Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:13:05 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:13:05 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:13:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:13:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:13:05 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Session Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:13:05 --> Session routines successfully run
DEBUG - 2013-08-30 04:13:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:13:05 --> Controller Class Initialized
ERROR - 2013-08-30 04:13:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:13:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:13:06 --> Model Class Initialized
DEBUG - 2013-08-30 04:13:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:13:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:13:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:13:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:13:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:13:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:13:06 --> Model Class Initialized
DEBUG - 2013-08-30 04:13:06 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:13:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:13:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:13:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:13:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:13:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:13:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:13:06 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:13:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:13:06 --> Final output sent to browser
DEBUG - 2013-08-30 04:13:06 --> Total execution time: 0.4170
DEBUG - 2013-08-30 04:13:06 --> Config Class Initialized
DEBUG - 2013-08-30 04:13:06 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:13:06 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:13:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:13:06 --> URI Class Initialized
DEBUG - 2013-08-30 04:13:06 --> Router Class Initialized
ERROR - 2013-08-30 04:13:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:13:19 --> Config Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:13:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:13:19 --> URI Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Router Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Output Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Security Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Input Class Initialized
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:13:19 --> Language Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Loader Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:13:19 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:13:19 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:13:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:13:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:13:19 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Session Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:13:19 --> Session routines successfully run
DEBUG - 2013-08-30 04:13:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Controller Class Initialized
ERROR - 2013-08-30 04:13:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:13:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:13:19 --> Model Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:13:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:13:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:13:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:13:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:13:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:13:19 --> Model Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:13:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:13:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:13:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:13:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:13:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:13:19 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:13:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:13:19 --> Final output sent to browser
DEBUG - 2013-08-30 04:13:19 --> Total execution time: 0.4360
DEBUG - 2013-08-30 04:13:19 --> Config Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:13:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:13:19 --> URI Class Initialized
DEBUG - 2013-08-30 04:13:19 --> Router Class Initialized
ERROR - 2013-08-30 04:13:19 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:13:23 --> Config Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:13:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:13:23 --> URI Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Router Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Output Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Security Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Input Class Initialized
DEBUG - 2013-08-30 04:13:23 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:23 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:23 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:23 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:23 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:23 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:23 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:23 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:13:23 --> Language Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Loader Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:13:23 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:13:23 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:13:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:13:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:13:23 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Session Class Initialized
DEBUG - 2013-08-30 04:13:23 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:13:24 --> Session routines successfully run
DEBUG - 2013-08-30 04:13:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:13:24 --> Controller Class Initialized
ERROR - 2013-08-30 04:13:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:13:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:13:24 --> Model Class Initialized
DEBUG - 2013-08-30 04:13:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:13:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:13:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:13:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:13:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:13:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:13:24 --> Model Class Initialized
DEBUG - 2013-08-30 04:13:24 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:13:24 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:24 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:24 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:24 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:24 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:24 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:13:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:13:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:13:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:13:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:13:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:13:24 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:13:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:13:24 --> Final output sent to browser
DEBUG - 2013-08-30 04:13:24 --> Total execution time: 0.4200
DEBUG - 2013-08-30 04:13:24 --> Config Class Initialized
DEBUG - 2013-08-30 04:13:24 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:13:24 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:13:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:13:24 --> URI Class Initialized
DEBUG - 2013-08-30 04:13:24 --> Router Class Initialized
ERROR - 2013-08-30 04:13:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:13:27 --> Config Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:13:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:13:27 --> URI Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Router Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Output Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Security Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Input Class Initialized
DEBUG - 2013-08-30 04:13:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:13:27 --> Language Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Loader Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:13:27 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:13:27 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:13:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:13:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:13:27 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Session Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:13:27 --> Session routines successfully run
DEBUG - 2013-08-30 04:13:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Controller Class Initialized
ERROR - 2013-08-30 04:13:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:13:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:13:27 --> Model Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:13:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:13:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:13:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:13:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:13:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:13:27 --> Model Class Initialized
DEBUG - 2013-08-30 04:13:27 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:13:28 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:28 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:28 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:28 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:28 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:28 --> XSS Filtering completed
DEBUG - 2013-08-30 04:13:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:13:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:13:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:13:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:13:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:13:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:13:28 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:13:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:13:28 --> Final output sent to browser
DEBUG - 2013-08-30 04:13:28 --> Total execution time: 0.6640
DEBUG - 2013-08-30 04:13:28 --> Config Class Initialized
DEBUG - 2013-08-30 04:13:28 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:13:28 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:13:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:13:28 --> URI Class Initialized
DEBUG - 2013-08-30 04:13:28 --> Router Class Initialized
ERROR - 2013-08-30 04:13:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:15:02 --> Config Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:15:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:15:02 --> URI Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Router Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Output Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Security Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Input Class Initialized
DEBUG - 2013-08-30 04:15:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:15:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:15:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:15:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:15:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:15:02 --> Language Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Loader Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:15:02 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:15:02 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:15:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:15:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:15:02 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Session Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:15:02 --> Session routines successfully run
DEBUG - 2013-08-30 04:15:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Controller Class Initialized
ERROR - 2013-08-30 04:15:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:15:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:15:02 --> Model Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:15:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:15:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:15:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:15:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:15:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:15:02 --> Model Class Initialized
DEBUG - 2013-08-30 04:15:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:15:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:15:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:15:02 --> File loaded: application/views/shared/menu.php
ERROR - 2013-08-30 04:15:02 --> Severity: Notice  --> Undefined index: uacc_id C:\xampp\htdocs\school\application\views\shared\breadcrumb.php 285
DEBUG - 2013-08-30 04:15:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:15:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:15:02 --> File loaded: application/views/users/show.php
DEBUG - 2013-08-30 04:15:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:15:02 --> Final output sent to browser
DEBUG - 2013-08-30 04:15:02 --> Total execution time: 0.4160
DEBUG - 2013-08-30 04:15:02 --> Config Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:15:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:15:02 --> URI Class Initialized
DEBUG - 2013-08-30 04:15:02 --> Router Class Initialized
ERROR - 2013-08-30 04:15:02 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:16:27 --> Config Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:16:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:16:27 --> URI Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Router Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Output Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Security Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Input Class Initialized
DEBUG - 2013-08-30 04:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:16:27 --> Language Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Loader Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:16:27 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:16:27 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:16:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:16:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:16:27 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Session Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:16:27 --> Session routines successfully run
DEBUG - 2013-08-30 04:16:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Controller Class Initialized
ERROR - 2013-08-30 04:16:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:16:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:16:27 --> Model Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:16:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:16:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:16:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:16:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:16:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:16:27 --> Model Class Initialized
DEBUG - 2013-08-30 04:16:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:16:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:16:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:16:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:16:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:16:27 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:16:27 --> File loaded: application/views/users/show.php
DEBUG - 2013-08-30 04:16:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:16:27 --> Final output sent to browser
DEBUG - 2013-08-30 04:16:27 --> Total execution time: 0.4340
DEBUG - 2013-08-30 04:16:27 --> Config Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:16:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:16:27 --> URI Class Initialized
DEBUG - 2013-08-30 04:16:27 --> Router Class Initialized
ERROR - 2013-08-30 04:16:27 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:16:35 --> Config Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:16:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:16:35 --> URI Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Router Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Output Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Security Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Input Class Initialized
DEBUG - 2013-08-30 04:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:16:35 --> Language Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Loader Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:16:35 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:16:35 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:16:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:16:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:16:35 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Session Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:16:35 --> Session routines successfully run
DEBUG - 2013-08-30 04:16:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Controller Class Initialized
ERROR - 2013-08-30 04:16:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:16:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:16:35 --> Model Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:16:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:16:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:16:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:16:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:16:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:16:35 --> Model Class Initialized
DEBUG - 2013-08-30 04:16:35 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:16:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:16:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:16:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:16:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:16:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:16:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:16:36 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:16:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:16:36 --> Final output sent to browser
DEBUG - 2013-08-30 04:16:36 --> Total execution time: 0.3990
DEBUG - 2013-08-30 04:16:36 --> Config Class Initialized
DEBUG - 2013-08-30 04:16:36 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:16:36 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:16:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:16:36 --> URI Class Initialized
DEBUG - 2013-08-30 04:16:36 --> Router Class Initialized
ERROR - 2013-08-30 04:16:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:24:16 --> Config Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:24:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:24:16 --> URI Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Router Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Output Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Security Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Input Class Initialized
DEBUG - 2013-08-30 04:24:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:24:16 --> Language Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Loader Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:24:16 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:24:16 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:24:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:24:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:24:16 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Session Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:24:16 --> Session routines successfully run
DEBUG - 2013-08-30 04:24:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Controller Class Initialized
ERROR - 2013-08-30 04:24:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:24:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:24:16 --> Model Class Initialized
DEBUG - 2013-08-30 04:24:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:24:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:24:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:24:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:24:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:24:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:24:16 --> Model Class Initialized
DEBUG - 2013-08-30 04:24:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:24:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:24:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:24:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:24:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:24:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:24:17 --> File loaded: application/views/users/edit.php
DEBUG - 2013-08-30 04:24:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:24:17 --> Final output sent to browser
DEBUG - 2013-08-30 04:24:17 --> Total execution time: 1.4261
DEBUG - 2013-08-30 04:24:17 --> Config Class Initialized
DEBUG - 2013-08-30 04:24:17 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:24:17 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:24:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:24:17 --> URI Class Initialized
DEBUG - 2013-08-30 04:24:17 --> Router Class Initialized
ERROR - 2013-08-30 04:24:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:24:19 --> Config Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:24:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:24:19 --> URI Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Router Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Output Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Security Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Input Class Initialized
DEBUG - 2013-08-30 04:24:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:24:19 --> Language Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Loader Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:24:19 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:24:19 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:24:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:24:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:24:19 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Session Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:24:19 --> Session routines successfully run
DEBUG - 2013-08-30 04:24:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Controller Class Initialized
ERROR - 2013-08-30 04:24:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:24:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:24:19 --> Model Class Initialized
DEBUG - 2013-08-30 04:24:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:24:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:24:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:24:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:24:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:24:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:24:20 --> Model Class Initialized
DEBUG - 2013-08-30 04:24:20 --> Form Validation Class Initialized
DEBUG - 2013-08-30 04:24:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:24:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 04:24:20 --> DB Transaction Failure
ERROR - 2013-08-30 04:24:20 --> Query error: Table 'school.users' doesn't exist
DEBUG - 2013-08-30 04:24:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-30 04:26:11 --> Config Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:26:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:26:11 --> URI Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Router Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Output Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Security Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Input Class Initialized
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:26:11 --> Language Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Loader Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:26:11 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Session Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:26:11 --> Session routines successfully run
DEBUG - 2013-08-30 04:26:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Controller Class Initialized
ERROR - 2013-08-30 04:26:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:26:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:26:11 --> Model Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:26:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:26:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:26:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:26:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:26:11 --> Model Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Form Validation Class Initialized
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 04:26:11 --> Config Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:26:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:26:11 --> URI Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Router Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Output Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Security Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Input Class Initialized
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:26:11 --> Language Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Loader Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:26:11 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Session Class Initialized
DEBUG - 2013-08-30 04:26:11 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:26:11 --> Session routines successfully run
DEBUG - 2013-08-30 04:26:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:26:12 --> Controller Class Initialized
ERROR - 2013-08-30 04:26:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:26:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:26:12 --> Model Class Initialized
DEBUG - 2013-08-30 04:26:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:26:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:26:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:26:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:26:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:26:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:26:12 --> Model Class Initialized
DEBUG - 2013-08-30 04:26:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:26:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:26:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:26:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:26:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:26:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:26:12 --> File loaded: application/views/users/show.php
DEBUG - 2013-08-30 04:26:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:26:12 --> Final output sent to browser
DEBUG - 2013-08-30 04:26:12 --> Total execution time: 0.4420
DEBUG - 2013-08-30 04:26:12 --> Config Class Initialized
DEBUG - 2013-08-30 04:26:12 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:26:12 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:26:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:26:12 --> URI Class Initialized
DEBUG - 2013-08-30 04:26:12 --> Router Class Initialized
ERROR - 2013-08-30 04:26:12 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:29:50 --> Config Class Initialized
DEBUG - 2013-08-30 04:29:50 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:29:50 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:29:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:29:50 --> URI Class Initialized
DEBUG - 2013-08-30 04:29:50 --> Router Class Initialized
DEBUG - 2013-08-30 04:29:50 --> Output Class Initialized
DEBUG - 2013-08-30 04:29:50 --> Security Class Initialized
DEBUG - 2013-08-30 04:29:50 --> Input Class Initialized
DEBUG - 2013-08-30 04:29:50 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:50 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:50 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:50 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:50 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:29:50 --> Language Class Initialized
DEBUG - 2013-08-30 04:29:50 --> Loader Class Initialized
DEBUG - 2013-08-30 04:29:50 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:29:50 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:29:50 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:29:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:29:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:29:51 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:29:51 --> Session Class Initialized
DEBUG - 2013-08-30 04:29:51 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:29:51 --> Session garbage collection performed.
DEBUG - 2013-08-30 04:29:51 --> Session routines successfully run
DEBUG - 2013-08-30 04:29:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:29:51 --> Controller Class Initialized
ERROR - 2013-08-30 04:29:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:29:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:29:51 --> Model Class Initialized
DEBUG - 2013-08-30 04:29:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:29:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:29:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:29:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:29:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:29:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:29:51 --> Model Class Initialized
DEBUG - 2013-08-30 04:29:51 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:29:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:29:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:29:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:29:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:29:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:29:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:29:51 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:29:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:29:51 --> Final output sent to browser
DEBUG - 2013-08-30 04:29:51 --> Total execution time: 0.5500
DEBUG - 2013-08-30 04:29:51 --> Config Class Initialized
DEBUG - 2013-08-30 04:29:51 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:29:51 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:29:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:29:51 --> URI Class Initialized
DEBUG - 2013-08-30 04:29:51 --> Router Class Initialized
ERROR - 2013-08-30 04:29:51 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:29:54 --> Config Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:29:54 --> URI Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Router Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Output Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Security Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Input Class Initialized
DEBUG - 2013-08-30 04:29:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:29:54 --> Language Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Loader Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:29:54 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:29:54 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:29:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:29:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:29:54 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Session Class Initialized
DEBUG - 2013-08-30 04:29:54 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:29:55 --> Session routines successfully run
DEBUG - 2013-08-30 04:29:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:29:55 --> Controller Class Initialized
ERROR - 2013-08-30 04:29:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:29:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:29:55 --> Model Class Initialized
DEBUG - 2013-08-30 04:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:29:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:29:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:29:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:29:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:29:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:29:55 --> Model Class Initialized
DEBUG - 2013-08-30 04:29:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:29:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:29:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:29:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:29:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:29:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:29:55 --> File loaded: application/views/users/edit.php
DEBUG - 2013-08-30 04:29:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:29:55 --> Final output sent to browser
DEBUG - 2013-08-30 04:29:55 --> Total execution time: 0.4460
DEBUG - 2013-08-30 04:29:55 --> Config Class Initialized
DEBUG - 2013-08-30 04:29:55 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:29:55 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:29:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:29:55 --> URI Class Initialized
DEBUG - 2013-08-30 04:29:55 --> Router Class Initialized
ERROR - 2013-08-30 04:29:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:30:01 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:01 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Router Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Output Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Security Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Input Class Initialized
DEBUG - 2013-08-30 04:30:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:30:01 --> Language Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Loader Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:30:01 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:30:01 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:30:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:30:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:30:01 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Session Class Initialized
DEBUG - 2013-08-30 04:30:01 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:30:02 --> Session routines successfully run
DEBUG - 2013-08-30 04:30:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Controller Class Initialized
ERROR - 2013-08-30 04:30:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:02 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:30:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:30:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:30:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:30:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:02 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Form Validation Class Initialized
DEBUG - 2013-08-30 04:30:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 04:30:02 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:02 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Router Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Output Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Security Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Input Class Initialized
DEBUG - 2013-08-30 04:30:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:02 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:30:02 --> Language Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Loader Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:30:02 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:30:02 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:30:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:30:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:30:02 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Session Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:30:02 --> Session routines successfully run
DEBUG - 2013-08-30 04:30:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Controller Class Initialized
ERROR - 2013-08-30 04:30:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:02 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:30:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:30:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:30:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:30:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:02 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:30:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:30:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:30:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:30:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:30:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:30:02 --> File loaded: application/views/users/show.php
DEBUG - 2013-08-30 04:30:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:30:02 --> Final output sent to browser
DEBUG - 2013-08-30 04:30:02 --> Total execution time: 0.4430
DEBUG - 2013-08-30 04:30:02 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:02 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:02 --> Router Class Initialized
ERROR - 2013-08-30 04:30:02 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:30:04 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:04 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Router Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Output Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Security Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Input Class Initialized
DEBUG - 2013-08-30 04:30:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:30:04 --> Language Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Loader Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:30:04 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:30:04 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:30:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:30:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:30:04 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Session Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:30:04 --> Session routines successfully run
DEBUG - 2013-08-30 04:30:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Controller Class Initialized
ERROR - 2013-08-30 04:30:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:04 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:30:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:30:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:30:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:30:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:05 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:05 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:30:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:30:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:30:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:30:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:30:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:30:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:30:05 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:30:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:30:05 --> Final output sent to browser
DEBUG - 2013-08-30 04:30:05 --> Total execution time: 0.4930
DEBUG - 2013-08-30 04:30:05 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:05 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:05 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:05 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:05 --> Router Class Initialized
ERROR - 2013-08-30 04:30:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:30:26 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:26 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Router Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Output Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Security Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Input Class Initialized
DEBUG - 2013-08-30 04:30:26 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:26 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:26 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:26 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:26 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:30:26 --> Language Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Loader Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:30:26 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:30:26 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:30:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:30:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:30:26 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Session Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:30:26 --> Session routines successfully run
DEBUG - 2013-08-30 04:30:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Controller Class Initialized
ERROR - 2013-08-30 04:30:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:26 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:30:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:30:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:30:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:30:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:26 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:30:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:30:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:30:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:30:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:30:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:30:26 --> File loaded: application/views/users/edit.php
DEBUG - 2013-08-30 04:30:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:30:26 --> Final output sent to browser
DEBUG - 2013-08-30 04:30:26 --> Total execution time: 0.5040
DEBUG - 2013-08-30 04:30:27 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:27 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:27 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:27 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:27 --> Router Class Initialized
ERROR - 2013-08-30 04:30:27 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:30:29 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:29 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:29 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:29 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:29 --> Router Class Initialized
DEBUG - 2013-08-30 04:30:29 --> Output Class Initialized
DEBUG - 2013-08-30 04:30:29 --> Security Class Initialized
DEBUG - 2013-08-30 04:30:29 --> Input Class Initialized
DEBUG - 2013-08-30 04:30:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:29 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:30:29 --> Language Class Initialized
DEBUG - 2013-08-30 04:30:29 --> Loader Class Initialized
DEBUG - 2013-08-30 04:30:29 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:30:29 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:30:29 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:30:29 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:30:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:30:30 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Session Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:30:30 --> Session routines successfully run
DEBUG - 2013-08-30 04:30:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Controller Class Initialized
ERROR - 2013-08-30 04:30:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:30 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:30:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:30:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:30:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:30:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:30 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Form Validation Class Initialized
DEBUG - 2013-08-30 04:30:30 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:30 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:30 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 04:30:30 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:30 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Router Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Output Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Security Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Input Class Initialized
DEBUG - 2013-08-30 04:30:30 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:30 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:30 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:30 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:30 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:30:30 --> Language Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Loader Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:30:30 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:30:30 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:30:30 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:30:30 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:30:30 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Session Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:30:30 --> Session routines successfully run
DEBUG - 2013-08-30 04:30:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Controller Class Initialized
ERROR - 2013-08-30 04:30:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:30 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:30:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:30:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:30:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:30:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:30 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:30:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:30:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:30:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:30:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:30:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:30:30 --> File loaded: application/views/users/show.php
DEBUG - 2013-08-30 04:30:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:30:30 --> Final output sent to browser
DEBUG - 2013-08-30 04:30:30 --> Total execution time: 0.4700
DEBUG - 2013-08-30 04:30:30 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:30 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:30 --> Router Class Initialized
ERROR - 2013-08-30 04:30:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:30:33 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:33 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Router Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Output Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Security Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Input Class Initialized
DEBUG - 2013-08-30 04:30:33 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:33 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:33 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:33 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:33 --> XSS Filtering completed
DEBUG - 2013-08-30 04:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:30:33 --> Language Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Loader Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:30:33 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:30:33 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:30:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:30:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:30:33 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Session Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:30:33 --> Session routines successfully run
DEBUG - 2013-08-30 04:30:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Controller Class Initialized
ERROR - 2013-08-30 04:30:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:33 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:30:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:30:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:30:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:30:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:30:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:30:33 --> Model Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:30:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:30:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:30:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:30:33 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:30:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:30:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:30:33 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:30:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:30:33 --> Final output sent to browser
DEBUG - 2013-08-30 04:30:33 --> Total execution time: 0.5600
DEBUG - 2013-08-30 04:30:33 --> Config Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:30:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:30:33 --> URI Class Initialized
DEBUG - 2013-08-30 04:30:33 --> Router Class Initialized
ERROR - 2013-08-30 04:30:33 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:31:35 --> Config Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:31:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:31:35 --> URI Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Router Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Output Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Security Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Input Class Initialized
DEBUG - 2013-08-30 04:31:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:35 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:31:35 --> Language Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Loader Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:31:35 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:31:35 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:31:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:31:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:31:35 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Session Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:31:35 --> Session routines successfully run
DEBUG - 2013-08-30 04:31:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Controller Class Initialized
ERROR - 2013-08-30 04:31:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:31:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:31:35 --> Model Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:31:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:31:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:31:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:31:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:31:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:31:35 --> Model Class Initialized
DEBUG - 2013-08-30 04:31:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:31:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:31:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:31:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:31:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:31:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:31:35 --> File loaded: application/views/users/new.php
DEBUG - 2013-08-30 04:31:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:31:35 --> Final output sent to browser
DEBUG - 2013-08-30 04:31:35 --> Total execution time: 0.5150
DEBUG - 2013-08-30 04:31:35 --> Config Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:31:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:31:35 --> URI Class Initialized
DEBUG - 2013-08-30 04:31:35 --> Router Class Initialized
ERROR - 2013-08-30 04:31:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:31:53 --> Config Class Initialized
DEBUG - 2013-08-30 04:31:53 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:31:53 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:31:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:31:53 --> URI Class Initialized
DEBUG - 2013-08-30 04:31:53 --> Router Class Initialized
DEBUG - 2013-08-30 04:31:53 --> Output Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Security Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Input Class Initialized
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:31:54 --> Language Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Loader Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:31:54 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Session Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:31:54 --> Session routines successfully run
DEBUG - 2013-08-30 04:31:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Controller Class Initialized
ERROR - 2013-08-30 04:31:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:31:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:31:54 --> Model Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:31:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:31:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:31:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:31:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:31:54 --> Model Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Form Validation Class Initialized
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 04:31:54 --> Config Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:31:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:31:54 --> URI Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Router Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Output Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Security Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Input Class Initialized
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> XSS Filtering completed
DEBUG - 2013-08-30 04:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:31:54 --> Language Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Loader Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:31:54 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Session Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:31:54 --> Session routines successfully run
DEBUG - 2013-08-30 04:31:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Controller Class Initialized
ERROR - 2013-08-30 04:31:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:31:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:31:54 --> Model Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:31:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:31:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:31:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:31:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:31:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:31:54 --> Model Class Initialized
DEBUG - 2013-08-30 04:31:54 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:31:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:31:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:31:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:31:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:31:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:31:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:31:55 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:31:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:31:55 --> Final output sent to browser
DEBUG - 2013-08-30 04:31:55 --> Total execution time: 0.5450
DEBUG - 2013-08-30 04:31:55 --> Config Class Initialized
DEBUG - 2013-08-30 04:31:55 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:31:55 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:31:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:31:55 --> URI Class Initialized
DEBUG - 2013-08-30 04:31:55 --> Router Class Initialized
ERROR - 2013-08-30 04:31:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:32:19 --> Config Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:32:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:32:19 --> URI Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Router Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Output Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Security Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Input Class Initialized
DEBUG - 2013-08-30 04:32:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:32:19 --> Language Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Loader Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:32:19 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:32:19 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:32:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:32:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:32:19 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Session Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:32:19 --> Session routines successfully run
DEBUG - 2013-08-30 04:32:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Controller Class Initialized
ERROR - 2013-08-30 04:32:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:32:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:32:19 --> Model Class Initialized
DEBUG - 2013-08-30 04:32:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:32:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:32:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:32:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:32:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:32:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:32:20 --> Model Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Config Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:32:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:32:20 --> URI Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Router Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Output Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Security Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Input Class Initialized
DEBUG - 2013-08-30 04:32:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:32:20 --> Language Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Loader Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:32:20 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:32:20 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:32:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:32:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:32:20 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Session Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:32:20 --> Session routines successfully run
DEBUG - 2013-08-30 04:32:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Controller Class Initialized
ERROR - 2013-08-30 04:32:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:32:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:32:20 --> Model Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:32:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:32:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:32:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:32:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:32:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:32:20 --> Model Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:32:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:32:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:32:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:32:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:32:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:32:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:32:20 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:32:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:32:20 --> Final output sent to browser
DEBUG - 2013-08-30 04:32:20 --> Total execution time: 0.5410
DEBUG - 2013-08-30 04:32:20 --> Config Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:32:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:32:20 --> URI Class Initialized
DEBUG - 2013-08-30 04:32:20 --> Router Class Initialized
ERROR - 2013-08-30 04:32:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:33:16 --> Config Class Initialized
DEBUG - 2013-08-30 04:33:16 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:33:16 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:33:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:33:16 --> URI Class Initialized
DEBUG - 2013-08-30 04:33:16 --> Router Class Initialized
DEBUG - 2013-08-30 04:33:16 --> Output Class Initialized
DEBUG - 2013-08-30 04:33:16 --> Security Class Initialized
DEBUG - 2013-08-30 04:33:16 --> Input Class Initialized
DEBUG - 2013-08-30 04:33:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:33:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:33:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:33:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:33:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:33:16 --> Language Class Initialized
DEBUG - 2013-08-30 04:33:16 --> Loader Class Initialized
DEBUG - 2013-08-30 04:33:16 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:33:16 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:33:16 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:33:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:33:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:33:17 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:33:17 --> Session Class Initialized
DEBUG - 2013-08-30 04:33:17 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:33:17 --> Session routines successfully run
DEBUG - 2013-08-30 04:33:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:33:17 --> Controller Class Initialized
ERROR - 2013-08-30 04:33:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:33:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:33:17 --> Model Class Initialized
DEBUG - 2013-08-30 04:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:33:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:33:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:33:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:33:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:33:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:33:17 --> Model Class Initialized
DEBUG - 2013-08-30 04:33:17 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:33:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:33:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:33:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:33:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:33:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:33:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:33:17 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:33:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:33:17 --> Final output sent to browser
DEBUG - 2013-08-30 04:33:17 --> Total execution time: 0.5880
DEBUG - 2013-08-30 04:33:17 --> Config Class Initialized
DEBUG - 2013-08-30 04:33:17 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:33:17 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:33:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:33:17 --> URI Class Initialized
DEBUG - 2013-08-30 04:33:17 --> Router Class Initialized
ERROR - 2013-08-30 04:33:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:34:25 --> Config Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:34:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:34:25 --> URI Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Router Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Output Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Security Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Input Class Initialized
DEBUG - 2013-08-30 04:34:25 --> XSS Filtering completed
DEBUG - 2013-08-30 04:34:25 --> XSS Filtering completed
DEBUG - 2013-08-30 04:34:25 --> XSS Filtering completed
DEBUG - 2013-08-30 04:34:25 --> XSS Filtering completed
DEBUG - 2013-08-30 04:34:25 --> XSS Filtering completed
DEBUG - 2013-08-30 04:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:34:25 --> Language Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Loader Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:34:25 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:34:25 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:34:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:34:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:34:25 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Session Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:34:25 --> Session routines successfully run
DEBUG - 2013-08-30 04:34:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Controller Class Initialized
ERROR - 2013-08-30 04:34:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:34:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:34:25 --> Model Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:34:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:34:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:34:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:34:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:34:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:34:25 --> Model Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:34:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:34:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:34:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:34:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:34:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:34:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:34:25 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-30 04:34:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:34:25 --> Final output sent to browser
DEBUG - 2013-08-30 04:34:25 --> Total execution time: 0.7500
DEBUG - 2013-08-30 04:34:25 --> Config Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:34:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:34:25 --> URI Class Initialized
DEBUG - 2013-08-30 04:34:25 --> Router Class Initialized
ERROR - 2013-08-30 04:34:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:48:47 --> Config Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:48:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:48:47 --> URI Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Router Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Output Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Security Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Input Class Initialized
DEBUG - 2013-08-30 04:48:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:48:47 --> Language Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Loader Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:48:47 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:48:47 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:48:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:48:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:48:47 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Session Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:48:47 --> Session routines successfully run
DEBUG - 2013-08-30 04:48:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:48:47 --> Controller Class Initialized
ERROR - 2013-08-30 04:48:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:48:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:48:48 --> Model Class Initialized
DEBUG - 2013-08-30 04:48:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:48:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:48:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:48:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:48:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:48:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:48:48 --> Model Class Initialized
DEBUG - 2013-08-30 04:48:48 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:48:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:48:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:48:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:48:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:48:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:48:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:48:48 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-30 04:48:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:48:48 --> Final output sent to browser
DEBUG - 2013-08-30 04:48:48 --> Total execution time: 1.8671
DEBUG - 2013-08-30 04:48:48 --> Config Class Initialized
DEBUG - 2013-08-30 04:48:48 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:48:48 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:48:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:48:48 --> URI Class Initialized
DEBUG - 2013-08-30 04:48:48 --> Router Class Initialized
ERROR - 2013-08-30 04:48:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:48:59 --> Config Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:48:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:48:59 --> URI Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Router Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Output Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Security Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Input Class Initialized
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:48:59 --> Language Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Loader Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:48:59 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:48:59 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:48:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:48:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:48:59 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Session Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:48:59 --> Session routines successfully run
DEBUG - 2013-08-30 04:48:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Controller Class Initialized
ERROR - 2013-08-30 04:48:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:48:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:48:59 --> Model Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:48:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:48:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:48:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:48:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:48:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:48:59 --> Model Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Config Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:48:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:48:59 --> URI Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Router Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Output Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Security Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Input Class Initialized
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> XSS Filtering completed
DEBUG - 2013-08-30 04:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:48:59 --> Language Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Loader Class Initialized
DEBUG - 2013-08-30 04:48:59 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:49:00 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:49:00 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:49:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:49:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:49:00 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:49:00 --> Session Class Initialized
DEBUG - 2013-08-30 04:49:00 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:49:00 --> Session garbage collection performed.
DEBUG - 2013-08-30 04:49:00 --> Session routines successfully run
DEBUG - 2013-08-30 04:49:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:49:00 --> Controller Class Initialized
ERROR - 2013-08-30 04:49:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:49:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:49:00 --> Model Class Initialized
DEBUG - 2013-08-30 04:49:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:49:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:49:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:49:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:49:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:49:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:49:00 --> Model Class Initialized
DEBUG - 2013-08-30 04:49:00 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:49:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:49:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:49:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:49:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:49:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:49:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:49:00 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-30 04:49:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:49:00 --> Final output sent to browser
DEBUG - 2013-08-30 04:49:00 --> Total execution time: 0.6130
DEBUG - 2013-08-30 04:49:00 --> Config Class Initialized
DEBUG - 2013-08-30 04:49:00 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:49:00 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:49:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:49:00 --> URI Class Initialized
DEBUG - 2013-08-30 04:49:00 --> Router Class Initialized
ERROR - 2013-08-30 04:49:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:49:03 --> Config Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:49:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:49:03 --> URI Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Router Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Output Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Security Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Input Class Initialized
DEBUG - 2013-08-30 04:49:03 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:03 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:03 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:03 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:03 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:49:03 --> Language Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Loader Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:49:03 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:49:03 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:49:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:49:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:49:03 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Session Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:49:03 --> Session routines successfully run
DEBUG - 2013-08-30 04:49:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Controller Class Initialized
ERROR - 2013-08-30 04:49:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:49:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:49:03 --> Model Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:49:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:49:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:49:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:49:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:49:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:49:03 --> Model Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:49:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:49:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:49:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:49:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:49:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:49:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:49:03 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:49:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:49:03 --> Final output sent to browser
DEBUG - 2013-08-30 04:49:03 --> Total execution time: 0.6270
DEBUG - 2013-08-30 04:49:03 --> Config Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:49:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:49:03 --> URI Class Initialized
DEBUG - 2013-08-30 04:49:03 --> Router Class Initialized
ERROR - 2013-08-30 04:49:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:49:11 --> Config Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:49:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:49:11 --> URI Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Router Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Output Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Security Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Input Class Initialized
DEBUG - 2013-08-30 04:49:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:49:11 --> Language Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Loader Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:49:11 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:49:11 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:49:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:49:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:49:11 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Session Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:49:11 --> Session routines successfully run
DEBUG - 2013-08-30 04:49:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:49:11 --> Controller Class Initialized
ERROR - 2013-08-30 04:49:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:49:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:49:12 --> Model Class Initialized
DEBUG - 2013-08-30 04:49:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:49:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:49:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:49:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:49:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:49:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:49:12 --> Model Class Initialized
DEBUG - 2013-08-30 04:49:12 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:49:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:49:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:49:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:49:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:49:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:49:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:49:12 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-30 04:49:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:49:12 --> Final output sent to browser
DEBUG - 2013-08-30 04:49:12 --> Total execution time: 0.6360
DEBUG - 2013-08-30 04:49:12 --> Config Class Initialized
DEBUG - 2013-08-30 04:49:12 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:49:12 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:49:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:49:12 --> URI Class Initialized
DEBUG - 2013-08-30 04:49:12 --> Router Class Initialized
ERROR - 2013-08-30 04:49:12 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:49:19 --> Config Class Initialized
DEBUG - 2013-08-30 04:49:19 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:49:19 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:49:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:49:19 --> URI Class Initialized
DEBUG - 2013-08-30 04:49:19 --> Router Class Initialized
DEBUG - 2013-08-30 04:49:19 --> Output Class Initialized
DEBUG - 2013-08-30 04:49:19 --> Security Class Initialized
DEBUG - 2013-08-30 04:49:19 --> Input Class Initialized
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:49:19 --> Language Class Initialized
DEBUG - 2013-08-30 04:49:19 --> Loader Class Initialized
DEBUG - 2013-08-30 04:49:19 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:49:19 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:49:19 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:49:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:49:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:49:19 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:49:19 --> Session Class Initialized
DEBUG - 2013-08-30 04:49:20 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:49:20 --> Session routines successfully run
DEBUG - 2013-08-30 04:49:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:49:20 --> Controller Class Initialized
ERROR - 2013-08-30 04:49:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:49:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:49:20 --> Model Class Initialized
DEBUG - 2013-08-30 04:49:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:49:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:49:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:49:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:49:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:49:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:49:20 --> Model Class Initialized
DEBUG - 2013-08-30 04:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> Config Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:50:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:50:19 --> URI Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Router Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Output Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Security Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Input Class Initialized
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:50:19 --> Language Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Loader Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:50:19 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:50:19 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:50:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:50:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:50:19 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Session Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:50:19 --> Session routines successfully run
DEBUG - 2013-08-30 04:50:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Controller Class Initialized
ERROR - 2013-08-30 04:50:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:50:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:50:19 --> Model Class Initialized
DEBUG - 2013-08-30 04:50:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:50:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:50:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:50:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:50:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:50:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:50:19 --> Model Class Initialized
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:50:19 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> Config Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:51:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:51:47 --> URI Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Router Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Output Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Security Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Input Class Initialized
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:51:47 --> Language Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Loader Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:51:47 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:51:47 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:51:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:51:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:51:47 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Session Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:51:47 --> Session routines successfully run
DEBUG - 2013-08-30 04:51:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Controller Class Initialized
ERROR - 2013-08-30 04:51:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:51:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:51:47 --> Model Class Initialized
DEBUG - 2013-08-30 04:51:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:51:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:51:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:51:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:51:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:51:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:51:48 --> Model Class Initialized
DEBUG - 2013-08-30 04:51:48 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:48 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:48 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:48 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:48 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:48 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:48 --> XSS Filtering completed
DEBUG - 2013-08-30 04:51:48 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> Config Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:52:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:52:01 --> URI Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Router Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Output Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Security Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Input Class Initialized
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:52:01 --> Language Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Loader Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:52:01 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:52:01 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:52:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:52:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:52:01 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Session Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:52:01 --> Session routines successfully run
DEBUG - 2013-08-30 04:52:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Controller Class Initialized
ERROR - 2013-08-30 04:52:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:52:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:52:01 --> Model Class Initialized
DEBUG - 2013-08-30 04:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:52:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:52:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:52:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:52:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:52:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:52:01 --> Model Class Initialized
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> Config Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:52:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:52:15 --> URI Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Router Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Output Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Security Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Input Class Initialized
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:52:15 --> Language Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Loader Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:52:15 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:52:15 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:52:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:52:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:52:15 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Session Class Initialized
DEBUG - 2013-08-30 04:52:15 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:52:15 --> Session routines successfully run
DEBUG - 2013-08-30 04:52:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:52:16 --> Controller Class Initialized
ERROR - 2013-08-30 04:52:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:52:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:52:16 --> Model Class Initialized
DEBUG - 2013-08-30 04:52:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:52:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:52:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:52:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:52:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:52:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:52:16 --> Model Class Initialized
DEBUG - 2013-08-30 04:52:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:52:16 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:57 --> Config Class Initialized
DEBUG - 2013-08-30 04:54:57 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:54:57 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:54:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:54:57 --> URI Class Initialized
DEBUG - 2013-08-30 04:54:57 --> Router Class Initialized
DEBUG - 2013-08-30 04:54:57 --> Output Class Initialized
DEBUG - 2013-08-30 04:54:57 --> Security Class Initialized
DEBUG - 2013-08-30 04:54:57 --> Input Class Initialized
DEBUG - 2013-08-30 04:54:57 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:57 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:57 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:57 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:57 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:57 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:57 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:54:57 --> Language Class Initialized
DEBUG - 2013-08-30 04:54:57 --> Loader Class Initialized
DEBUG - 2013-08-30 04:54:57 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:54:57 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:54:57 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:54:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:54:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:54:58 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Session Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:54:58 --> Session routines successfully run
DEBUG - 2013-08-30 04:54:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Controller Class Initialized
ERROR - 2013-08-30 04:54:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:54:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:54:58 --> Model Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:54:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:54:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:54:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:54:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:54:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:54:58 --> Model Class Initialized
DEBUG - 2013-08-30 04:54:58 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:58 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:58 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:58 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:58 --> Config Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:54:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:54:58 --> URI Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Router Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Output Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Security Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Input Class Initialized
DEBUG - 2013-08-30 04:54:58 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:58 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:58 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:58 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:58 --> XSS Filtering completed
DEBUG - 2013-08-30 04:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:54:58 --> Language Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Loader Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:54:58 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:54:58 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:54:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:54:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:54:58 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Session Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:54:58 --> Session routines successfully run
DEBUG - 2013-08-30 04:54:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Controller Class Initialized
ERROR - 2013-08-30 04:54:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:54:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:54:58 --> Model Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:54:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:54:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:54:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:54:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:54:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:54:58 --> Model Class Initialized
DEBUG - 2013-08-30 04:54:58 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:54:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:54:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:54:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:54:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:54:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:54:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:54:59 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-30 04:54:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:54:59 --> Final output sent to browser
DEBUG - 2013-08-30 04:54:59 --> Total execution time: 0.7540
DEBUG - 2013-08-30 04:54:59 --> Config Class Initialized
DEBUG - 2013-08-30 04:54:59 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:54:59 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:54:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:54:59 --> URI Class Initialized
DEBUG - 2013-08-30 04:54:59 --> Router Class Initialized
ERROR - 2013-08-30 04:54:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:55:01 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:01 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:01 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:01 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:01 --> Router Class Initialized
DEBUG - 2013-08-30 04:55:01 --> Output Class Initialized
DEBUG - 2013-08-30 04:55:01 --> Security Class Initialized
DEBUG - 2013-08-30 04:55:01 --> Input Class Initialized
DEBUG - 2013-08-30 04:55:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:01 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:55:02 --> Language Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Loader Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:55:02 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:55:02 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:55:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:55:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:55:02 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Session Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:55:02 --> Session routines successfully run
DEBUG - 2013-08-30 04:55:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Controller Class Initialized
ERROR - 2013-08-30 04:55:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:02 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:55:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:55:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:55:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:55:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:02 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:55:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:55:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:55:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:55:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:55:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:55:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:55:02 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 04:55:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:55:02 --> Final output sent to browser
DEBUG - 2013-08-30 04:55:02 --> Total execution time: 0.6880
DEBUG - 2013-08-30 04:55:02 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:02 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:02 --> Router Class Initialized
ERROR - 2013-08-30 04:55:02 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:55:04 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:04 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:04 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:04 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:04 --> Router Class Initialized
DEBUG - 2013-08-30 04:55:04 --> Output Class Initialized
DEBUG - 2013-08-30 04:55:04 --> Security Class Initialized
DEBUG - 2013-08-30 04:55:04 --> Input Class Initialized
DEBUG - 2013-08-30 04:55:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:04 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:55:04 --> Language Class Initialized
DEBUG - 2013-08-30 04:55:04 --> Loader Class Initialized
DEBUG - 2013-08-30 04:55:04 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:55:04 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:55:04 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:55:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:55:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:55:05 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:55:05 --> Session Class Initialized
DEBUG - 2013-08-30 04:55:05 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:55:05 --> Session routines successfully run
DEBUG - 2013-08-30 04:55:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:55:05 --> Controller Class Initialized
ERROR - 2013-08-30 04:55:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:05 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:55:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:55:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:55:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:55:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:05 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:05 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:55:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:55:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:55:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:55:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:55:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:55:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:55:05 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-30 04:55:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:55:05 --> Final output sent to browser
DEBUG - 2013-08-30 04:55:05 --> Total execution time: 0.7260
DEBUG - 2013-08-30 04:55:05 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:05 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:05 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:05 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:05 --> Router Class Initialized
ERROR - 2013-08-30 04:55:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:55:11 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:11 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Router Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Output Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Security Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Input Class Initialized
DEBUG - 2013-08-30 04:55:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:11 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:55:11 --> Language Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Loader Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:55:11 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:55:11 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:55:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:55:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:55:11 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Session Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:55:11 --> Session routines successfully run
DEBUG - 2013-08-30 04:55:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Controller Class Initialized
ERROR - 2013-08-30 04:55:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:11 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:55:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:55:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:55:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:55:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:11 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:11 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:55:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:55:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:55:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:55:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:55:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:55:12 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-30 04:55:12 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 04:55:12 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 04:55:12 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 04:55:12 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 04:55:12 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-08-30 04:55:12 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-30 04:55:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:55:12 --> Final output sent to browser
DEBUG - 2013-08-30 04:55:12 --> Total execution time: 0.8480
DEBUG - 2013-08-30 04:55:12 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:12 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:12 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:12 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:12 --> Router Class Initialized
ERROR - 2013-08-30 04:55:12 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:55:18 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:18 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Router Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Output Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Security Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Input Class Initialized
DEBUG - 2013-08-30 04:55:18 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:18 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:18 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:18 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:18 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:55:18 --> Language Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Loader Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:55:18 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:55:18 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:55:18 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:55:18 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:55:18 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Session Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:55:18 --> Session routines successfully run
DEBUG - 2013-08-30 04:55:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:55:18 --> Controller Class Initialized
ERROR - 2013-08-30 04:55:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:19 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:55:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:55:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:55:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:55:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:19 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:19 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:55:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:55:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:55:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:55:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:55:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:55:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:55:19 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-30 04:55:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:55:19 --> Final output sent to browser
DEBUG - 2013-08-30 04:55:19 --> Total execution time: 0.8640
DEBUG - 2013-08-30 04:55:19 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:19 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:19 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:19 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:19 --> Router Class Initialized
ERROR - 2013-08-30 04:55:19 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 04:55:20 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:20 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:20 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:21 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Router Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Output Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Security Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Input Class Initialized
DEBUG - 2013-08-30 04:55:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:21 --> XSS Filtering completed
DEBUG - 2013-08-30 04:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 04:55:21 --> Language Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Loader Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Helper loaded: url_helper
DEBUG - 2013-08-30 04:55:21 --> Helper loaded: file_helper
DEBUG - 2013-08-30 04:55:21 --> Helper loaded: form_helper
DEBUG - 2013-08-30 04:55:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 04:55:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 04:55:21 --> Database Driver Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Session Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Helper loaded: string_helper
DEBUG - 2013-08-30 04:55:21 --> Session routines successfully run
DEBUG - 2013-08-30 04:55:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Controller Class Initialized
ERROR - 2013-08-30 04:55:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:21 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 04:55:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 04:55:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 04:55:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 04:55:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 04:55:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 04:55:21 --> Model Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Pagination Class Initialized
DEBUG - 2013-08-30 04:55:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 04:55:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 04:55:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 04:55:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 04:55:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 04:55:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 04:55:21 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-30 04:55:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 04:55:21 --> Final output sent to browser
DEBUG - 2013-08-30 04:55:21 --> Total execution time: 0.7530
DEBUG - 2013-08-30 04:55:21 --> Config Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Hooks Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Utf8 Class Initialized
DEBUG - 2013-08-30 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 04:55:21 --> URI Class Initialized
DEBUG - 2013-08-30 04:55:21 --> Router Class Initialized
ERROR - 2013-08-30 04:55:21 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:09:09 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:09 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:10 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Router Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Output Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Security Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Input Class Initialized
DEBUG - 2013-08-30 05:09:10 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:10 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:10 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:10 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:10 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:09:10 --> Language Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Loader Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:09:10 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:09:10 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:09:10 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:09:10 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:09:10 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Session Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:09:10 --> Session routines successfully run
DEBUG - 2013-08-30 05:09:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Controller Class Initialized
ERROR - 2013-08-30 05:09:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:10 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:09:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:09:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:09:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:09:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:10 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:09:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:09:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:09:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:09:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:09:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:09:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:09:10 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-30 05:09:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:09:10 --> Final output sent to browser
DEBUG - 2013-08-30 05:09:10 --> Total execution time: 0.7780
DEBUG - 2013-08-30 05:09:10 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:10 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:10 --> Router Class Initialized
ERROR - 2013-08-30 05:09:10 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:09:14 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:14 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:14 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:14 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:14 --> Router Class Initialized
DEBUG - 2013-08-30 05:09:14 --> Output Class Initialized
DEBUG - 2013-08-30 05:09:14 --> Security Class Initialized
DEBUG - 2013-08-30 05:09:14 --> Input Class Initialized
DEBUG - 2013-08-30 05:09:14 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:14 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:14 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:14 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:14 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:09:14 --> Language Class Initialized
DEBUG - 2013-08-30 05:09:14 --> Loader Class Initialized
DEBUG - 2013-08-30 05:09:14 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:09:14 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:09:15 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:09:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:09:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:09:15 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:09:15 --> Session Class Initialized
DEBUG - 2013-08-30 05:09:15 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:09:15 --> Session routines successfully run
DEBUG - 2013-08-30 05:09:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:09:15 --> Controller Class Initialized
ERROR - 2013-08-30 05:09:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:15 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:09:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:09:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:09:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:09:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:15 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:15 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:09:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:09:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:09:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:09:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:09:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:09:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:09:15 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:09:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:09:15 --> Final output sent to browser
DEBUG - 2013-08-30 05:09:15 --> Total execution time: 0.9131
DEBUG - 2013-08-30 05:09:15 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:15 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:15 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:15 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:15 --> Router Class Initialized
ERROR - 2013-08-30 05:09:15 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:09:17 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:17 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:17 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:17 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:17 --> Router Class Initialized
DEBUG - 2013-08-30 05:09:17 --> Output Class Initialized
DEBUG - 2013-08-30 05:09:17 --> Security Class Initialized
DEBUG - 2013-08-30 05:09:17 --> Input Class Initialized
DEBUG - 2013-08-30 05:09:17 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:17 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:17 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:17 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:17 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:09:17 --> Language Class Initialized
DEBUG - 2013-08-30 05:09:17 --> Loader Class Initialized
DEBUG - 2013-08-30 05:09:17 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:09:17 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:09:17 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:09:17 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:09:17 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:09:17 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:09:18 --> Session Class Initialized
DEBUG - 2013-08-30 05:09:18 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:09:18 --> Session routines successfully run
DEBUG - 2013-08-30 05:09:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:09:18 --> Controller Class Initialized
ERROR - 2013-08-30 05:09:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:18 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:09:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:09:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:09:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:09:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:18 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:09:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:09:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:09:18 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:09:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:09:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:09:18 --> File loaded: application/views/jurusans/new.php
DEBUG - 2013-08-30 05:09:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:09:18 --> Final output sent to browser
DEBUG - 2013-08-30 05:09:18 --> Total execution time: 0.8250
DEBUG - 2013-08-30 05:09:18 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:18 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:18 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:18 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:18 --> Router Class Initialized
ERROR - 2013-08-30 05:09:18 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:09:24 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:24 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Router Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Output Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Security Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Input Class Initialized
DEBUG - 2013-08-30 05:09:24 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:24 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:24 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:24 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:24 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:24 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:24 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:09:24 --> Language Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Loader Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:09:24 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:09:24 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:09:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:09:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:09:24 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Session Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:09:24 --> Session routines successfully run
DEBUG - 2013-08-30 05:09:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Controller Class Initialized
ERROR - 2013-08-30 05:09:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:24 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:09:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:09:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:09:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:09:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:24 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:24 --> Form Validation Class Initialized
DEBUG - 2013-08-30 05:09:24 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 05:09:25 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:25 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Router Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Output Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Security Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Input Class Initialized
DEBUG - 2013-08-30 05:09:25 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:25 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:25 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:25 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:25 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:09:25 --> Language Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Loader Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:09:25 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:09:25 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:09:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:09:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:09:25 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Session Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:09:25 --> Session routines successfully run
DEBUG - 2013-08-30 05:09:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Controller Class Initialized
ERROR - 2013-08-30 05:09:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:25 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:09:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:09:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:09:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:09:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:25 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:25 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:09:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:09:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:09:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:09:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:09:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:09:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:09:25 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:09:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:09:25 --> Final output sent to browser
DEBUG - 2013-08-30 05:09:26 --> Total execution time: 0.8871
DEBUG - 2013-08-30 05:09:26 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:26 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:26 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:26 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:26 --> Router Class Initialized
ERROR - 2013-08-30 05:09:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:09:34 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:34 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:35 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Router Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Output Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Security Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Input Class Initialized
DEBUG - 2013-08-30 05:09:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:09:35 --> Language Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Loader Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:09:35 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:09:35 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:09:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:09:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:09:35 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Session Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:09:35 --> Session routines successfully run
DEBUG - 2013-08-30 05:09:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Controller Class Initialized
ERROR - 2013-08-30 05:09:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:35 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:09:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:09:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:09:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:09:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:35 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:35 --> DB Transaction Failure
ERROR - 2013-08-30 05:09:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1
DEBUG - 2013-08-30 05:09:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-30 05:09:52 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:52 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Router Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Output Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Security Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Input Class Initialized
DEBUG - 2013-08-30 05:09:52 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:52 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:52 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:52 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:52 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:09:52 --> Language Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Loader Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:09:52 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:09:52 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:09:52 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:09:52 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:09:52 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Session Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:09:52 --> Session routines successfully run
DEBUG - 2013-08-30 05:09:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:09:52 --> Controller Class Initialized
ERROR - 2013-08-30 05:09:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:52 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:09:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:09:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:09:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:09:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:53 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:53 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Router Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Output Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Security Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Input Class Initialized
DEBUG - 2013-08-30 05:09:53 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:53 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:53 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:53 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:53 --> XSS Filtering completed
DEBUG - 2013-08-30 05:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:09:53 --> Language Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Loader Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:09:53 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:09:53 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:09:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:09:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:09:53 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Session Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:09:53 --> Session routines successfully run
DEBUG - 2013-08-30 05:09:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Controller Class Initialized
ERROR - 2013-08-30 05:09:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:53 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:09:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:09:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:09:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:09:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:09:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:09:53 --> Model Class Initialized
DEBUG - 2013-08-30 05:09:53 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:09:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:09:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:09:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:09:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:09:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:09:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:09:53 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:09:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:09:53 --> Final output sent to browser
DEBUG - 2013-08-30 05:09:53 --> Total execution time: 0.7740
DEBUG - 2013-08-30 05:09:54 --> Config Class Initialized
DEBUG - 2013-08-30 05:09:54 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:09:54 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:09:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:09:54 --> URI Class Initialized
DEBUG - 2013-08-30 05:09:54 --> Router Class Initialized
ERROR - 2013-08-30 05:09:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:10:01 --> Config Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:10:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:10:01 --> URI Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Router Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Output Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Security Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Input Class Initialized
DEBUG - 2013-08-30 05:10:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:10:01 --> Language Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Loader Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:10:01 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:10:01 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:10:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:10:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:10:01 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Session Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:10:01 --> Session garbage collection performed.
DEBUG - 2013-08-30 05:10:01 --> Session routines successfully run
DEBUG - 2013-08-30 05:10:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Controller Class Initialized
ERROR - 2013-08-30 05:10:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:10:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:10:01 --> Model Class Initialized
DEBUG - 2013-08-30 05:10:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:10:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:10:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:10:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:10:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:10:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:10:02 --> Model Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Config Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:10:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:10:02 --> URI Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Router Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Output Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Security Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Input Class Initialized
DEBUG - 2013-08-30 05:10:02 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:02 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:02 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:02 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:02 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:10:02 --> Language Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Loader Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:10:02 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:10:02 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:10:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:10:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:10:02 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Session Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:10:02 --> Session routines successfully run
DEBUG - 2013-08-30 05:10:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Controller Class Initialized
ERROR - 2013-08-30 05:10:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:10:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:10:02 --> Model Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:10:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:10:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:10:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:10:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:10:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:10:02 --> Model Class Initialized
DEBUG - 2013-08-30 05:10:02 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:10:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:10:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:10:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:10:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:10:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:10:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:10:02 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:10:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:10:02 --> Final output sent to browser
DEBUG - 2013-08-30 05:10:02 --> Total execution time: 0.8600
DEBUG - 2013-08-30 05:10:03 --> Config Class Initialized
DEBUG - 2013-08-30 05:10:03 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:10:03 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:10:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:10:03 --> URI Class Initialized
DEBUG - 2013-08-30 05:10:03 --> Router Class Initialized
ERROR - 2013-08-30 05:10:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:10:07 --> Config Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:10:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:10:07 --> URI Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Router Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Output Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Security Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Input Class Initialized
DEBUG - 2013-08-30 05:10:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:10:07 --> Language Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Loader Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:10:07 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:10:07 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:10:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:10:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:10:07 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Session Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:10:07 --> Session routines successfully run
DEBUG - 2013-08-30 05:10:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Controller Class Initialized
ERROR - 2013-08-30 05:10:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:10:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:10:07 --> Model Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:10:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:10:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:10:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:10:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:10:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:10:07 --> Model Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Config Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:10:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:10:07 --> URI Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Router Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Output Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Security Class Initialized
DEBUG - 2013-08-30 05:10:07 --> Input Class Initialized
DEBUG - 2013-08-30 05:10:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:08 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:08 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:08 --> XSS Filtering completed
DEBUG - 2013-08-30 05:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:10:08 --> Language Class Initialized
DEBUG - 2013-08-30 05:10:08 --> Loader Class Initialized
DEBUG - 2013-08-30 05:10:08 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:10:08 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:10:08 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:10:08 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:10:08 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:10:08 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:10:08 --> Session Class Initialized
DEBUG - 2013-08-30 05:10:08 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:10:08 --> Session garbage collection performed.
DEBUG - 2013-08-30 05:10:08 --> Session routines successfully run
DEBUG - 2013-08-30 05:10:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:10:08 --> Controller Class Initialized
ERROR - 2013-08-30 05:10:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:10:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:10:08 --> Model Class Initialized
DEBUG - 2013-08-30 05:10:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:10:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:10:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:10:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:10:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:10:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:10:08 --> Model Class Initialized
DEBUG - 2013-08-30 05:10:08 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:10:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:10:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:10:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:10:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:10:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:10:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:10:08 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:10:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:10:08 --> Final output sent to browser
DEBUG - 2013-08-30 05:10:08 --> Total execution time: 0.9561
DEBUG - 2013-08-30 05:10:08 --> Config Class Initialized
DEBUG - 2013-08-30 05:10:08 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:10:08 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:10:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:10:08 --> URI Class Initialized
DEBUG - 2013-08-30 05:10:09 --> Router Class Initialized
ERROR - 2013-08-30 05:10:09 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:13:06 --> Config Class Initialized
DEBUG - 2013-08-30 05:13:06 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:13:06 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:13:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:13:06 --> URI Class Initialized
DEBUG - 2013-08-30 05:13:06 --> Router Class Initialized
DEBUG - 2013-08-30 05:13:06 --> Output Class Initialized
DEBUG - 2013-08-30 05:13:06 --> Security Class Initialized
DEBUG - 2013-08-30 05:13:06 --> Input Class Initialized
DEBUG - 2013-08-30 05:13:06 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:06 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:06 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:06 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:06 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:06 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:06 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:06 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:13:06 --> Language Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Loader Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:13:07 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Session Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:13:07 --> Session routines successfully run
DEBUG - 2013-08-30 05:13:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Controller Class Initialized
ERROR - 2013-08-30 05:13:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:13:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:13:07 --> Model Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:13:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:13:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:13:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:13:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:13:07 --> Model Class Initialized
DEBUG - 2013-08-30 05:13:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:07 --> Config Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:13:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:13:07 --> URI Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Router Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Output Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Security Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Input Class Initialized
DEBUG - 2013-08-30 05:13:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:07 --> XSS Filtering completed
DEBUG - 2013-08-30 05:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:13:07 --> Language Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Loader Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:13:07 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Session Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:13:07 --> Session routines successfully run
DEBUG - 2013-08-30 05:13:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:13:07 --> Controller Class Initialized
ERROR - 2013-08-30 05:13:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:13:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:13:08 --> Model Class Initialized
DEBUG - 2013-08-30 05:13:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:13:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:13:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:13:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:13:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:13:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:13:08 --> Model Class Initialized
DEBUG - 2013-08-30 05:13:08 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:13:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:13:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:13:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:13:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:13:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:13:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:13:08 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:13:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:13:08 --> Final output sent to browser
DEBUG - 2013-08-30 05:13:08 --> Total execution time: 0.8841
DEBUG - 2013-08-30 05:13:08 --> Config Class Initialized
DEBUG - 2013-08-30 05:13:08 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:13:08 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:13:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:13:08 --> URI Class Initialized
DEBUG - 2013-08-30 05:13:08 --> Router Class Initialized
ERROR - 2013-08-30 05:13:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:14:00 --> Config Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:14:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:14:00 --> URI Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Router Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Output Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Security Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Input Class Initialized
DEBUG - 2013-08-30 05:14:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:14:00 --> Language Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Loader Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:14:00 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:14:00 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:14:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:14:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:14:00 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Session Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:14:00 --> Session routines successfully run
DEBUG - 2013-08-30 05:14:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:14:00 --> Controller Class Initialized
ERROR - 2013-08-30 05:14:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:14:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:14:01 --> Model Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:14:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:14:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:14:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:14:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:14:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:14:01 --> Model Class Initialized
DEBUG - 2013-08-30 05:14:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:01 --> Config Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:14:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:14:01 --> URI Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Router Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Output Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Security Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Input Class Initialized
DEBUG - 2013-08-30 05:14:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:14:01 --> Language Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Loader Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:14:01 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:14:01 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:14:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:14:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:14:01 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Session Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:14:01 --> Session routines successfully run
DEBUG - 2013-08-30 05:14:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Controller Class Initialized
ERROR - 2013-08-30 05:14:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:14:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:14:01 --> Model Class Initialized
DEBUG - 2013-08-30 05:14:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:14:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:14:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:14:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:14:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:14:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:14:04 --> Model Class Initialized
DEBUG - 2013-08-30 05:14:04 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:14:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:14:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:14:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:14:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:14:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:14:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:14:04 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:14:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:14:04 --> Final output sent to browser
DEBUG - 2013-08-30 05:14:04 --> Total execution time: 3.6402
DEBUG - 2013-08-30 05:14:05 --> Config Class Initialized
DEBUG - 2013-08-30 05:14:05 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:14:05 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:14:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:14:05 --> URI Class Initialized
DEBUG - 2013-08-30 05:14:05 --> Router Class Initialized
ERROR - 2013-08-30 05:14:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:15:09 --> Config Class Initialized
DEBUG - 2013-08-30 05:15:09 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:15:09 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:15:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:15:09 --> URI Class Initialized
DEBUG - 2013-08-30 05:15:09 --> Router Class Initialized
DEBUG - 2013-08-30 05:15:09 --> Output Class Initialized
DEBUG - 2013-08-30 05:15:09 --> Security Class Initialized
DEBUG - 2013-08-30 05:15:09 --> Input Class Initialized
DEBUG - 2013-08-30 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:09 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:15:09 --> Language Class Initialized
DEBUG - 2013-08-30 05:15:09 --> Loader Class Initialized
DEBUG - 2013-08-30 05:15:09 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:15:10 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:15:10 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:15:10 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:15:10 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:15:10 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:15:10 --> Session Class Initialized
DEBUG - 2013-08-30 05:15:10 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:15:11 --> Session routines successfully run
DEBUG - 2013-08-30 05:15:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:15:11 --> Controller Class Initialized
ERROR - 2013-08-30 05:15:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:15:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:15:11 --> Model Class Initialized
DEBUG - 2013-08-30 05:15:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:15:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:15:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:15:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:15:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:15:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:15:12 --> Model Class Initialized
DEBUG - 2013-08-30 05:15:12 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:12 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:12 --> XSS Filtering completed
DEBUG - 2013-08-30 05:15:12 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:26 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:26 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Router Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Output Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Security Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Input Class Initialized
DEBUG - 2013-08-30 05:16:26 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:26 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:26 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:26 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:26 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:26 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:26 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:26 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:16:26 --> Language Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Loader Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:16:26 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:16:26 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:16:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:16:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:16:26 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Session Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:16:26 --> Session routines successfully run
DEBUG - 2013-08-30 05:16:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:16:26 --> Controller Class Initialized
ERROR - 2013-08-30 05:16:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:26 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:16:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:16:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:16:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:16:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:27 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:27 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:27 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Router Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Output Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Security Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Input Class Initialized
DEBUG - 2013-08-30 05:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:27 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:16:27 --> Language Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Loader Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:16:27 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:16:27 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:16:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:16:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:16:27 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Session Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:16:27 --> Session routines successfully run
DEBUG - 2013-08-30 05:16:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:16:27 --> Controller Class Initialized
ERROR - 2013-08-30 05:16:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:27 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:16:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:16:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:16:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:16:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:28 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:28 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:16:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:16:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:16:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:16:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:16:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:16:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:16:28 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:16:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:16:28 --> Final output sent to browser
DEBUG - 2013-08-30 05:16:28 --> Total execution time: 1.1921
DEBUG - 2013-08-30 05:16:28 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:28 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:28 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:28 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:28 --> Router Class Initialized
ERROR - 2013-08-30 05:16:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:16:35 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:35 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Router Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Output Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Security Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Input Class Initialized
DEBUG - 2013-08-30 05:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:35 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:16:35 --> Language Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Loader Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:16:35 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:16:35 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:16:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:16:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:16:35 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Session Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:16:35 --> Session routines successfully run
DEBUG - 2013-08-30 05:16:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:16:35 --> Controller Class Initialized
ERROR - 2013-08-30 05:16:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:36 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:16:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:16:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:16:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:16:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:36 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:16:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:16:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:16:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:16:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:16:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:16:36 --> File loaded: application/views/jurusans/new.php
DEBUG - 2013-08-30 05:16:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:16:36 --> Final output sent to browser
DEBUG - 2013-08-30 05:16:36 --> Total execution time: 1.0431
DEBUG - 2013-08-30 05:16:36 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:36 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:36 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:36 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:36 --> Router Class Initialized
ERROR - 2013-08-30 05:16:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:16:40 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:40 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:40 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:40 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:40 --> Router Class Initialized
DEBUG - 2013-08-30 05:16:40 --> Output Class Initialized
DEBUG - 2013-08-30 05:16:40 --> Security Class Initialized
DEBUG - 2013-08-30 05:16:40 --> Input Class Initialized
DEBUG - 2013-08-30 05:16:40 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:40 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:40 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:40 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:40 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:40 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:40 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:16:40 --> Language Class Initialized
DEBUG - 2013-08-30 05:16:40 --> Loader Class Initialized
DEBUG - 2013-08-30 05:16:40 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:16:40 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:16:40 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:16:40 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:16:40 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:16:40 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:16:40 --> Session Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:16:41 --> Session routines successfully run
DEBUG - 2013-08-30 05:16:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Controller Class Initialized
ERROR - 2013-08-30 05:16:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:41 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:16:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:16:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:16:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:16:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:41 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Form Validation Class Initialized
DEBUG - 2013-08-30 05:16:41 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 05:16:41 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:41 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Router Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Output Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Security Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Input Class Initialized
DEBUG - 2013-08-30 05:16:41 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:41 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:41 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:41 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:41 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:16:41 --> Language Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Loader Class Initialized
DEBUG - 2013-08-30 05:16:41 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:16:42 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:16:42 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:16:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:16:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:16:42 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:16:42 --> Session Class Initialized
DEBUG - 2013-08-30 05:16:42 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:16:42 --> Session routines successfully run
DEBUG - 2013-08-30 05:16:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:16:42 --> Controller Class Initialized
ERROR - 2013-08-30 05:16:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:42 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:16:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:16:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:16:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:16:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:42 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:42 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:16:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:16:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:16:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:16:42 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:16:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:16:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:16:42 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:16:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:16:42 --> Final output sent to browser
DEBUG - 2013-08-30 05:16:42 --> Total execution time: 1.0841
DEBUG - 2013-08-30 05:16:42 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:42 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:42 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:42 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:42 --> Router Class Initialized
ERROR - 2013-08-30 05:16:42 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:16:49 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:49 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Router Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Output Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Security Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Input Class Initialized
DEBUG - 2013-08-30 05:16:49 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:49 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:49 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:49 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:49 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:49 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:16:49 --> Language Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Loader Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:16:49 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:16:49 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:16:49 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:16:49 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:16:49 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Session Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:16:49 --> Session routines successfully run
DEBUG - 2013-08-30 05:16:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Controller Class Initialized
ERROR - 2013-08-30 05:16:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:49 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:16:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:16:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:16:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:16:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:50 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:50 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:50 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:50 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:50 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Router Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Output Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Security Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Input Class Initialized
DEBUG - 2013-08-30 05:16:50 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:50 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:50 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:50 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:50 --> XSS Filtering completed
DEBUG - 2013-08-30 05:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:16:50 --> Language Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Loader Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:16:50 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:16:50 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:16:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:16:50 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:16:50 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Session Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:16:50 --> Session routines successfully run
DEBUG - 2013-08-30 05:16:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Controller Class Initialized
ERROR - 2013-08-30 05:16:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:50 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:16:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:16:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:16:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:16:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:16:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:16:50 --> Model Class Initialized
DEBUG - 2013-08-30 05:16:50 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:16:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:16:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:16:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:16:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:16:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:16:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:16:51 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:16:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:16:51 --> Final output sent to browser
DEBUG - 2013-08-30 05:16:51 --> Total execution time: 1.0571
DEBUG - 2013-08-30 05:16:51 --> Config Class Initialized
DEBUG - 2013-08-30 05:16:51 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:16:51 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:16:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:16:51 --> URI Class Initialized
DEBUG - 2013-08-30 05:16:51 --> Router Class Initialized
ERROR - 2013-08-30 05:16:51 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 05:17:00 --> Config Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:17:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:17:00 --> URI Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Router Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Output Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Security Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Input Class Initialized
DEBUG - 2013-08-30 05:17:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:00 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:17:00 --> Language Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Loader Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:17:00 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:17:00 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:17:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:17:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:17:00 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Session Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:17:00 --> Session routines successfully run
DEBUG - 2013-08-30 05:17:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Controller Class Initialized
ERROR - 2013-08-30 05:17:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:17:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:17:00 --> Model Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:17:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:17:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:17:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:17:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:17:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:17:00 --> Model Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Config Class Initialized
DEBUG - 2013-08-30 05:17:00 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:17:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:17:01 --> URI Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Router Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Output Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Security Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Input Class Initialized
DEBUG - 2013-08-30 05:17:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:01 --> XSS Filtering completed
DEBUG - 2013-08-30 05:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 05:17:01 --> Language Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Loader Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Helper loaded: url_helper
DEBUG - 2013-08-30 05:17:01 --> Helper loaded: file_helper
DEBUG - 2013-08-30 05:17:01 --> Helper loaded: form_helper
DEBUG - 2013-08-30 05:17:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 05:17:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 05:17:01 --> Database Driver Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Session Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Helper loaded: string_helper
DEBUG - 2013-08-30 05:17:01 --> Session routines successfully run
DEBUG - 2013-08-30 05:17:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Controller Class Initialized
ERROR - 2013-08-30 05:17:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:17:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:17:01 --> Model Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 05:17:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 05:17:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 05:17:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 05:17:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 05:17:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 05:17:01 --> Model Class Initialized
DEBUG - 2013-08-30 05:17:01 --> Pagination Class Initialized
DEBUG - 2013-08-30 05:17:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 05:17:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 05:17:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 05:17:01 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 05:17:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 05:17:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 05:17:01 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 05:17:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 05:17:02 --> Final output sent to browser
DEBUG - 2013-08-30 05:17:02 --> Total execution time: 1.0541
DEBUG - 2013-08-30 05:17:02 --> Config Class Initialized
DEBUG - 2013-08-30 05:17:02 --> Hooks Class Initialized
DEBUG - 2013-08-30 05:17:02 --> Utf8 Class Initialized
DEBUG - 2013-08-30 05:17:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 05:17:02 --> URI Class Initialized
DEBUG - 2013-08-30 05:17:02 --> Router Class Initialized
ERROR - 2013-08-30 05:17:02 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 06:10:58 --> Config Class Initialized
DEBUG - 2013-08-30 06:10:58 --> Hooks Class Initialized
DEBUG - 2013-08-30 06:10:58 --> Utf8 Class Initialized
DEBUG - 2013-08-30 06:10:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 06:10:58 --> URI Class Initialized
DEBUG - 2013-08-30 06:10:58 --> Router Class Initialized
DEBUG - 2013-08-30 06:10:58 --> Output Class Initialized
DEBUG - 2013-08-30 06:10:58 --> Security Class Initialized
DEBUG - 2013-08-30 06:10:58 --> Input Class Initialized
DEBUG - 2013-08-30 06:10:58 --> XSS Filtering completed
DEBUG - 2013-08-30 06:10:58 --> XSS Filtering completed
DEBUG - 2013-08-30 06:10:58 --> XSS Filtering completed
DEBUG - 2013-08-30 06:10:59 --> XSS Filtering completed
DEBUG - 2013-08-30 06:10:59 --> XSS Filtering completed
DEBUG - 2013-08-30 06:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 06:10:59 --> Language Class Initialized
DEBUG - 2013-08-30 06:10:59 --> Loader Class Initialized
DEBUG - 2013-08-30 06:10:59 --> Helper loaded: url_helper
DEBUG - 2013-08-30 06:10:59 --> Helper loaded: file_helper
DEBUG - 2013-08-30 06:10:59 --> Helper loaded: form_helper
DEBUG - 2013-08-30 06:10:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 06:10:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 06:10:59 --> Database Driver Class Initialized
DEBUG - 2013-08-30 06:10:59 --> Session Class Initialized
DEBUG - 2013-08-30 06:10:59 --> Helper loaded: string_helper
DEBUG - 2013-08-30 06:10:59 --> Session routines successfully run
DEBUG - 2013-08-30 06:10:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 06:10:59 --> Controller Class Initialized
ERROR - 2013-08-30 06:10:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:10:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:10:59 --> Model Class Initialized
DEBUG - 2013-08-30 06:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 06:10:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 06:10:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 06:10:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 06:10:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:11:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:11:00 --> Model Class Initialized
DEBUG - 2013-08-30 06:11:00 --> Pagination Class Initialized
DEBUG - 2013-08-30 06:11:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 06:11:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 06:11:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 06:11:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 06:11:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 06:11:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 06:11:00 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-30 06:11:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 06:11:00 --> Final output sent to browser
DEBUG - 2013-08-30 06:11:00 --> Total execution time: 2.4941
DEBUG - 2013-08-30 06:11:00 --> Config Class Initialized
DEBUG - 2013-08-30 06:11:00 --> Hooks Class Initialized
DEBUG - 2013-08-30 06:11:00 --> Utf8 Class Initialized
DEBUG - 2013-08-30 06:11:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 06:11:00 --> URI Class Initialized
DEBUG - 2013-08-30 06:11:00 --> Router Class Initialized
ERROR - 2013-08-30 06:11:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 06:11:08 --> Config Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Hooks Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Utf8 Class Initialized
DEBUG - 2013-08-30 06:11:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 06:11:08 --> URI Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Router Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Output Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Security Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Input Class Initialized
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 06:11:08 --> Language Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Loader Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Helper loaded: url_helper
DEBUG - 2013-08-30 06:11:08 --> Helper loaded: file_helper
DEBUG - 2013-08-30 06:11:08 --> Helper loaded: form_helper
DEBUG - 2013-08-30 06:11:08 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 06:11:08 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 06:11:08 --> Database Driver Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Session Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Helper loaded: string_helper
DEBUG - 2013-08-30 06:11:08 --> Session routines successfully run
DEBUG - 2013-08-30 06:11:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 06:11:08 --> Controller Class Initialized
ERROR - 2013-08-30 06:11:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:11:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:11:08 --> Model Class Initialized
DEBUG - 2013-08-30 06:11:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 06:11:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 06:11:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 06:11:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 06:11:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:11:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:11:09 --> Model Class Initialized
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:11:09 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> Config Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Hooks Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Utf8 Class Initialized
DEBUG - 2013-08-30 06:12:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 06:12:46 --> URI Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Router Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Output Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Security Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Input Class Initialized
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 06:12:46 --> Language Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Loader Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Helper loaded: url_helper
DEBUG - 2013-08-30 06:12:46 --> Helper loaded: file_helper
DEBUG - 2013-08-30 06:12:46 --> Helper loaded: form_helper
DEBUG - 2013-08-30 06:12:46 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 06:12:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 06:12:46 --> Database Driver Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Session Class Initialized
DEBUG - 2013-08-30 06:12:46 --> Helper loaded: string_helper
DEBUG - 2013-08-30 06:12:46 --> Session routines successfully run
DEBUG - 2013-08-30 06:12:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 06:12:47 --> Controller Class Initialized
ERROR - 2013-08-30 06:12:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:12:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:12:47 --> Model Class Initialized
DEBUG - 2013-08-30 06:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 06:12:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 06:12:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 06:12:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 06:12:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:12:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:12:47 --> Model Class Initialized
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:12:47 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> Config Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Hooks Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Utf8 Class Initialized
DEBUG - 2013-08-30 06:13:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 06:13:20 --> URI Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Router Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Output Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Security Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Input Class Initialized
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 06:13:20 --> Language Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Loader Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Helper loaded: url_helper
DEBUG - 2013-08-30 06:13:20 --> Helper loaded: file_helper
DEBUG - 2013-08-30 06:13:20 --> Helper loaded: form_helper
DEBUG - 2013-08-30 06:13:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 06:13:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 06:13:20 --> Database Driver Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Session Class Initialized
DEBUG - 2013-08-30 06:13:20 --> Helper loaded: string_helper
DEBUG - 2013-08-30 06:13:20 --> Session routines successfully run
DEBUG - 2013-08-30 06:13:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 06:13:21 --> Controller Class Initialized
ERROR - 2013-08-30 06:13:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:13:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:13:21 --> Model Class Initialized
DEBUG - 2013-08-30 06:13:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 06:13:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 06:13:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 06:13:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 06:13:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:13:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:13:21 --> Model Class Initialized
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:21 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> Config Class Initialized
DEBUG - 2013-08-30 06:13:39 --> Hooks Class Initialized
DEBUG - 2013-08-30 06:13:39 --> Utf8 Class Initialized
DEBUG - 2013-08-30 06:13:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 06:13:39 --> URI Class Initialized
DEBUG - 2013-08-30 06:13:39 --> Router Class Initialized
DEBUG - 2013-08-30 06:13:39 --> Output Class Initialized
DEBUG - 2013-08-30 06:13:39 --> Security Class Initialized
DEBUG - 2013-08-30 06:13:39 --> Input Class Initialized
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:39 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 06:13:40 --> Language Class Initialized
DEBUG - 2013-08-30 06:13:40 --> Loader Class Initialized
DEBUG - 2013-08-30 06:13:40 --> Helper loaded: url_helper
DEBUG - 2013-08-30 06:13:40 --> Helper loaded: file_helper
DEBUG - 2013-08-30 06:13:40 --> Helper loaded: form_helper
DEBUG - 2013-08-30 06:13:40 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 06:13:40 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 06:13:40 --> Database Driver Class Initialized
DEBUG - 2013-08-30 06:13:40 --> Session Class Initialized
DEBUG - 2013-08-30 06:13:40 --> Helper loaded: string_helper
DEBUG - 2013-08-30 06:13:40 --> Session routines successfully run
DEBUG - 2013-08-30 06:13:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 06:13:40 --> Controller Class Initialized
ERROR - 2013-08-30 06:13:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:13:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:13:40 --> Model Class Initialized
DEBUG - 2013-08-30 06:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 06:13:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 06:13:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 06:13:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 06:13:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 06:13:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 06:13:40 --> Model Class Initialized
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 06:13:40 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:16 --> Config Class Initialized
DEBUG - 2013-08-30 08:31:16 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:31:16 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:31:16 --> URI Class Initialized
DEBUG - 2013-08-30 08:31:16 --> Router Class Initialized
DEBUG - 2013-08-30 08:31:17 --> Output Class Initialized
DEBUG - 2013-08-30 08:31:17 --> Security Class Initialized
DEBUG - 2013-08-30 08:31:17 --> Input Class Initialized
DEBUG - 2013-08-30 08:31:17 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:17 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:17 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:17 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 08:31:17 --> Language Class Initialized
DEBUG - 2013-08-30 08:31:17 --> Loader Class Initialized
DEBUG - 2013-08-30 08:31:17 --> Helper loaded: url_helper
DEBUG - 2013-08-30 08:31:17 --> Helper loaded: file_helper
DEBUG - 2013-08-30 08:31:17 --> Helper loaded: form_helper
DEBUG - 2013-08-30 08:31:17 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 08:31:17 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 08:31:17 --> Database Driver Class Initialized
DEBUG - 2013-08-30 08:31:18 --> Session Class Initialized
DEBUG - 2013-08-30 08:31:19 --> Helper loaded: string_helper
DEBUG - 2013-08-30 08:31:19 --> A session cookie was not found.
DEBUG - 2013-08-30 08:31:19 --> Session routines successfully run
DEBUG - 2013-08-30 08:31:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 08:31:20 --> Controller Class Initialized
ERROR - 2013-08-30 08:31:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:20 --> Model Class Initialized
DEBUG - 2013-08-30 08:31:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 08:31:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 08:31:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 08:31:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 08:31:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:21 --> Config Class Initialized
DEBUG - 2013-08-30 08:31:21 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:31:21 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:31:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:31:21 --> URI Class Initialized
DEBUG - 2013-08-30 08:31:21 --> Router Class Initialized
DEBUG - 2013-08-30 08:31:21 --> Output Class Initialized
DEBUG - 2013-08-30 08:31:21 --> Security Class Initialized
DEBUG - 2013-08-30 08:31:21 --> Input Class Initialized
DEBUG - 2013-08-30 08:31:21 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:21 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 08:31:21 --> Language Class Initialized
DEBUG - 2013-08-30 08:31:21 --> Loader Class Initialized
DEBUG - 2013-08-30 08:31:21 --> Helper loaded: url_helper
DEBUG - 2013-08-30 08:31:21 --> Helper loaded: file_helper
DEBUG - 2013-08-30 08:31:21 --> Helper loaded: form_helper
DEBUG - 2013-08-30 08:31:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 08:31:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 08:31:22 --> Database Driver Class Initialized
DEBUG - 2013-08-30 08:31:22 --> Session Class Initialized
DEBUG - 2013-08-30 08:31:22 --> Helper loaded: string_helper
DEBUG - 2013-08-30 08:31:22 --> Session routines successfully run
DEBUG - 2013-08-30 08:31:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 08:31:22 --> Controller Class Initialized
ERROR - 2013-08-30 08:31:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:22 --> Model Class Initialized
DEBUG - 2013-08-30 08:31:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 08:31:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 08:31:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 08:31:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 08:31:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 08:31:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 08:31:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 08:31:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 08:31:22 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-30 08:31:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 08:31:22 --> Final output sent to browser
DEBUG - 2013-08-30 08:31:22 --> Total execution time: 1.0771
DEBUG - 2013-08-30 08:31:22 --> Config Class Initialized
DEBUG - 2013-08-30 08:31:22 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:31:22 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:31:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:31:22 --> URI Class Initialized
DEBUG - 2013-08-30 08:31:22 --> Router Class Initialized
ERROR - 2013-08-30 08:31:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 08:31:31 --> Config Class Initialized
DEBUG - 2013-08-30 08:31:31 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:31:31 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:31:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:31:31 --> URI Class Initialized
DEBUG - 2013-08-30 08:31:31 --> Router Class Initialized
DEBUG - 2013-08-30 08:31:31 --> Output Class Initialized
DEBUG - 2013-08-30 08:31:31 --> Security Class Initialized
DEBUG - 2013-08-30 08:31:31 --> Input Class Initialized
DEBUG - 2013-08-30 08:31:31 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:31 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:31 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:31 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:31 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 08:31:31 --> Language Class Initialized
DEBUG - 2013-08-30 08:31:32 --> Loader Class Initialized
DEBUG - 2013-08-30 08:31:32 --> Helper loaded: url_helper
DEBUG - 2013-08-30 08:31:32 --> Helper loaded: file_helper
DEBUG - 2013-08-30 08:31:32 --> Helper loaded: form_helper
DEBUG - 2013-08-30 08:31:32 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 08:31:32 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 08:31:32 --> Database Driver Class Initialized
DEBUG - 2013-08-30 08:31:32 --> Session Class Initialized
DEBUG - 2013-08-30 08:31:32 --> Helper loaded: string_helper
DEBUG - 2013-08-30 08:31:32 --> Session routines successfully run
DEBUG - 2013-08-30 08:31:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 08:31:32 --> Controller Class Initialized
ERROR - 2013-08-30 08:31:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:32 --> Model Class Initialized
DEBUG - 2013-08-30 08:31:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 08:31:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 08:31:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 08:31:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 08:31:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:32 --> Model Class Initialized
DEBUG - 2013-08-30 08:31:32 --> Form Validation Class Initialized
DEBUG - 2013-08-30 08:31:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 08:31:33 --> Config Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:31:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:31:33 --> URI Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Router Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Output Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Security Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Input Class Initialized
DEBUG - 2013-08-30 08:31:33 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:33 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 08:31:33 --> Language Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Loader Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Helper loaded: url_helper
DEBUG - 2013-08-30 08:31:33 --> Helper loaded: file_helper
DEBUG - 2013-08-30 08:31:33 --> Helper loaded: form_helper
DEBUG - 2013-08-30 08:31:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 08:31:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 08:31:33 --> Database Driver Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Session Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Helper loaded: string_helper
DEBUG - 2013-08-30 08:31:33 --> Session routines successfully run
DEBUG - 2013-08-30 08:31:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Controller Class Initialized
ERROR - 2013-08-30 08:31:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:33 --> Model Class Initialized
DEBUG - 2013-08-30 08:31:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 08:31:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 08:31:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 08:31:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 08:31:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:34 --> Config Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:31:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:31:34 --> URI Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Router Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Output Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Security Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Input Class Initialized
DEBUG - 2013-08-30 08:31:34 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:34 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 08:31:34 --> Language Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Loader Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Helper loaded: url_helper
DEBUG - 2013-08-30 08:31:34 --> Helper loaded: file_helper
DEBUG - 2013-08-30 08:31:34 --> Helper loaded: form_helper
DEBUG - 2013-08-30 08:31:34 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 08:31:34 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 08:31:34 --> Database Driver Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Session Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Helper loaded: string_helper
DEBUG - 2013-08-30 08:31:34 --> Session routines successfully run
DEBUG - 2013-08-30 08:31:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Controller Class Initialized
ERROR - 2013-08-30 08:31:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:34 --> Model Class Initialized
DEBUG - 2013-08-30 08:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 08:31:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 08:31:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 08:31:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 08:31:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:34 --> Model Class Initialized
DEBUG - 2013-08-30 08:31:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 08:31:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 08:31:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 08:31:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 08:31:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 08:31:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 08:31:35 --> File loaded: application/views/home.php
DEBUG - 2013-08-30 08:31:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 08:31:35 --> Final output sent to browser
DEBUG - 2013-08-30 08:31:35 --> Total execution time: 1.4241
DEBUG - 2013-08-30 08:31:35 --> Config Class Initialized
DEBUG - 2013-08-30 08:31:35 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:31:35 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:31:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:31:35 --> URI Class Initialized
DEBUG - 2013-08-30 08:31:35 --> Router Class Initialized
ERROR - 2013-08-30 08:31:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 08:31:50 --> Config Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:31:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:31:50 --> URI Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Router Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Output Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Security Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Input Class Initialized
DEBUG - 2013-08-30 08:31:50 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:50 --> XSS Filtering completed
DEBUG - 2013-08-30 08:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 08:31:50 --> Language Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Loader Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Helper loaded: url_helper
DEBUG - 2013-08-30 08:31:50 --> Helper loaded: file_helper
DEBUG - 2013-08-30 08:31:50 --> Helper loaded: form_helper
DEBUG - 2013-08-30 08:31:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 08:31:50 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 08:31:50 --> Database Driver Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Session Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Helper loaded: string_helper
DEBUG - 2013-08-30 08:31:50 --> Session routines successfully run
DEBUG - 2013-08-30 08:31:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Controller Class Initialized
ERROR - 2013-08-30 08:31:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:50 --> Model Class Initialized
DEBUG - 2013-08-30 08:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 08:31:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 08:31:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 08:31:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 08:31:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:31:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:31:51 --> Model Class Initialized
DEBUG - 2013-08-30 08:31:51 --> Pagination Class Initialized
DEBUG - 2013-08-30 08:31:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 08:31:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 08:31:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 08:31:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 08:31:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 08:31:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 08:31:51 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-30 08:31:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 08:31:51 --> Final output sent to browser
DEBUG - 2013-08-30 08:31:51 --> Total execution time: 1.2261
DEBUG - 2013-08-30 08:31:51 --> Config Class Initialized
DEBUG - 2013-08-30 08:31:51 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:31:51 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:31:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:31:51 --> URI Class Initialized
DEBUG - 2013-08-30 08:31:51 --> Router Class Initialized
ERROR - 2013-08-30 08:31:51 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 08:33:25 --> Config Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:33:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:33:25 --> URI Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Router Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Output Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Security Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Input Class Initialized
DEBUG - 2013-08-30 08:33:25 --> XSS Filtering completed
DEBUG - 2013-08-30 08:33:25 --> XSS Filtering completed
DEBUG - 2013-08-30 08:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 08:33:25 --> Language Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Loader Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Helper loaded: url_helper
DEBUG - 2013-08-30 08:33:25 --> Helper loaded: file_helper
DEBUG - 2013-08-30 08:33:25 --> Helper loaded: form_helper
DEBUG - 2013-08-30 08:33:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 08:33:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 08:33:25 --> Database Driver Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Session Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Helper loaded: string_helper
DEBUG - 2013-08-30 08:33:25 --> Session routines successfully run
DEBUG - 2013-08-30 08:33:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Controller Class Initialized
ERROR - 2013-08-30 08:33:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:33:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:33:25 --> Model Class Initialized
DEBUG - 2013-08-30 08:33:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 08:33:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 08:33:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 08:33:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 08:33:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:33:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:33:26 --> Model Class Initialized
DEBUG - 2013-08-30 08:33:26 --> Pagination Class Initialized
DEBUG - 2013-08-30 08:33:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 08:33:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 08:33:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 08:33:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 08:33:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 08:33:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 08:33:26 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-30 08:33:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 08:33:26 --> Final output sent to browser
DEBUG - 2013-08-30 08:33:26 --> Total execution time: 1.0591
DEBUG - 2013-08-30 08:33:26 --> Config Class Initialized
DEBUG - 2013-08-30 08:33:26 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:33:26 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:33:26 --> URI Class Initialized
DEBUG - 2013-08-30 08:33:26 --> Router Class Initialized
ERROR - 2013-08-30 08:33:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 08:34:18 --> Config Class Initialized
DEBUG - 2013-08-30 08:34:18 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:34:18 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:34:18 --> URI Class Initialized
DEBUG - 2013-08-30 08:34:18 --> Router Class Initialized
DEBUG - 2013-08-30 08:34:18 --> Output Class Initialized
DEBUG - 2013-08-30 08:34:18 --> Security Class Initialized
DEBUG - 2013-08-30 08:34:18 --> Input Class Initialized
DEBUG - 2013-08-30 08:34:18 --> XSS Filtering completed
DEBUG - 2013-08-30 08:34:18 --> XSS Filtering completed
DEBUG - 2013-08-30 08:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 08:34:18 --> Language Class Initialized
DEBUG - 2013-08-30 08:34:18 --> Loader Class Initialized
DEBUG - 2013-08-30 08:34:18 --> Helper loaded: url_helper
DEBUG - 2013-08-30 08:34:18 --> Helper loaded: file_helper
DEBUG - 2013-08-30 08:34:18 --> Helper loaded: form_helper
DEBUG - 2013-08-30 08:34:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 08:34:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 08:34:19 --> Database Driver Class Initialized
DEBUG - 2013-08-30 08:34:19 --> Session Class Initialized
DEBUG - 2013-08-30 08:34:19 --> Helper loaded: string_helper
DEBUG - 2013-08-30 08:34:19 --> Session routines successfully run
DEBUG - 2013-08-30 08:34:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 08:34:19 --> Controller Class Initialized
ERROR - 2013-08-30 08:34:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:34:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:34:19 --> Model Class Initialized
DEBUG - 2013-08-30 08:34:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 08:34:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 08:34:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 08:34:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 08:34:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 08:34:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 08:34:19 --> Model Class Initialized
DEBUG - 2013-08-30 08:34:19 --> Pagination Class Initialized
DEBUG - 2013-08-30 08:34:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 08:34:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 08:34:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 08:34:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 08:34:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 08:34:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 08:34:20 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 08:34:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 08:34:20 --> Final output sent to browser
DEBUG - 2013-08-30 08:34:20 --> Total execution time: 1.5701
DEBUG - 2013-08-30 08:34:20 --> Config Class Initialized
DEBUG - 2013-08-30 08:34:20 --> Hooks Class Initialized
DEBUG - 2013-08-30 08:34:20 --> Utf8 Class Initialized
DEBUG - 2013-08-30 08:34:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 08:34:20 --> URI Class Initialized
DEBUG - 2013-08-30 08:34:20 --> Router Class Initialized
ERROR - 2013-08-30 08:34:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:43:26 --> Config Class Initialized
DEBUG - 2013-08-30 09:43:26 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:43:26 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:43:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:43:26 --> URI Class Initialized
DEBUG - 2013-08-30 09:43:27 --> Router Class Initialized
DEBUG - 2013-08-30 09:43:27 --> No URI present. Default controller set.
DEBUG - 2013-08-30 09:43:27 --> Output Class Initialized
DEBUG - 2013-08-30 09:43:27 --> Security Class Initialized
DEBUG - 2013-08-30 09:43:27 --> Input Class Initialized
DEBUG - 2013-08-30 09:43:27 --> XSS Filtering completed
DEBUG - 2013-08-30 09:43:27 --> XSS Filtering completed
DEBUG - 2013-08-30 09:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:43:27 --> Language Class Initialized
DEBUG - 2013-08-30 09:43:27 --> Loader Class Initialized
DEBUG - 2013-08-30 09:43:27 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:43:27 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:43:27 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:43:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:43:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:43:27 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:43:27 --> Session Class Initialized
DEBUG - 2013-08-30 09:43:27 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:43:28 --> Session routines successfully run
DEBUG - 2013-08-30 09:43:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:43:28 --> Controller Class Initialized
ERROR - 2013-08-30 09:43:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:43:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:43:28 --> Model Class Initialized
DEBUG - 2013-08-30 09:43:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:43:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:43:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:43:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:43:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:43:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:43:28 --> Model Class Initialized
DEBUG - 2013-08-30 09:43:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:43:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:43:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:43:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:43:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:43:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:43:28 --> File loaded: application/views/home.php
DEBUG - 2013-08-30 09:43:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:43:28 --> Final output sent to browser
DEBUG - 2013-08-30 09:43:28 --> Total execution time: 2.7662
DEBUG - 2013-08-30 09:43:28 --> Config Class Initialized
DEBUG - 2013-08-30 09:43:28 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:43:28 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:43:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:43:29 --> URI Class Initialized
DEBUG - 2013-08-30 09:43:29 --> Router Class Initialized
ERROR - 2013-08-30 09:43:29 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:43:34 --> Config Class Initialized
DEBUG - 2013-08-30 09:43:34 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:43:34 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:43:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:43:34 --> URI Class Initialized
DEBUG - 2013-08-30 09:43:34 --> Router Class Initialized
DEBUG - 2013-08-30 09:43:34 --> Output Class Initialized
DEBUG - 2013-08-30 09:43:34 --> Security Class Initialized
DEBUG - 2013-08-30 09:43:34 --> Input Class Initialized
DEBUG - 2013-08-30 09:43:34 --> XSS Filtering completed
DEBUG - 2013-08-30 09:43:34 --> XSS Filtering completed
DEBUG - 2013-08-30 09:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:43:34 --> Language Class Initialized
DEBUG - 2013-08-30 09:43:34 --> Loader Class Initialized
DEBUG - 2013-08-30 09:43:34 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:43:35 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:43:35 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:43:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:43:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:43:35 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:43:35 --> Session Class Initialized
DEBUG - 2013-08-30 09:43:35 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:43:35 --> Session garbage collection performed.
DEBUG - 2013-08-30 09:43:35 --> Session routines successfully run
DEBUG - 2013-08-30 09:43:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:43:35 --> Controller Class Initialized
ERROR - 2013-08-30 09:43:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:43:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:43:35 --> Model Class Initialized
DEBUG - 2013-08-30 09:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:43:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:43:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:43:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:43:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:43:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:43:35 --> Model Class Initialized
DEBUG - 2013-08-30 09:43:35 --> Pagination Class Initialized
DEBUG - 2013-08-30 09:43:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:43:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:43:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:43:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:43:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:43:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:43:35 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 09:43:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:43:35 --> Final output sent to browser
DEBUG - 2013-08-30 09:43:35 --> Total execution time: 1.2891
DEBUG - 2013-08-30 09:43:36 --> Config Class Initialized
DEBUG - 2013-08-30 09:43:36 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:43:36 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:43:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:43:36 --> URI Class Initialized
DEBUG - 2013-08-30 09:43:36 --> Router Class Initialized
ERROR - 2013-08-30 09:43:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:43:39 --> Config Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:43:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:43:39 --> URI Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Router Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Output Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Security Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Input Class Initialized
DEBUG - 2013-08-30 09:43:39 --> XSS Filtering completed
DEBUG - 2013-08-30 09:43:39 --> XSS Filtering completed
DEBUG - 2013-08-30 09:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:43:39 --> Language Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Loader Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:43:39 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:43:39 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:43:39 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:43:39 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:43:39 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Session Class Initialized
DEBUG - 2013-08-30 09:43:39 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:43:39 --> Session routines successfully run
DEBUG - 2013-08-30 09:43:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:43:40 --> Controller Class Initialized
ERROR - 2013-08-30 09:43:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:43:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:43:40 --> Model Class Initialized
DEBUG - 2013-08-30 09:43:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:43:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:43:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:43:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:43:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:43:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:43:40 --> Model Class Initialized
DEBUG - 2013-08-30 09:43:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:43:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:43:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:43:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:43:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:43:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:43:40 --> File loaded: application/views/users/edit.php
DEBUG - 2013-08-30 09:43:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:43:40 --> Final output sent to browser
DEBUG - 2013-08-30 09:43:40 --> Total execution time: 1.0991
DEBUG - 2013-08-30 09:43:40 --> Config Class Initialized
DEBUG - 2013-08-30 09:43:40 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:43:40 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:43:40 --> URI Class Initialized
DEBUG - 2013-08-30 09:43:40 --> Router Class Initialized
ERROR - 2013-08-30 09:43:40 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:43:44 --> Config Class Initialized
DEBUG - 2013-08-30 09:43:44 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:43:44 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:43:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:43:44 --> URI Class Initialized
DEBUG - 2013-08-30 09:43:44 --> Router Class Initialized
DEBUG - 2013-08-30 09:43:44 --> Output Class Initialized
DEBUG - 2013-08-30 09:43:44 --> Security Class Initialized
DEBUG - 2013-08-30 09:43:44 --> Input Class Initialized
DEBUG - 2013-08-30 09:43:44 --> XSS Filtering completed
DEBUG - 2013-08-30 09:43:44 --> XSS Filtering completed
DEBUG - 2013-08-30 09:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:43:44 --> Language Class Initialized
DEBUG - 2013-08-30 09:43:44 --> Loader Class Initialized
DEBUG - 2013-08-30 09:43:45 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:43:45 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:43:45 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:43:45 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:43:45 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:43:45 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:43:45 --> Session Class Initialized
DEBUG - 2013-08-30 09:43:45 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:43:45 --> Session routines successfully run
DEBUG - 2013-08-30 09:43:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:43:45 --> Controller Class Initialized
ERROR - 2013-08-30 09:43:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:43:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:43:45 --> Model Class Initialized
DEBUG - 2013-08-30 09:43:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:43:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:43:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:43:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:43:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:43:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:43:45 --> Model Class Initialized
DEBUG - 2013-08-30 09:43:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:43:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:43:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:43:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:43:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:43:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:43:45 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-08-30 09:43:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:43:45 --> Final output sent to browser
DEBUG - 2013-08-30 09:43:45 --> Total execution time: 1.0501
DEBUG - 2013-08-30 09:43:46 --> Config Class Initialized
DEBUG - 2013-08-30 09:43:46 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:43:46 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:43:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:43:46 --> URI Class Initialized
DEBUG - 2013-08-30 09:43:46 --> Router Class Initialized
ERROR - 2013-08-30 09:43:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:49:14 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:14 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:14 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:14 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:14 --> Router Class Initialized
DEBUG - 2013-08-30 09:49:14 --> Output Class Initialized
DEBUG - 2013-08-30 09:49:14 --> Security Class Initialized
DEBUG - 2013-08-30 09:49:14 --> Input Class Initialized
DEBUG - 2013-08-30 09:49:14 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:14 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:49:14 --> Language Class Initialized
DEBUG - 2013-08-30 09:49:15 --> Loader Class Initialized
DEBUG - 2013-08-30 09:49:15 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:49:15 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:49:15 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:49:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:49:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:49:15 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:49:15 --> Session Class Initialized
DEBUG - 2013-08-30 09:49:15 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:49:15 --> Session routines successfully run
DEBUG - 2013-08-30 09:49:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:49:15 --> Controller Class Initialized
ERROR - 2013-08-30 09:49:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:15 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:49:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:49:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:49:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:49:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:15 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:15 --> Pagination Class Initialized
DEBUG - 2013-08-30 09:49:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:49:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:49:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:49:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:49:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:49:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:49:15 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 09:49:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:49:15 --> Final output sent to browser
DEBUG - 2013-08-30 09:49:15 --> Total execution time: 1.0621
DEBUG - 2013-08-30 09:49:16 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:16 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:16 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:16 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:16 --> Router Class Initialized
ERROR - 2013-08-30 09:49:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:49:19 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:19 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:19 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:19 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:19 --> Router Class Initialized
DEBUG - 2013-08-30 09:49:19 --> Output Class Initialized
DEBUG - 2013-08-30 09:49:19 --> Security Class Initialized
DEBUG - 2013-08-30 09:49:19 --> Input Class Initialized
DEBUG - 2013-08-30 09:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:20 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:49:20 --> Language Class Initialized
DEBUG - 2013-08-30 09:49:20 --> Loader Class Initialized
DEBUG - 2013-08-30 09:49:20 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:49:20 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:49:20 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:49:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:49:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:49:20 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:49:20 --> Session Class Initialized
DEBUG - 2013-08-30 09:49:20 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:49:20 --> Session routines successfully run
DEBUG - 2013-08-30 09:49:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:49:20 --> Controller Class Initialized
ERROR - 2013-08-30 09:49:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:20 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:49:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:49:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:49:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:49:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:20 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:49:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:49:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:49:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:49:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:49:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:49:20 --> File loaded: application/views/users/new.php
DEBUG - 2013-08-30 09:49:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:49:20 --> Final output sent to browser
DEBUG - 2013-08-30 09:49:20 --> Total execution time: 1.1271
DEBUG - 2013-08-30 09:49:21 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:21 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:21 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:21 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:21 --> Router Class Initialized
ERROR - 2013-08-30 09:49:21 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:49:32 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:32 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Router Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Output Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Security Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Input Class Initialized
DEBUG - 2013-08-30 09:49:32 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:32 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:32 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:32 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:32 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:32 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:49:32 --> Language Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Loader Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:49:32 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:49:32 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:49:32 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:49:32 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:49:32 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Session Class Initialized
DEBUG - 2013-08-30 09:49:32 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:49:32 --> Session garbage collection performed.
DEBUG - 2013-08-30 09:49:32 --> Session routines successfully run
DEBUG - 2013-08-30 09:49:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:49:33 --> Controller Class Initialized
ERROR - 2013-08-30 09:49:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:33 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:49:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:49:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:49:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:49:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:33 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:33 --> Form Validation Class Initialized
DEBUG - 2013-08-30 09:49:33 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:33 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:33 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 09:49:33 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:33 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:33 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:33 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:33 --> Router Class Initialized
DEBUG - 2013-08-30 09:49:33 --> Output Class Initialized
DEBUG - 2013-08-30 09:49:33 --> Security Class Initialized
DEBUG - 2013-08-30 09:49:33 --> Input Class Initialized
DEBUG - 2013-08-30 09:49:33 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:33 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:49:34 --> Language Class Initialized
DEBUG - 2013-08-30 09:49:34 --> Loader Class Initialized
DEBUG - 2013-08-30 09:49:34 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:49:34 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:49:34 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:49:34 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:49:34 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:49:34 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:49:34 --> Session Class Initialized
DEBUG - 2013-08-30 09:49:34 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:49:34 --> Session routines successfully run
DEBUG - 2013-08-30 09:49:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:49:34 --> Controller Class Initialized
ERROR - 2013-08-30 09:49:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:34 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:49:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:49:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:49:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:49:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:34 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:34 --> Pagination Class Initialized
DEBUG - 2013-08-30 09:49:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:49:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:49:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:49:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:49:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:49:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:49:34 --> File loaded: application/views/users/index.php
DEBUG - 2013-08-30 09:49:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:49:34 --> Final output sent to browser
DEBUG - 2013-08-30 09:49:35 --> Total execution time: 1.3601
DEBUG - 2013-08-30 09:49:35 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:35 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:35 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:35 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:35 --> Router Class Initialized
ERROR - 2013-08-30 09:49:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:49:38 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:38 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Router Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Output Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Security Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Input Class Initialized
DEBUG - 2013-08-30 09:49:38 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:38 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:49:38 --> Language Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Loader Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:49:38 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:49:38 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:49:38 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:49:38 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:49:38 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Session Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:49:38 --> Session routines successfully run
DEBUG - 2013-08-30 09:49:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:49:38 --> Controller Class Initialized
ERROR - 2013-08-30 09:49:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:39 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:49:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:49:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:49:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:49:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:39 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:49:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:49:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:49:39 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:49:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:49:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:49:39 --> File loaded: application/views/users/edit.php
DEBUG - 2013-08-30 09:49:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:49:39 --> Final output sent to browser
DEBUG - 2013-08-30 09:49:39 --> Total execution time: 1.1501
DEBUG - 2013-08-30 09:49:39 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:39 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:39 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:39 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:39 --> Router Class Initialized
ERROR - 2013-08-30 09:49:39 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:49:47 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:47 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:47 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:47 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:47 --> Router Class Initialized
DEBUG - 2013-08-30 09:49:48 --> Output Class Initialized
DEBUG - 2013-08-30 09:49:48 --> Security Class Initialized
DEBUG - 2013-08-30 09:49:48 --> Input Class Initialized
DEBUG - 2013-08-30 09:49:48 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:48 --> XSS Filtering completed
DEBUG - 2013-08-30 09:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:49:48 --> Language Class Initialized
DEBUG - 2013-08-30 09:49:48 --> Loader Class Initialized
DEBUG - 2013-08-30 09:49:48 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:49:48 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:49:48 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:49:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:49:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:49:48 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:49:48 --> Session Class Initialized
DEBUG - 2013-08-30 09:49:48 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:49:48 --> Session routines successfully run
DEBUG - 2013-08-30 09:49:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:49:48 --> Controller Class Initialized
ERROR - 2013-08-30 09:49:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:48 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:49:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:49:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:49:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:49:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:49:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:49:48 --> Model Class Initialized
DEBUG - 2013-08-30 09:49:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:49:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:49:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:49:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:49:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:49:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:49:48 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-08-30 09:49:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:49:48 --> Final output sent to browser
DEBUG - 2013-08-30 09:49:49 --> Total execution time: 1.1211
DEBUG - 2013-08-30 09:49:49 --> Config Class Initialized
DEBUG - 2013-08-30 09:49:49 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:49:49 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:49:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:49:49 --> URI Class Initialized
DEBUG - 2013-08-30 09:49:49 --> Router Class Initialized
ERROR - 2013-08-30 09:49:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:50:02 --> Config Class Initialized
DEBUG - 2013-08-30 09:50:02 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:50:02 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:50:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:50:02 --> URI Class Initialized
DEBUG - 2013-08-30 09:50:02 --> Router Class Initialized
DEBUG - 2013-08-30 09:50:02 --> Output Class Initialized
DEBUG - 2013-08-30 09:50:02 --> Security Class Initialized
DEBUG - 2013-08-30 09:50:02 --> Input Class Initialized
DEBUG - 2013-08-30 09:50:02 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:02 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:02 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:02 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:02 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:02 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:50:03 --> Language Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Loader Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:50:03 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:50:03 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:50:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:50:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:50:03 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Session Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:50:03 --> Session routines successfully run
DEBUG - 2013-08-30 09:50:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Controller Class Initialized
ERROR - 2013-08-30 09:50:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:50:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:50:03 --> Model Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:50:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:50:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:50:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:50:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:50:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:50:03 --> Model Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Form Validation Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 09:50:03 --> Config Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:50:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:50:03 --> URI Class Initialized
DEBUG - 2013-08-30 09:50:03 --> Router Class Initialized
DEBUG - 2013-08-30 09:50:04 --> Output Class Initialized
DEBUG - 2013-08-30 09:50:04 --> Security Class Initialized
DEBUG - 2013-08-30 09:50:04 --> Input Class Initialized
DEBUG - 2013-08-30 09:50:04 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:04 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:50:04 --> Language Class Initialized
DEBUG - 2013-08-30 09:50:04 --> Loader Class Initialized
DEBUG - 2013-08-30 09:50:04 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:50:04 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:50:04 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:50:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:50:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:50:04 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:50:04 --> Session Class Initialized
DEBUG - 2013-08-30 09:50:04 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:50:04 --> Session routines successfully run
DEBUG - 2013-08-30 09:50:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:50:04 --> Controller Class Initialized
ERROR - 2013-08-30 09:50:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:50:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:50:04 --> Model Class Initialized
DEBUG - 2013-08-30 09:50:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:50:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:50:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:50:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:50:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:50:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:50:05 --> Model Class Initialized
DEBUG - 2013-08-30 09:50:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:50:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:50:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:50:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:50:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:50:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:50:05 --> File loaded: application/views/users/edit.php
DEBUG - 2013-08-30 09:50:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:50:05 --> Final output sent to browser
DEBUG - 2013-08-30 09:50:05 --> Total execution time: 1.4411
DEBUG - 2013-08-30 09:50:05 --> Config Class Initialized
DEBUG - 2013-08-30 09:50:05 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:50:05 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:50:05 --> URI Class Initialized
DEBUG - 2013-08-30 09:50:05 --> Router Class Initialized
ERROR - 2013-08-30 09:50:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:50:51 --> Config Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:50:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:50:51 --> URI Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Router Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Output Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Security Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Input Class Initialized
DEBUG - 2013-08-30 09:50:51 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:51 --> XSS Filtering completed
DEBUG - 2013-08-30 09:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:50:51 --> Language Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Loader Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:50:51 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:50:51 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:50:51 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:50:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:50:51 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Session Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:50:51 --> Session routines successfully run
DEBUG - 2013-08-30 09:50:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Controller Class Initialized
ERROR - 2013-08-30 09:50:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:50:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:50:51 --> Model Class Initialized
DEBUG - 2013-08-30 09:50:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:50:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:50:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:50:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:50:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:50:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:50:52 --> Model Class Initialized
DEBUG - 2013-08-30 09:50:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:50:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:50:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:50:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:50:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:50:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:50:52 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-08-30 09:50:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:50:52 --> Final output sent to browser
DEBUG - 2013-08-30 09:50:52 --> Total execution time: 1.1341
DEBUG - 2013-08-30 09:50:52 --> Config Class Initialized
DEBUG - 2013-08-30 09:50:52 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:50:52 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:50:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:50:52 --> URI Class Initialized
DEBUG - 2013-08-30 09:50:52 --> Router Class Initialized
ERROR - 2013-08-30 09:50:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:51:03 --> Config Class Initialized
DEBUG - 2013-08-30 09:51:03 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:51:03 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:51:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:51:03 --> URI Class Initialized
DEBUG - 2013-08-30 09:51:03 --> Router Class Initialized
DEBUG - 2013-08-30 09:51:03 --> Output Class Initialized
DEBUG - 2013-08-30 09:51:03 --> Security Class Initialized
DEBUG - 2013-08-30 09:51:03 --> Input Class Initialized
DEBUG - 2013-08-30 09:51:03 --> XSS Filtering completed
DEBUG - 2013-08-30 09:51:03 --> XSS Filtering completed
DEBUG - 2013-08-30 09:51:04 --> XSS Filtering completed
DEBUG - 2013-08-30 09:51:04 --> XSS Filtering completed
DEBUG - 2013-08-30 09:51:04 --> XSS Filtering completed
DEBUG - 2013-08-30 09:51:04 --> XSS Filtering completed
DEBUG - 2013-08-30 09:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:51:04 --> Language Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Loader Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:51:04 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:51:04 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:51:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:51:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:51:04 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Session Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:51:04 --> Session routines successfully run
DEBUG - 2013-08-30 09:51:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Controller Class Initialized
ERROR - 2013-08-30 09:51:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:51:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:51:04 --> Model Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:51:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:51:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:51:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:51:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:51:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:51:04 --> Model Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Form Validation Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-30 09:51:04 --> Config Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:51:04 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:51:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:51:04 --> URI Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Router Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Output Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Security Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Input Class Initialized
DEBUG - 2013-08-30 09:51:05 --> XSS Filtering completed
DEBUG - 2013-08-30 09:51:05 --> XSS Filtering completed
DEBUG - 2013-08-30 09:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:51:05 --> Language Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Loader Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:51:05 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:51:05 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:51:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:51:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:51:05 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Session Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:51:05 --> Session routines successfully run
DEBUG - 2013-08-30 09:51:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Controller Class Initialized
ERROR - 2013-08-30 09:51:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:51:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:51:05 --> Model Class Initialized
DEBUG - 2013-08-30 09:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:51:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:51:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:51:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:51:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:51:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:51:05 --> Model Class Initialized
DEBUG - 2013-08-30 09:51:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:51:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:51:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:51:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:51:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:51:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:51:06 --> File loaded: application/views/users/edit.php
DEBUG - 2013-08-30 09:51:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:51:06 --> Final output sent to browser
DEBUG - 2013-08-30 09:51:06 --> Total execution time: 1.3381
DEBUG - 2013-08-30 09:51:06 --> Config Class Initialized
DEBUG - 2013-08-30 09:51:06 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:51:06 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:51:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:51:06 --> URI Class Initialized
DEBUG - 2013-08-30 09:51:06 --> Router Class Initialized
ERROR - 2013-08-30 09:51:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:52:06 --> Config Class Initialized
DEBUG - 2013-08-30 09:52:06 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:52:06 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:52:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:52:06 --> URI Class Initialized
DEBUG - 2013-08-30 09:52:06 --> Router Class Initialized
DEBUG - 2013-08-30 09:52:06 --> Output Class Initialized
DEBUG - 2013-08-30 09:52:06 --> Security Class Initialized
DEBUG - 2013-08-30 09:52:06 --> Input Class Initialized
DEBUG - 2013-08-30 09:52:06 --> XSS Filtering completed
DEBUG - 2013-08-30 09:52:06 --> XSS Filtering completed
DEBUG - 2013-08-30 09:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:52:06 --> Language Class Initialized
DEBUG - 2013-08-30 09:52:06 --> Loader Class Initialized
DEBUG - 2013-08-30 09:52:06 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:52:06 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:52:07 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:52:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:52:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:52:07 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:52:07 --> Session Class Initialized
DEBUG - 2013-08-30 09:52:07 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:52:07 --> Session routines successfully run
DEBUG - 2013-08-30 09:52:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:52:07 --> Controller Class Initialized
ERROR - 2013-08-30 09:52:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:52:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:52:07 --> Model Class Initialized
DEBUG - 2013-08-30 09:52:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:52:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:52:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:52:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:52:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:52:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:52:07 --> Model Class Initialized
DEBUG - 2013-08-30 09:52:07 --> Pagination Class Initialized
DEBUG - 2013-08-30 09:52:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:52:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:52:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:52:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:52:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:52:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:52:07 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-30 09:52:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:52:07 --> Final output sent to browser
DEBUG - 2013-08-30 09:52:07 --> Total execution time: 1.3441
DEBUG - 2013-08-30 09:52:08 --> Config Class Initialized
DEBUG - 2013-08-30 09:52:08 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:52:08 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:52:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:52:08 --> URI Class Initialized
DEBUG - 2013-08-30 09:52:08 --> Router Class Initialized
ERROR - 2013-08-30 09:52:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:54:22 --> Config Class Initialized
DEBUG - 2013-08-30 09:54:22 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:54:22 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:54:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:54:23 --> URI Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Router Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Output Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Security Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Input Class Initialized
DEBUG - 2013-08-30 09:54:23 --> XSS Filtering completed
DEBUG - 2013-08-30 09:54:23 --> XSS Filtering completed
DEBUG - 2013-08-30 09:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:54:23 --> Language Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Loader Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:54:23 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:54:23 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:54:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:54:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:54:23 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Session Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:54:23 --> Session garbage collection performed.
DEBUG - 2013-08-30 09:54:23 --> Session routines successfully run
DEBUG - 2013-08-30 09:54:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Controller Class Initialized
ERROR - 2013-08-30 09:54:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:54:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:54:23 --> Model Class Initialized
DEBUG - 2013-08-30 09:54:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:54:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:54:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:54:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:54:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:54:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:54:23 --> Model Class Initialized
DEBUG - 2013-08-30 09:54:24 --> Pagination Class Initialized
DEBUG - 2013-08-30 09:54:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:54:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:54:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:54:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:54:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:54:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:54:24 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-30 09:54:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:54:24 --> Final output sent to browser
DEBUG - 2013-08-30 09:54:24 --> Total execution time: 1.3121
DEBUG - 2013-08-30 09:54:24 --> Config Class Initialized
DEBUG - 2013-08-30 09:54:24 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:54:24 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:54:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:54:24 --> URI Class Initialized
DEBUG - 2013-08-30 09:54:24 --> Router Class Initialized
ERROR - 2013-08-30 09:54:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:58:36 --> Config Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:58:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:58:36 --> URI Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Router Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Output Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Security Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Input Class Initialized
DEBUG - 2013-08-30 09:58:36 --> XSS Filtering completed
DEBUG - 2013-08-30 09:58:36 --> XSS Filtering completed
DEBUG - 2013-08-30 09:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:58:36 --> Language Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Loader Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:58:36 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:58:36 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:58:36 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:58:36 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:58:36 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Session Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:58:36 --> Session routines successfully run
DEBUG - 2013-08-30 09:58:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Controller Class Initialized
ERROR - 2013-08-30 09:58:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:58:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:58:36 --> Model Class Initialized
DEBUG - 2013-08-30 09:58:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:58:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:58:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:58:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:58:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:58:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:58:37 --> Model Class Initialized
DEBUG - 2013-08-30 09:58:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:58:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:58:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:58:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:58:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:58:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:58:37 --> File loaded: application/views/tahun_ajarans/new.php
DEBUG - 2013-08-30 09:58:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:58:37 --> Final output sent to browser
DEBUG - 2013-08-30 09:58:37 --> Total execution time: 1.3051
DEBUG - 2013-08-30 09:58:37 --> Config Class Initialized
DEBUG - 2013-08-30 09:58:37 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:58:37 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:58:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:58:37 --> URI Class Initialized
DEBUG - 2013-08-30 09:58:37 --> Router Class Initialized
ERROR - 2013-08-30 09:58:37 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 09:58:44 --> Config Class Initialized
DEBUG - 2013-08-30 09:58:44 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:58:44 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:58:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:58:44 --> URI Class Initialized
DEBUG - 2013-08-30 09:58:44 --> Router Class Initialized
DEBUG - 2013-08-30 09:58:44 --> Output Class Initialized
DEBUG - 2013-08-30 09:58:45 --> Security Class Initialized
DEBUG - 2013-08-30 09:58:45 --> Input Class Initialized
DEBUG - 2013-08-30 09:58:45 --> XSS Filtering completed
DEBUG - 2013-08-30 09:58:45 --> XSS Filtering completed
DEBUG - 2013-08-30 09:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 09:58:45 --> Language Class Initialized
DEBUG - 2013-08-30 09:58:45 --> Loader Class Initialized
DEBUG - 2013-08-30 09:58:45 --> Helper loaded: url_helper
DEBUG - 2013-08-30 09:58:45 --> Helper loaded: file_helper
DEBUG - 2013-08-30 09:58:45 --> Helper loaded: form_helper
DEBUG - 2013-08-30 09:58:45 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 09:58:45 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 09:58:45 --> Database Driver Class Initialized
DEBUG - 2013-08-30 09:58:45 --> Session Class Initialized
DEBUG - 2013-08-30 09:58:45 --> Helper loaded: string_helper
DEBUG - 2013-08-30 09:58:45 --> Session routines successfully run
DEBUG - 2013-08-30 09:58:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 09:58:45 --> Controller Class Initialized
ERROR - 2013-08-30 09:58:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:58:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:58:45 --> Model Class Initialized
DEBUG - 2013-08-30 09:58:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 09:58:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 09:58:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 09:58:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 09:58:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 09:58:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 09:58:45 --> Model Class Initialized
DEBUG - 2013-08-30 09:58:45 --> Pagination Class Initialized
DEBUG - 2013-08-30 09:58:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 09:58:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 09:58:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 09:58:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 09:58:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 09:58:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 09:58:46 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-30 09:58:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 09:58:46 --> Final output sent to browser
DEBUG - 2013-08-30 09:58:46 --> Total execution time: 1.2741
DEBUG - 2013-08-30 09:58:46 --> Config Class Initialized
DEBUG - 2013-08-30 09:58:46 --> Hooks Class Initialized
DEBUG - 2013-08-30 09:58:46 --> Utf8 Class Initialized
DEBUG - 2013-08-30 09:58:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 09:58:46 --> URI Class Initialized
DEBUG - 2013-08-30 09:58:46 --> Router Class Initialized
ERROR - 2013-08-30 09:58:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 10:46:14 --> Config Class Initialized
DEBUG - 2013-08-30 10:46:15 --> Hooks Class Initialized
DEBUG - 2013-08-30 10:46:15 --> Utf8 Class Initialized
DEBUG - 2013-08-30 10:46:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 10:46:16 --> URI Class Initialized
DEBUG - 2013-08-30 10:46:16 --> Router Class Initialized
DEBUG - 2013-08-30 10:46:16 --> Output Class Initialized
DEBUG - 2013-08-30 10:46:16 --> Security Class Initialized
DEBUG - 2013-08-30 10:46:16 --> Input Class Initialized
DEBUG - 2013-08-30 10:46:16 --> XSS Filtering completed
DEBUG - 2013-08-30 10:46:16 --> XSS Filtering completed
DEBUG - 2013-08-30 10:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 10:46:16 --> Language Class Initialized
DEBUG - 2013-08-30 10:46:16 --> Loader Class Initialized
DEBUG - 2013-08-30 10:46:16 --> Helper loaded: url_helper
DEBUG - 2013-08-30 10:46:16 --> Helper loaded: file_helper
DEBUG - 2013-08-30 10:46:16 --> Helper loaded: form_helper
DEBUG - 2013-08-30 10:46:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 10:46:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 10:46:16 --> Database Driver Class Initialized
DEBUG - 2013-08-30 10:46:17 --> Session Class Initialized
DEBUG - 2013-08-30 10:46:17 --> Helper loaded: string_helper
DEBUG - 2013-08-30 10:46:17 --> Session routines successfully run
DEBUG - 2013-08-30 10:46:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 10:46:17 --> Controller Class Initialized
ERROR - 2013-08-30 10:46:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:46:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:46:17 --> Model Class Initialized
DEBUG - 2013-08-30 10:46:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 10:46:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 10:46:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 10:46:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 10:46:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:46:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:46:17 --> Model Class Initialized
DEBUG - 2013-08-30 10:46:17 --> Pagination Class Initialized
DEBUG - 2013-08-30 10:46:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 10:46:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 10:46:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 10:46:18 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 10:46:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 10:46:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 10:46:18 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-30 10:46:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 10:46:18 --> Final output sent to browser
DEBUG - 2013-08-30 10:46:18 --> Total execution time: 3.2342
DEBUG - 2013-08-30 10:46:18 --> Config Class Initialized
DEBUG - 2013-08-30 10:46:18 --> Hooks Class Initialized
DEBUG - 2013-08-30 10:46:18 --> Utf8 Class Initialized
DEBUG - 2013-08-30 10:46:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 10:46:18 --> URI Class Initialized
DEBUG - 2013-08-30 10:46:18 --> Router Class Initialized
ERROR - 2013-08-30 10:46:18 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 10:47:30 --> Config Class Initialized
DEBUG - 2013-08-30 10:47:30 --> Hooks Class Initialized
DEBUG - 2013-08-30 10:47:30 --> Utf8 Class Initialized
DEBUG - 2013-08-30 10:47:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 10:47:30 --> URI Class Initialized
DEBUG - 2013-08-30 10:47:30 --> Router Class Initialized
DEBUG - 2013-08-30 10:47:30 --> Output Class Initialized
DEBUG - 2013-08-30 10:47:30 --> Security Class Initialized
DEBUG - 2013-08-30 10:47:30 --> Input Class Initialized
DEBUG - 2013-08-30 10:47:30 --> XSS Filtering completed
DEBUG - 2013-08-30 10:47:30 --> XSS Filtering completed
DEBUG - 2013-08-30 10:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 10:47:30 --> Language Class Initialized
DEBUG - 2013-08-30 10:47:30 --> Loader Class Initialized
DEBUG - 2013-08-30 10:47:30 --> Helper loaded: url_helper
DEBUG - 2013-08-30 10:47:30 --> Helper loaded: file_helper
DEBUG - 2013-08-30 10:47:30 --> Helper loaded: form_helper
DEBUG - 2013-08-30 10:47:30 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 10:47:30 --> Database Driver Class Initialized
DEBUG - 2013-08-30 10:47:31 --> Session Class Initialized
DEBUG - 2013-08-30 10:47:31 --> Helper loaded: string_helper
DEBUG - 2013-08-30 10:47:31 --> Session routines successfully run
DEBUG - 2013-08-30 10:47:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 10:47:31 --> Controller Class Initialized
ERROR - 2013-08-30 10:47:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:47:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:47:31 --> Model Class Initialized
DEBUG - 2013-08-30 10:47:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 10:47:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 10:47:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 10:47:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 10:47:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:47:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:47:31 --> Model Class Initialized
DEBUG - 2013-08-30 10:47:31 --> Pagination Class Initialized
DEBUG - 2013-08-30 10:47:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 10:47:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 10:47:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 10:47:43 --> Config Class Initialized
DEBUG - 2013-08-30 10:47:43 --> Hooks Class Initialized
DEBUG - 2013-08-30 10:47:43 --> Utf8 Class Initialized
DEBUG - 2013-08-30 10:47:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 10:47:43 --> URI Class Initialized
DEBUG - 2013-08-30 10:47:43 --> Router Class Initialized
DEBUG - 2013-08-30 10:47:43 --> Output Class Initialized
DEBUG - 2013-08-30 10:47:43 --> Security Class Initialized
DEBUG - 2013-08-30 10:47:43 --> Input Class Initialized
DEBUG - 2013-08-30 10:47:43 --> XSS Filtering completed
DEBUG - 2013-08-30 10:47:43 --> XSS Filtering completed
DEBUG - 2013-08-30 10:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 10:47:43 --> Language Class Initialized
DEBUG - 2013-08-30 10:47:43 --> Loader Class Initialized
DEBUG - 2013-08-30 10:47:43 --> Helper loaded: url_helper
DEBUG - 2013-08-30 10:47:43 --> Helper loaded: file_helper
DEBUG - 2013-08-30 10:47:44 --> Helper loaded: form_helper
DEBUG - 2013-08-30 10:47:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 10:47:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-30 10:47:44 --> Database Driver Class Initialized
DEBUG - 2013-08-30 10:47:44 --> Session Class Initialized
DEBUG - 2013-08-30 10:47:44 --> Helper loaded: string_helper
DEBUG - 2013-08-30 10:47:44 --> Session routines successfully run
DEBUG - 2013-08-30 10:47:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 10:47:44 --> Controller Class Initialized
ERROR - 2013-08-30 10:47:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:47:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:47:44 --> Model Class Initialized
DEBUG - 2013-08-30 10:47:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 10:47:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 10:47:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 10:47:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 10:47:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:47:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:47:44 --> Model Class Initialized
DEBUG - 2013-08-30 10:47:44 --> Pagination Class Initialized
DEBUG - 2013-08-30 10:47:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 10:47:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 10:47:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 10:47:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 10:47:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 10:47:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 10:47:44 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-30 10:47:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 10:47:44 --> Final output sent to browser
DEBUG - 2013-08-30 10:47:44 --> Total execution time: 1.1661
DEBUG - 2013-08-30 10:47:44 --> Config Class Initialized
DEBUG - 2013-08-30 10:47:44 --> Hooks Class Initialized
DEBUG - 2013-08-30 10:47:45 --> Utf8 Class Initialized
DEBUG - 2013-08-30 10:47:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 10:47:45 --> URI Class Initialized
DEBUG - 2013-08-30 10:47:45 --> Router Class Initialized
ERROR - 2013-08-30 10:47:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 10:57:53 --> Config Class Initialized
DEBUG - 2013-08-30 10:57:53 --> Hooks Class Initialized
DEBUG - 2013-08-30 10:57:53 --> Utf8 Class Initialized
DEBUG - 2013-08-30 10:57:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 10:57:53 --> URI Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Router Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Output Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Security Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Input Class Initialized
DEBUG - 2013-08-30 10:57:54 --> XSS Filtering completed
DEBUG - 2013-08-30 10:57:54 --> XSS Filtering completed
DEBUG - 2013-08-30 10:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 10:57:54 --> Language Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Loader Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Helper loaded: url_helper
DEBUG - 2013-08-30 10:57:54 --> Helper loaded: file_helper
DEBUG - 2013-08-30 10:57:54 --> Helper loaded: form_helper
DEBUG - 2013-08-30 10:57:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 10:57:54 --> Helper loaded: application_helper
DEBUG - 2013-08-30 10:57:54 --> Database Driver Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Session Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Helper loaded: string_helper
DEBUG - 2013-08-30 10:57:54 --> Session routines successfully run
DEBUG - 2013-08-30 10:57:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Controller Class Initialized
ERROR - 2013-08-30 10:57:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:57:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:57:54 --> Model Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 10:57:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 10:57:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 10:57:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 10:57:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:57:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:57:54 --> Model Class Initialized
DEBUG - 2013-08-30 10:57:54 --> Pagination Class Initialized
DEBUG - 2013-08-30 10:57:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 10:57:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 10:57:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 10:57:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 10:57:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 10:57:55 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-30 10:57:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 10:57:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 10:57:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 10:57:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 10:57:55 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-08-30 10:57:55 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-30 10:57:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 10:57:55 --> Final output sent to browser
DEBUG - 2013-08-30 10:57:55 --> Total execution time: 1.4341
DEBUG - 2013-08-30 10:57:55 --> Config Class Initialized
DEBUG - 2013-08-30 10:57:55 --> Hooks Class Initialized
DEBUG - 2013-08-30 10:57:55 --> Utf8 Class Initialized
DEBUG - 2013-08-30 10:57:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 10:57:55 --> URI Class Initialized
DEBUG - 2013-08-30 10:57:55 --> Router Class Initialized
ERROR - 2013-08-30 10:57:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 10:57:57 --> Config Class Initialized
DEBUG - 2013-08-30 10:57:57 --> Hooks Class Initialized
DEBUG - 2013-08-30 10:57:57 --> Utf8 Class Initialized
DEBUG - 2013-08-30 10:57:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 10:57:57 --> URI Class Initialized
DEBUG - 2013-08-30 10:57:57 --> Router Class Initialized
DEBUG - 2013-08-30 10:57:57 --> Output Class Initialized
DEBUG - 2013-08-30 10:57:58 --> Security Class Initialized
DEBUG - 2013-08-30 10:57:58 --> Input Class Initialized
DEBUG - 2013-08-30 10:57:58 --> XSS Filtering completed
DEBUG - 2013-08-30 10:57:58 --> XSS Filtering completed
DEBUG - 2013-08-30 10:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 10:57:58 --> Language Class Initialized
DEBUG - 2013-08-30 10:57:58 --> Loader Class Initialized
DEBUG - 2013-08-30 10:57:58 --> Helper loaded: url_helper
DEBUG - 2013-08-30 10:57:58 --> Helper loaded: file_helper
DEBUG - 2013-08-30 10:57:58 --> Helper loaded: form_helper
DEBUG - 2013-08-30 10:57:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 10:57:58 --> Helper loaded: application_helper
DEBUG - 2013-08-30 10:57:58 --> Database Driver Class Initialized
DEBUG - 2013-08-30 10:57:58 --> Session Class Initialized
DEBUG - 2013-08-30 10:57:58 --> Helper loaded: string_helper
DEBUG - 2013-08-30 10:57:58 --> Session routines successfully run
DEBUG - 2013-08-30 10:57:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 10:57:58 --> Controller Class Initialized
ERROR - 2013-08-30 10:57:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:57:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:57:58 --> Model Class Initialized
DEBUG - 2013-08-30 10:57:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 10:57:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 10:57:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 10:57:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 10:57:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 10:57:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 10:57:58 --> Model Class Initialized
DEBUG - 2013-08-30 10:57:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 10:57:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 10:57:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 10:57:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 10:57:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 10:57:58 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-30 10:57:59 --> Severity: Notice  --> Undefined variable: jenis_kelamin C:\xampp\htdocs\school\application\views\siswas\new.php 20
ERROR - 2013-08-30 10:57:59 --> Severity: Notice  --> Undefined variable: jenis_kelamin C:\xampp\htdocs\school\application\views\siswas\new.php 21
DEBUG - 2013-08-30 10:57:59 --> File loaded: application/views/siswas/new.php
DEBUG - 2013-08-30 10:57:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 10:57:59 --> Final output sent to browser
DEBUG - 2013-08-30 10:57:59 --> Total execution time: 1.3101
DEBUG - 2013-08-30 10:57:59 --> Config Class Initialized
DEBUG - 2013-08-30 10:57:59 --> Hooks Class Initialized
DEBUG - 2013-08-30 10:57:59 --> Utf8 Class Initialized
DEBUG - 2013-08-30 10:57:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 10:57:59 --> URI Class Initialized
DEBUG - 2013-08-30 10:57:59 --> Router Class Initialized
ERROR - 2013-08-30 10:57:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 11:14:03 --> Config Class Initialized
DEBUG - 2013-08-30 11:14:03 --> Hooks Class Initialized
DEBUG - 2013-08-30 11:14:03 --> Utf8 Class Initialized
DEBUG - 2013-08-30 11:14:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 11:14:03 --> URI Class Initialized
DEBUG - 2013-08-30 11:14:03 --> Router Class Initialized
DEBUG - 2013-08-30 11:14:03 --> Output Class Initialized
DEBUG - 2013-08-30 11:14:03 --> Security Class Initialized
DEBUG - 2013-08-30 11:14:03 --> Input Class Initialized
DEBUG - 2013-08-30 11:14:04 --> XSS Filtering completed
DEBUG - 2013-08-30 11:14:04 --> XSS Filtering completed
DEBUG - 2013-08-30 11:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 11:14:04 --> Language Class Initialized
DEBUG - 2013-08-30 11:14:04 --> Loader Class Initialized
DEBUG - 2013-08-30 11:14:04 --> Helper loaded: url_helper
DEBUG - 2013-08-30 11:14:04 --> Helper loaded: file_helper
DEBUG - 2013-08-30 11:14:04 --> Helper loaded: form_helper
DEBUG - 2013-08-30 11:14:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 11:14:04 --> Helper loaded: application_helper
DEBUG - 2013-08-30 11:14:04 --> Database Driver Class Initialized
DEBUG - 2013-08-30 11:14:04 --> Session Class Initialized
DEBUG - 2013-08-30 11:14:04 --> Helper loaded: string_helper
DEBUG - 2013-08-30 11:14:04 --> Session garbage collection performed.
DEBUG - 2013-08-30 11:14:04 --> Session routines successfully run
DEBUG - 2013-08-30 11:14:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 11:14:04 --> Controller Class Initialized
ERROR - 2013-08-30 11:14:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 11:14:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 11:14:04 --> Model Class Initialized
DEBUG - 2013-08-30 11:14:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 11:14:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 11:14:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 11:14:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 11:14:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 11:14:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 11:14:04 --> Model Class Initialized
DEBUG - 2013-08-30 11:14:04 --> Pagination Class Initialized
DEBUG - 2013-08-30 11:14:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 11:14:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 11:14:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 11:14:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 11:14:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 11:14:04 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-30 11:14:04 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 11:14:04 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 11:14:05 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 11:14:05 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 11:14:05 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-08-30 11:14:05 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-30 11:14:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 11:14:05 --> Final output sent to browser
DEBUG - 2013-08-30 11:14:05 --> Total execution time: 1.3521
DEBUG - 2013-08-30 11:14:05 --> Config Class Initialized
DEBUG - 2013-08-30 11:14:05 --> Hooks Class Initialized
DEBUG - 2013-08-30 11:14:05 --> Utf8 Class Initialized
DEBUG - 2013-08-30 11:14:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 11:14:05 --> URI Class Initialized
DEBUG - 2013-08-30 11:14:05 --> Router Class Initialized
ERROR - 2013-08-30 11:14:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 11:14:57 --> Config Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Hooks Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Utf8 Class Initialized
DEBUG - 2013-08-30 11:14:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 11:14:57 --> URI Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Router Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Output Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Security Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Input Class Initialized
DEBUG - 2013-08-30 11:14:57 --> XSS Filtering completed
DEBUG - 2013-08-30 11:14:57 --> XSS Filtering completed
DEBUG - 2013-08-30 11:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 11:14:57 --> Language Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Loader Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Helper loaded: url_helper
DEBUG - 2013-08-30 11:14:57 --> Helper loaded: file_helper
DEBUG - 2013-08-30 11:14:57 --> Helper loaded: form_helper
DEBUG - 2013-08-30 11:14:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 11:14:57 --> Helper loaded: application_helper
DEBUG - 2013-08-30 11:14:57 --> Database Driver Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Session Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Helper loaded: string_helper
DEBUG - 2013-08-30 11:14:57 --> Session routines successfully run
DEBUG - 2013-08-30 11:14:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 11:14:57 --> Controller Class Initialized
ERROR - 2013-08-30 11:14:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 11:14:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 11:14:58 --> Model Class Initialized
DEBUG - 2013-08-30 11:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 11:14:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 11:14:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 11:14:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 11:14:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 11:14:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 11:14:58 --> Model Class Initialized
DEBUG - 2013-08-30 11:14:58 --> Pagination Class Initialized
DEBUG - 2013-08-30 11:14:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 11:14:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 11:14:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 11:14:58 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-08-30 11:14:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-30 11:14:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-30 11:14:58 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-30 11:14:58 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 11:14:58 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 11:14:58 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 11:14:58 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-08-30 11:14:58 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-08-30 11:14:58 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-30 11:14:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 11:14:58 --> Final output sent to browser
DEBUG - 2013-08-30 11:14:58 --> Total execution time: 1.3471
DEBUG - 2013-08-30 11:14:58 --> Config Class Initialized
DEBUG - 2013-08-30 11:14:58 --> Hooks Class Initialized
DEBUG - 2013-08-30 11:14:58 --> Utf8 Class Initialized
DEBUG - 2013-08-30 11:14:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 11:14:58 --> URI Class Initialized
DEBUG - 2013-08-30 11:14:59 --> Router Class Initialized
ERROR - 2013-08-30 11:14:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-30 17:39:42 --> Config Class Initialized
DEBUG - 2013-08-30 17:39:42 --> Hooks Class Initialized
DEBUG - 2013-08-30 17:39:42 --> Utf8 Class Initialized
DEBUG - 2013-08-30 17:39:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 17:39:43 --> URI Class Initialized
DEBUG - 2013-08-30 17:39:43 --> Router Class Initialized
DEBUG - 2013-08-30 17:39:43 --> Output Class Initialized
DEBUG - 2013-08-30 17:39:43 --> Security Class Initialized
DEBUG - 2013-08-30 17:39:44 --> Input Class Initialized
DEBUG - 2013-08-30 17:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-30 17:39:44 --> Language Class Initialized
DEBUG - 2013-08-30 17:39:44 --> Loader Class Initialized
DEBUG - 2013-08-30 17:39:44 --> Helper loaded: url_helper
DEBUG - 2013-08-30 17:39:44 --> Helper loaded: file_helper
DEBUG - 2013-08-30 17:39:44 --> Helper loaded: form_helper
DEBUG - 2013-08-30 17:39:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-30 17:39:44 --> Helper loaded: application_helper
DEBUG - 2013-08-30 17:39:45 --> Database Driver Class Initialized
DEBUG - 2013-08-30 17:39:45 --> Session Class Initialized
DEBUG - 2013-08-30 17:39:45 --> Helper loaded: string_helper
DEBUG - 2013-08-30 17:39:45 --> A session cookie was not found.
DEBUG - 2013-08-30 17:39:45 --> Session routines successfully run
DEBUG - 2013-08-30 17:39:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-30 17:39:45 --> Controller Class Initialized
ERROR - 2013-08-30 17:39:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 17:39:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 17:39:46 --> Model Class Initialized
DEBUG - 2013-08-30 17:39:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-30 17:39:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-30 17:39:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-30 17:39:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-30 17:39:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-30 17:39:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-30 17:39:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-30 17:39:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-30 17:39:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-30 17:39:47 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-30 17:39:47 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-30 17:39:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-30 17:39:47 --> Final output sent to browser
DEBUG - 2013-08-30 17:39:47 --> Total execution time: 5.2803
DEBUG - 2013-08-30 17:39:47 --> Config Class Initialized
DEBUG - 2013-08-30 17:39:47 --> Hooks Class Initialized
DEBUG - 2013-08-30 17:39:48 --> Utf8 Class Initialized
DEBUG - 2013-08-30 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-30 17:39:48 --> URI Class Initialized
DEBUG - 2013-08-30 17:39:48 --> Router Class Initialized
ERROR - 2013-08-30 17:39:48 --> 404 Page Not Found --> css
