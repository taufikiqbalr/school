<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-05 06:34:29 --> Config Class Initialized
DEBUG - 2013-09-05 06:34:29 --> Hooks Class Initialized
DEBUG - 2013-09-05 06:34:29 --> Utf8 Class Initialized
DEBUG - 2013-09-05 06:34:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 06:34:29 --> URI Class Initialized
DEBUG - 2013-09-05 06:34:29 --> Router Class Initialized
DEBUG - 2013-09-05 06:34:29 --> Output Class Initialized
DEBUG - 2013-09-05 06:34:29 --> Security Class Initialized
DEBUG - 2013-09-05 06:34:29 --> Input Class Initialized
DEBUG - 2013-09-05 06:34:29 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:29 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:29 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:29 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 06:34:29 --> Language Class Initialized
DEBUG - 2013-09-05 06:34:29 --> Loader Class Initialized
DEBUG - 2013-09-05 06:34:29 --> Helper loaded: url_helper
DEBUG - 2013-09-05 06:34:29 --> Helper loaded: file_helper
DEBUG - 2013-09-05 06:34:29 --> Helper loaded: form_helper
DEBUG - 2013-09-05 06:34:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 06:34:29 --> Helper loaded: application_helper
DEBUG - 2013-09-05 06:34:29 --> Database Driver Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Session Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Helper loaded: string_helper
DEBUG - 2013-09-05 06:34:30 --> A session cookie was not found.
DEBUG - 2013-09-05 06:34:30 --> Session routines successfully run
DEBUG - 2013-09-05 06:34:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Controller Class Initialized
ERROR - 2013-09-05 06:34:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:30 --> Model Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 06:34:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 06:34:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 06:34:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 06:34:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:30 --> Config Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Hooks Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Utf8 Class Initialized
DEBUG - 2013-09-05 06:34:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 06:34:30 --> URI Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Router Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Output Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Security Class Initialized
DEBUG - 2013-09-05 06:34:30 --> Input Class Initialized
DEBUG - 2013-09-05 06:34:30 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:30 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 06:34:30 --> Language Class Initialized
DEBUG - 2013-09-05 06:34:31 --> Loader Class Initialized
DEBUG - 2013-09-05 06:34:31 --> Helper loaded: url_helper
DEBUG - 2013-09-05 06:34:31 --> Helper loaded: file_helper
DEBUG - 2013-09-05 06:34:31 --> Helper loaded: form_helper
DEBUG - 2013-09-05 06:34:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 06:34:31 --> Helper loaded: application_helper
DEBUG - 2013-09-05 06:34:31 --> Database Driver Class Initialized
DEBUG - 2013-09-05 06:34:31 --> Session Class Initialized
DEBUG - 2013-09-05 06:34:31 --> Helper loaded: string_helper
DEBUG - 2013-09-05 06:34:31 --> Session routines successfully run
DEBUG - 2013-09-05 06:34:31 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 06:34:31 --> Controller Class Initialized
ERROR - 2013-09-05 06:34:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:31 --> Model Class Initialized
DEBUG - 2013-09-05 06:34:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 06:34:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 06:34:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 06:34:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 06:34:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-05 06:34:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-05 06:34:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-05 06:34:31 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-05 06:34:31 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-05 06:34:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-05 06:34:31 --> Final output sent to browser
DEBUG - 2013-09-05 06:34:31 --> Total execution time: 0.3270
DEBUG - 2013-09-05 06:34:31 --> Config Class Initialized
DEBUG - 2013-09-05 06:34:31 --> Hooks Class Initialized
DEBUG - 2013-09-05 06:34:31 --> Utf8 Class Initialized
DEBUG - 2013-09-05 06:34:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 06:34:31 --> URI Class Initialized
DEBUG - 2013-09-05 06:34:31 --> Router Class Initialized
ERROR - 2013-09-05 06:34:31 --> 404 Page Not Found --> css
DEBUG - 2013-09-05 06:34:37 --> Config Class Initialized
DEBUG - 2013-09-05 06:34:37 --> Hooks Class Initialized
DEBUG - 2013-09-05 06:34:37 --> Utf8 Class Initialized
DEBUG - 2013-09-05 06:34:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 06:34:37 --> URI Class Initialized
DEBUG - 2013-09-05 06:34:37 --> Router Class Initialized
DEBUG - 2013-09-05 06:34:37 --> Output Class Initialized
DEBUG - 2013-09-05 06:34:37 --> Security Class Initialized
DEBUG - 2013-09-05 06:34:37 --> Input Class Initialized
DEBUG - 2013-09-05 06:34:37 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:37 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:37 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:37 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:37 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:37 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 06:34:37 --> Language Class Initialized
DEBUG - 2013-09-05 06:34:37 --> Loader Class Initialized
DEBUG - 2013-09-05 06:34:37 --> Helper loaded: url_helper
DEBUG - 2013-09-05 06:34:37 --> Helper loaded: file_helper
DEBUG - 2013-09-05 06:34:37 --> Helper loaded: form_helper
DEBUG - 2013-09-05 06:34:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 06:34:37 --> Helper loaded: application_helper
DEBUG - 2013-09-05 06:34:37 --> Database Driver Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Session Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: string_helper
DEBUG - 2013-09-05 06:34:38 --> Session routines successfully run
DEBUG - 2013-09-05 06:34:38 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Controller Class Initialized
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:38 --> Model Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 06:34:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 06:34:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:38 --> Model Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Form Validation Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-05 06:34:38 --> Config Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Hooks Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Utf8 Class Initialized
DEBUG - 2013-09-05 06:34:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 06:34:38 --> URI Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Router Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Output Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Security Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Input Class Initialized
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 06:34:38 --> Language Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Loader Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: url_helper
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: file_helper
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: form_helper
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: application_helper
DEBUG - 2013-09-05 06:34:38 --> Database Driver Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Session Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: string_helper
DEBUG - 2013-09-05 06:34:38 --> Session routines successfully run
DEBUG - 2013-09-05 06:34:38 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Controller Class Initialized
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:38 --> Model Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 06:34:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 06:34:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:38 --> Config Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Hooks Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Utf8 Class Initialized
DEBUG - 2013-09-05 06:34:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 06:34:38 --> URI Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Router Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Output Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Security Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Input Class Initialized
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> XSS Filtering completed
DEBUG - 2013-09-05 06:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 06:34:38 --> Language Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Loader Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: url_helper
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: file_helper
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: form_helper
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: application_helper
DEBUG - 2013-09-05 06:34:38 --> Database Driver Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Session Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: string_helper
DEBUG - 2013-09-05 06:34:38 --> Session routines successfully run
DEBUG - 2013-09-05 06:34:38 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Controller Class Initialized
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:38 --> Model Class Initialized
DEBUG - 2013-09-05 06:34:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 06:34:38 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 06:34:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 06:34:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 06:34:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 06:34:38 --> Model Class Initialized
DEBUG - 2013-09-05 06:34:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-05 06:34:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-05 06:34:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-05 06:34:38 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-05 06:34:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-05 06:34:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-05 06:34:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-05 06:34:39 --> File loaded: application/views/home.php
DEBUG - 2013-09-05 06:34:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-05 06:34:39 --> Final output sent to browser
DEBUG - 2013-09-05 06:34:39 --> Total execution time: 0.4360
DEBUG - 2013-09-05 06:34:39 --> Config Class Initialized
DEBUG - 2013-09-05 06:34:39 --> Hooks Class Initialized
DEBUG - 2013-09-05 06:34:39 --> Utf8 Class Initialized
DEBUG - 2013-09-05 06:34:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 06:34:39 --> URI Class Initialized
DEBUG - 2013-09-05 06:34:39 --> Router Class Initialized
ERROR - 2013-09-05 06:34:39 --> 404 Page Not Found --> css
DEBUG - 2013-09-05 09:36:57 --> Config Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Hooks Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Utf8 Class Initialized
DEBUG - 2013-09-05 09:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 09:36:57 --> URI Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Router Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Output Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Security Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Input Class Initialized
DEBUG - 2013-09-05 09:36:57 --> XSS Filtering completed
DEBUG - 2013-09-05 09:36:57 --> XSS Filtering completed
DEBUG - 2013-09-05 09:36:57 --> XSS Filtering completed
DEBUG - 2013-09-05 09:36:57 --> XSS Filtering completed
DEBUG - 2013-09-05 09:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 09:36:57 --> Language Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Loader Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Helper loaded: url_helper
DEBUG - 2013-09-05 09:36:57 --> Helper loaded: file_helper
DEBUG - 2013-09-05 09:36:57 --> Helper loaded: form_helper
DEBUG - 2013-09-05 09:36:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 09:36:57 --> Helper loaded: application_helper
DEBUG - 2013-09-05 09:36:57 --> Database Driver Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Session Class Initialized
DEBUG - 2013-09-05 09:36:57 --> Helper loaded: string_helper
DEBUG - 2013-09-05 09:36:57 --> A session cookie was not found.
DEBUG - 2013-09-05 09:36:57 --> Session routines successfully run
DEBUG - 2013-09-05 09:36:57 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Controller Class Initialized
ERROR - 2013-09-05 09:36:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:36:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:36:58 --> Model Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 09:36:58 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 09:36:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 09:36:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 09:36:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:36:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:36:58 --> Config Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Hooks Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Utf8 Class Initialized
DEBUG - 2013-09-05 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 09:36:58 --> URI Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Router Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Output Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Security Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Input Class Initialized
DEBUG - 2013-09-05 09:36:58 --> XSS Filtering completed
DEBUG - 2013-09-05 09:36:58 --> XSS Filtering completed
DEBUG - 2013-09-05 09:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 09:36:58 --> Language Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Loader Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Helper loaded: url_helper
DEBUG - 2013-09-05 09:36:58 --> Helper loaded: file_helper
DEBUG - 2013-09-05 09:36:58 --> Helper loaded: form_helper
DEBUG - 2013-09-05 09:36:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 09:36:58 --> Helper loaded: application_helper
DEBUG - 2013-09-05 09:36:58 --> Database Driver Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Session Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Helper loaded: string_helper
DEBUG - 2013-09-05 09:36:58 --> Session routines successfully run
DEBUG - 2013-09-05 09:36:58 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Controller Class Initialized
ERROR - 2013-09-05 09:36:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:36:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:36:58 --> Model Class Initialized
DEBUG - 2013-09-05 09:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 09:36:58 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 09:36:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 09:36:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 09:36:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:36:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:36:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-05 09:36:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-05 09:36:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-05 09:36:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-05 09:36:59 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-05 09:36:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-05 09:36:59 --> Final output sent to browser
DEBUG - 2013-09-05 09:36:59 --> Total execution time: 0.5900
DEBUG - 2013-09-05 09:36:59 --> Config Class Initialized
DEBUG - 2013-09-05 09:36:59 --> Hooks Class Initialized
DEBUG - 2013-09-05 09:36:59 --> Utf8 Class Initialized
DEBUG - 2013-09-05 09:36:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 09:36:59 --> URI Class Initialized
DEBUG - 2013-09-05 09:36:59 --> Router Class Initialized
ERROR - 2013-09-05 09:36:59 --> 404 Page Not Found --> css
DEBUG - 2013-09-05 09:37:05 --> Config Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Hooks Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Utf8 Class Initialized
DEBUG - 2013-09-05 09:37:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 09:37:05 --> URI Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Router Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Output Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Security Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Input Class Initialized
DEBUG - 2013-09-05 09:37:05 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:05 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:05 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:05 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:05 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:05 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 09:37:05 --> Language Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Loader Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Helper loaded: url_helper
DEBUG - 2013-09-05 09:37:05 --> Helper loaded: file_helper
DEBUG - 2013-09-05 09:37:05 --> Helper loaded: form_helper
DEBUG - 2013-09-05 09:37:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 09:37:05 --> Helper loaded: application_helper
DEBUG - 2013-09-05 09:37:05 --> Database Driver Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Session Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Helper loaded: string_helper
DEBUG - 2013-09-05 09:37:05 --> Session routines successfully run
DEBUG - 2013-09-05 09:37:05 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Controller Class Initialized
ERROR - 2013-09-05 09:37:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:37:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:37:05 --> Model Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 09:37:05 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 09:37:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 09:37:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 09:37:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:37:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:37:05 --> Model Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Form Validation Class Initialized
DEBUG - 2013-09-05 09:37:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-05 09:37:06 --> Config Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Hooks Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Utf8 Class Initialized
DEBUG - 2013-09-05 09:37:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 09:37:06 --> URI Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Router Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Output Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Security Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Input Class Initialized
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 09:37:06 --> Language Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Loader Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: url_helper
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: file_helper
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: form_helper
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: application_helper
DEBUG - 2013-09-05 09:37:06 --> Database Driver Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Session Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: string_helper
DEBUG - 2013-09-05 09:37:06 --> Session garbage collection performed.
DEBUG - 2013-09-05 09:37:06 --> Session routines successfully run
DEBUG - 2013-09-05 09:37:06 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Controller Class Initialized
ERROR - 2013-09-05 09:37:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:37:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:37:06 --> Model Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 09:37:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 09:37:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 09:37:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:37:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:37:06 --> Config Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Hooks Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Utf8 Class Initialized
DEBUG - 2013-09-05 09:37:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 09:37:06 --> URI Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Router Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Output Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Security Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Input Class Initialized
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 09:37:06 --> Language Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Loader Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: url_helper
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: file_helper
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: form_helper
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: application_helper
DEBUG - 2013-09-05 09:37:06 --> Database Driver Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Session Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: string_helper
DEBUG - 2013-09-05 09:37:06 --> Session garbage collection performed.
DEBUG - 2013-09-05 09:37:06 --> Session routines successfully run
DEBUG - 2013-09-05 09:37:06 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Controller Class Initialized
ERROR - 2013-09-05 09:37:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:37:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:37:06 --> Model Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 09:37:06 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 09:37:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 09:37:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 09:37:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:37:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:37:06 --> Model Class Initialized
DEBUG - 2013-09-05 09:37:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-05 09:37:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-05 09:37:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-05 09:37:06 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-05 09:37:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-05 09:37:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-05 09:37:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-05 09:37:06 --> File loaded: application/views/home.php
DEBUG - 2013-09-05 09:37:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-05 09:37:06 --> Final output sent to browser
DEBUG - 2013-09-05 09:37:06 --> Total execution time: 0.4540
DEBUG - 2013-09-05 09:37:06 --> Config Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Hooks Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Utf8 Class Initialized
DEBUG - 2013-09-05 09:37:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 09:37:06 --> URI Class Initialized
DEBUG - 2013-09-05 09:37:06 --> Router Class Initialized
ERROR - 2013-09-05 09:37:06 --> 404 Page Not Found --> css
DEBUG - 2013-09-05 09:37:09 --> Config Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Hooks Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Utf8 Class Initialized
DEBUG - 2013-09-05 09:37:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 09:37:09 --> URI Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Router Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Output Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Security Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Input Class Initialized
DEBUG - 2013-09-05 09:37:09 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:09 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:09 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:09 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:09 --> XSS Filtering completed
DEBUG - 2013-09-05 09:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-05 09:37:09 --> Language Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Loader Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Helper loaded: url_helper
DEBUG - 2013-09-05 09:37:09 --> Helper loaded: file_helper
DEBUG - 2013-09-05 09:37:09 --> Helper loaded: form_helper
DEBUG - 2013-09-05 09:37:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-05 09:37:09 --> Helper loaded: application_helper
DEBUG - 2013-09-05 09:37:09 --> Database Driver Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Session Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Helper loaded: string_helper
DEBUG - 2013-09-05 09:37:09 --> Session routines successfully run
DEBUG - 2013-09-05 09:37:09 --> XML-RPC Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Controller Class Initialized
ERROR - 2013-09-05 09:37:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:37:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:37:09 --> Model Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-05 09:37:09 --> Helper loaded: cookie_helper
DEBUG - 2013-09-05 09:37:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-05 09:37:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-05 09:37:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-05 09:37:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-05 09:37:09 --> Model Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Pagination Class Initialized
DEBUG - 2013-09-05 09:37:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-05 09:37:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-05 09:37:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-05 09:37:09 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-05 09:37:09 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-05 09:37:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-05 09:37:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-05 09:37:09 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-09-05 09:37:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-05 09:37:09 --> Final output sent to browser
DEBUG - 2013-09-05 09:37:09 --> Total execution time: 0.4550
DEBUG - 2013-09-05 09:37:09 --> Config Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Hooks Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Utf8 Class Initialized
DEBUG - 2013-09-05 09:37:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-05 09:37:09 --> URI Class Initialized
DEBUG - 2013-09-05 09:37:09 --> Router Class Initialized
ERROR - 2013-09-05 09:37:09 --> 404 Page Not Found --> css
