<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-26 16:03:18 --> Config Class Initialized
DEBUG - 2013-08-26 16:03:18 --> Hooks Class Initialized
DEBUG - 2013-08-26 16:03:18 --> Utf8 Class Initialized
DEBUG - 2013-08-26 16:03:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-26 16:03:18 --> URI Class Initialized
DEBUG - 2013-08-26 16:03:18 --> Router Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Output Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Security Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Input Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-26 16:03:19 --> Language Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Loader Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Helper loaded: url_helper
DEBUG - 2013-08-26 16:03:19 --> Helper loaded: file_helper
DEBUG - 2013-08-26 16:03:19 --> Helper loaded: form_helper
DEBUG - 2013-08-26 16:03:19 --> Database Driver Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Session Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Helper loaded: string_helper
DEBUG - 2013-08-26 16:03:19 --> A session cookie was not found.
DEBUG - 2013-08-26 16:03:19 --> Session routines successfully run
DEBUG - 2013-08-26 16:03:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Controller Class Initialized
ERROR - 2013-08-26 16:03:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:03:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-26 16:03:19 --> Model Class Initialized
DEBUG - 2013-08-26 16:03:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-26 16:03:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-26 16:03:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-26 16:03:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-26 16:03:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:03:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-26 16:03:19 --> Pagination Class Initialized
ERROR - 2013-08-26 16:03:20 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:03:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:03:20 --> Severity: Warning  --> include_once(application/core/Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:03:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:03:20 --> Non-existent class: Excel_reader
ERROR - 2013-08-26 16:03:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school\system\libraries\Excel_reader.php:1084) C:\xampp\htdocs\school\system\core\Common.php 442
DEBUG - 2013-08-26 16:08:56 --> Config Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Hooks Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Utf8 Class Initialized
DEBUG - 2013-08-26 16:08:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-26 16:08:56 --> URI Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Router Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Output Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Security Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Input Class Initialized
DEBUG - 2013-08-26 16:08:56 --> XSS Filtering completed
DEBUG - 2013-08-26 16:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-26 16:08:56 --> Language Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Loader Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Helper loaded: url_helper
DEBUG - 2013-08-26 16:08:56 --> Helper loaded: file_helper
DEBUG - 2013-08-26 16:08:56 --> Helper loaded: form_helper
DEBUG - 2013-08-26 16:08:56 --> Database Driver Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Session Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Helper loaded: string_helper
DEBUG - 2013-08-26 16:08:56 --> Session routines successfully run
DEBUG - 2013-08-26 16:08:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Controller Class Initialized
ERROR - 2013-08-26 16:08:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:08:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-26 16:08:56 --> Model Class Initialized
DEBUG - 2013-08-26 16:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-26 16:08:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-26 16:08:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-26 16:08:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-26 16:08:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:08:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-26 16:08:57 --> Pagination Class Initialized
ERROR - 2013-08-26 16:08:57 --> Severity: Warning  --> include_once(application/core/MY_Spreadsheet_Excel_Reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:08:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Spreadsheet_Excel_Reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:08:57 --> Severity: Warning  --> include_once(application/core/Spreadsheet_Excel_Reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:08:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Spreadsheet_Excel_Reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:08:57 --> Non-existent class: Spreadsheet_Excel_Reader
ERROR - 2013-08-26 16:08:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school\system\libraries\Spreadsheet_Excel_Reader.php:1084) C:\xampp\htdocs\school\system\core\Common.php 442
DEBUG - 2013-08-26 16:16:00 --> Config Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Hooks Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Utf8 Class Initialized
DEBUG - 2013-08-26 16:16:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-26 16:16:00 --> URI Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Router Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Output Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Security Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Input Class Initialized
DEBUG - 2013-08-26 16:16:00 --> XSS Filtering completed
DEBUG - 2013-08-26 16:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-26 16:16:00 --> Language Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Loader Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Helper loaded: url_helper
DEBUG - 2013-08-26 16:16:00 --> Helper loaded: file_helper
DEBUG - 2013-08-26 16:16:00 --> Helper loaded: form_helper
DEBUG - 2013-08-26 16:16:00 --> Database Driver Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Session Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Helper loaded: string_helper
DEBUG - 2013-08-26 16:16:00 --> Session routines successfully run
DEBUG - 2013-08-26 16:16:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Controller Class Initialized
ERROR - 2013-08-26 16:16:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:16:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-26 16:16:00 --> Model Class Initialized
DEBUG - 2013-08-26 16:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-26 16:16:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-26 16:16:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-26 16:16:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-26 16:16:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:16:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-26 16:16:00 --> Pagination Class Initialized
ERROR - 2013-08-26 16:16:00 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-26 16:16:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
