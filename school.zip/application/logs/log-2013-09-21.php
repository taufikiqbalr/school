<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-09-21 01:33:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:02 --> 404 Page Not Found --> css
ERROR - 2013-09-21 01:33:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:18 --> 404 Page Not Found --> css
ERROR - 2013-09-21 01:33:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:33:22 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 108
ERROR - 2013-09-21 01:33:22 --> Severity: Notice  --> Undefined variable: guru_kelas_matpel_ids C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 108
ERROR - 2013-09-21 01:34:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:34:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:34:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:34:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 108
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined variable: guru_kelas_matpel_ids C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 108
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 113
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined variable: guru_kelas_matpel_ids C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 113
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 108
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined variable: guru_kelas_matpel_ids C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 108
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 113
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined variable: guru_kelas_matpel_ids C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 113
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 147
ERROR - 2013-09-21 01:34:04 --> Severity: Notice  --> Undefined variable: guru_kelas_matpel_ids C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 147
ERROR - 2013-09-21 01:34:04 --> 404 Page Not Found --> css
ERROR - 2013-09-21 01:34:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:34:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:34:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:34:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:34:55 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 108
ERROR - 2013-09-21 01:34:55 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 113
ERROR - 2013-09-21 01:34:55 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 108
ERROR - 2013-09-21 01:34:55 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 113
ERROR - 2013-09-21 01:34:55 --> Severity: Notice  --> Undefined index: guru_kelas_bagian_id C:\xampp\htdocs\school\application\views\siswa_nilais\index.php 147
ERROR - 2013-09-21 01:34:55 --> 404 Page Not Found --> css
ERROR - 2013-09-21 01:35:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:35:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:35:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:35:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 01:35:43 --> 404 Page Not Found --> css
ERROR - 2013-09-21 02:24:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 02:24:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 02:24:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 02:24:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 02:24:28 --> 404 Page Not Found --> css
ERROR - 2013-09-21 02:24:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 02:24:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 02:24:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 02:24:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-21 02:24:32 --> 404 Page Not Found --> css
