<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-09 07:48:29 --> Config Class Initialized
DEBUG - 2013-09-09 07:48:29 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:48:29 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:48:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:48:30 --> URI Class Initialized
DEBUG - 2013-09-09 07:48:30 --> Router Class Initialized
DEBUG - 2013-09-09 07:48:30 --> No URI present. Default controller set.
DEBUG - 2013-09-09 07:48:30 --> Output Class Initialized
DEBUG - 2013-09-09 07:48:30 --> Security Class Initialized
DEBUG - 2013-09-09 07:48:30 --> Input Class Initialized
DEBUG - 2013-09-09 07:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 07:48:30 --> Language Class Initialized
DEBUG - 2013-09-09 07:48:30 --> Loader Class Initialized
DEBUG - 2013-09-09 07:48:30 --> Helper loaded: url_helper
DEBUG - 2013-09-09 07:48:30 --> Helper loaded: file_helper
DEBUG - 2013-09-09 07:48:30 --> Helper loaded: form_helper
DEBUG - 2013-09-09 07:48:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 07:48:30 --> Helper loaded: application_helper
DEBUG - 2013-09-09 07:48:30 --> Database Driver Class Initialized
DEBUG - 2013-09-09 07:48:30 --> Session Class Initialized
DEBUG - 2013-09-09 07:48:30 --> Helper loaded: string_helper
DEBUG - 2013-09-09 07:48:30 --> A session cookie was not found.
DEBUG - 2013-09-09 07:48:30 --> Session routines successfully run
DEBUG - 2013-09-09 07:48:31 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Controller Class Initialized
ERROR - 2013-09-09 07:48:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:31 --> Model Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 07:48:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 07:48:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 07:48:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 07:48:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:31 --> Config Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:48:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:48:31 --> URI Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Router Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Output Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Security Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Input Class Initialized
DEBUG - 2013-09-09 07:48:31 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 07:48:31 --> Language Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Loader Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Helper loaded: url_helper
DEBUG - 2013-09-09 07:48:31 --> Helper loaded: file_helper
DEBUG - 2013-09-09 07:48:31 --> Helper loaded: form_helper
DEBUG - 2013-09-09 07:48:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 07:48:31 --> Helper loaded: application_helper
DEBUG - 2013-09-09 07:48:31 --> Database Driver Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Session Class Initialized
DEBUG - 2013-09-09 07:48:31 --> Helper loaded: string_helper
DEBUG - 2013-09-09 07:48:32 --> Session routines successfully run
DEBUG - 2013-09-09 07:48:32 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 07:48:32 --> Controller Class Initialized
ERROR - 2013-09-09 07:48:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:32 --> Model Class Initialized
DEBUG - 2013-09-09 07:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 07:48:32 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 07:48:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 07:48:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 07:48:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 07:48:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 07:48:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 07:48:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 07:48:32 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-09 07:48:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 07:48:32 --> Final output sent to browser
DEBUG - 2013-09-09 07:48:32 --> Total execution time: 0.5480
DEBUG - 2013-09-09 07:48:32 --> Config Class Initialized
DEBUG - 2013-09-09 07:48:32 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:48:32 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:48:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:48:32 --> URI Class Initialized
DEBUG - 2013-09-09 07:48:32 --> Router Class Initialized
ERROR - 2013-09-09 07:48:32 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 07:48:39 --> Config Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:48:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:48:39 --> URI Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Router Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Output Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Security Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Input Class Initialized
DEBUG - 2013-09-09 07:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 07:48:39 --> Language Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Loader Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Helper loaded: url_helper
DEBUG - 2013-09-09 07:48:39 --> Helper loaded: file_helper
DEBUG - 2013-09-09 07:48:39 --> Helper loaded: form_helper
DEBUG - 2013-09-09 07:48:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 07:48:39 --> Helper loaded: application_helper
DEBUG - 2013-09-09 07:48:39 --> Database Driver Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Session Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Helper loaded: string_helper
DEBUG - 2013-09-09 07:48:39 --> Session routines successfully run
DEBUG - 2013-09-09 07:48:39 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Controller Class Initialized
ERROR - 2013-09-09 07:48:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:39 --> Model Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 07:48:39 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 07:48:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 07:48:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 07:48:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:39 --> Model Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Form Validation Class Initialized
DEBUG - 2013-09-09 07:48:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 07:48:40 --> Config Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:48:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:48:40 --> URI Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Router Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Output Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Security Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Input Class Initialized
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 07:48:40 --> Language Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Loader Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 07:48:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Session Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 07:48:40 --> Session routines successfully run
DEBUG - 2013-09-09 07:48:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Controller Class Initialized
ERROR - 2013-09-09 07:48:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:40 --> Model Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 07:48:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 07:48:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 07:48:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:40 --> Config Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:48:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:48:40 --> URI Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Router Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Output Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Security Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Input Class Initialized
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 07:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 07:48:40 --> Language Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Loader Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 07:48:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Session Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 07:48:40 --> Session routines successfully run
DEBUG - 2013-09-09 07:48:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Controller Class Initialized
ERROR - 2013-09-09 07:48:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:40 --> Model Class Initialized
DEBUG - 2013-09-09 07:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 07:48:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 07:48:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 07:48:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 07:48:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:48:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:48:40 --> Model Class Initialized
DEBUG - 2013-09-09 07:48:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 07:48:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 07:48:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 07:48:40 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 07:48:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 07:48:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 07:48:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 07:48:40 --> File loaded: application/views/home.php
DEBUG - 2013-09-09 07:48:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 07:48:41 --> Final output sent to browser
DEBUG - 2013-09-09 07:48:41 --> Total execution time: 0.5080
DEBUG - 2013-09-09 07:48:41 --> Config Class Initialized
DEBUG - 2013-09-09 07:48:41 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:48:41 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:48:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:48:41 --> URI Class Initialized
DEBUG - 2013-09-09 07:48:41 --> Router Class Initialized
ERROR - 2013-09-09 07:48:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 07:59:41 --> Config Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:59:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:59:41 --> URI Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Router Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Output Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Security Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Input Class Initialized
DEBUG - 2013-09-09 07:59:41 --> XSS Filtering completed
DEBUG - 2013-09-09 07:59:41 --> XSS Filtering completed
DEBUG - 2013-09-09 07:59:41 --> XSS Filtering completed
DEBUG - 2013-09-09 07:59:41 --> XSS Filtering completed
DEBUG - 2013-09-09 07:59:41 --> XSS Filtering completed
DEBUG - 2013-09-09 07:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 07:59:41 --> Language Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Loader Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Helper loaded: url_helper
DEBUG - 2013-09-09 07:59:41 --> Helper loaded: file_helper
DEBUG - 2013-09-09 07:59:41 --> Helper loaded: form_helper
DEBUG - 2013-09-09 07:59:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 07:59:41 --> Helper loaded: application_helper
DEBUG - 2013-09-09 07:59:41 --> Database Driver Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Session Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Helper loaded: string_helper
DEBUG - 2013-09-09 07:59:41 --> Session routines successfully run
DEBUG - 2013-09-09 07:59:41 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Controller Class Initialized
ERROR - 2013-09-09 07:59:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:59:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:59:41 --> Model Class Initialized
DEBUG - 2013-09-09 07:59:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 07:59:41 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 07:59:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 07:59:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 07:59:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 07:59:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 07:59:41 --> Model Class Initialized
DEBUG - 2013-09-09 07:59:42 --> Pagination Class Initialized
DEBUG - 2013-09-09 07:59:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 07:59:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 07:59:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 07:59:42 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 07:59:42 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 07:59:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 07:59:42 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 07:59:42 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 07:59:42 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 07:59:42 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 07:59:42 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 07:59:42 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-09 07:59:42 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-09 07:59:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 07:59:42 --> Final output sent to browser
DEBUG - 2013-09-09 07:59:42 --> Total execution time: 0.6440
DEBUG - 2013-09-09 07:59:42 --> Config Class Initialized
DEBUG - 2013-09-09 07:59:42 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:59:42 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:59:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:59:42 --> URI Class Initialized
DEBUG - 2013-09-09 07:59:42 --> Router Class Initialized
ERROR - 2013-09-09 07:59:42 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 07:59:46 --> Config Class Initialized
DEBUG - 2013-09-09 07:59:46 --> Hooks Class Initialized
DEBUG - 2013-09-09 07:59:46 --> Utf8 Class Initialized
DEBUG - 2013-09-09 07:59:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 07:59:46 --> URI Class Initialized
DEBUG - 2013-09-09 07:59:46 --> Router Class Initialized
ERROR - 2013-09-09 07:59:46 --> 404 Page Not Found --> siswakelas
DEBUG - 2013-09-09 08:00:37 --> Config Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Hooks Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Utf8 Class Initialized
DEBUG - 2013-09-09 08:00:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 08:00:37 --> URI Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Router Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Output Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Security Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Input Class Initialized
DEBUG - 2013-09-09 08:00:37 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:37 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:37 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:37 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:37 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 08:00:37 --> Language Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Loader Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Helper loaded: url_helper
DEBUG - 2013-09-09 08:00:37 --> Helper loaded: file_helper
DEBUG - 2013-09-09 08:00:37 --> Helper loaded: form_helper
DEBUG - 2013-09-09 08:00:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 08:00:37 --> Helper loaded: application_helper
DEBUG - 2013-09-09 08:00:37 --> Database Driver Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Session Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Helper loaded: string_helper
DEBUG - 2013-09-09 08:00:37 --> Session routines successfully run
DEBUG - 2013-09-09 08:00:37 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 08:00:37 --> Controller Class Initialized
ERROR - 2013-09-09 08:00:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 08:00:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 08:00:37 --> Model Class Initialized
DEBUG - 2013-09-09 08:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 08:00:38 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 08:00:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 08:00:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 08:00:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 08:00:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 08:00:38 --> Model Class Initialized
DEBUG - 2013-09-09 08:00:38 --> Pagination Class Initialized
DEBUG - 2013-09-09 08:00:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 08:00:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 08:00:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 08:00:38 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 08:00:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 08:00:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 08:00:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 08:00:38 --> File loaded: application/views/siswa_kelas/index.php
DEBUG - 2013-09-09 08:00:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 08:00:38 --> Final output sent to browser
DEBUG - 2013-09-09 08:00:38 --> Total execution time: 0.3850
DEBUG - 2013-09-09 08:00:38 --> Config Class Initialized
DEBUG - 2013-09-09 08:00:38 --> Hooks Class Initialized
DEBUG - 2013-09-09 08:00:38 --> Utf8 Class Initialized
DEBUG - 2013-09-09 08:00:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 08:00:38 --> URI Class Initialized
DEBUG - 2013-09-09 08:00:38 --> Router Class Initialized
ERROR - 2013-09-09 08:00:38 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 08:00:42 --> Config Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Hooks Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Utf8 Class Initialized
DEBUG - 2013-09-09 08:00:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 08:00:42 --> URI Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Router Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Output Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Security Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Input Class Initialized
DEBUG - 2013-09-09 08:00:42 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:42 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:42 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:42 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:42 --> XSS Filtering completed
DEBUG - 2013-09-09 08:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 08:00:42 --> Language Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Loader Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Helper loaded: url_helper
DEBUG - 2013-09-09 08:00:42 --> Helper loaded: file_helper
DEBUG - 2013-09-09 08:00:42 --> Helper loaded: form_helper
DEBUG - 2013-09-09 08:00:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 08:00:42 --> Helper loaded: application_helper
DEBUG - 2013-09-09 08:00:42 --> Database Driver Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Session Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Helper loaded: string_helper
DEBUG - 2013-09-09 08:00:42 --> Session routines successfully run
DEBUG - 2013-09-09 08:00:42 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Controller Class Initialized
ERROR - 2013-09-09 08:00:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 08:00:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 08:00:42 --> Model Class Initialized
DEBUG - 2013-09-09 08:00:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 08:00:42 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 08:00:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 08:00:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 08:00:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 08:00:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 08:00:43 --> Model Class Initialized
DEBUG - 2013-09-09 08:00:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 08:00:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 08:00:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 08:00:43 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 08:00:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 08:00:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 08:00:43 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:00:43 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
DEBUG - 2013-09-09 08:00:43 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 08:00:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 08:00:43 --> Final output sent to browser
DEBUG - 2013-09-09 08:00:43 --> Total execution time: 0.4020
DEBUG - 2013-09-09 08:00:43 --> Config Class Initialized
DEBUG - 2013-09-09 08:00:43 --> Hooks Class Initialized
DEBUG - 2013-09-09 08:00:43 --> Utf8 Class Initialized
DEBUG - 2013-09-09 08:00:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 08:00:43 --> URI Class Initialized
DEBUG - 2013-09-09 08:00:43 --> Router Class Initialized
ERROR - 2013-09-09 08:00:43 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 08:01:24 --> Config Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Hooks Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Utf8 Class Initialized
DEBUG - 2013-09-09 08:01:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 08:01:24 --> URI Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Router Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Output Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Security Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Input Class Initialized
DEBUG - 2013-09-09 08:01:24 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:24 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:24 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:24 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:24 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 08:01:24 --> Language Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Loader Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Helper loaded: url_helper
DEBUG - 2013-09-09 08:01:24 --> Helper loaded: file_helper
DEBUG - 2013-09-09 08:01:24 --> Helper loaded: form_helper
DEBUG - 2013-09-09 08:01:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 08:01:24 --> Helper loaded: application_helper
DEBUG - 2013-09-09 08:01:24 --> Database Driver Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Session Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Helper loaded: string_helper
DEBUG - 2013-09-09 08:01:24 --> Session routines successfully run
DEBUG - 2013-09-09 08:01:24 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Controller Class Initialized
ERROR - 2013-09-09 08:01:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 08:01:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 08:01:24 --> Model Class Initialized
DEBUG - 2013-09-09 08:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 08:01:24 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 08:01:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 08:01:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 08:01:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 08:01:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 08:01:24 --> Model Class Initialized
DEBUG - 2013-09-09 08:01:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 08:01:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 08:01:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 08:01:24 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 08:01:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 08:01:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 08:01:24 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:24 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
DEBUG - 2013-09-09 08:01:24 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 08:01:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 08:01:25 --> Final output sent to browser
DEBUG - 2013-09-09 08:01:25 --> Total execution time: 0.5330
DEBUG - 2013-09-09 08:01:25 --> Config Class Initialized
DEBUG - 2013-09-09 08:01:25 --> Hooks Class Initialized
DEBUG - 2013-09-09 08:01:25 --> Utf8 Class Initialized
DEBUG - 2013-09-09 08:01:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 08:01:25 --> URI Class Initialized
DEBUG - 2013-09-09 08:01:25 --> Router Class Initialized
ERROR - 2013-09-09 08:01:25 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 08:01:27 --> Config Class Initialized
DEBUG - 2013-09-09 08:01:27 --> Hooks Class Initialized
DEBUG - 2013-09-09 08:01:27 --> Utf8 Class Initialized
DEBUG - 2013-09-09 08:01:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 08:01:27 --> URI Class Initialized
DEBUG - 2013-09-09 08:01:27 --> Router Class Initialized
DEBUG - 2013-09-09 08:01:27 --> Output Class Initialized
DEBUG - 2013-09-09 08:01:27 --> Security Class Initialized
DEBUG - 2013-09-09 08:01:27 --> Input Class Initialized
DEBUG - 2013-09-09 08:01:27 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:27 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:27 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:27 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:27 --> XSS Filtering completed
DEBUG - 2013-09-09 08:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 08:01:27 --> Language Class Initialized
DEBUG - 2013-09-09 08:01:28 --> Loader Class Initialized
DEBUG - 2013-09-09 08:01:28 --> Helper loaded: url_helper
DEBUG - 2013-09-09 08:01:28 --> Helper loaded: file_helper
DEBUG - 2013-09-09 08:01:28 --> Helper loaded: form_helper
DEBUG - 2013-09-09 08:01:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 08:01:28 --> Helper loaded: application_helper
DEBUG - 2013-09-09 08:01:28 --> Database Driver Class Initialized
DEBUG - 2013-09-09 08:01:28 --> Session Class Initialized
DEBUG - 2013-09-09 08:01:28 --> Helper loaded: string_helper
DEBUG - 2013-09-09 08:01:28 --> Session routines successfully run
DEBUG - 2013-09-09 08:01:28 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 08:01:28 --> Controller Class Initialized
ERROR - 2013-09-09 08:01:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 08:01:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 08:01:28 --> Model Class Initialized
DEBUG - 2013-09-09 08:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 08:01:28 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 08:01:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 08:01:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 08:01:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 08:01:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 08:01:28 --> Model Class Initialized
DEBUG - 2013-09-09 08:01:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 08:01:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 08:01:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 08:01:28 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 08:01:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 08:01:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 08:01:28 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 08:01:28 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
DEBUG - 2013-09-09 08:01:28 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 08:01:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 08:01:28 --> Final output sent to browser
DEBUG - 2013-09-09 08:01:28 --> Total execution time: 0.5020
DEBUG - 2013-09-09 08:01:28 --> Config Class Initialized
DEBUG - 2013-09-09 08:01:28 --> Hooks Class Initialized
DEBUG - 2013-09-09 08:01:28 --> Utf8 Class Initialized
DEBUG - 2013-09-09 08:01:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 08:01:28 --> URI Class Initialized
DEBUG - 2013-09-09 08:01:28 --> Router Class Initialized
ERROR - 2013-09-09 08:01:28 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:13:32 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:32 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:32 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:32 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:32 --> Router Class Initialized
DEBUG - 2013-09-09 11:13:32 --> No URI present. Default controller set.
DEBUG - 2013-09-09 11:13:33 --> Output Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Security Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Input Class Initialized
DEBUG - 2013-09-09 11:13:33 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:33 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:33 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:33 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:13:33 --> Language Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Loader Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:13:33 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Session Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:13:33 --> A session cookie was not found.
DEBUG - 2013-09-09 11:13:33 --> Session routines successfully run
DEBUG - 2013-09-09 11:13:33 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Controller Class Initialized
ERROR - 2013-09-09 11:13:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:33 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:13:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:13:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:13:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:33 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:33 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Router Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Output Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Security Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Input Class Initialized
DEBUG - 2013-09-09 11:13:33 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:33 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:13:33 --> Language Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Loader Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:13:33 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Session Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:13:33 --> Session routines successfully run
DEBUG - 2013-09-09 11:13:33 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Controller Class Initialized
ERROR - 2013-09-09 11:13:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:33 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:13:33 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:13:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:13:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:13:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:13:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:13:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:13:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 11:13:33 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-09 11:13:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:13:33 --> Final output sent to browser
DEBUG - 2013-09-09 11:13:33 --> Total execution time: 0.3200
DEBUG - 2013-09-09 11:13:33 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:33 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:33 --> Router Class Initialized
ERROR - 2013-09-09 11:13:33 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:13:39 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:39 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:39 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:39 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:39 --> Router Class Initialized
DEBUG - 2013-09-09 11:13:39 --> Output Class Initialized
DEBUG - 2013-09-09 11:13:39 --> Security Class Initialized
DEBUG - 2013-09-09 11:13:39 --> Input Class Initialized
DEBUG - 2013-09-09 11:13:39 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:39 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:39 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:39 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:39 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:39 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:13:39 --> Language Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Loader Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:13:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Session Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:13:40 --> Session routines successfully run
DEBUG - 2013-09-09 11:13:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Controller Class Initialized
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:40 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:13:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:13:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:40 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Form Validation Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 11:13:40 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:40 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Router Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Output Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Security Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Input Class Initialized
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:13:40 --> Language Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Loader Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:13:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Session Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:13:40 --> Session routines successfully run
DEBUG - 2013-09-09 11:13:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Controller Class Initialized
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:40 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:13:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:13:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:40 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:40 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Router Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Output Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Security Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Input Class Initialized
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:13:40 --> Language Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Loader Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:13:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Session Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:13:40 --> Session routines successfully run
DEBUG - 2013-09-09 11:13:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:13:40 --> Controller Class Initialized
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:40 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:13:41 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:13:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:13:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:13:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:41 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:13:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:13:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:13:41 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:13:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:13:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:13:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 11:13:41 --> File loaded: application/views/home.php
DEBUG - 2013-09-09 11:13:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:13:41 --> Final output sent to browser
DEBUG - 2013-09-09 11:13:41 --> Total execution time: 0.5120
DEBUG - 2013-09-09 11:13:41 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:41 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:41 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:41 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:41 --> Router Class Initialized
ERROR - 2013-09-09 11:13:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:13:47 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:47 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Router Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Output Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Security Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Input Class Initialized
DEBUG - 2013-09-09 11:13:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:13:47 --> Language Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Loader Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:13:47 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:13:47 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:13:47 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:13:47 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:13:47 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Session Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:13:47 --> Session routines successfully run
DEBUG - 2013-09-09 11:13:47 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Controller Class Initialized
ERROR - 2013-09-09 11:13:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:47 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:13:47 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:13:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:13:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:13:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:47 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Pagination Class Initialized
DEBUG - 2013-09-09 11:13:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:13:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:13:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:13:47 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:13:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:13:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:13:47 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:13:47 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:13:47 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:13:47 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:13:47 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:13:47 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-09 11:13:47 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-09 11:13:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:13:47 --> Final output sent to browser
DEBUG - 2013-09-09 11:13:47 --> Total execution time: 0.4660
DEBUG - 2013-09-09 11:13:47 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:47 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:47 --> Router Class Initialized
ERROR - 2013-09-09 11:13:47 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:13:51 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:51 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Router Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Output Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Security Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Input Class Initialized
DEBUG - 2013-09-09 11:13:51 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:51 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:51 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:51 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:51 --> XSS Filtering completed
DEBUG - 2013-09-09 11:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:13:51 --> Language Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Loader Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:13:51 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:13:51 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:13:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:13:51 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:13:51 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Session Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:13:51 --> Session routines successfully run
DEBUG - 2013-09-09 11:13:51 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Controller Class Initialized
ERROR - 2013-09-09 11:13:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:51 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:13:51 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:13:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:13:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:13:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:13:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:13:51 --> Model Class Initialized
DEBUG - 2013-09-09 11:13:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:13:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:13:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:13:51 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:13:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:13:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:13:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 11:13:51 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-09-09 11:13:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:13:51 --> Final output sent to browser
DEBUG - 2013-09-09 11:13:51 --> Total execution time: 0.5000
DEBUG - 2013-09-09 11:13:51 --> Config Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:13:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:13:51 --> URI Class Initialized
DEBUG - 2013-09-09 11:13:51 --> Router Class Initialized
ERROR - 2013-09-09 11:13:51 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:14:02 --> Config Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:14:02 --> URI Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Router Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Output Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Security Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Input Class Initialized
DEBUG - 2013-09-09 11:14:02 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:02 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:02 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:02 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:02 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:14:02 --> Language Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Loader Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:14:02 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:14:02 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:14:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:14:02 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:14:02 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Session Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:14:02 --> Session routines successfully run
DEBUG - 2013-09-09 11:14:02 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Controller Class Initialized
ERROR - 2013-09-09 11:14:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:14:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:14:02 --> Model Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:14:02 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:14:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:14:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:14:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:14:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:14:02 --> Model Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Pagination Class Initialized
DEBUG - 2013-09-09 11:14:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:14:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:14:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:14:02 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:14:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:14:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:14:02 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:14:02 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:14:02 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:14:02 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:14:02 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:14:02 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-09 11:14:02 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-09 11:14:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:14:02 --> Final output sent to browser
DEBUG - 2013-09-09 11:14:02 --> Total execution time: 0.4700
DEBUG - 2013-09-09 11:14:02 --> Config Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:14:02 --> URI Class Initialized
DEBUG - 2013-09-09 11:14:02 --> Router Class Initialized
ERROR - 2013-09-09 11:14:02 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:14:05 --> Config Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:14:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:14:05 --> URI Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Router Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Output Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Security Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Input Class Initialized
DEBUG - 2013-09-09 11:14:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:14:05 --> Language Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Loader Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:14:05 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:14:05 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:14:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:14:05 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:14:05 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Session Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:14:05 --> Session routines successfully run
DEBUG - 2013-09-09 11:14:05 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Controller Class Initialized
ERROR - 2013-09-09 11:14:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:14:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:14:05 --> Model Class Initialized
DEBUG - 2013-09-09 11:14:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:14:05 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:14:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:14:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:14:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:14:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:14:05 --> Model Class Initialized
DEBUG - 2013-09-09 11:14:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:14:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:14:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:14:06 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:14:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:14:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:14:06 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:14:06 --> Severity: Notice  --> Undefined variable: guru C:\xampp\htdocs\school\application\views\siswas\edit.php 241
ERROR - 2013-09-09 11:14:06 --> Severity: Notice  --> Undefined variable: guru C:\xampp\htdocs\school\application\views\siswas\edit.php 260
DEBUG - 2013-09-09 11:14:06 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 11:14:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:14:06 --> Final output sent to browser
DEBUG - 2013-09-09 11:14:06 --> Total execution time: 0.4230
DEBUG - 2013-09-09 11:14:06 --> Config Class Initialized
DEBUG - 2013-09-09 11:14:06 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:14:06 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:14:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:14:06 --> URI Class Initialized
DEBUG - 2013-09-09 11:14:06 --> Router Class Initialized
ERROR - 2013-09-09 11:14:06 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:16:34 --> Config Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:16:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:16:34 --> URI Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Router Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Output Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Security Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Input Class Initialized
DEBUG - 2013-09-09 11:16:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:16:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:16:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:16:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:16:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:16:34 --> Language Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Loader Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:16:34 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:16:34 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:16:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:16:34 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:16:34 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Session Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:16:34 --> Session routines successfully run
DEBUG - 2013-09-09 11:16:34 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Controller Class Initialized
ERROR - 2013-09-09 11:16:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:16:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:16:34 --> Model Class Initialized
DEBUG - 2013-09-09 11:16:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:16:34 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:16:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:16:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:16:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:16:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:16:34 --> Model Class Initialized
DEBUG - 2013-09-09 11:16:34 --> DB Transaction Failure
ERROR - 2013-09-09 11:16:34 --> Query error: Column 'id' in where clause is ambiguous
DEBUG - 2013-09-09 11:16:34 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 11:17:05 --> Config Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:17:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:17:05 --> URI Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Router Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Output Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Security Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Input Class Initialized
DEBUG - 2013-09-09 11:17:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:17:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:17:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:17:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:17:05 --> XSS Filtering completed
DEBUG - 2013-09-09 11:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:17:05 --> Language Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Loader Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:17:05 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:17:05 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:17:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:17:05 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:17:05 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Session Class Initialized
DEBUG - 2013-09-09 11:17:05 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:17:05 --> Session routines successfully run
DEBUG - 2013-09-09 11:17:05 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:17:06 --> Controller Class Initialized
ERROR - 2013-09-09 11:17:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:17:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:17:06 --> Model Class Initialized
DEBUG - 2013-09-09 11:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:17:06 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:17:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:17:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:17:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:17:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:17:06 --> Model Class Initialized
DEBUG - 2013-09-09 11:17:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:17:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:17:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:17:06 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:17:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:17:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:17:06 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:17:06 --> Severity: Notice  --> Undefined variable: guru C:\xampp\htdocs\school\application\views\siswas\edit.php 260
DEBUG - 2013-09-09 11:17:06 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 11:17:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:17:06 --> Final output sent to browser
DEBUG - 2013-09-09 11:17:06 --> Total execution time: 0.5170
DEBUG - 2013-09-09 11:17:06 --> Config Class Initialized
DEBUG - 2013-09-09 11:17:06 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:17:06 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:17:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:17:06 --> URI Class Initialized
DEBUG - 2013-09-09 11:17:06 --> Router Class Initialized
ERROR - 2013-09-09 11:17:06 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:20:03 --> Config Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:20:03 --> URI Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Router Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Output Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Security Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Input Class Initialized
DEBUG - 2013-09-09 11:20:03 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:03 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:03 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:03 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:03 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:20:03 --> Language Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Loader Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:20:03 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:20:03 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:20:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:20:03 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:20:03 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Session Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:20:03 --> Session routines successfully run
DEBUG - 2013-09-09 11:20:03 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Controller Class Initialized
ERROR - 2013-09-09 11:20:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:20:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:20:03 --> Model Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:20:03 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:20:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:20:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:20:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:20:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:20:03 --> Model Class Initialized
DEBUG - 2013-09-09 11:20:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:20:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:20:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:20:03 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:20:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:20:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:20:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 11:20:03 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 11:20:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:20:03 --> Final output sent to browser
DEBUG - 2013-09-09 11:20:03 --> Total execution time: 0.5310
DEBUG - 2013-09-09 11:20:03 --> Config Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:20:03 --> URI Class Initialized
DEBUG - 2013-09-09 11:20:03 --> Router Class Initialized
ERROR - 2013-09-09 11:20:03 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:20:07 --> Config Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:20:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:20:07 --> URI Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Router Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Output Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Security Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Input Class Initialized
DEBUG - 2013-09-09 11:20:07 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:07 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:07 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:07 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:07 --> XSS Filtering completed
DEBUG - 2013-09-09 11:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:20:07 --> Language Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Loader Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:20:07 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:20:07 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:20:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:20:07 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:20:07 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Session Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:20:07 --> Session routines successfully run
DEBUG - 2013-09-09 11:20:07 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Controller Class Initialized
ERROR - 2013-09-09 11:20:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:20:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:20:07 --> Model Class Initialized
DEBUG - 2013-09-09 11:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:20:07 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:20:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:20:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:20:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:20:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:20:07 --> Model Class Initialized
DEBUG - 2013-09-09 11:20:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:20:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:20:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:20:07 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:20:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:20:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:20:07 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: tingkat C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: jurusan C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
ERROR - 2013-09-09 11:20:07 --> Severity: Notice  --> Undefined index: nama_kelas C:\xampp\htdocs\school\application\views\siswa_kelas\new.php 24
DEBUG - 2013-09-09 11:20:08 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:20:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:20:08 --> Final output sent to browser
DEBUG - 2013-09-09 11:20:08 --> Total execution time: 0.7610
DEBUG - 2013-09-09 11:20:08 --> Config Class Initialized
DEBUG - 2013-09-09 11:20:08 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:20:08 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:20:08 --> URI Class Initialized
DEBUG - 2013-09-09 11:20:08 --> Router Class Initialized
ERROR - 2013-09-09 11:20:08 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:23:42 --> Config Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:23:42 --> URI Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Router Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Output Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Security Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Input Class Initialized
DEBUG - 2013-09-09 11:23:42 --> XSS Filtering completed
DEBUG - 2013-09-09 11:23:42 --> XSS Filtering completed
DEBUG - 2013-09-09 11:23:42 --> XSS Filtering completed
DEBUG - 2013-09-09 11:23:42 --> XSS Filtering completed
DEBUG - 2013-09-09 11:23:42 --> XSS Filtering completed
DEBUG - 2013-09-09 11:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:23:42 --> Language Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Loader Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:23:42 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:23:42 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:23:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:23:42 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:23:42 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Session Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:23:42 --> Session garbage collection performed.
DEBUG - 2013-09-09 11:23:42 --> Session routines successfully run
DEBUG - 2013-09-09 11:23:42 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Controller Class Initialized
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:23:42 --> Model Class Initialized
DEBUG - 2013-09-09 11:23:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:23:42 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:23:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:23:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:23:42 --> Model Class Initialized
DEBUG - 2013-09-09 11:23:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:23:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:23:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:23:42 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:23:42 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:23:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:23:42 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:23:42 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:23:42 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:23:42 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:23:42 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:23:42 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:23:42 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:23:42 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:23:42 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:23:42 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:23:42 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:23:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:23:43 --> Final output sent to browser
DEBUG - 2013-09-09 11:23:43 --> Total execution time: 0.7640
DEBUG - 2013-09-09 11:23:43 --> Config Class Initialized
DEBUG - 2013-09-09 11:23:43 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:23:43 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:23:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:23:43 --> URI Class Initialized
DEBUG - 2013-09-09 11:23:43 --> Router Class Initialized
ERROR - 2013-09-09 11:23:43 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:23:46 --> Config Class Initialized
DEBUG - 2013-09-09 11:23:46 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:23:46 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:23:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:23:46 --> URI Class Initialized
DEBUG - 2013-09-09 11:23:46 --> Router Class Initialized
ERROR - 2013-09-09 11:23:46 --> 404 Page Not Found --> siswakelas
DEBUG - 2013-09-09 11:24:45 --> Config Class Initialized
DEBUG - 2013-09-09 11:24:45 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:24:45 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:24:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:24:45 --> URI Class Initialized
DEBUG - 2013-09-09 11:24:45 --> Router Class Initialized
DEBUG - 2013-09-09 11:24:45 --> Output Class Initialized
DEBUG - 2013-09-09 11:24:45 --> Security Class Initialized
DEBUG - 2013-09-09 11:24:45 --> Input Class Initialized
DEBUG - 2013-09-09 11:24:45 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:24:46 --> Language Class Initialized
DEBUG - 2013-09-09 11:24:46 --> Loader Class Initialized
DEBUG - 2013-09-09 11:24:46 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:24:46 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:24:46 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:24:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:24:46 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:24:46 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:24:46 --> Session Class Initialized
DEBUG - 2013-09-09 11:24:46 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:24:46 --> Session routines successfully run
DEBUG - 2013-09-09 11:24:46 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:24:46 --> Controller Class Initialized
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:24:46 --> Model Class Initialized
DEBUG - 2013-09-09 11:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:24:46 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:24:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:24:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:24:46 --> Model Class Initialized
DEBUG - 2013-09-09 11:24:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:24:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:24:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:24:46 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:24:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:24:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:24:46 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:46 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:46 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:24:46 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:24:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:24:46 --> Final output sent to browser
DEBUG - 2013-09-09 11:24:46 --> Total execution time: 0.6860
DEBUG - 2013-09-09 11:24:46 --> Config Class Initialized
DEBUG - 2013-09-09 11:24:46 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:24:46 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:24:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:24:46 --> URI Class Initialized
DEBUG - 2013-09-09 11:24:46 --> Router Class Initialized
ERROR - 2013-09-09 11:24:46 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:24:49 --> Config Class Initialized
DEBUG - 2013-09-09 11:24:49 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:24:49 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:24:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:24:49 --> URI Class Initialized
DEBUG - 2013-09-09 11:24:49 --> Router Class Initialized
ERROR - 2013-09-09 11:24:49 --> 404 Page Not Found --> siswakelas
DEBUG - 2013-09-09 11:24:53 --> Config Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:24:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:24:53 --> URI Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Router Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Output Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Security Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Input Class Initialized
DEBUG - 2013-09-09 11:24:53 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:53 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:53 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:53 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:53 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:24:53 --> Language Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Loader Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:24:53 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:24:53 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:24:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:24:53 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:24:53 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Session Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:24:53 --> Session routines successfully run
DEBUG - 2013-09-09 11:24:53 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Controller Class Initialized
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:24:53 --> Model Class Initialized
DEBUG - 2013-09-09 11:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:24:53 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:24:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:24:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:24:53 --> Model Class Initialized
DEBUG - 2013-09-09 11:24:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:24:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:24:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:24:53 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:24:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:24:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:24:53 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:53 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:53 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:53 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:53 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:53 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:53 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:24:54 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:24:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:24:54 --> Final output sent to browser
DEBUG - 2013-09-09 11:24:54 --> Total execution time: 0.7210
DEBUG - 2013-09-09 11:24:54 --> Config Class Initialized
DEBUG - 2013-09-09 11:24:54 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:24:54 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:24:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:24:54 --> URI Class Initialized
DEBUG - 2013-09-09 11:24:54 --> Router Class Initialized
ERROR - 2013-09-09 11:24:54 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:24:55 --> Config Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:24:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:24:55 --> URI Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Router Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Output Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Security Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Input Class Initialized
DEBUG - 2013-09-09 11:24:55 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:55 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:55 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:55 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:55 --> XSS Filtering completed
DEBUG - 2013-09-09 11:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:24:55 --> Language Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Loader Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:24:55 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:24:55 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:24:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:24:55 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:24:55 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Session Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:24:55 --> Session routines successfully run
DEBUG - 2013-09-09 11:24:55 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Controller Class Initialized
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:24:55 --> Model Class Initialized
DEBUG - 2013-09-09 11:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:24:55 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:24:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:24:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:24:55 --> Model Class Initialized
DEBUG - 2013-09-09 11:24:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:24:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:24:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:24:55 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:24:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:24:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:24:55 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:24:55 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:24:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:24:55 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:24:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:24:55 --> Final output sent to browser
DEBUG - 2013-09-09 11:24:55 --> Total execution time: 0.8420
DEBUG - 2013-09-09 11:24:56 --> Config Class Initialized
DEBUG - 2013-09-09 11:24:56 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:24:56 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:24:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:24:56 --> URI Class Initialized
DEBUG - 2013-09-09 11:24:56 --> Router Class Initialized
ERROR - 2013-09-09 11:24:56 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:25:09 --> Config Class Initialized
DEBUG - 2013-09-09 11:25:09 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:25:09 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:25:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:25:09 --> URI Class Initialized
DEBUG - 2013-09-09 11:25:09 --> Router Class Initialized
ERROR - 2013-09-09 11:25:09 --> 404 Page Not Found --> siswakelas
DEBUG - 2013-09-09 11:26:45 --> Config Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:26:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:26:45 --> URI Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Router Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Output Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Security Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Input Class Initialized
DEBUG - 2013-09-09 11:26:45 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:45 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:45 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:45 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:45 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:26:45 --> Language Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Loader Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:26:45 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:26:45 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:26:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:26:45 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:26:45 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Session Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:26:45 --> Session routines successfully run
DEBUG - 2013-09-09 11:26:45 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Controller Class Initialized
ERROR - 2013-09-09 11:26:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:26:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:26:45 --> Model Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:26:45 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:26:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:26:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:26:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:26:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:26:45 --> Model Class Initialized
DEBUG - 2013-09-09 11:26:45 --> Pagination Class Initialized
DEBUG - 2013-09-09 11:26:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:26:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:26:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:26:46 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:26:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:26:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:26:46 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:26:46 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:26:46 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:26:46 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:26:46 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:26:46 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-09 11:26:46 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-09 11:26:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:26:46 --> Final output sent to browser
DEBUG - 2013-09-09 11:26:46 --> Total execution time: 0.6310
DEBUG - 2013-09-09 11:26:46 --> Config Class Initialized
DEBUG - 2013-09-09 11:26:46 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:26:46 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:26:46 --> URI Class Initialized
DEBUG - 2013-09-09 11:26:46 --> Router Class Initialized
ERROR - 2013-09-09 11:26:46 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:26:49 --> Config Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:26:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:26:49 --> URI Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Router Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Output Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Security Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Input Class Initialized
DEBUG - 2013-09-09 11:26:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:26:49 --> Language Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Loader Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:26:49 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:26:49 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:26:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:26:49 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:26:49 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Session Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:26:49 --> Session routines successfully run
DEBUG - 2013-09-09 11:26:49 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Controller Class Initialized
ERROR - 2013-09-09 11:26:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:26:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:26:49 --> Model Class Initialized
DEBUG - 2013-09-09 11:26:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:26:49 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:26:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:26:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:26:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:26:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:26:49 --> Model Class Initialized
DEBUG - 2013-09-09 11:26:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:26:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:26:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:26:49 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:26:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:26:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:26:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 11:26:49 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 11:26:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:26:49 --> Final output sent to browser
DEBUG - 2013-09-09 11:26:49 --> Total execution time: 0.6030
DEBUG - 2013-09-09 11:26:50 --> Config Class Initialized
DEBUG - 2013-09-09 11:26:50 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:26:50 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:26:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:26:50 --> URI Class Initialized
DEBUG - 2013-09-09 11:26:50 --> Router Class Initialized
ERROR - 2013-09-09 11:26:50 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:26:53 --> Config Class Initialized
DEBUG - 2013-09-09 11:26:53 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:26:53 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:26:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:26:54 --> URI Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Router Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Output Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Security Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Input Class Initialized
DEBUG - 2013-09-09 11:26:54 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:54 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:54 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:54 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:54 --> XSS Filtering completed
DEBUG - 2013-09-09 11:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:26:54 --> Language Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Loader Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:26:54 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:26:54 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:26:54 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:26:54 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:26:54 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Session Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:26:54 --> Session routines successfully run
DEBUG - 2013-09-09 11:26:54 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Controller Class Initialized
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:26:54 --> Model Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:26:54 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:26:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:26:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:26:54 --> Model Class Initialized
DEBUG - 2013-09-09 11:26:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:26:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:26:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:26:54 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:26:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:26:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:26:54 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:26:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:26:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:26:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:26:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:26:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:26:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:26:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:26:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:26:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:26:54 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:26:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:26:54 --> Final output sent to browser
DEBUG - 2013-09-09 11:26:54 --> Total execution time: 0.9111
DEBUG - 2013-09-09 11:26:54 --> Config Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:26:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:26:54 --> URI Class Initialized
DEBUG - 2013-09-09 11:26:54 --> Router Class Initialized
ERROR - 2013-09-09 11:26:55 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:27:00 --> Config Class Initialized
DEBUG - 2013-09-09 11:27:00 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:27:00 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:27:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:27:00 --> URI Class Initialized
DEBUG - 2013-09-09 11:27:00 --> Router Class Initialized
ERROR - 2013-09-09 11:27:00 --> 404 Page Not Found --> siswakelas
DEBUG - 2013-09-09 11:31:34 --> Config Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:31:34 --> URI Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Router Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Output Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Security Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Input Class Initialized
DEBUG - 2013-09-09 11:31:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:34 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:31:34 --> Language Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Loader Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:31:34 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:31:34 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:31:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:31:34 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:31:34 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Session Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:31:34 --> Session routines successfully run
DEBUG - 2013-09-09 11:31:34 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Controller Class Initialized
ERROR - 2013-09-09 11:31:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:31:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:31:34 --> Model Class Initialized
DEBUG - 2013-09-09 11:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:31:34 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:31:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:31:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:31:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:31:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:31:34 --> Model Class Initialized
DEBUG - 2013-09-09 11:31:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:31:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:31:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:31:34 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:31:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:31:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:31:34 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:31:34 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:34 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:34 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:34 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:34 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:35 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:35 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:31:35 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:31:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:31:35 --> Final output sent to browser
DEBUG - 2013-09-09 11:31:35 --> Total execution time: 0.9381
DEBUG - 2013-09-09 11:31:35 --> Config Class Initialized
DEBUG - 2013-09-09 11:31:35 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:31:35 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:31:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:31:35 --> URI Class Initialized
DEBUG - 2013-09-09 11:31:35 --> Router Class Initialized
ERROR - 2013-09-09 11:31:35 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:31:56 --> Config Class Initialized
DEBUG - 2013-09-09 11:31:56 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:31:56 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:31:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:31:56 --> URI Class Initialized
DEBUG - 2013-09-09 11:31:56 --> Router Class Initialized
DEBUG - 2013-09-09 11:31:56 --> Output Class Initialized
DEBUG - 2013-09-09 11:31:56 --> Security Class Initialized
DEBUG - 2013-09-09 11:31:56 --> Input Class Initialized
DEBUG - 2013-09-09 11:31:56 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:56 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:56 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:56 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:56 --> XSS Filtering completed
DEBUG - 2013-09-09 11:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:31:56 --> Language Class Initialized
DEBUG - 2013-09-09 11:31:56 --> Loader Class Initialized
DEBUG - 2013-09-09 11:31:57 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:31:57 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:31:57 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:31:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:31:57 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:31:57 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:31:57 --> Session Class Initialized
DEBUG - 2013-09-09 11:31:57 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:31:57 --> Session routines successfully run
DEBUG - 2013-09-09 11:31:57 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:31:57 --> Controller Class Initialized
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:31:57 --> Model Class Initialized
DEBUG - 2013-09-09 11:31:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:31:57 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:31:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:31:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:31:57 --> Model Class Initialized
DEBUG - 2013-09-09 11:31:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:31:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:31:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:31:57 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:31:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:31:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:31:57 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:57 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:57 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:57 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:57 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:57 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:57 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:57 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:31:57 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:31:57 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:31:57 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:31:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:31:57 --> Final output sent to browser
DEBUG - 2013-09-09 11:31:57 --> Total execution time: 0.9451
DEBUG - 2013-09-09 11:31:57 --> Config Class Initialized
DEBUG - 2013-09-09 11:31:57 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:31:57 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:31:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:31:58 --> URI Class Initialized
DEBUG - 2013-09-09 11:31:58 --> Router Class Initialized
ERROR - 2013-09-09 11:31:58 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:33:48 --> Config Class Initialized
DEBUG - 2013-09-09 11:33:48 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:33:48 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:33:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:33:48 --> URI Class Initialized
DEBUG - 2013-09-09 11:33:48 --> Router Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Output Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Security Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Input Class Initialized
DEBUG - 2013-09-09 11:33:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:49 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:33:49 --> Language Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Loader Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:33:49 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:33:49 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:33:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:33:49 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:33:49 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Session Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:33:49 --> Session routines successfully run
DEBUG - 2013-09-09 11:33:49 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Controller Class Initialized
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:33:49 --> Model Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:33:49 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:33:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:33:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:33:49 --> Model Class Initialized
DEBUG - 2013-09-09 11:33:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:33:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:33:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:33:49 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:33:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:33:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:33:49 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:33:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:33:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:33:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:33:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:33:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:33:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:33:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:33:49 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:33:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:33:49 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:33:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:33:49 --> Final output sent to browser
DEBUG - 2013-09-09 11:33:49 --> Total execution time: 0.8560
DEBUG - 2013-09-09 11:33:49 --> Config Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:33:49 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:33:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:33:50 --> URI Class Initialized
DEBUG - 2013-09-09 11:33:50 --> Router Class Initialized
ERROR - 2013-09-09 11:33:50 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:33:52 --> Config Class Initialized
DEBUG - 2013-09-09 11:33:52 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:33:52 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:33:52 --> URI Class Initialized
DEBUG - 2013-09-09 11:33:52 --> Router Class Initialized
DEBUG - 2013-09-09 11:33:52 --> Output Class Initialized
DEBUG - 2013-09-09 11:33:52 --> Security Class Initialized
DEBUG - 2013-09-09 11:33:52 --> Input Class Initialized
DEBUG - 2013-09-09 11:33:52 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:52 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:52 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:52 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:52 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:52 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:52 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:52 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:33:52 --> Language Class Initialized
DEBUG - 2013-09-09 11:33:52 --> Loader Class Initialized
DEBUG - 2013-09-09 11:33:52 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:33:52 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:33:52 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:33:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:33:52 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:33:53 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:33:53 --> Session Class Initialized
DEBUG - 2013-09-09 11:33:53 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:33:53 --> Session routines successfully run
DEBUG - 2013-09-09 11:33:53 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:33:53 --> Controller Class Initialized
ERROR - 2013-09-09 11:33:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:33:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:33:53 --> Model Class Initialized
DEBUG - 2013-09-09 11:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:33:53 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:33:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:33:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:33:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:33:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:33:53 --> Model Class Initialized
DEBUG - 2013-09-09 11:33:53 --> Form Validation Class Initialized
DEBUG - 2013-09-09 11:33:53 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:53 --> XSS Filtering completed
DEBUG - 2013-09-09 11:33:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 11:33:53 --> DB Transaction Failure
ERROR - 2013-09-09 11:33:53 --> Query error: Field 'tahun_ajaran_id' doesn't have a default value
DEBUG - 2013-09-09 11:33:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 11:40:39 --> Config Class Initialized
DEBUG - 2013-09-09 11:40:39 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:40:39 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:40:39 --> URI Class Initialized
DEBUG - 2013-09-09 11:40:39 --> Router Class Initialized
DEBUG - 2013-09-09 11:40:39 --> Output Class Initialized
DEBUG - 2013-09-09 11:40:40 --> Security Class Initialized
DEBUG - 2013-09-09 11:40:40 --> Input Class Initialized
DEBUG - 2013-09-09 11:40:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:40 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:40:40 --> Language Class Initialized
DEBUG - 2013-09-09 11:40:40 --> Loader Class Initialized
DEBUG - 2013-09-09 11:40:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:40:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:40:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:40:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:40:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:40:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:40:40 --> Session Class Initialized
DEBUG - 2013-09-09 11:40:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:40:40 --> Session routines successfully run
DEBUG - 2013-09-09 11:40:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:40:40 --> Controller Class Initialized
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:40:40 --> Model Class Initialized
DEBUG - 2013-09-09 11:40:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:40:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:40:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:40:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:40:40 --> Model Class Initialized
DEBUG - 2013-09-09 11:40:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:40:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:40:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:40:40 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:40:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:40:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:40:40 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:40:40 --> File loaded: application/views/siswa_kelas/new.php
DEBUG - 2013-09-09 11:40:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:40:40 --> Final output sent to browser
DEBUG - 2013-09-09 11:40:41 --> Total execution time: 1.0921
DEBUG - 2013-09-09 11:40:41 --> Config Class Initialized
DEBUG - 2013-09-09 11:40:41 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:40:41 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:40:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:40:41 --> URI Class Initialized
DEBUG - 2013-09-09 11:40:41 --> Router Class Initialized
ERROR - 2013-09-09 11:40:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:40:46 --> Config Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:40:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:40:46 --> URI Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Router Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Output Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Security Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Input Class Initialized
DEBUG - 2013-09-09 11:40:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:46 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:40:46 --> Language Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Loader Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:40:46 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:40:46 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:40:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:40:46 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:40:46 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Session Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:40:46 --> Session routines successfully run
DEBUG - 2013-09-09 11:40:46 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Controller Class Initialized
ERROR - 2013-09-09 11:40:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:40:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:40:46 --> Model Class Initialized
DEBUG - 2013-09-09 11:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:40:46 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:40:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:40:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:40:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:40:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:40:46 --> Model Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Form Validation Class Initialized
DEBUG - 2013-09-09 11:40:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 11:40:47 --> Config Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:40:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:40:47 --> URI Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Router Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Output Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Security Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Input Class Initialized
DEBUG - 2013-09-09 11:40:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:47 --> XSS Filtering completed
DEBUG - 2013-09-09 11:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:40:47 --> Language Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Loader Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:40:47 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:40:47 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:40:47 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:40:47 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:40:47 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Session Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:40:47 --> Session routines successfully run
DEBUG - 2013-09-09 11:40:47 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Controller Class Initialized
ERROR - 2013-09-09 11:40:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:40:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:40:47 --> Model Class Initialized
DEBUG - 2013-09-09 11:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:40:47 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:40:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:40:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:40:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:40:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:40:47 --> Model Class Initialized
DEBUG - 2013-09-09 11:40:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:40:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:40:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:40:47 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:40:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:40:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:40:47 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:40:47 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:40:47 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:47 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:47 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:47 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:47 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:40:48 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:40:48 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-09-09 11:40:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:40:48 --> Final output sent to browser
DEBUG - 2013-09-09 11:40:48 --> Total execution time: 1.5551
DEBUG - 2013-09-09 11:40:48 --> Config Class Initialized
DEBUG - 2013-09-09 11:40:48 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:40:48 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:40:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:40:49 --> URI Class Initialized
DEBUG - 2013-09-09 11:40:49 --> Router Class Initialized
ERROR - 2013-09-09 11:40:49 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:41:19 --> Config Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:41:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:41:19 --> URI Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Router Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Output Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Security Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Input Class Initialized
DEBUG - 2013-09-09 11:41:19 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:19 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:19 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:19 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:19 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:41:19 --> Language Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Loader Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:41:19 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:41:19 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:41:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:41:19 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:41:19 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Session Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:41:19 --> Session routines successfully run
DEBUG - 2013-09-09 11:41:19 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Controller Class Initialized
ERROR - 2013-09-09 11:41:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:41:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:41:19 --> Model Class Initialized
DEBUG - 2013-09-09 11:41:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:41:19 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:41:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:41:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:41:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:41:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:41:20 --> Model Class Initialized
DEBUG - 2013-09-09 11:41:20 --> Pagination Class Initialized
DEBUG - 2013-09-09 11:41:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:41:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:41:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:41:20 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:41:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:41:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:41:20 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:41:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:41:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:41:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:41:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:41:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-09 11:41:20 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-09 11:41:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:41:20 --> Final output sent to browser
DEBUG - 2013-09-09 11:41:20 --> Total execution time: 0.8160
DEBUG - 2013-09-09 11:41:20 --> Config Class Initialized
DEBUG - 2013-09-09 11:41:20 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:41:20 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:41:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:41:20 --> URI Class Initialized
DEBUG - 2013-09-09 11:41:20 --> Router Class Initialized
ERROR - 2013-09-09 11:41:20 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:41:22 --> Config Class Initialized
DEBUG - 2013-09-09 11:41:22 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:41:22 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:41:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:41:22 --> URI Class Initialized
DEBUG - 2013-09-09 11:41:22 --> Router Class Initialized
DEBUG - 2013-09-09 11:41:22 --> Output Class Initialized
DEBUG - 2013-09-09 11:41:22 --> Security Class Initialized
DEBUG - 2013-09-09 11:41:22 --> Input Class Initialized
DEBUG - 2013-09-09 11:41:22 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:22 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:22 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:22 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:22 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:41:22 --> Language Class Initialized
DEBUG - 2013-09-09 11:41:22 --> Loader Class Initialized
DEBUG - 2013-09-09 11:41:23 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:41:23 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:41:23 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:41:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:41:23 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:41:23 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:41:23 --> Session Class Initialized
DEBUG - 2013-09-09 11:41:23 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:41:23 --> Session garbage collection performed.
DEBUG - 2013-09-09 11:41:23 --> Session routines successfully run
DEBUG - 2013-09-09 11:41:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:41:23 --> Controller Class Initialized
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:41:23 --> Model Class Initialized
DEBUG - 2013-09-09 11:41:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:41:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:41:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:41:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:41:23 --> Model Class Initialized
DEBUG - 2013-09-09 11:41:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:41:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:41:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:41:23 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:41:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:41:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:41:23 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 273
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 279
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 282
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 286
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 287
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 289
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 299
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 273
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 279
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:23 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 282
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 286
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 287
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 289
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 299
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 273
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 279
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 282
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 286
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 287
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 289
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 299
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 273
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 279
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 282
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 286
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 287
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 289
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 299
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 273
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 279
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 282
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 286
ERROR - 2013-09-09 11:41:24 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 287
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 289
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 299
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 273
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 279
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 282
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 286
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 287
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 289
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 299
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 273
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 279
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 282
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 286
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 287
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 289
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\edit.php 295
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\siswas\edit.php 299
ERROR - 2013-09-09 11:41:25 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:25 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:26 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:26 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:26 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:26 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:26 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:26 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:26 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:26 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:41:26 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 11:41:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:41:26 --> Final output sent to browser
DEBUG - 2013-09-09 11:41:26 --> Total execution time: 3.5622
DEBUG - 2013-09-09 11:41:26 --> Config Class Initialized
DEBUG - 2013-09-09 11:41:26 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:41:26 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:41:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:41:26 --> URI Class Initialized
DEBUG - 2013-09-09 11:41:26 --> Router Class Initialized
ERROR - 2013-09-09 11:41:26 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:41:35 --> Config Class Initialized
DEBUG - 2013-09-09 11:41:35 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:41:35 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:41:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:41:35 --> URI Class Initialized
DEBUG - 2013-09-09 11:41:35 --> Router Class Initialized
DEBUG - 2013-09-09 11:41:36 --> Output Class Initialized
DEBUG - 2013-09-09 11:41:36 --> Security Class Initialized
DEBUG - 2013-09-09 11:41:36 --> Input Class Initialized
DEBUG - 2013-09-09 11:41:36 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:36 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:36 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:36 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:36 --> XSS Filtering completed
DEBUG - 2013-09-09 11:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:41:36 --> Language Class Initialized
DEBUG - 2013-09-09 11:41:36 --> Loader Class Initialized
DEBUG - 2013-09-09 11:41:36 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:41:36 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:41:36 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:41:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:41:36 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:41:36 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:41:36 --> Session Class Initialized
DEBUG - 2013-09-09 11:41:36 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:41:36 --> Session routines successfully run
DEBUG - 2013-09-09 11:41:36 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:41:36 --> Controller Class Initialized
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:41:36 --> Model Class Initialized
DEBUG - 2013-09-09 11:41:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:41:36 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:41:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:41:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:41:36 --> Model Class Initialized
DEBUG - 2013-09-09 11:41:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:41:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:41:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:41:36 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:41:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:41:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:41:36 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:41:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'kelas_bagian_id' C:\xampp\htdocs\school\application\views\siswas\show.php 352
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'tahun_ajaran_id' C:\xampp\htdocs\school\application\views\siswas\show.php 355
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'kelas_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 85
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 11:41:37 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 11:41:37 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-09-09 11:41:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:41:37 --> Final output sent to browser
DEBUG - 2013-09-09 11:41:37 --> Total execution time: 1.8321
DEBUG - 2013-09-09 11:41:38 --> Config Class Initialized
DEBUG - 2013-09-09 11:41:38 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:41:38 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:41:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:41:38 --> URI Class Initialized
DEBUG - 2013-09-09 11:41:38 --> Router Class Initialized
ERROR - 2013-09-09 11:41:38 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:45:35 --> Config Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:45:35 --> URI Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Router Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Output Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Security Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Input Class Initialized
DEBUG - 2013-09-09 11:45:35 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:35 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:35 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:35 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:35 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:45:35 --> Language Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Loader Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:45:35 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:45:35 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:45:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:45:35 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:45:35 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Session Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:45:35 --> Session routines successfully run
DEBUG - 2013-09-09 11:45:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:45:35 --> Controller Class Initialized
ERROR - 2013-09-09 11:45:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:45:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:45:36 --> Model Class Initialized
DEBUG - 2013-09-09 11:45:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:45:36 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:45:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:45:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:45:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:45:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:45:36 --> Model Class Initialized
DEBUG - 2013-09-09 11:45:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:45:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:45:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:45:36 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:45:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:45:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:45:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 11:45:36 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-09-09 11:45:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:45:36 --> Final output sent to browser
DEBUG - 2013-09-09 11:45:36 --> Total execution time: 0.9911
DEBUG - 2013-09-09 11:45:36 --> Config Class Initialized
DEBUG - 2013-09-09 11:45:36 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:45:36 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:45:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:45:36 --> URI Class Initialized
DEBUG - 2013-09-09 11:45:36 --> Router Class Initialized
ERROR - 2013-09-09 11:45:36 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:45:43 --> Config Class Initialized
DEBUG - 2013-09-09 11:45:43 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:45:43 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:45:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:45:43 --> URI Class Initialized
DEBUG - 2013-09-09 11:45:43 --> Router Class Initialized
DEBUG - 2013-09-09 11:45:43 --> Output Class Initialized
DEBUG - 2013-09-09 11:45:43 --> Security Class Initialized
DEBUG - 2013-09-09 11:45:43 --> Input Class Initialized
DEBUG - 2013-09-09 11:45:44 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:44 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:44 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:44 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:44 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:45:44 --> Language Class Initialized
DEBUG - 2013-09-09 11:45:44 --> Loader Class Initialized
DEBUG - 2013-09-09 11:45:44 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:45:44 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:45:44 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:45:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:45:44 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:45:44 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:45:44 --> Session Class Initialized
DEBUG - 2013-09-09 11:45:44 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:45:44 --> Session routines successfully run
DEBUG - 2013-09-09 11:45:44 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:45:44 --> Controller Class Initialized
ERROR - 2013-09-09 11:45:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:45:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:45:44 --> Model Class Initialized
DEBUG - 2013-09-09 11:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:45:44 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:45:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:45:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:45:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:45:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:45:44 --> Model Class Initialized
DEBUG - 2013-09-09 11:45:44 --> Pagination Class Initialized
DEBUG - 2013-09-09 11:45:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:45:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:45:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:45:44 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:45:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:45:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:45:44 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 11:45:44 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:45:44 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:45:44 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:45:44 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 11:45:44 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-09 11:45:44 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-09 11:45:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:45:44 --> Final output sent to browser
DEBUG - 2013-09-09 11:45:44 --> Total execution time: 1.0581
DEBUG - 2013-09-09 11:45:45 --> Config Class Initialized
DEBUG - 2013-09-09 11:45:45 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:45:45 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:45:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:45:45 --> URI Class Initialized
DEBUG - 2013-09-09 11:45:45 --> Router Class Initialized
ERROR - 2013-09-09 11:45:45 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 11:45:48 --> Config Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:45:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:45:48 --> URI Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Router Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Output Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Security Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Input Class Initialized
DEBUG - 2013-09-09 11:45:48 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:48 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:48 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:48 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:48 --> XSS Filtering completed
DEBUG - 2013-09-09 11:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 11:45:48 --> Language Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Loader Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Helper loaded: url_helper
DEBUG - 2013-09-09 11:45:48 --> Helper loaded: file_helper
DEBUG - 2013-09-09 11:45:48 --> Helper loaded: form_helper
DEBUG - 2013-09-09 11:45:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 11:45:48 --> Helper loaded: application_helper
DEBUG - 2013-09-09 11:45:48 --> Database Driver Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Session Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Helper loaded: string_helper
DEBUG - 2013-09-09 11:45:48 --> Session routines successfully run
DEBUG - 2013-09-09 11:45:48 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 11:45:48 --> Controller Class Initialized
ERROR - 2013-09-09 11:45:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:45:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:45:49 --> Model Class Initialized
DEBUG - 2013-09-09 11:45:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 11:45:49 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 11:45:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 11:45:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 11:45:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 11:45:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 11:45:49 --> Model Class Initialized
DEBUG - 2013-09-09 11:45:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 11:45:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 11:45:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 11:45:49 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 11:45:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 11:45:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 11:45:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 11:45:49 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 11:45:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 11:45:49 --> Final output sent to browser
DEBUG - 2013-09-09 11:45:49 --> Total execution time: 0.9221
DEBUG - 2013-09-09 11:45:49 --> Config Class Initialized
DEBUG - 2013-09-09 11:45:49 --> Hooks Class Initialized
DEBUG - 2013-09-09 11:45:49 --> Utf8 Class Initialized
DEBUG - 2013-09-09 11:45:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 11:45:49 --> URI Class Initialized
DEBUG - 2013-09-09 11:45:49 --> Router Class Initialized
ERROR - 2013-09-09 11:45:49 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:07:32 --> Config Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:07:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:07:32 --> URI Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Router Class Initialized
DEBUG - 2013-09-09 14:07:32 --> No URI present. Default controller set.
DEBUG - 2013-09-09 14:07:32 --> Output Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Security Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Input Class Initialized
DEBUG - 2013-09-09 14:07:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:07:32 --> Language Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Loader Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:07:32 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:07:32 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:07:32 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:07:32 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:07:32 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Session Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:07:32 --> A session cookie was not found.
DEBUG - 2013-09-09 14:07:32 --> Session routines successfully run
DEBUG - 2013-09-09 14:07:32 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Controller Class Initialized
ERROR - 2013-09-09 14:07:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:32 --> Model Class Initialized
DEBUG - 2013-09-09 14:07:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:07:32 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:07:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:07:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:07:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:33 --> Config Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:07:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:07:33 --> URI Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Router Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Output Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Security Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Input Class Initialized
DEBUG - 2013-09-09 14:07:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:07:33 --> Language Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Loader Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:07:33 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:07:33 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:07:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:07:33 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:07:33 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Session Class Initialized
DEBUG - 2013-09-09 14:07:33 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:07:33 --> Session routines successfully run
DEBUG - 2013-09-09 14:07:34 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:07:34 --> Controller Class Initialized
ERROR - 2013-09-09 14:07:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:34 --> Model Class Initialized
DEBUG - 2013-09-09 14:07:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:07:34 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:07:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:07:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:07:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:07:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:07:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:07:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:07:34 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-09 14:07:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:07:34 --> Final output sent to browser
DEBUG - 2013-09-09 14:07:34 --> Total execution time: 0.9261
DEBUG - 2013-09-09 14:07:34 --> Config Class Initialized
DEBUG - 2013-09-09 14:07:34 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:07:34 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:07:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:07:34 --> URI Class Initialized
DEBUG - 2013-09-09 14:07:34 --> Router Class Initialized
ERROR - 2013-09-09 14:07:34 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:07:43 --> Config Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:07:43 --> URI Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Router Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Output Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Security Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Input Class Initialized
DEBUG - 2013-09-09 14:07:43 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:43 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:43 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:43 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:43 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:07:43 --> Language Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Loader Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:07:43 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:07:43 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:07:43 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:07:43 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:07:43 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Session Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:07:43 --> Session routines successfully run
DEBUG - 2013-09-09 14:07:43 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Controller Class Initialized
ERROR - 2013-09-09 14:07:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:43 --> Model Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:07:43 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:07:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:07:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:07:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:43 --> Model Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:07:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:07:44 --> Config Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:07:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:07:44 --> URI Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Router Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Output Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Security Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Input Class Initialized
DEBUG - 2013-09-09 14:07:44 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:44 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:07:44 --> Language Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Loader Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:07:44 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:07:44 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:07:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:07:44 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:07:44 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Session Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:07:44 --> Session routines successfully run
DEBUG - 2013-09-09 14:07:44 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Controller Class Initialized
ERROR - 2013-09-09 14:07:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:44 --> Model Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:07:44 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:07:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:07:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:07:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:44 --> Config Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:07:44 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:07:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:07:44 --> URI Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Router Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Output Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Security Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Input Class Initialized
DEBUG - 2013-09-09 14:07:45 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:45 --> XSS Filtering completed
DEBUG - 2013-09-09 14:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:07:45 --> Language Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Loader Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:07:45 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:07:45 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:07:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:07:45 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:07:45 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Session Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:07:45 --> Session routines successfully run
DEBUG - 2013-09-09 14:07:45 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Controller Class Initialized
ERROR - 2013-09-09 14:07:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:45 --> Model Class Initialized
DEBUG - 2013-09-09 14:07:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:07:45 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:07:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:07:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:07:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:07:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:07:45 --> Model Class Initialized
DEBUG - 2013-09-09 14:07:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:07:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:07:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:07:45 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:07:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:07:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:07:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:07:45 --> File loaded: application/views/home.php
DEBUG - 2013-09-09 14:07:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:07:46 --> Final output sent to browser
DEBUG - 2013-09-09 14:07:46 --> Total execution time: 1.1271
DEBUG - 2013-09-09 14:07:46 --> Config Class Initialized
DEBUG - 2013-09-09 14:07:46 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:07:46 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:07:46 --> URI Class Initialized
DEBUG - 2013-09-09 14:07:46 --> Router Class Initialized
ERROR - 2013-09-09 14:07:46 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:08:01 --> Config Class Initialized
DEBUG - 2013-09-09 14:08:01 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:08:01 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:08:01 --> URI Class Initialized
DEBUG - 2013-09-09 14:08:01 --> Router Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Output Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Security Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Input Class Initialized
DEBUG - 2013-09-09 14:08:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:08:02 --> Language Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Loader Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:08:02 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:08:02 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:08:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:08:02 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:08:02 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Session Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:08:02 --> Session routines successfully run
DEBUG - 2013-09-09 14:08:02 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Controller Class Initialized
ERROR - 2013-09-09 14:08:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:02 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:08:02 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:08:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:08:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:08:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:02 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:02 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:08:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:08:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:08:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:08:02 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:08:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:08:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:08:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:08:02 --> File loaded: application/views/users/index.php
DEBUG - 2013-09-09 14:08:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:08:02 --> Final output sent to browser
DEBUG - 2013-09-09 14:08:02 --> Total execution time: 1.0241
DEBUG - 2013-09-09 14:08:03 --> Config Class Initialized
DEBUG - 2013-09-09 14:08:03 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:08:03 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:08:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:08:03 --> URI Class Initialized
DEBUG - 2013-09-09 14:08:03 --> Router Class Initialized
ERROR - 2013-09-09 14:08:03 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:08:06 --> Config Class Initialized
DEBUG - 2013-09-09 14:08:06 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:08:06 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:08:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:08:06 --> URI Class Initialized
DEBUG - 2013-09-09 14:08:06 --> Router Class Initialized
DEBUG - 2013-09-09 14:08:06 --> Output Class Initialized
DEBUG - 2013-09-09 14:08:06 --> Security Class Initialized
DEBUG - 2013-09-09 14:08:06 --> Input Class Initialized
DEBUG - 2013-09-09 14:08:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:08:06 --> Language Class Initialized
DEBUG - 2013-09-09 14:08:06 --> Loader Class Initialized
DEBUG - 2013-09-09 14:08:07 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:08:07 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:08:07 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:08:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:08:07 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:08:07 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:08:07 --> Session Class Initialized
DEBUG - 2013-09-09 14:08:07 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:08:07 --> Session routines successfully run
DEBUG - 2013-09-09 14:08:07 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:08:07 --> Controller Class Initialized
ERROR - 2013-09-09 14:08:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:07 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:08:07 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:08:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:08:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:08:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:07 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:08:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:08:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:08:07 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:08:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:08:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:08:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:08:07 --> File loaded: application/views/users/edit.php
DEBUG - 2013-09-09 14:08:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:08:07 --> Final output sent to browser
DEBUG - 2013-09-09 14:08:07 --> Total execution time: 0.9801
DEBUG - 2013-09-09 14:08:07 --> Config Class Initialized
DEBUG - 2013-09-09 14:08:07 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:08:07 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:08:07 --> URI Class Initialized
DEBUG - 2013-09-09 14:08:07 --> Router Class Initialized
ERROR - 2013-09-09 14:08:07 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:08:15 --> Config Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:08:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:08:15 --> URI Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Router Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Output Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Security Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Input Class Initialized
DEBUG - 2013-09-09 14:08:15 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:15 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:08:15 --> Language Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Loader Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:08:15 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:08:15 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:08:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:08:15 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:08:15 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Session Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:08:15 --> Session routines successfully run
DEBUG - 2013-09-09 14:08:15 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Controller Class Initialized
ERROR - 2013-09-09 14:08:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:15 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:08:15 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:08:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:08:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:08:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:16 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:08:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:08:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:08:16 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:08:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:08:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:08:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:08:16 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:08:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:08:16 --> Final output sent to browser
DEBUG - 2013-09-09 14:08:16 --> Total execution time: 0.8780
DEBUG - 2013-09-09 14:08:16 --> Config Class Initialized
DEBUG - 2013-09-09 14:08:16 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:08:16 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:08:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:08:16 --> URI Class Initialized
DEBUG - 2013-09-09 14:08:16 --> Router Class Initialized
ERROR - 2013-09-09 14:08:16 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:08:34 --> Config Class Initialized
DEBUG - 2013-09-09 14:08:34 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:08:34 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:08:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:08:34 --> URI Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Router Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Output Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Security Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Input Class Initialized
DEBUG - 2013-09-09 14:08:35 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:35 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:35 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:35 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:35 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:35 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:08:35 --> Language Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Loader Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:08:35 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:08:35 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:08:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:08:35 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:08:35 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Session Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:08:35 --> Session routines successfully run
DEBUG - 2013-09-09 14:08:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Controller Class Initialized
ERROR - 2013-09-09 14:08:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:35 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:08:35 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:08:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:08:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:08:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:35 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:08:35 --> Config Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:08:35 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:08:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:08:35 --> URI Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Router Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Output Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Security Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Input Class Initialized
DEBUG - 2013-09-09 14:08:36 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:36 --> XSS Filtering completed
DEBUG - 2013-09-09 14:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:08:36 --> Language Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Loader Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:08:36 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:08:36 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:08:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:08:36 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:08:36 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Session Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:08:36 --> Session routines successfully run
DEBUG - 2013-09-09 14:08:36 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Controller Class Initialized
ERROR - 2013-09-09 14:08:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:36 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:08:36 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:08:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:08:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:08:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:08:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:08:36 --> Model Class Initialized
DEBUG - 2013-09-09 14:08:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:08:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:08:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:08:36 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:08:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:08:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:08:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:08:36 --> File loaded: application/views/users/edit.php
DEBUG - 2013-09-09 14:08:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:08:36 --> Final output sent to browser
DEBUG - 2013-09-09 14:08:36 --> Total execution time: 1.0361
DEBUG - 2013-09-09 14:08:37 --> Config Class Initialized
DEBUG - 2013-09-09 14:08:37 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:08:37 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:08:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:08:37 --> URI Class Initialized
DEBUG - 2013-09-09 14:08:37 --> Router Class Initialized
ERROR - 2013-09-09 14:08:37 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:10:48 --> Config Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:10:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:10:48 --> URI Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Router Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Output Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Security Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Input Class Initialized
DEBUG - 2013-09-09 14:10:48 --> XSS Filtering completed
DEBUG - 2013-09-09 14:10:48 --> XSS Filtering completed
DEBUG - 2013-09-09 14:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:10:48 --> Language Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Loader Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:10:48 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:10:48 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:10:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:10:48 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:10:48 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Session Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:10:48 --> Session routines successfully run
DEBUG - 2013-09-09 14:10:48 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Controller Class Initialized
ERROR - 2013-09-09 14:10:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:10:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:10:48 --> Model Class Initialized
DEBUG - 2013-09-09 14:10:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:10:48 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:10:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:10:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:10:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:10:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:10:48 --> Model Class Initialized
DEBUG - 2013-09-09 14:10:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:10:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:10:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:10:48 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:10:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:10:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:10:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:10:49 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:10:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:10:49 --> Final output sent to browser
DEBUG - 2013-09-09 14:10:49 --> Total execution time: 0.9221
DEBUG - 2013-09-09 14:10:49 --> Config Class Initialized
DEBUG - 2013-09-09 14:10:49 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:10:49 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:10:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:10:49 --> URI Class Initialized
DEBUG - 2013-09-09 14:10:49 --> Router Class Initialized
ERROR - 2013-09-09 14:10:49 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:12:00 --> Config Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:12:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:12:00 --> URI Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Router Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Output Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Security Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Input Class Initialized
DEBUG - 2013-09-09 14:12:00 --> XSS Filtering completed
DEBUG - 2013-09-09 14:12:00 --> XSS Filtering completed
DEBUG - 2013-09-09 14:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:12:00 --> Language Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Loader Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:12:00 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:12:00 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:12:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:12:00 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:12:00 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Session Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:12:00 --> Session routines successfully run
DEBUG - 2013-09-09 14:12:00 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Controller Class Initialized
ERROR - 2013-09-09 14:12:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:12:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:12:00 --> Model Class Initialized
DEBUG - 2013-09-09 14:12:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:12:00 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:12:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:12:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:12:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:12:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:12:01 --> Model Class Initialized
DEBUG - 2013-09-09 14:12:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:12:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:12:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:12:01 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:12:01 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:12:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:12:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:12:01 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:12:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:12:01 --> Final output sent to browser
DEBUG - 2013-09-09 14:12:01 --> Total execution time: 0.8881
DEBUG - 2013-09-09 14:12:01 --> Config Class Initialized
DEBUG - 2013-09-09 14:12:01 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:12:01 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:12:01 --> URI Class Initialized
DEBUG - 2013-09-09 14:12:01 --> Router Class Initialized
ERROR - 2013-09-09 14:12:01 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:12:02 --> Config Class Initialized
DEBUG - 2013-09-09 14:12:02 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:12:02 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:12:02 --> URI Class Initialized
DEBUG - 2013-09-09 14:12:02 --> Router Class Initialized
DEBUG - 2013-09-09 14:12:02 --> Output Class Initialized
DEBUG - 2013-09-09 14:12:02 --> Security Class Initialized
DEBUG - 2013-09-09 14:12:02 --> Input Class Initialized
DEBUG - 2013-09-09 14:12:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:12:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:12:02 --> Language Class Initialized
DEBUG - 2013-09-09 14:12:02 --> Loader Class Initialized
DEBUG - 2013-09-09 14:12:02 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:12:02 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:12:02 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:12:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:12:03 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:12:03 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:12:03 --> Session Class Initialized
DEBUG - 2013-09-09 14:12:03 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:12:03 --> Session routines successfully run
DEBUG - 2013-09-09 14:12:03 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:12:03 --> Controller Class Initialized
ERROR - 2013-09-09 14:12:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:12:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:12:03 --> Model Class Initialized
DEBUG - 2013-09-09 14:12:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:12:03 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:12:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:12:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:12:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:12:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:12:03 --> Model Class Initialized
DEBUG - 2013-09-09 14:12:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:12:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:12:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:12:03 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:12:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:12:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:12:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:12:03 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:12:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:12:03 --> Final output sent to browser
DEBUG - 2013-09-09 14:12:03 --> Total execution time: 0.9041
DEBUG - 2013-09-09 14:12:03 --> Config Class Initialized
DEBUG - 2013-09-09 14:12:03 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:12:03 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:12:03 --> URI Class Initialized
DEBUG - 2013-09-09 14:12:03 --> Router Class Initialized
ERROR - 2013-09-09 14:12:03 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:12:17 --> Config Class Initialized
DEBUG - 2013-09-09 14:12:17 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:12:17 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:12:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:12:17 --> URI Class Initialized
DEBUG - 2013-09-09 14:12:17 --> Router Class Initialized
ERROR - 2013-09-09 14:12:17 --> 404 Page Not Found --> users
DEBUG - 2013-09-09 14:13:11 --> Config Class Initialized
DEBUG - 2013-09-09 14:13:11 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:13:11 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:13:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:13:11 --> URI Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Router Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Output Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Security Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Input Class Initialized
DEBUG - 2013-09-09 14:13:12 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:12 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:13:12 --> Language Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Loader Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:13:12 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:13:12 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:13:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:13:12 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:13:12 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Session Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:13:12 --> Session routines successfully run
DEBUG - 2013-09-09 14:13:12 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Controller Class Initialized
ERROR - 2013-09-09 14:13:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:13:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:13:12 --> Model Class Initialized
DEBUG - 2013-09-09 14:13:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:13:12 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:13:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:13:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:13:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:13:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:13:12 --> Model Class Initialized
DEBUG - 2013-09-09 14:13:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:13:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:13:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:13:12 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:13:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:13:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:13:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:13:12 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:13:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:13:12 --> Final output sent to browser
DEBUG - 2013-09-09 14:13:12 --> Total execution time: 0.9731
DEBUG - 2013-09-09 14:13:13 --> Config Class Initialized
DEBUG - 2013-09-09 14:13:13 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:13:13 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:13:13 --> URI Class Initialized
DEBUG - 2013-09-09 14:13:13 --> Router Class Initialized
ERROR - 2013-09-09 14:13:13 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:13:14 --> Config Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:13:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:13:14 --> URI Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Router Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Output Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Security Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Input Class Initialized
DEBUG - 2013-09-09 14:13:14 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:14 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:13:14 --> Language Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Loader Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:13:14 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:13:14 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:13:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:13:14 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:13:14 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Session Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:13:14 --> Session routines successfully run
DEBUG - 2013-09-09 14:13:14 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Controller Class Initialized
ERROR - 2013-09-09 14:13:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:13:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:13:14 --> Model Class Initialized
DEBUG - 2013-09-09 14:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:13:14 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:13:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:13:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:13:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:13:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:13:14 --> Model Class Initialized
DEBUG - 2013-09-09 14:13:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:13:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:13:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:13:15 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:13:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:13:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:13:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:13:15 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:13:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:13:15 --> Final output sent to browser
DEBUG - 2013-09-09 14:13:15 --> Total execution time: 0.9211
DEBUG - 2013-09-09 14:13:15 --> Config Class Initialized
DEBUG - 2013-09-09 14:13:15 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:13:15 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:13:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:13:15 --> URI Class Initialized
DEBUG - 2013-09-09 14:13:15 --> Router Class Initialized
ERROR - 2013-09-09 14:13:15 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:13:23 --> Config Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:13:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:13:23 --> URI Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Router Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Output Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Security Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Input Class Initialized
DEBUG - 2013-09-09 14:13:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:13:23 --> Language Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Loader Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:13:23 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:13:23 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:13:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:13:23 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:13:23 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Session Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:13:23 --> Session routines successfully run
DEBUG - 2013-09-09 14:13:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:13:23 --> Controller Class Initialized
ERROR - 2013-09-09 14:13:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:13:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:13:24 --> Model Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:13:24 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:13:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:13:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:13:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:13:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:13:24 --> Model Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:13:24 --> Config Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:13:24 --> URI Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Router Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Output Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Security Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Input Class Initialized
DEBUG - 2013-09-09 14:13:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:13:24 --> Language Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Loader Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:13:24 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:13:24 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:13:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:13:24 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:13:24 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Session Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:13:24 --> Session routines successfully run
DEBUG - 2013-09-09 14:13:24 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Controller Class Initialized
ERROR - 2013-09-09 14:13:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:13:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:13:24 --> Model Class Initialized
DEBUG - 2013-09-09 14:13:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:13:25 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:13:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:13:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:13:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:13:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:13:25 --> Model Class Initialized
DEBUG - 2013-09-09 14:13:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:13:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:13:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:13:25 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:13:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:13:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:13:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:13:25 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:13:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:13:25 --> Final output sent to browser
DEBUG - 2013-09-09 14:13:25 --> Total execution time: 1.0301
DEBUG - 2013-09-09 14:13:25 --> Config Class Initialized
DEBUG - 2013-09-09 14:13:25 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:13:25 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:13:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:13:25 --> URI Class Initialized
DEBUG - 2013-09-09 14:13:25 --> Router Class Initialized
ERROR - 2013-09-09 14:13:25 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:18:52 --> Config Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:18:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:18:52 --> URI Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Router Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Output Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Security Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Input Class Initialized
DEBUG - 2013-09-09 14:18:52 --> XSS Filtering completed
DEBUG - 2013-09-09 14:18:52 --> XSS Filtering completed
DEBUG - 2013-09-09 14:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:18:52 --> Language Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Loader Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:18:52 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:18:52 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:18:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:18:52 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:18:52 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Session Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:18:52 --> Session routines successfully run
DEBUG - 2013-09-09 14:18:52 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Controller Class Initialized
ERROR - 2013-09-09 14:18:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:18:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:18:52 --> Model Class Initialized
DEBUG - 2013-09-09 14:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:18:52 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:18:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:18:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:18:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:18:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:18:52 --> Model Class Initialized
DEBUG - 2013-09-09 14:18:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:18:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:18:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:18:53 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:18:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:18:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:18:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:18:53 --> File loaded: application/views/users/show.php
DEBUG - 2013-09-09 14:18:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:18:53 --> Final output sent to browser
DEBUG - 2013-09-09 14:18:53 --> Total execution time: 0.9981
DEBUG - 2013-09-09 14:18:53 --> Config Class Initialized
DEBUG - 2013-09-09 14:18:53 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:18:53 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:18:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:18:53 --> URI Class Initialized
DEBUG - 2013-09-09 14:18:53 --> Router Class Initialized
ERROR - 2013-09-09 14:18:53 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:18:54 --> Config Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:18:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:18:54 --> URI Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Router Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Output Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Security Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Input Class Initialized
DEBUG - 2013-09-09 14:18:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:18:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:18:54 --> Language Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Loader Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:18:54 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:18:54 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:18:54 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:18:54 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:18:54 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Session Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:18:54 --> Session routines successfully run
DEBUG - 2013-09-09 14:18:54 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Controller Class Initialized
ERROR - 2013-09-09 14:18:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:18:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:18:54 --> Model Class Initialized
DEBUG - 2013-09-09 14:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:18:54 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:18:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:18:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:18:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:18:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:18:55 --> Model Class Initialized
DEBUG - 2013-09-09 14:18:55 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:18:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:18:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:18:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:18:55 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:18:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:18:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:18:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:18:55 --> File loaded: application/views/users/index.php
DEBUG - 2013-09-09 14:18:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:18:55 --> Final output sent to browser
DEBUG - 2013-09-09 14:18:55 --> Total execution time: 1.0421
DEBUG - 2013-09-09 14:18:55 --> Config Class Initialized
DEBUG - 2013-09-09 14:18:55 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:18:55 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:18:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:18:55 --> URI Class Initialized
DEBUG - 2013-09-09 14:18:55 --> Router Class Initialized
ERROR - 2013-09-09 14:18:55 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:18:57 --> Config Class Initialized
DEBUG - 2013-09-09 14:18:57 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:18:57 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:18:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:18:58 --> URI Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Router Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Output Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Security Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Input Class Initialized
DEBUG - 2013-09-09 14:18:58 --> XSS Filtering completed
DEBUG - 2013-09-09 14:18:58 --> XSS Filtering completed
DEBUG - 2013-09-09 14:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:18:58 --> Language Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Loader Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:18:58 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:18:58 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:18:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:18:58 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:18:58 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Session Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:18:58 --> Session routines successfully run
DEBUG - 2013-09-09 14:18:58 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Controller Class Initialized
ERROR - 2013-09-09 14:18:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:18:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:18:58 --> Model Class Initialized
DEBUG - 2013-09-09 14:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:18:58 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:18:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:18:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:18:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:18:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:18:58 --> Model Class Initialized
DEBUG - 2013-09-09 14:18:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:18:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:18:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:18:58 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:18:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:18:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:18:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:18:58 --> File loaded: application/views/users/edit.php
DEBUG - 2013-09-09 14:18:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:18:58 --> Final output sent to browser
DEBUG - 2013-09-09 14:18:58 --> Total execution time: 0.9661
DEBUG - 2013-09-09 14:18:59 --> Config Class Initialized
DEBUG - 2013-09-09 14:18:59 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:18:59 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:18:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:18:59 --> URI Class Initialized
DEBUG - 2013-09-09 14:18:59 --> Router Class Initialized
ERROR - 2013-09-09 14:18:59 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:19:03 --> Config Class Initialized
DEBUG - 2013-09-09 14:19:03 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:19:03 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:19:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:19:03 --> URI Class Initialized
DEBUG - 2013-09-09 14:19:03 --> Router Class Initialized
DEBUG - 2013-09-09 14:19:03 --> Output Class Initialized
DEBUG - 2013-09-09 14:19:04 --> Security Class Initialized
DEBUG - 2013-09-09 14:19:04 --> Input Class Initialized
DEBUG - 2013-09-09 14:19:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:19:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:19:04 --> Language Class Initialized
DEBUG - 2013-09-09 14:19:04 --> Loader Class Initialized
DEBUG - 2013-09-09 14:19:04 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:19:04 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:19:04 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:19:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:19:04 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:19:04 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:19:04 --> Session Class Initialized
DEBUG - 2013-09-09 14:19:04 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:19:04 --> Session garbage collection performed.
DEBUG - 2013-09-09 14:19:04 --> Session routines successfully run
DEBUG - 2013-09-09 14:19:04 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:19:04 --> Controller Class Initialized
ERROR - 2013-09-09 14:19:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:19:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:19:04 --> Model Class Initialized
DEBUG - 2013-09-09 14:19:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:19:04 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:19:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:19:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:19:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:19:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:19:04 --> Model Class Initialized
DEBUG - 2013-09-09 14:19:04 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:19:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:19:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:19:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:19:04 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:19:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:19:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:19:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:19:04 --> File loaded: application/views/users/index.php
DEBUG - 2013-09-09 14:19:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:19:04 --> Final output sent to browser
DEBUG - 2013-09-09 14:19:04 --> Total execution time: 1.0451
DEBUG - 2013-09-09 14:19:04 --> Config Class Initialized
DEBUG - 2013-09-09 14:19:05 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:19:05 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:19:05 --> URI Class Initialized
DEBUG - 2013-09-09 14:19:05 --> Router Class Initialized
ERROR - 2013-09-09 14:19:05 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:19:07 --> Config Class Initialized
DEBUG - 2013-09-09 14:19:07 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:19:07 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:19:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:19:08 --> URI Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Router Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Output Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Security Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Input Class Initialized
DEBUG - 2013-09-09 14:19:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:19:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:19:08 --> Language Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Loader Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:19:08 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:19:08 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:19:08 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:19:08 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:19:08 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Session Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:19:08 --> Session routines successfully run
DEBUG - 2013-09-09 14:19:08 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Controller Class Initialized
ERROR - 2013-09-09 14:19:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:19:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:19:08 --> Model Class Initialized
DEBUG - 2013-09-09 14:19:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:19:08 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:19:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:19:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:19:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:19:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:19:08 --> Model Class Initialized
DEBUG - 2013-09-09 14:19:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:19:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:19:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:19:08 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:19:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:19:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:19:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:19:08 --> File loaded: application/views/users/show.php
DEBUG - 2013-09-09 14:19:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:19:08 --> Final output sent to browser
DEBUG - 2013-09-09 14:19:08 --> Total execution time: 1.0181
DEBUG - 2013-09-09 14:19:09 --> Config Class Initialized
DEBUG - 2013-09-09 14:19:09 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:19:09 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:19:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:19:09 --> URI Class Initialized
DEBUG - 2013-09-09 14:19:09 --> Router Class Initialized
ERROR - 2013-09-09 14:19:09 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:19:12 --> Config Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:19:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:19:12 --> URI Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Router Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Output Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Security Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Input Class Initialized
DEBUG - 2013-09-09 14:19:12 --> XSS Filtering completed
DEBUG - 2013-09-09 14:19:12 --> XSS Filtering completed
DEBUG - 2013-09-09 14:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:19:12 --> Language Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Loader Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:19:12 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:19:12 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:19:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:19:12 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:19:12 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Session Class Initialized
DEBUG - 2013-09-09 14:19:12 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:19:13 --> Session routines successfully run
DEBUG - 2013-09-09 14:19:13 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:19:13 --> Controller Class Initialized
ERROR - 2013-09-09 14:19:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:19:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:19:13 --> Model Class Initialized
DEBUG - 2013-09-09 14:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:19:13 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:19:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:19:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:19:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:19:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:19:13 --> Model Class Initialized
DEBUG - 2013-09-09 14:19:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:19:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:19:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:19:13 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:19:13 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:19:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:19:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:19:13 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:19:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:19:13 --> Final output sent to browser
DEBUG - 2013-09-09 14:19:13 --> Total execution time: 1.0591
DEBUG - 2013-09-09 14:19:13 --> Config Class Initialized
DEBUG - 2013-09-09 14:19:13 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:19:13 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:19:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:19:13 --> URI Class Initialized
DEBUG - 2013-09-09 14:19:13 --> Router Class Initialized
ERROR - 2013-09-09 14:19:13 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:20:08 --> Config Class Initialized
DEBUG - 2013-09-09 14:20:08 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:20:08 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:20:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:20:08 --> URI Class Initialized
DEBUG - 2013-09-09 14:20:08 --> Router Class Initialized
DEBUG - 2013-09-09 14:20:08 --> Output Class Initialized
DEBUG - 2013-09-09 14:20:08 --> Security Class Initialized
DEBUG - 2013-09-09 14:20:08 --> Input Class Initialized
DEBUG - 2013-09-09 14:20:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:09 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:20:09 --> Language Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Loader Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:20:09 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:20:09 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:20:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:20:09 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:20:09 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Session Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:20:09 --> Session routines successfully run
DEBUG - 2013-09-09 14:20:09 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Controller Class Initialized
ERROR - 2013-09-09 14:20:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:20:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:20:09 --> Model Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:20:09 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:20:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:20:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:20:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:20:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:20:09 --> Model Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:20:09 --> Config Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:20:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:20:09 --> URI Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Router Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Output Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Security Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Input Class Initialized
DEBUG - 2013-09-09 14:20:09 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:09 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:20:09 --> Language Class Initialized
DEBUG - 2013-09-09 14:20:09 --> Loader Class Initialized
DEBUG - 2013-09-09 14:20:10 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:20:10 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:20:10 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:20:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:20:10 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:20:10 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:20:10 --> Session Class Initialized
DEBUG - 2013-09-09 14:20:10 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:20:10 --> Session routines successfully run
DEBUG - 2013-09-09 14:20:10 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:20:10 --> Controller Class Initialized
ERROR - 2013-09-09 14:20:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:20:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:20:10 --> Model Class Initialized
DEBUG - 2013-09-09 14:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:20:10 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:20:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:20:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:20:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:20:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:20:10 --> Model Class Initialized
DEBUG - 2013-09-09 14:20:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:20:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:20:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:20:10 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:20:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:20:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:20:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:20:10 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:20:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:20:10 --> Final output sent to browser
DEBUG - 2013-09-09 14:20:10 --> Total execution time: 1.1911
DEBUG - 2013-09-09 14:20:10 --> Config Class Initialized
DEBUG - 2013-09-09 14:20:11 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:20:11 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:20:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:20:11 --> URI Class Initialized
DEBUG - 2013-09-09 14:20:11 --> Router Class Initialized
ERROR - 2013-09-09 14:20:11 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:20:14 --> Config Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:20:14 --> URI Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Router Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Output Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Security Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Input Class Initialized
DEBUG - 2013-09-09 14:20:14 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:14 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:14 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:14 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:14 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:14 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:20:14 --> Language Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Loader Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:20:14 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:20:14 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:20:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:20:14 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:20:14 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Session Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:20:14 --> Session routines successfully run
DEBUG - 2013-09-09 14:20:14 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Controller Class Initialized
ERROR - 2013-09-09 14:20:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:20:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:20:14 --> Model Class Initialized
DEBUG - 2013-09-09 14:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:20:14 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:20:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:20:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:20:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:20:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:20:15 --> Model Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:20:15 --> Config Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:20:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:20:15 --> URI Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Router Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Output Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Security Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Input Class Initialized
DEBUG - 2013-09-09 14:20:15 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:15 --> XSS Filtering completed
DEBUG - 2013-09-09 14:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:20:15 --> Language Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Loader Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:20:15 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:20:15 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:20:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:20:15 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:20:15 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Session Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:20:15 --> Session routines successfully run
DEBUG - 2013-09-09 14:20:15 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Controller Class Initialized
ERROR - 2013-09-09 14:20:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:20:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:20:15 --> Model Class Initialized
DEBUG - 2013-09-09 14:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:20:16 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:20:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:20:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:20:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:20:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:20:16 --> Model Class Initialized
DEBUG - 2013-09-09 14:20:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:20:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:20:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:20:16 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:20:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:20:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:20:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:20:16 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:20:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:20:16 --> Final output sent to browser
DEBUG - 2013-09-09 14:20:16 --> Total execution time: 1.2041
DEBUG - 2013-09-09 14:20:16 --> Config Class Initialized
DEBUG - 2013-09-09 14:20:16 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:20:16 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:20:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:20:16 --> URI Class Initialized
DEBUG - 2013-09-09 14:20:16 --> Router Class Initialized
ERROR - 2013-09-09 14:20:16 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:21:33 --> Config Class Initialized
DEBUG - 2013-09-09 14:21:33 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:21:33 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:21:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:21:33 --> URI Class Initialized
DEBUG - 2013-09-09 14:21:33 --> Router Class Initialized
DEBUG - 2013-09-09 14:21:33 --> Output Class Initialized
DEBUG - 2013-09-09 14:21:33 --> Security Class Initialized
DEBUG - 2013-09-09 14:21:33 --> Input Class Initialized
DEBUG - 2013-09-09 14:21:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:21:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:21:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:21:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:21:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:21:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:21:33 --> Language Class Initialized
DEBUG - 2013-09-09 14:21:33 --> Loader Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:21:34 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Session Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:21:34 --> Session routines successfully run
DEBUG - 2013-09-09 14:21:34 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Controller Class Initialized
ERROR - 2013-09-09 14:21:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:21:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:21:34 --> Model Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:21:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:21:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:21:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:21:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:21:34 --> Model Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:21:34 --> Config Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:21:34 --> URI Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Router Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Output Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Security Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Input Class Initialized
DEBUG - 2013-09-09 14:21:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:21:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:21:34 --> Language Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Loader Class Initialized
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:21:34 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:21:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:21:35 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:21:35 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:21:35 --> Session Class Initialized
DEBUG - 2013-09-09 14:21:35 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:21:35 --> Session routines successfully run
DEBUG - 2013-09-09 14:21:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:21:35 --> Controller Class Initialized
ERROR - 2013-09-09 14:21:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:21:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:21:35 --> Model Class Initialized
DEBUG - 2013-09-09 14:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:21:35 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:21:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:21:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:21:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:21:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:21:35 --> Model Class Initialized
DEBUG - 2013-09-09 14:21:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:21:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:21:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:21:35 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:21:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:21:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:21:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:21:35 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:21:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:21:35 --> Final output sent to browser
DEBUG - 2013-09-09 14:21:35 --> Total execution time: 1.2481
DEBUG - 2013-09-09 14:21:35 --> Config Class Initialized
DEBUG - 2013-09-09 14:21:36 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:21:36 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:21:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:21:36 --> URI Class Initialized
DEBUG - 2013-09-09 14:21:36 --> Router Class Initialized
ERROR - 2013-09-09 14:21:36 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:22:32 --> Config Class Initialized
DEBUG - 2013-09-09 14:22:32 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:22:32 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:22:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:22:32 --> URI Class Initialized
DEBUG - 2013-09-09 14:22:32 --> Router Class Initialized
DEBUG - 2013-09-09 14:22:32 --> Output Class Initialized
DEBUG - 2013-09-09 14:22:32 --> Security Class Initialized
DEBUG - 2013-09-09 14:22:32 --> Input Class Initialized
DEBUG - 2013-09-09 14:22:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:22:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:22:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:22:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:22:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:22:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:22:33 --> Language Class Initialized
DEBUG - 2013-09-09 14:22:33 --> Loader Class Initialized
DEBUG - 2013-09-09 14:22:33 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:22:33 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:22:33 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:22:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:22:33 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:22:33 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:22:33 --> Session Class Initialized
DEBUG - 2013-09-09 14:22:33 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:22:33 --> Session routines successfully run
DEBUG - 2013-09-09 14:22:33 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:22:33 --> Controller Class Initialized
ERROR - 2013-09-09 14:22:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:22:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:22:33 --> Model Class Initialized
DEBUG - 2013-09-09 14:22:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:22:33 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:22:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:22:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:22:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:22:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:22:33 --> Model Class Initialized
DEBUG - 2013-09-09 14:22:33 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:22:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:28:11 --> Config Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:28:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:28:11 --> URI Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Router Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Output Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Security Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Input Class Initialized
DEBUG - 2013-09-09 14:28:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:28:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:28:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:28:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:28:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:28:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:28:11 --> Language Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Loader Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:28:11 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:28:11 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:28:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:28:11 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:28:11 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Session Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:28:11 --> Session routines successfully run
DEBUG - 2013-09-09 14:28:11 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:28:11 --> Controller Class Initialized
ERROR - 2013-09-09 14:28:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:28:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:28:12 --> Model Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:28:12 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:28:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:28:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:28:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:28:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:28:12 --> Model Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:28:12 --> Config Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:28:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:28:12 --> URI Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Router Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Output Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Security Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Input Class Initialized
DEBUG - 2013-09-09 14:28:12 --> XSS Filtering completed
DEBUG - 2013-09-09 14:28:12 --> XSS Filtering completed
DEBUG - 2013-09-09 14:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:28:12 --> Language Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Loader Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:28:12 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:28:12 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:28:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:28:12 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:28:12 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Session Class Initialized
DEBUG - 2013-09-09 14:28:12 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:28:13 --> Session routines successfully run
DEBUG - 2013-09-09 14:28:13 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:28:13 --> Controller Class Initialized
ERROR - 2013-09-09 14:28:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:28:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:28:13 --> Model Class Initialized
DEBUG - 2013-09-09 14:28:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:28:13 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:28:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:28:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:28:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:28:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:28:13 --> Model Class Initialized
DEBUG - 2013-09-09 14:28:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:28:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:28:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:28:13 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:28:13 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:28:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:28:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:28:13 --> File loaded: application/views/users/edit_password.php
DEBUG - 2013-09-09 14:28:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:28:13 --> Final output sent to browser
DEBUG - 2013-09-09 14:28:13 --> Total execution time: 1.2981
DEBUG - 2013-09-09 14:28:13 --> Config Class Initialized
DEBUG - 2013-09-09 14:28:13 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:28:13 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:28:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:28:13 --> URI Class Initialized
DEBUG - 2013-09-09 14:28:13 --> Router Class Initialized
ERROR - 2013-09-09 14:28:13 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:34:43 --> Config Class Initialized
DEBUG - 2013-09-09 14:34:43 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:34:43 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:34:43 --> URI Class Initialized
DEBUG - 2013-09-09 14:34:43 --> Router Class Initialized
DEBUG - 2013-09-09 14:34:43 --> Output Class Initialized
DEBUG - 2013-09-09 14:34:43 --> Security Class Initialized
DEBUG - 2013-09-09 14:34:43 --> Input Class Initialized
DEBUG - 2013-09-09 14:34:43 --> XSS Filtering completed
DEBUG - 2013-09-09 14:34:43 --> XSS Filtering completed
DEBUG - 2013-09-09 14:34:43 --> XSS Filtering completed
DEBUG - 2013-09-09 14:34:44 --> XSS Filtering completed
DEBUG - 2013-09-09 14:34:44 --> XSS Filtering completed
DEBUG - 2013-09-09 14:34:44 --> XSS Filtering completed
DEBUG - 2013-09-09 14:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:34:44 --> Language Class Initialized
DEBUG - 2013-09-09 14:34:44 --> Loader Class Initialized
DEBUG - 2013-09-09 14:34:44 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:34:44 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:34:44 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:34:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:34:44 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:34:44 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:34:44 --> Session Class Initialized
DEBUG - 2013-09-09 14:34:44 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:34:44 --> Session routines successfully run
DEBUG - 2013-09-09 14:34:44 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:34:44 --> Controller Class Initialized
ERROR - 2013-09-09 14:34:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:34:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:34:44 --> Model Class Initialized
DEBUG - 2013-09-09 14:34:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:34:44 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:34:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:34:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:34:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:34:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:34:44 --> Model Class Initialized
DEBUG - 2013-09-09 14:34:44 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:34:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:36:32 --> Config Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:36:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:36:32 --> URI Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Router Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Output Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Security Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Input Class Initialized
DEBUG - 2013-09-09 14:36:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:36:32 --> Language Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Loader Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:36:32 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:36:32 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:36:32 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:36:32 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:36:32 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Session Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:36:32 --> Session routines successfully run
DEBUG - 2013-09-09 14:36:32 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Controller Class Initialized
ERROR - 2013-09-09 14:36:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:32 --> Model Class Initialized
DEBUG - 2013-09-09 14:36:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:36:32 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:36:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:36:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:36:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:32 --> Model Class Initialized
DEBUG - 2013-09-09 14:36:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:36:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:36:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:36:33 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:36:33 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:36:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:36:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:36:33 --> File loaded: application/views/users/show.php
DEBUG - 2013-09-09 14:36:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:36:33 --> Final output sent to browser
DEBUG - 2013-09-09 14:36:33 --> Total execution time: 1.1961
DEBUG - 2013-09-09 14:36:33 --> Config Class Initialized
DEBUG - 2013-09-09 14:36:33 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:36:33 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:36:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:36:33 --> URI Class Initialized
DEBUG - 2013-09-09 14:36:33 --> Router Class Initialized
ERROR - 2013-09-09 14:36:33 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:36:37 --> Config Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:36:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:36:37 --> URI Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Router Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Output Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Security Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Input Class Initialized
DEBUG - 2013-09-09 14:36:37 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:37 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:36:37 --> Language Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Loader Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:36:37 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:36:37 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:36:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:36:37 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:36:37 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Session Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:36:37 --> Session routines successfully run
DEBUG - 2013-09-09 14:36:37 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Controller Class Initialized
ERROR - 2013-09-09 14:36:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:37 --> Model Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:36:37 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:36:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:36:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:36:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:37 --> Config Class Initialized
DEBUG - 2013-09-09 14:36:37 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:36:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:36:38 --> URI Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Router Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Output Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Security Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Input Class Initialized
DEBUG - 2013-09-09 14:36:38 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:38 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:36:38 --> Language Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Loader Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:36:38 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:36:38 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:36:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:36:38 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:36:38 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Session Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:36:38 --> Session routines successfully run
DEBUG - 2013-09-09 14:36:38 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Controller Class Initialized
ERROR - 2013-09-09 14:36:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:38 --> Model Class Initialized
DEBUG - 2013-09-09 14:36:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:36:38 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:36:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:36:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:36:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:36:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:36:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:36:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:36:39 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-09 14:36:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:36:39 --> Final output sent to browser
DEBUG - 2013-09-09 14:36:39 --> Total execution time: 1.1101
DEBUG - 2013-09-09 14:36:39 --> Config Class Initialized
DEBUG - 2013-09-09 14:36:39 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:36:39 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:36:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:36:39 --> URI Class Initialized
DEBUG - 2013-09-09 14:36:39 --> Router Class Initialized
ERROR - 2013-09-09 14:36:39 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:36:46 --> Config Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:36:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:36:46 --> URI Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Router Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Output Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Security Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Input Class Initialized
DEBUG - 2013-09-09 14:36:46 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:46 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:46 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:46 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:46 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:36:46 --> Language Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Loader Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:36:46 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:36:46 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:36:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:36:46 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:36:46 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Session Class Initialized
DEBUG - 2013-09-09 14:36:46 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:36:47 --> Session routines successfully run
DEBUG - 2013-09-09 14:36:47 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Controller Class Initialized
ERROR - 2013-09-09 14:36:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:47 --> Model Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:36:47 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:36:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:36:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:36:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:47 --> Model Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:36:47 --> Config Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:36:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:36:47 --> URI Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Router Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Output Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Security Class Initialized
DEBUG - 2013-09-09 14:36:47 --> Input Class Initialized
DEBUG - 2013-09-09 14:36:47 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:47 --> XSS Filtering completed
DEBUG - 2013-09-09 14:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:36:47 --> Language Class Initialized
DEBUG - 2013-09-09 14:36:48 --> Loader Class Initialized
DEBUG - 2013-09-09 14:36:48 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:36:48 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:36:48 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:36:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:36:48 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:36:48 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:36:48 --> Session Class Initialized
DEBUG - 2013-09-09 14:36:48 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:36:48 --> Session routines successfully run
DEBUG - 2013-09-09 14:36:48 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:36:48 --> Controller Class Initialized
ERROR - 2013-09-09 14:36:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:48 --> Model Class Initialized
DEBUG - 2013-09-09 14:36:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:36:48 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:36:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:36:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:36:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:36:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:36:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:36:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:36:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:36:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:36:48 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-09 14:36:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:36:48 --> Final output sent to browser
DEBUG - 2013-09-09 14:36:48 --> Total execution time: 1.3521
DEBUG - 2013-09-09 14:36:49 --> Config Class Initialized
DEBUG - 2013-09-09 14:36:49 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:36:49 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:36:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:36:49 --> URI Class Initialized
DEBUG - 2013-09-09 14:36:49 --> Router Class Initialized
ERROR - 2013-09-09 14:36:49 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:37:00 --> Config Class Initialized
DEBUG - 2013-09-09 14:37:00 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:37:00 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:37:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:37:00 --> URI Class Initialized
DEBUG - 2013-09-09 14:37:00 --> Router Class Initialized
DEBUG - 2013-09-09 14:37:00 --> Output Class Initialized
DEBUG - 2013-09-09 14:37:00 --> Security Class Initialized
DEBUG - 2013-09-09 14:37:00 --> Input Class Initialized
DEBUG - 2013-09-09 14:37:00 --> XSS Filtering completed
DEBUG - 2013-09-09 14:37:00 --> XSS Filtering completed
DEBUG - 2013-09-09 14:37:00 --> XSS Filtering completed
DEBUG - 2013-09-09 14:37:00 --> XSS Filtering completed
DEBUG - 2013-09-09 14:37:00 --> XSS Filtering completed
DEBUG - 2013-09-09 14:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:37:00 --> Language Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Loader Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:37:01 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:37:01 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:37:01 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:37:01 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:37:01 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Session Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:37:01 --> Session routines successfully run
DEBUG - 2013-09-09 14:37:01 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Controller Class Initialized
ERROR - 2013-09-09 14:37:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:37:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:37:01 --> Model Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:37:01 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:37:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:37:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:37:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:37:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:37:01 --> Model Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:37:01 --> Config Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:37:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:37:01 --> URI Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Router Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Output Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Security Class Initialized
DEBUG - 2013-09-09 14:37:01 --> Input Class Initialized
DEBUG - 2013-09-09 14:37:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:37:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:37:02 --> Language Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Loader Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:37:02 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:37:02 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:37:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:37:02 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:37:02 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Session Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:37:02 --> Session routines successfully run
DEBUG - 2013-09-09 14:37:02 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Controller Class Initialized
ERROR - 2013-09-09 14:37:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:37:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:37:02 --> Model Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:37:02 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:37:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:37:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:37:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:37:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:37:02 --> Config Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:37:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:37:02 --> URI Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Router Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Output Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Security Class Initialized
DEBUG - 2013-09-09 14:37:02 --> Input Class Initialized
DEBUG - 2013-09-09 14:37:03 --> XSS Filtering completed
DEBUG - 2013-09-09 14:37:03 --> XSS Filtering completed
DEBUG - 2013-09-09 14:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:37:03 --> Language Class Initialized
DEBUG - 2013-09-09 14:37:03 --> Loader Class Initialized
DEBUG - 2013-09-09 14:37:03 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:37:03 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:37:03 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:37:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:37:03 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:37:03 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:37:03 --> Session Class Initialized
DEBUG - 2013-09-09 14:37:03 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:37:03 --> Session routines successfully run
DEBUG - 2013-09-09 14:37:03 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:37:03 --> Controller Class Initialized
ERROR - 2013-09-09 14:37:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:37:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:37:03 --> Model Class Initialized
DEBUG - 2013-09-09 14:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:37:03 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:37:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:37:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:37:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:37:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:37:03 --> Model Class Initialized
DEBUG - 2013-09-09 14:37:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:37:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:37:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:37:03 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:37:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:37:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:37:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:37:04 --> File loaded: application/views/home.php
DEBUG - 2013-09-09 14:37:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:37:04 --> Final output sent to browser
DEBUG - 2013-09-09 14:37:04 --> Total execution time: 1.3001
DEBUG - 2013-09-09 14:37:04 --> Config Class Initialized
DEBUG - 2013-09-09 14:37:04 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:37:04 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:37:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:37:04 --> URI Class Initialized
DEBUG - 2013-09-09 14:37:04 --> Router Class Initialized
ERROR - 2013-09-09 14:37:04 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:41:06 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:41:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:41:06 --> URI Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Router Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Output Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Security Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Input Class Initialized
DEBUG - 2013-09-09 14:41:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:41:06 --> Language Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Loader Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:41:06 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:41:06 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:41:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:41:06 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:41:06 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Session Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:41:06 --> Session routines successfully run
DEBUG - 2013-09-09 14:41:06 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:41:06 --> Controller Class Initialized
ERROR - 2013-09-09 14:41:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:07 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:41:07 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:41:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:41:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:41:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:07 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:07 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:41:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:41:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:41:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:41:07 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:41:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:41:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:41:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:41:07 --> File loaded: application/views/users/index.php
DEBUG - 2013-09-09 14:41:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:41:07 --> Final output sent to browser
DEBUG - 2013-09-09 14:41:07 --> Total execution time: 1.2641
DEBUG - 2013-09-09 14:41:07 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:07 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:07 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:41:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:41:07 --> URI Class Initialized
DEBUG - 2013-09-09 14:41:07 --> Router Class Initialized
ERROR - 2013-09-09 14:41:07 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:41:38 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:41:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:41:39 --> URI Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Router Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Output Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Security Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Input Class Initialized
DEBUG - 2013-09-09 14:41:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:41:39 --> Language Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Loader Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:41:39 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:41:39 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:41:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:41:39 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:41:39 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Session Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:41:39 --> Session routines successfully run
DEBUG - 2013-09-09 14:41:39 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Controller Class Initialized
ERROR - 2013-09-09 14:41:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:39 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:41:39 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:41:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:41:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:41:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:39 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:41:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:41:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:41:39 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:41:39 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:41:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:41:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:41:40 --> File loaded: application/views/users/edit.php
DEBUG - 2013-09-09 14:41:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:41:40 --> Final output sent to browser
DEBUG - 2013-09-09 14:41:40 --> Total execution time: 1.1421
DEBUG - 2013-09-09 14:41:40 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:40 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:40 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:41:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:41:40 --> URI Class Initialized
DEBUG - 2013-09-09 14:41:40 --> Router Class Initialized
ERROR - 2013-09-09 14:41:40 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:41:48 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:48 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:48 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:41:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:41:48 --> URI Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Router Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Output Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Security Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Input Class Initialized
DEBUG - 2013-09-09 14:41:49 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:49 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:41:49 --> Language Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Loader Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:41:49 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:41:49 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:41:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:41:49 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:41:49 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Session Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:41:49 --> Session routines successfully run
DEBUG - 2013-09-09 14:41:49 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Controller Class Initialized
ERROR - 2013-09-09 14:41:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:49 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:41:49 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:41:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:41:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:41:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:49 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:49 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:41:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:41:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:41:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:41:49 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:41:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:41:50 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:41:50 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:41:50 --> File loaded: application/views/users/index.php
DEBUG - 2013-09-09 14:41:50 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:41:50 --> Final output sent to browser
DEBUG - 2013-09-09 14:41:50 --> Total execution time: 1.2251
DEBUG - 2013-09-09 14:41:50 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:50 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:50 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:41:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:41:50 --> URI Class Initialized
DEBUG - 2013-09-09 14:41:50 --> Router Class Initialized
ERROR - 2013-09-09 14:41:50 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:41:55 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:41:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:41:55 --> URI Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Router Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Output Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Security Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Input Class Initialized
DEBUG - 2013-09-09 14:41:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:41:55 --> Language Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Loader Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:41:55 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:41:55 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:41:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:41:55 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:41:55 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Session Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:41:55 --> Session routines successfully run
DEBUG - 2013-09-09 14:41:55 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Controller Class Initialized
ERROR - 2013-09-09 14:41:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:55 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:41:56 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:41:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:41:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:41:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:56 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:41:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:41:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:41:56 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:41:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:41:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:41:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:41:56 --> File loaded: application/views/users/show.php
DEBUG - 2013-09-09 14:41:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:41:56 --> Final output sent to browser
DEBUG - 2013-09-09 14:41:56 --> Total execution time: 1.1191
DEBUG - 2013-09-09 14:41:56 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:56 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:56 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:41:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:41:56 --> URI Class Initialized
DEBUG - 2013-09-09 14:41:56 --> Router Class Initialized
ERROR - 2013-09-09 14:41:56 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:41:58 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:41:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:41:58 --> URI Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Router Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Output Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Security Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Input Class Initialized
DEBUG - 2013-09-09 14:41:58 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:58 --> XSS Filtering completed
DEBUG - 2013-09-09 14:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:41:58 --> Language Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Loader Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:41:58 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:41:58 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:41:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:41:58 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:41:58 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Session Class Initialized
DEBUG - 2013-09-09 14:41:58 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:41:58 --> Session routines successfully run
DEBUG - 2013-09-09 14:41:58 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:41:59 --> Controller Class Initialized
ERROR - 2013-09-09 14:41:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:59 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:41:59 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:41:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:41:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:41:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:41:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:41:59 --> Model Class Initialized
DEBUG - 2013-09-09 14:41:59 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:41:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:41:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:41:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:41:59 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:41:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:41:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:41:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:41:59 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-09-09 14:41:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:41:59 --> Final output sent to browser
DEBUG - 2013-09-09 14:41:59 --> Total execution time: 1.3121
DEBUG - 2013-09-09 14:41:59 --> Config Class Initialized
DEBUG - 2013-09-09 14:41:59 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:41:59 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:42:00 --> URI Class Initialized
DEBUG - 2013-09-09 14:42:00 --> Router Class Initialized
ERROR - 2013-09-09 14:42:00 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:42:01 --> Config Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:42:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:42:01 --> URI Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Router Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Output Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Security Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Input Class Initialized
DEBUG - 2013-09-09 14:42:01 --> XSS Filtering completed
DEBUG - 2013-09-09 14:42:01 --> XSS Filtering completed
DEBUG - 2013-09-09 14:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:42:01 --> Language Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Loader Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:42:01 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:42:01 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:42:01 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:42:01 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:42:01 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Session Class Initialized
DEBUG - 2013-09-09 14:42:01 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:42:02 --> Session routines successfully run
DEBUG - 2013-09-09 14:42:02 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:42:02 --> Controller Class Initialized
ERROR - 2013-09-09 14:42:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:42:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:42:02 --> Model Class Initialized
DEBUG - 2013-09-09 14:42:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:42:02 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:42:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:42:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:42:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:42:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:42:02 --> Model Class Initialized
DEBUG - 2013-09-09 14:42:02 --> DB Transaction Failure
ERROR - 2013-09-09 14:42:02 --> Query error: Column 'guru_id' in where clause is ambiguous
DEBUG - 2013-09-09 14:42:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 14:43:44 --> Config Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:43:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:43:44 --> URI Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Router Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Output Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Security Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Input Class Initialized
DEBUG - 2013-09-09 14:43:44 --> XSS Filtering completed
DEBUG - 2013-09-09 14:43:44 --> XSS Filtering completed
DEBUG - 2013-09-09 14:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:43:44 --> Language Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Loader Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:43:44 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:43:44 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:43:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:43:44 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:43:44 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Session Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:43:44 --> Session routines successfully run
DEBUG - 2013-09-09 14:43:44 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:43:44 --> Controller Class Initialized
ERROR - 2013-09-09 14:43:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:43:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:43:45 --> Model Class Initialized
DEBUG - 2013-09-09 14:43:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:43:45 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:43:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:43:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:43:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:43:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:43:45 --> Model Class Initialized
DEBUG - 2013-09-09 14:43:45 --> DB Transaction Failure
ERROR - 2013-09-09 14:43:45 --> Query error: Column 'guru_id' in where clause is ambiguous
DEBUG - 2013-09-09 14:43:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 14:45:40 --> Config Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:45:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:45:40 --> URI Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Router Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Output Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Security Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Input Class Initialized
DEBUG - 2013-09-09 14:45:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:45:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:45:40 --> Language Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Loader Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:45:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:45:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:45:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:45:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:45:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Session Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:45:40 --> Session routines successfully run
DEBUG - 2013-09-09 14:45:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Controller Class Initialized
ERROR - 2013-09-09 14:45:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:45:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:45:40 --> Model Class Initialized
DEBUG - 2013-09-09 14:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:45:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:45:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:45:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:45:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:45:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:45:41 --> Model Class Initialized
DEBUG - 2013-09-09 14:45:41 --> DB Transaction Failure
ERROR - 2013-09-09 14:45:41 --> Query error: Column 'guru_id' in where clause is ambiguous
DEBUG - 2013-09-09 14:45:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 14:46:23 --> Config Class Initialized
DEBUG - 2013-09-09 14:46:23 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:46:23 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:46:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:46:23 --> URI Class Initialized
DEBUG - 2013-09-09 14:46:23 --> Router Class Initialized
DEBUG - 2013-09-09 14:46:23 --> Output Class Initialized
DEBUG - 2013-09-09 14:46:23 --> Security Class Initialized
DEBUG - 2013-09-09 14:46:23 --> Input Class Initialized
DEBUG - 2013-09-09 14:46:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:46:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:46:23 --> Language Class Initialized
DEBUG - 2013-09-09 14:46:23 --> Loader Class Initialized
DEBUG - 2013-09-09 14:46:23 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:46:23 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:46:23 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:46:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:46:23 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:46:23 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:46:23 --> Session Class Initialized
DEBUG - 2013-09-09 14:46:24 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:46:24 --> Session routines successfully run
DEBUG - 2013-09-09 14:46:24 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:46:24 --> Controller Class Initialized
ERROR - 2013-09-09 14:46:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:46:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:46:24 --> Model Class Initialized
DEBUG - 2013-09-09 14:46:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:46:24 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:46:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:46:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:46:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:46:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:46:24 --> Model Class Initialized
DEBUG - 2013-09-09 14:46:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:46:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:46:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:46:24 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:46:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:46:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:46:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:46:24 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-09-09 14:46:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:46:24 --> Final output sent to browser
DEBUG - 2013-09-09 14:46:24 --> Total execution time: 1.3281
DEBUG - 2013-09-09 14:46:24 --> Config Class Initialized
DEBUG - 2013-09-09 14:46:24 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:46:24 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:46:24 --> URI Class Initialized
DEBUG - 2013-09-09 14:46:25 --> Router Class Initialized
ERROR - 2013-09-09 14:46:25 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:46:36 --> Config Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:46:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:46:36 --> URI Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Router Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Output Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Security Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Input Class Initialized
DEBUG - 2013-09-09 14:46:36 --> XSS Filtering completed
DEBUG - 2013-09-09 14:46:36 --> XSS Filtering completed
DEBUG - 2013-09-09 14:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:46:36 --> Language Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Loader Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:46:36 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:46:36 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:46:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:46:36 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:46:36 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Session Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:46:36 --> Session routines successfully run
DEBUG - 2013-09-09 14:46:36 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:46:36 --> Controller Class Initialized
ERROR - 2013-09-09 14:46:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:46:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:46:37 --> Model Class Initialized
DEBUG - 2013-09-09 14:46:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:46:37 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:46:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:46:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:46:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:46:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:46:37 --> Model Class Initialized
DEBUG - 2013-09-09 14:46:37 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:46:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:46:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:46:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:46:37 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:46:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:46:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:46:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:46:37 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-09-09 14:46:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:46:37 --> Final output sent to browser
DEBUG - 2013-09-09 14:46:37 --> Total execution time: 1.2801
DEBUG - 2013-09-09 14:46:37 --> Config Class Initialized
DEBUG - 2013-09-09 14:46:37 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:46:37 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:46:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:46:37 --> URI Class Initialized
DEBUG - 2013-09-09 14:46:37 --> Router Class Initialized
ERROR - 2013-09-09 14:46:37 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:46:39 --> Config Class Initialized
DEBUG - 2013-09-09 14:46:39 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:46:39 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:46:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:46:40 --> URI Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Router Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Output Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Security Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Input Class Initialized
DEBUG - 2013-09-09 14:46:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:46:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:46:40 --> Language Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Loader Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:46:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:46:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:46:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:46:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:46:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Session Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:46:40 --> Session routines successfully run
DEBUG - 2013-09-09 14:46:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Controller Class Initialized
ERROR - 2013-09-09 14:46:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:46:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:46:40 --> Model Class Initialized
DEBUG - 2013-09-09 14:46:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:46:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:46:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:46:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:46:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:46:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:46:40 --> Model Class Initialized
DEBUG - 2013-09-09 14:46:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:46:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:46:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:46:40 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:46:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:46:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:46:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:46:41 --> File loaded: application/views/gurus/edit.php
DEBUG - 2013-09-09 14:46:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:46:41 --> Final output sent to browser
DEBUG - 2013-09-09 14:46:41 --> Total execution time: 1.2571
DEBUG - 2013-09-09 14:46:41 --> Config Class Initialized
DEBUG - 2013-09-09 14:46:41 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:46:41 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:46:41 --> URI Class Initialized
DEBUG - 2013-09-09 14:46:41 --> Router Class Initialized
ERROR - 2013-09-09 14:46:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:46:54 --> Config Class Initialized
DEBUG - 2013-09-09 14:46:54 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:46:54 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:46:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:46:55 --> URI Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Router Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Output Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Security Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Input Class Initialized
DEBUG - 2013-09-09 14:46:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:46:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:46:55 --> Language Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Loader Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:46:55 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:46:55 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:46:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:46:55 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:46:55 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Session Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:46:55 --> Session routines successfully run
DEBUG - 2013-09-09 14:46:55 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Controller Class Initialized
ERROR - 2013-09-09 14:46:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:46:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:46:55 --> Model Class Initialized
DEBUG - 2013-09-09 14:46:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:46:55 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:46:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:46:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:46:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:46:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:46:55 --> Model Class Initialized
DEBUG - 2013-09-09 14:46:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:46:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:46:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:46:56 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:46:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:46:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:46:56 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 14:46:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 14:46:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 14:46:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 14:46:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 14:46:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 14:46:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 14:46:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 14:46:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 14:46:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 14:46:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 14:46:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 14:46:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 14:46:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 14:46:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 14:46:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 14:46:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 14:46:56 --> File loaded: application/views/guru_walis/new.php
DEBUG - 2013-09-09 14:46:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:46:56 --> Final output sent to browser
DEBUG - 2013-09-09 14:46:56 --> Total execution time: 1.8131
DEBUG - 2013-09-09 14:46:56 --> Config Class Initialized
DEBUG - 2013-09-09 14:46:56 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:46:56 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:46:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:46:57 --> URI Class Initialized
DEBUG - 2013-09-09 14:46:57 --> Router Class Initialized
ERROR - 2013-09-09 14:46:57 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:47:02 --> Config Class Initialized
DEBUG - 2013-09-09 14:47:02 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:47:02 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:47:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:47:02 --> URI Class Initialized
DEBUG - 2013-09-09 14:47:02 --> Router Class Initialized
DEBUG - 2013-09-09 14:47:02 --> Output Class Initialized
DEBUG - 2013-09-09 14:47:02 --> Security Class Initialized
DEBUG - 2013-09-09 14:47:02 --> Input Class Initialized
DEBUG - 2013-09-09 14:47:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:02 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:47:02 --> Language Class Initialized
DEBUG - 2013-09-09 14:47:02 --> Loader Class Initialized
DEBUG - 2013-09-09 14:47:02 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:47:02 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:47:02 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:47:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:47:02 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:47:03 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Session Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:47:03 --> Session routines successfully run
DEBUG - 2013-09-09 14:47:03 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Controller Class Initialized
ERROR - 2013-09-09 14:47:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:47:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:47:03 --> Model Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:47:03 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:47:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:47:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:47:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:47:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:47:03 --> Model Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:47:03 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:03 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:03 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:47:03 --> Config Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:47:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:47:03 --> URI Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Router Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Output Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Security Class Initialized
DEBUG - 2013-09-09 14:47:03 --> Input Class Initialized
DEBUG - 2013-09-09 14:47:03 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:47:04 --> Language Class Initialized
DEBUG - 2013-09-09 14:47:04 --> Loader Class Initialized
DEBUG - 2013-09-09 14:47:04 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:47:04 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:47:04 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:47:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:47:04 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:47:04 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:47:04 --> Session Class Initialized
DEBUG - 2013-09-09 14:47:04 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:47:04 --> Session routines successfully run
DEBUG - 2013-09-09 14:47:04 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:47:04 --> Controller Class Initialized
ERROR - 2013-09-09 14:47:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:47:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:47:04 --> Model Class Initialized
DEBUG - 2013-09-09 14:47:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:47:04 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:47:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:47:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:47:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:47:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:47:04 --> Model Class Initialized
DEBUG - 2013-09-09 14:47:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:47:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:47:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:47:04 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:47:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:47:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:47:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:47:05 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-09-09 14:47:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:47:05 --> Final output sent to browser
DEBUG - 2013-09-09 14:47:05 --> Total execution time: 1.4691
DEBUG - 2013-09-09 14:47:05 --> Config Class Initialized
DEBUG - 2013-09-09 14:47:05 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:47:05 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:47:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:47:05 --> URI Class Initialized
DEBUG - 2013-09-09 14:47:05 --> Router Class Initialized
ERROR - 2013-09-09 14:47:05 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:47:20 --> Config Class Initialized
DEBUG - 2013-09-09 14:47:20 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:47:20 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:47:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:47:20 --> URI Class Initialized
DEBUG - 2013-09-09 14:47:20 --> Router Class Initialized
DEBUG - 2013-09-09 14:47:20 --> Output Class Initialized
DEBUG - 2013-09-09 14:47:21 --> Security Class Initialized
DEBUG - 2013-09-09 14:47:21 --> Input Class Initialized
DEBUG - 2013-09-09 14:47:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:47:21 --> Language Class Initialized
DEBUG - 2013-09-09 14:47:21 --> Loader Class Initialized
DEBUG - 2013-09-09 14:47:21 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:47:21 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:47:21 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:47:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:47:21 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:47:21 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:47:21 --> Session Class Initialized
DEBUG - 2013-09-09 14:47:21 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:47:21 --> Session routines successfully run
DEBUG - 2013-09-09 14:47:21 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:47:21 --> Controller Class Initialized
ERROR - 2013-09-09 14:47:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:47:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:47:21 --> Model Class Initialized
DEBUG - 2013-09-09 14:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:47:21 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:47:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:47:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:47:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:47:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:47:21 --> Model Class Initialized
DEBUG - 2013-09-09 14:47:21 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:47:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:47:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:47:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:47:21 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:47:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:47:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:47:22 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 14:47:22 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:47:22 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:47:22 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:47:22 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:47:22 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-09 14:47:22 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-09 14:47:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:47:22 --> Final output sent to browser
DEBUG - 2013-09-09 14:47:22 --> Total execution time: 1.5141
DEBUG - 2013-09-09 14:47:22 --> Config Class Initialized
DEBUG - 2013-09-09 14:47:22 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:47:22 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:47:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:47:22 --> URI Class Initialized
DEBUG - 2013-09-09 14:47:22 --> Router Class Initialized
ERROR - 2013-09-09 14:47:22 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:47:29 --> Config Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:47:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:47:29 --> URI Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Router Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Output Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Security Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Input Class Initialized
DEBUG - 2013-09-09 14:47:29 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:29 --> XSS Filtering completed
DEBUG - 2013-09-09 14:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:47:29 --> Language Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Loader Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:47:29 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:47:29 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:47:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:47:29 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:47:29 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Session Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:47:29 --> Session routines successfully run
DEBUG - 2013-09-09 14:47:29 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Controller Class Initialized
ERROR - 2013-09-09 14:47:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:47:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:47:29 --> Model Class Initialized
DEBUG - 2013-09-09 14:47:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:47:29 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:47:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:47:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:47:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:47:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:47:30 --> Model Class Initialized
DEBUG - 2013-09-09 14:47:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:47:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:47:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:47:30 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:47:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:47:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:47:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:47:30 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 14:47:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:47:30 --> Final output sent to browser
DEBUG - 2013-09-09 14:47:30 --> Total execution time: 1.4131
DEBUG - 2013-09-09 14:47:30 --> Config Class Initialized
DEBUG - 2013-09-09 14:47:30 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:47:30 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:47:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:47:30 --> URI Class Initialized
DEBUG - 2013-09-09 14:47:30 --> Router Class Initialized
ERROR - 2013-09-09 14:47:30 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:47:43 --> Config Class Initialized
DEBUG - 2013-09-09 14:47:43 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:47:43 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:47:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:47:43 --> URI Class Initialized
DEBUG - 2013-09-09 14:47:43 --> Router Class Initialized
ERROR - 2013-09-09 14:47:43 --> 404 Page Not Found --> siswars
DEBUG - 2013-09-09 14:48:23 --> Config Class Initialized
DEBUG - 2013-09-09 14:48:23 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:48:23 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:48:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:48:24 --> URI Class Initialized
DEBUG - 2013-09-09 14:48:24 --> Router Class Initialized
ERROR - 2013-09-09 14:48:24 --> 404 Page Not Found --> siswars
DEBUG - 2013-09-09 14:48:30 --> Config Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:48:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:48:30 --> URI Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Router Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Output Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Security Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Input Class Initialized
DEBUG - 2013-09-09 14:48:30 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:30 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:48:30 --> Language Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Loader Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:48:30 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:48:30 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:48:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:48:30 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:48:30 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Session Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:48:30 --> Session routines successfully run
DEBUG - 2013-09-09 14:48:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Controller Class Initialized
ERROR - 2013-09-09 14:48:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:48:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:48:30 --> Model Class Initialized
DEBUG - 2013-09-09 14:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:48:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:48:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:48:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:48:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:48:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:48:31 --> Model Class Initialized
DEBUG - 2013-09-09 14:48:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:48:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:48:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:48:31 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:48:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:48:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:48:31 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:48:31 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 14:48:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:48:31 --> Final output sent to browser
DEBUG - 2013-09-09 14:48:31 --> Total execution time: 1.2631
DEBUG - 2013-09-09 14:48:31 --> Config Class Initialized
DEBUG - 2013-09-09 14:48:31 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:48:31 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:48:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:48:31 --> URI Class Initialized
DEBUG - 2013-09-09 14:48:31 --> Router Class Initialized
ERROR - 2013-09-09 14:48:31 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:48:32 --> Config Class Initialized
DEBUG - 2013-09-09 14:48:32 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:48:32 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:48:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:48:32 --> URI Class Initialized
DEBUG - 2013-09-09 14:48:32 --> Router Class Initialized
DEBUG - 2013-09-09 14:48:32 --> Output Class Initialized
DEBUG - 2013-09-09 14:48:33 --> Security Class Initialized
DEBUG - 2013-09-09 14:48:33 --> Input Class Initialized
DEBUG - 2013-09-09 14:48:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:48:33 --> Language Class Initialized
DEBUG - 2013-09-09 14:48:33 --> Loader Class Initialized
DEBUG - 2013-09-09 14:48:33 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:48:33 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:48:33 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:48:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:48:33 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:48:33 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:48:33 --> Session Class Initialized
DEBUG - 2013-09-09 14:48:33 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:48:33 --> Session garbage collection performed.
DEBUG - 2013-09-09 14:48:33 --> Session routines successfully run
DEBUG - 2013-09-09 14:48:33 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:48:33 --> Controller Class Initialized
ERROR - 2013-09-09 14:48:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:48:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:48:33 --> Model Class Initialized
DEBUG - 2013-09-09 14:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:48:33 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:48:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:48:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:48:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:48:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:48:33 --> Model Class Initialized
DEBUG - 2013-09-09 14:48:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:48:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:48:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:48:33 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:48:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:48:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:48:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:48:34 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 14:48:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:48:34 --> Final output sent to browser
DEBUG - 2013-09-09 14:48:34 --> Total execution time: 1.3421
DEBUG - 2013-09-09 14:48:34 --> Config Class Initialized
DEBUG - 2013-09-09 14:48:34 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:48:34 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:48:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:48:34 --> URI Class Initialized
DEBUG - 2013-09-09 14:48:34 --> Router Class Initialized
ERROR - 2013-09-09 14:48:34 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:48:39 --> Config Class Initialized
DEBUG - 2013-09-09 14:48:39 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:48:39 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:48:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:48:39 --> URI Class Initialized
DEBUG - 2013-09-09 14:48:39 --> Router Class Initialized
DEBUG - 2013-09-09 14:48:39 --> Output Class Initialized
DEBUG - 2013-09-09 14:48:39 --> Security Class Initialized
DEBUG - 2013-09-09 14:48:39 --> Input Class Initialized
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:48:40 --> Language Class Initialized
DEBUG - 2013-09-09 14:48:40 --> Loader Class Initialized
DEBUG - 2013-09-09 14:48:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:48:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:48:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:48:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:48:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:48:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:48:41 --> Session Class Initialized
DEBUG - 2013-09-09 14:48:41 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:48:41 --> Session routines successfully run
DEBUG - 2013-09-09 14:48:41 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:48:41 --> Controller Class Initialized
ERROR - 2013-09-09 14:48:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:48:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:48:41 --> Model Class Initialized
DEBUG - 2013-09-09 14:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:48:41 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:48:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:48:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:48:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:48:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:48:41 --> Model Class Initialized
DEBUG - 2013-09-09 14:48:41 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:48:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:48:42 --> DB Transaction Failure
ERROR - 2013-09-09 14:48:42 --> Query error: Unknown column 'nip' in 'where clause'
DEBUG - 2013-09-09 14:48:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 14:49:20 --> Config Class Initialized
DEBUG - 2013-09-09 14:49:20 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:49:20 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:49:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:49:20 --> URI Class Initialized
DEBUG - 2013-09-09 14:49:21 --> Router Class Initialized
DEBUG - 2013-09-09 14:49:21 --> Output Class Initialized
DEBUG - 2013-09-09 14:49:21 --> Security Class Initialized
DEBUG - 2013-09-09 14:49:21 --> Input Class Initialized
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:49:22 --> Language Class Initialized
DEBUG - 2013-09-09 14:49:22 --> Loader Class Initialized
DEBUG - 2013-09-09 14:49:22 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:49:22 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:49:22 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:49:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:49:22 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:49:22 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:49:22 --> Session Class Initialized
DEBUG - 2013-09-09 14:49:22 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:49:22 --> Session routines successfully run
DEBUG - 2013-09-09 14:49:22 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:49:22 --> Controller Class Initialized
ERROR - 2013-09-09 14:49:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:49:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:49:22 --> Model Class Initialized
DEBUG - 2013-09-09 14:49:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:49:22 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:49:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:49:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:49:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:49:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:49:23 --> Model Class Initialized
DEBUG - 2013-09-09 14:49:23 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:24 --> XSS Filtering completed
DEBUG - 2013-09-09 14:49:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:49:24 --> DB Transaction Failure
ERROR - 2013-09-09 14:49:24 --> Query error: Unknown column 'nip' in 'where clause'
DEBUG - 2013-09-09 14:49:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 14:50:18 --> Config Class Initialized
DEBUG - 2013-09-09 14:50:18 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:50:18 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:50:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:50:18 --> URI Class Initialized
DEBUG - 2013-09-09 14:50:18 --> Router Class Initialized
DEBUG - 2013-09-09 14:50:18 --> Output Class Initialized
DEBUG - 2013-09-09 14:50:19 --> Security Class Initialized
DEBUG - 2013-09-09 14:50:19 --> Input Class Initialized
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:20 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:20 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:20 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:20 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:20 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:20 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:50:20 --> Language Class Initialized
DEBUG - 2013-09-09 14:50:20 --> Loader Class Initialized
DEBUG - 2013-09-09 14:50:20 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:50:20 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:50:20 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:50:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:50:20 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:50:20 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:50:20 --> Session Class Initialized
DEBUG - 2013-09-09 14:50:20 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:50:20 --> Session routines successfully run
DEBUG - 2013-09-09 14:50:20 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:50:20 --> Controller Class Initialized
ERROR - 2013-09-09 14:50:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:50:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:50:20 --> Model Class Initialized
DEBUG - 2013-09-09 14:50:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:50:20 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:50:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:50:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:50:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:50:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:50:21 --> Model Class Initialized
DEBUG - 2013-09-09 14:50:21 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:21 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:50:22 --> Config Class Initialized
DEBUG - 2013-09-09 14:50:22 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:50:22 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:50:22 --> URI Class Initialized
DEBUG - 2013-09-09 14:50:22 --> Router Class Initialized
DEBUG - 2013-09-09 14:50:22 --> Output Class Initialized
DEBUG - 2013-09-09 14:50:22 --> Security Class Initialized
DEBUG - 2013-09-09 14:50:22 --> Input Class Initialized
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:50:22 --> Language Class Initialized
DEBUG - 2013-09-09 14:50:22 --> Loader Class Initialized
DEBUG - 2013-09-09 14:50:22 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:50:22 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:50:22 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:50:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:50:22 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:50:23 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:50:23 --> Session Class Initialized
DEBUG - 2013-09-09 14:50:23 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:50:23 --> Session routines successfully run
DEBUG - 2013-09-09 14:50:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:50:23 --> Controller Class Initialized
ERROR - 2013-09-09 14:50:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:50:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:50:23 --> Model Class Initialized
DEBUG - 2013-09-09 14:50:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:50:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:50:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:50:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:50:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:50:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:50:23 --> Model Class Initialized
DEBUG - 2013-09-09 14:50:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:50:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:50:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:50:23 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:50:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:50:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:50:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:50:23 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 14:50:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:50:23 --> Final output sent to browser
DEBUG - 2013-09-09 14:50:24 --> Total execution time: 1.5291
DEBUG - 2013-09-09 14:50:24 --> Config Class Initialized
DEBUG - 2013-09-09 14:50:24 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:50:24 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:50:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:50:24 --> URI Class Initialized
DEBUG - 2013-09-09 14:50:24 --> Router Class Initialized
ERROR - 2013-09-09 14:50:24 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:50:53 --> Config Class Initialized
DEBUG - 2013-09-09 14:50:53 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:50:53 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:50:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:50:53 --> URI Class Initialized
DEBUG - 2013-09-09 14:50:53 --> Router Class Initialized
DEBUG - 2013-09-09 14:50:53 --> Output Class Initialized
DEBUG - 2013-09-09 14:50:53 --> Security Class Initialized
DEBUG - 2013-09-09 14:50:53 --> Input Class Initialized
DEBUG - 2013-09-09 14:50:53 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:53 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:53 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:50:55 --> Language Class Initialized
DEBUG - 2013-09-09 14:50:55 --> Loader Class Initialized
DEBUG - 2013-09-09 14:50:55 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:50:55 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:50:55 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:50:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:50:55 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:50:55 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:50:55 --> Session Class Initialized
DEBUG - 2013-09-09 14:50:55 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:50:55 --> Session routines successfully run
DEBUG - 2013-09-09 14:50:55 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:50:55 --> Controller Class Initialized
ERROR - 2013-09-09 14:50:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:50:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:50:55 --> Model Class Initialized
DEBUG - 2013-09-09 14:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:50:55 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:50:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:50:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:50:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:50:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:50:56 --> Model Class Initialized
DEBUG - 2013-09-09 14:50:56 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:50:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:50:57 --> DB Transaction Failure
ERROR - 2013-09-09 14:50:57 --> Query error: Unknown column 'pkribu' in 'field list'
DEBUG - 2013-09-09 14:50:57 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 14:51:31 --> Config Class Initialized
DEBUG - 2013-09-09 14:51:31 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:51:31 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:51:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:51:31 --> URI Class Initialized
DEBUG - 2013-09-09 14:51:31 --> Router Class Initialized
DEBUG - 2013-09-09 14:51:31 --> Output Class Initialized
DEBUG - 2013-09-09 14:51:31 --> Security Class Initialized
DEBUG - 2013-09-09 14:51:31 --> Input Class Initialized
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:31 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:51:32 --> Language Class Initialized
DEBUG - 2013-09-09 14:51:32 --> Loader Class Initialized
DEBUG - 2013-09-09 14:51:32 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:51:32 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:51:32 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:51:32 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:51:32 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:51:32 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:51:32 --> Session Class Initialized
DEBUG - 2013-09-09 14:51:32 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:51:33 --> Session routines successfully run
DEBUG - 2013-09-09 14:51:33 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:51:33 --> Controller Class Initialized
ERROR - 2013-09-09 14:51:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:51:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:51:33 --> Model Class Initialized
DEBUG - 2013-09-09 14:51:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:51:33 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:51:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:51:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:51:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:51:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:51:33 --> Model Class Initialized
DEBUG - 2013-09-09 14:51:33 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> XSS Filtering completed
DEBUG - 2013-09-09 14:51:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:51:34 --> DB Transaction Failure
ERROR - 2013-09-09 14:51:34 --> Query error: Incorrect integer value: '' for column 'pkrjbpk' at row 1
DEBUG - 2013-09-09 14:51:34 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 14:53:07 --> Config Class Initialized
DEBUG - 2013-09-09 14:53:07 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:53:07 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:53:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:53:07 --> URI Class Initialized
DEBUG - 2013-09-09 14:53:07 --> Router Class Initialized
DEBUG - 2013-09-09 14:53:07 --> Output Class Initialized
DEBUG - 2013-09-09 14:53:07 --> Security Class Initialized
DEBUG - 2013-09-09 14:53:07 --> Input Class Initialized
DEBUG - 2013-09-09 14:53:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:09 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:53:09 --> Language Class Initialized
DEBUG - 2013-09-09 14:53:09 --> Loader Class Initialized
DEBUG - 2013-09-09 14:53:09 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:53:09 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:53:09 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:53:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:53:09 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:53:09 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:53:09 --> Session Class Initialized
DEBUG - 2013-09-09 14:53:09 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:53:09 --> Session routines successfully run
DEBUG - 2013-09-09 14:53:09 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:53:09 --> Controller Class Initialized
ERROR - 2013-09-09 14:53:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:53:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:53:09 --> Model Class Initialized
DEBUG - 2013-09-09 14:53:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:53:09 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:53:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:53:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:53:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:53:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:53:09 --> Model Class Initialized
DEBUG - 2013-09-09 14:53:09 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:10 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:53:11 --> Config Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:53:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:53:11 --> URI Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Router Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Output Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Security Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Input Class Initialized
DEBUG - 2013-09-09 14:53:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:11 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:53:11 --> Language Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Loader Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:53:11 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:53:11 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:53:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:53:11 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:53:11 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Session Class Initialized
DEBUG - 2013-09-09 14:53:11 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:53:12 --> Session routines successfully run
DEBUG - 2013-09-09 14:53:12 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:53:12 --> Controller Class Initialized
ERROR - 2013-09-09 14:53:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:53:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:53:12 --> Model Class Initialized
DEBUG - 2013-09-09 14:53:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:53:12 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:53:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:53:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:53:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:53:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:53:12 --> Model Class Initialized
DEBUG - 2013-09-09 14:53:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:53:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:53:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:53:12 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:53:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:53:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:53:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:53:12 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-09-09 14:53:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:53:12 --> Final output sent to browser
DEBUG - 2013-09-09 14:53:12 --> Total execution time: 1.6141
DEBUG - 2013-09-09 14:53:13 --> Config Class Initialized
DEBUG - 2013-09-09 14:53:13 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:53:13 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:53:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:53:13 --> URI Class Initialized
DEBUG - 2013-09-09 14:53:13 --> Router Class Initialized
ERROR - 2013-09-09 14:53:13 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:53:32 --> Config Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:53:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:53:33 --> URI Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Router Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Output Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Security Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Input Class Initialized
DEBUG - 2013-09-09 14:53:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:33 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:53:33 --> Language Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Loader Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:53:33 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:53:33 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:53:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:53:33 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:53:33 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Session Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:53:33 --> Session routines successfully run
DEBUG - 2013-09-09 14:53:33 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Controller Class Initialized
ERROR - 2013-09-09 14:53:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:53:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:53:33 --> Model Class Initialized
DEBUG - 2013-09-09 14:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:53:33 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:53:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:53:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:53:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:53:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:53:34 --> Model Class Initialized
DEBUG - 2013-09-09 14:53:34 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:53:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:53:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:53:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:53:34 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:53:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:53:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:53:34 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 14:53:34 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:53:34 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:53:34 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:53:34 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:53:34 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-09 14:53:34 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-09 14:53:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:53:34 --> Final output sent to browser
DEBUG - 2013-09-09 14:53:34 --> Total execution time: 1.6231
DEBUG - 2013-09-09 14:53:34 --> Config Class Initialized
DEBUG - 2013-09-09 14:53:34 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:53:34 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:53:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:53:34 --> URI Class Initialized
DEBUG - 2013-09-09 14:53:34 --> Router Class Initialized
ERROR - 2013-09-09 14:53:34 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:53:37 --> Config Class Initialized
DEBUG - 2013-09-09 14:53:37 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:53:37 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:53:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:53:37 --> URI Class Initialized
DEBUG - 2013-09-09 14:53:37 --> Router Class Initialized
DEBUG - 2013-09-09 14:53:37 --> Output Class Initialized
DEBUG - 2013-09-09 14:53:37 --> Security Class Initialized
DEBUG - 2013-09-09 14:53:37 --> Input Class Initialized
DEBUG - 2013-09-09 14:53:37 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:37 --> XSS Filtering completed
DEBUG - 2013-09-09 14:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:53:37 --> Language Class Initialized
DEBUG - 2013-09-09 14:53:37 --> Loader Class Initialized
DEBUG - 2013-09-09 14:53:37 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:53:37 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:53:37 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:53:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:53:37 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:53:38 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:53:38 --> Session Class Initialized
DEBUG - 2013-09-09 14:53:38 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:53:38 --> Session routines successfully run
DEBUG - 2013-09-09 14:53:38 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:53:38 --> Controller Class Initialized
ERROR - 2013-09-09 14:53:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:53:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:53:38 --> Model Class Initialized
DEBUG - 2013-09-09 14:53:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:53:38 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:53:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:53:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:53:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:53:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:53:38 --> Model Class Initialized
DEBUG - 2013-09-09 14:53:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:53:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:53:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:53:38 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:53:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:53:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:53:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:53:38 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 14:53:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:53:38 --> Final output sent to browser
DEBUG - 2013-09-09 14:53:38 --> Total execution time: 1.5221
DEBUG - 2013-09-09 14:53:39 --> Config Class Initialized
DEBUG - 2013-09-09 14:53:39 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:53:39 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:53:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:53:39 --> URI Class Initialized
DEBUG - 2013-09-09 14:53:39 --> Router Class Initialized
ERROR - 2013-09-09 14:53:39 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:54:04 --> Config Class Initialized
DEBUG - 2013-09-09 14:54:04 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:54:04 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:54:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:54:04 --> URI Class Initialized
DEBUG - 2013-09-09 14:54:04 --> Router Class Initialized
DEBUG - 2013-09-09 14:54:04 --> Output Class Initialized
DEBUG - 2013-09-09 14:54:04 --> Security Class Initialized
DEBUG - 2013-09-09 14:54:04 --> Input Class Initialized
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:04 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:54:05 --> Language Class Initialized
DEBUG - 2013-09-09 14:54:05 --> Loader Class Initialized
DEBUG - 2013-09-09 14:54:06 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:54:06 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:54:06 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:54:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:54:06 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:54:06 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:54:06 --> Session Class Initialized
DEBUG - 2013-09-09 14:54:06 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:54:06 --> Session routines successfully run
DEBUG - 2013-09-09 14:54:06 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:54:06 --> Controller Class Initialized
ERROR - 2013-09-09 14:54:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:06 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:54:06 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:54:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:54:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:54:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:06 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:06 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:54:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:06 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:54:08 --> Config Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:54:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:54:08 --> URI Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Router Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Output Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Security Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Input Class Initialized
DEBUG - 2013-09-09 14:54:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:08 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:54:08 --> Language Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Loader Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:54:08 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:54:08 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:54:08 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:54:08 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:54:08 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Session Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:54:08 --> Session routines successfully run
DEBUG - 2013-09-09 14:54:08 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Controller Class Initialized
ERROR - 2013-09-09 14:54:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:08 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:54:09 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:54:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:54:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:54:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:09 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:54:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:54:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:54:09 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:54:09 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:54:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:54:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:54:09 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-09-09 14:54:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:54:09 --> Final output sent to browser
DEBUG - 2013-09-09 14:54:09 --> Total execution time: 1.5231
DEBUG - 2013-09-09 14:54:09 --> Config Class Initialized
DEBUG - 2013-09-09 14:54:09 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:54:09 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:54:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:54:09 --> URI Class Initialized
DEBUG - 2013-09-09 14:54:09 --> Router Class Initialized
ERROR - 2013-09-09 14:54:10 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:54:19 --> Config Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:54:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:54:19 --> URI Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Router Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Output Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Security Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Input Class Initialized
DEBUG - 2013-09-09 14:54:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:19 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:54:19 --> Language Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Loader Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:54:19 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:54:19 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:54:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:54:19 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:54:19 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Session Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:54:19 --> Session routines successfully run
DEBUG - 2013-09-09 14:54:19 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:54:19 --> Controller Class Initialized
ERROR - 2013-09-09 14:54:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:20 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:54:20 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:54:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:54:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:54:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:20 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:20 --> Pagination Class Initialized
DEBUG - 2013-09-09 14:54:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:54:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:54:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:54:20 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:54:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:54:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:54:20 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 14:54:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:54:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:54:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:54:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-09 14:54:20 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-09 14:54:20 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-09 14:54:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:54:20 --> Final output sent to browser
DEBUG - 2013-09-09 14:54:20 --> Total execution time: 1.7581
DEBUG - 2013-09-09 14:54:21 --> Config Class Initialized
DEBUG - 2013-09-09 14:54:21 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:54:21 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:54:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:54:21 --> URI Class Initialized
DEBUG - 2013-09-09 14:54:21 --> Router Class Initialized
ERROR - 2013-09-09 14:54:21 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:54:23 --> Config Class Initialized
DEBUG - 2013-09-09 14:54:23 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:54:23 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:54:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:54:23 --> URI Class Initialized
DEBUG - 2013-09-09 14:54:23 --> Router Class Initialized
DEBUG - 2013-09-09 14:54:23 --> Output Class Initialized
DEBUG - 2013-09-09 14:54:23 --> Security Class Initialized
DEBUG - 2013-09-09 14:54:23 --> Input Class Initialized
DEBUG - 2013-09-09 14:54:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:23 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:54:24 --> Language Class Initialized
DEBUG - 2013-09-09 14:54:24 --> Loader Class Initialized
DEBUG - 2013-09-09 14:54:24 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:54:24 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:54:24 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:54:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:54:24 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:54:24 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:54:24 --> Session Class Initialized
DEBUG - 2013-09-09 14:54:24 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:54:24 --> Session routines successfully run
DEBUG - 2013-09-09 14:54:24 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:54:24 --> Controller Class Initialized
ERROR - 2013-09-09 14:54:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:24 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:54:24 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:54:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:54:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:54:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:24 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:54:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:54:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:54:24 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:54:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:54:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:54:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:54:25 --> File loaded: application/views/siswas/edit.php
DEBUG - 2013-09-09 14:54:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:54:25 --> Final output sent to browser
DEBUG - 2013-09-09 14:54:25 --> Total execution time: 1.5641
DEBUG - 2013-09-09 14:54:25 --> Config Class Initialized
DEBUG - 2013-09-09 14:54:25 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:54:25 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:54:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:54:25 --> URI Class Initialized
DEBUG - 2013-09-09 14:54:25 --> Router Class Initialized
ERROR - 2013-09-09 14:54:25 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 14:54:38 --> Config Class Initialized
DEBUG - 2013-09-09 14:54:38 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:54:38 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:54:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:54:38 --> URI Class Initialized
DEBUG - 2013-09-09 14:54:39 --> Router Class Initialized
DEBUG - 2013-09-09 14:54:39 --> Output Class Initialized
DEBUG - 2013-09-09 14:54:39 --> Security Class Initialized
DEBUG - 2013-09-09 14:54:39 --> Input Class Initialized
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:39 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:54:40 --> Language Class Initialized
DEBUG - 2013-09-09 14:54:40 --> Loader Class Initialized
DEBUG - 2013-09-09 14:54:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:54:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:54:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:54:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:54:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:54:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:54:40 --> Session Class Initialized
DEBUG - 2013-09-09 14:54:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:54:40 --> Session routines successfully run
DEBUG - 2013-09-09 14:54:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:54:40 --> Controller Class Initialized
ERROR - 2013-09-09 14:54:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:41 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:54:41 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:54:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:54:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:54:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:54:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:54:41 --> Model Class Initialized
DEBUG - 2013-09-09 14:54:41 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:41 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> XSS Filtering completed
DEBUG - 2013-09-09 14:54:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:54:42 --> DB Transaction Failure
ERROR - 2013-09-09 14:54:42 --> Query error: Incorrect integer value: 'ISLAM' for column 'agama' at row 1
DEBUG - 2013-09-09 14:54:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 14:55:54 --> Config Class Initialized
DEBUG - 2013-09-09 14:55:54 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:55:54 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:55:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:55:54 --> URI Class Initialized
DEBUG - 2013-09-09 14:55:54 --> Router Class Initialized
DEBUG - 2013-09-09 14:55:54 --> Output Class Initialized
DEBUG - 2013-09-09 14:55:54 --> Security Class Initialized
DEBUG - 2013-09-09 14:55:54 --> Input Class Initialized
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:54 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:55:55 --> Language Class Initialized
DEBUG - 2013-09-09 14:55:55 --> Loader Class Initialized
DEBUG - 2013-09-09 14:55:55 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:55:55 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:55:56 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:55:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:55:56 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:55:56 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:55:56 --> Session Class Initialized
DEBUG - 2013-09-09 14:55:56 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:55:56 --> Session routines successfully run
DEBUG - 2013-09-09 14:55:56 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:55:56 --> Controller Class Initialized
ERROR - 2013-09-09 14:55:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:55:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:55:56 --> Model Class Initialized
DEBUG - 2013-09-09 14:55:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:55:56 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:55:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:55:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:55:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:55:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:55:56 --> Model Class Initialized
DEBUG - 2013-09-09 14:55:56 --> Form Validation Class Initialized
DEBUG - 2013-09-09 14:55:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:56 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:57 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:58 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-09 14:55:58 --> Config Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:55:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:55:58 --> URI Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Router Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Output Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Security Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Input Class Initialized
DEBUG - 2013-09-09 14:55:58 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:58 --> XSS Filtering completed
DEBUG - 2013-09-09 14:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 14:55:58 --> Language Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Loader Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Helper loaded: url_helper
DEBUG - 2013-09-09 14:55:58 --> Helper loaded: file_helper
DEBUG - 2013-09-09 14:55:58 --> Helper loaded: form_helper
DEBUG - 2013-09-09 14:55:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 14:55:58 --> Helper loaded: application_helper
DEBUG - 2013-09-09 14:55:58 --> Database Driver Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Session Class Initialized
DEBUG - 2013-09-09 14:55:58 --> Helper loaded: string_helper
DEBUG - 2013-09-09 14:55:58 --> Session routines successfully run
DEBUG - 2013-09-09 14:55:58 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 14:55:59 --> Controller Class Initialized
ERROR - 2013-09-09 14:55:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:55:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:55:59 --> Model Class Initialized
DEBUG - 2013-09-09 14:55:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 14:55:59 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 14:55:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 14:55:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 14:55:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 14:55:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 14:55:59 --> Model Class Initialized
DEBUG - 2013-09-09 14:55:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 14:55:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 14:55:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 14:55:59 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 14:55:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 14:55:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 14:55:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 14:55:59 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-09-09 14:55:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 14:55:59 --> Final output sent to browser
DEBUG - 2013-09-09 14:55:59 --> Total execution time: 1.6291
DEBUG - 2013-09-09 14:55:59 --> Config Class Initialized
DEBUG - 2013-09-09 14:55:59 --> Hooks Class Initialized
DEBUG - 2013-09-09 14:55:59 --> Utf8 Class Initialized
DEBUG - 2013-09-09 14:55:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 14:55:59 --> URI Class Initialized
DEBUG - 2013-09-09 14:56:00 --> Router Class Initialized
ERROR - 2013-09-09 14:56:00 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:00:22 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:22 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:22 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:22 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:22 --> Router Class Initialized
DEBUG - 2013-09-09 15:00:22 --> Output Class Initialized
DEBUG - 2013-09-09 15:00:22 --> Security Class Initialized
DEBUG - 2013-09-09 15:00:22 --> Input Class Initialized
DEBUG - 2013-09-09 15:00:22 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:22 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:00:22 --> Language Class Initialized
DEBUG - 2013-09-09 15:00:22 --> Loader Class Initialized
DEBUG - 2013-09-09 15:00:22 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:00:22 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:00:22 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:00:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:00:22 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:00:22 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:00:23 --> Session Class Initialized
DEBUG - 2013-09-09 15:00:23 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:00:23 --> Session routines successfully run
DEBUG - 2013-09-09 15:00:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:00:23 --> Controller Class Initialized
ERROR - 2013-09-09 15:00:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:23 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:00:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:00:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:00:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:00:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:23 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:23 --> Pagination Class Initialized
DEBUG - 2013-09-09 15:00:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:00:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:00:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:00:23 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:00:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:00:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:00:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:00:23 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-09-09 15:00:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:00:24 --> Final output sent to browser
DEBUG - 2013-09-09 15:00:24 --> Total execution time: 1.7571
DEBUG - 2013-09-09 15:00:24 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:24 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:24 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:24 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:24 --> Router Class Initialized
ERROR - 2013-09-09 15:00:24 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:00:27 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:28 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Router Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Output Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Security Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Input Class Initialized
DEBUG - 2013-09-09 15:00:28 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:28 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:00:28 --> Language Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Loader Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:00:28 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:00:28 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:00:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:00:28 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:00:28 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Session Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:00:28 --> Session routines successfully run
DEBUG - 2013-09-09 15:00:28 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Controller Class Initialized
ERROR - 2013-09-09 15:00:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:28 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:00:28 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:00:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:00:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:00:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:29 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:00:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:00:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:00:29 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:00:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:00:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:00:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:00:29 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-09-09 15:00:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:00:29 --> Final output sent to browser
DEBUG - 2013-09-09 15:00:29 --> Total execution time: 1.6111
DEBUG - 2013-09-09 15:00:29 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:29 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:29 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:29 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:29 --> Router Class Initialized
ERROR - 2013-09-09 15:00:30 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:00:34 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:34 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:34 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:34 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:34 --> Router Class Initialized
DEBUG - 2013-09-09 15:00:34 --> Output Class Initialized
DEBUG - 2013-09-09 15:00:34 --> Security Class Initialized
DEBUG - 2013-09-09 15:00:34 --> Input Class Initialized
DEBUG - 2013-09-09 15:00:34 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:34 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:00:34 --> Language Class Initialized
DEBUG - 2013-09-09 15:00:35 --> Loader Class Initialized
DEBUG - 2013-09-09 15:00:35 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:00:35 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:00:35 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:00:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:00:35 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:00:35 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:00:35 --> Session Class Initialized
DEBUG - 2013-09-09 15:00:35 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:00:35 --> Session routines successfully run
DEBUG - 2013-09-09 15:00:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:00:35 --> Controller Class Initialized
ERROR - 2013-09-09 15:00:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:35 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:00:35 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:00:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:00:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:00:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:35 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:00:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:00:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:00:35 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:00:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:00:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:00:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:00:36 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-09-09 15:00:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:00:36 --> Final output sent to browser
DEBUG - 2013-09-09 15:00:36 --> Total execution time: 1.5961
DEBUG - 2013-09-09 15:00:36 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:36 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:36 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:36 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:36 --> Router Class Initialized
ERROR - 2013-09-09 15:00:36 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:00:39 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:39 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:39 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:40 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Router Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Output Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Security Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Input Class Initialized
DEBUG - 2013-09-09 15:00:40 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:40 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:00:40 --> Language Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Loader Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:00:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:00:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:00:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:00:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:00:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Session Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:00:40 --> Session routines successfully run
DEBUG - 2013-09-09 15:00:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Controller Class Initialized
ERROR - 2013-09-09 15:00:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:40 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:00:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:00:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:00:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:00:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:41 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:41 --> Pagination Class Initialized
DEBUG - 2013-09-09 15:00:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:00:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:00:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:00:41 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:00:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:00:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:00:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:00:41 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-09-09 15:00:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:00:41 --> Final output sent to browser
DEBUG - 2013-09-09 15:00:41 --> Total execution time: 1.7641
DEBUG - 2013-09-09 15:00:41 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:41 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:41 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:41 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:42 --> Router Class Initialized
ERROR - 2013-09-09 15:00:42 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:00:45 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:45 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:45 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:45 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:45 --> Router Class Initialized
DEBUG - 2013-09-09 15:00:45 --> Output Class Initialized
DEBUG - 2013-09-09 15:00:45 --> Security Class Initialized
DEBUG - 2013-09-09 15:00:45 --> Input Class Initialized
DEBUG - 2013-09-09 15:00:45 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:45 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:00:45 --> Language Class Initialized
DEBUG - 2013-09-09 15:00:45 --> Loader Class Initialized
DEBUG - 2013-09-09 15:00:45 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:00:45 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:00:45 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:00:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:00:46 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:00:46 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:00:46 --> Session Class Initialized
DEBUG - 2013-09-09 15:00:46 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:00:46 --> Session routines successfully run
DEBUG - 2013-09-09 15:00:46 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:00:46 --> Controller Class Initialized
ERROR - 2013-09-09 15:00:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:46 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:00:46 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:00:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:00:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:00:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:46 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:46 --> Pagination Class Initialized
DEBUG - 2013-09-09 15:00:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:00:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:00:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:00:46 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:00:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:00:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:00:47 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:00:47 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-09-09 15:00:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:00:47 --> Final output sent to browser
DEBUG - 2013-09-09 15:00:47 --> Total execution time: 1.8121
DEBUG - 2013-09-09 15:00:47 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:47 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:47 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:47 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:47 --> Router Class Initialized
ERROR - 2013-09-09 15:00:47 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:00:51 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:51 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Router Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Output Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Security Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Input Class Initialized
DEBUG - 2013-09-09 15:00:51 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:51 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:00:51 --> Language Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Loader Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:00:51 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:00:51 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:00:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:00:51 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:00:51 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Session Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:00:51 --> Session routines successfully run
DEBUG - 2013-09-09 15:00:51 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:00:51 --> Controller Class Initialized
ERROR - 2013-09-09 15:00:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:52 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:00:52 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:00:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:00:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:00:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:52 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:52 --> Pagination Class Initialized
DEBUG - 2013-09-09 15:00:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:00:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:00:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:00:52 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:00:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:00:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:00:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:00:52 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-09-09 15:00:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:00:52 --> Final output sent to browser
DEBUG - 2013-09-09 15:00:52 --> Total execution time: 1.8561
DEBUG - 2013-09-09 15:00:53 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:53 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:53 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:53 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:53 --> Router Class Initialized
ERROR - 2013-09-09 15:00:53 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:00:55 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:55 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Router Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Output Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Security Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Input Class Initialized
DEBUG - 2013-09-09 15:00:55 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:55 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:00:55 --> Language Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Loader Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:00:55 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:00:55 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:00:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:00:55 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:00:55 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Session Class Initialized
DEBUG - 2013-09-09 15:00:55 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:00:55 --> Session routines successfully run
DEBUG - 2013-09-09 15:00:55 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:00:56 --> Controller Class Initialized
ERROR - 2013-09-09 15:00:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:56 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:00:56 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:00:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:00:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:00:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:56 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:56 --> Pagination Class Initialized
DEBUG - 2013-09-09 15:00:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:00:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:00:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:00:56 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:00:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:00:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:00:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:00:56 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-09-09 15:00:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:00:56 --> Final output sent to browser
DEBUG - 2013-09-09 15:00:56 --> Total execution time: 1.9211
DEBUG - 2013-09-09 15:00:57 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:57 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:57 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:57 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:57 --> Router Class Initialized
ERROR - 2013-09-09 15:00:57 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:00:58 --> Config Class Initialized
DEBUG - 2013-09-09 15:00:58 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:00:58 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:00:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:00:58 --> URI Class Initialized
DEBUG - 2013-09-09 15:00:58 --> Router Class Initialized
DEBUG - 2013-09-09 15:00:58 --> Output Class Initialized
DEBUG - 2013-09-09 15:00:58 --> Security Class Initialized
DEBUG - 2013-09-09 15:00:58 --> Input Class Initialized
DEBUG - 2013-09-09 15:00:59 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:59 --> XSS Filtering completed
DEBUG - 2013-09-09 15:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:00:59 --> Language Class Initialized
DEBUG - 2013-09-09 15:00:59 --> Loader Class Initialized
DEBUG - 2013-09-09 15:00:59 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:00:59 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:00:59 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:00:59 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:00:59 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:00:59 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:00:59 --> Session Class Initialized
DEBUG - 2013-09-09 15:00:59 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:00:59 --> Session routines successfully run
DEBUG - 2013-09-09 15:00:59 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:00:59 --> Controller Class Initialized
ERROR - 2013-09-09 15:00:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:00:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:00:59 --> Model Class Initialized
DEBUG - 2013-09-09 15:00:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:00:59 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:00:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:00:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:00:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:01:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:01:00 --> Model Class Initialized
DEBUG - 2013-09-09 15:01:00 --> Pagination Class Initialized
ERROR - 2013-09-09 15:01:00 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:01:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:01:00 --> DB Transaction Failure
ERROR - 2013-09-09 15:01:00 --> Query error: Unknown column 'gurus.guru_id' in 'on clause'
DEBUG - 2013-09-09 15:01:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-09 15:02:15 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:15 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:15 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:15 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:15 --> Router Class Initialized
DEBUG - 2013-09-09 15:02:16 --> Output Class Initialized
DEBUG - 2013-09-09 15:02:16 --> Security Class Initialized
DEBUG - 2013-09-09 15:02:16 --> Input Class Initialized
DEBUG - 2013-09-09 15:02:16 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:16 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:02:16 --> Language Class Initialized
DEBUG - 2013-09-09 15:02:16 --> Loader Class Initialized
DEBUG - 2013-09-09 15:02:16 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:02:16 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:02:16 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:02:16 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:02:16 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:02:16 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:02:16 --> Session Class Initialized
DEBUG - 2013-09-09 15:02:16 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:02:16 --> Session garbage collection performed.
DEBUG - 2013-09-09 15:02:16 --> Session routines successfully run
DEBUG - 2013-09-09 15:02:16 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:02:16 --> Controller Class Initialized
ERROR - 2013-09-09 15:02:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:16 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:02:16 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:02:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:02:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:02:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:17 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:17 --> Pagination Class Initialized
ERROR - 2013-09-09 15:02:17 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:02:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:02:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:02:17 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:02:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:02:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:02:17 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-09 15:02:17 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 15:02:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 15:02:17 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 15:02:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 15:02:17 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 15:02:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 15:02:17 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 15:02:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 15:02:17 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 15:02:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 15:02:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 15:02:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 15:02:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 15:02:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-09 15:02:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-09 15:02:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-09 15:02:18 --> File loaded: application/views/absensis/index.php
DEBUG - 2013-09-09 15:02:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:02:18 --> Final output sent to browser
DEBUG - 2013-09-09 15:02:18 --> Total execution time: 2.5311
DEBUG - 2013-09-09 15:02:18 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:18 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:18 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:18 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:18 --> Router Class Initialized
ERROR - 2013-09-09 15:02:18 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:02:27 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:27 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:27 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:27 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:27 --> Router Class Initialized
DEBUG - 2013-09-09 15:02:27 --> Output Class Initialized
DEBUG - 2013-09-09 15:02:27 --> Security Class Initialized
DEBUG - 2013-09-09 15:02:27 --> Input Class Initialized
DEBUG - 2013-09-09 15:02:27 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:27 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:02:27 --> Language Class Initialized
DEBUG - 2013-09-09 15:02:27 --> Loader Class Initialized
DEBUG - 2013-09-09 15:02:27 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:02:27 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:02:27 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:02:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:02:28 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:02:28 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:02:28 --> Session Class Initialized
DEBUG - 2013-09-09 15:02:28 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:02:28 --> Session routines successfully run
DEBUG - 2013-09-09 15:02:28 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:02:28 --> Controller Class Initialized
ERROR - 2013-09-09 15:02:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:28 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:02:28 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:02:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:02:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:02:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:28 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:28 --> Pagination Class Initialized
DEBUG - 2013-09-09 15:02:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:02:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:02:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:02:28 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:02:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:02:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:02:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:02:29 --> File loaded: application/views/siswa_nilais/index.php
DEBUG - 2013-09-09 15:02:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:02:29 --> Final output sent to browser
DEBUG - 2013-09-09 15:02:29 --> Total execution time: 1.8881
DEBUG - 2013-09-09 15:02:29 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:29 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:29 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:29 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:29 --> Router Class Initialized
ERROR - 2013-09-09 15:02:29 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:02:32 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:32 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Router Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Output Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Security Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Input Class Initialized
DEBUG - 2013-09-09 15:02:32 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:32 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:02:32 --> Language Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Loader Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:02:32 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:02:32 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:02:32 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:02:32 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:02:32 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Session Class Initialized
DEBUG - 2013-09-09 15:02:32 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:02:32 --> Session routines successfully run
DEBUG - 2013-09-09 15:02:32 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:02:33 --> Controller Class Initialized
ERROR - 2013-09-09 15:02:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:33 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:02:33 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:02:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:02:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:02:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:33 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:33 --> Pagination Class Initialized
DEBUG - 2013-09-09 15:02:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:02:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:02:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:02:33 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:02:33 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:02:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:02:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:02:33 --> File loaded: application/views/mata_pelajaran_persentases/index.php
DEBUG - 2013-09-09 15:02:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:02:34 --> Final output sent to browser
DEBUG - 2013-09-09 15:02:34 --> Total execution time: 1.9121
DEBUG - 2013-09-09 15:02:34 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:34 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:34 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:34 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:34 --> Router Class Initialized
ERROR - 2013-09-09 15:02:34 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:02:36 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:36 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:36 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:36 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:36 --> Router Class Initialized
DEBUG - 2013-09-09 15:02:36 --> Output Class Initialized
DEBUG - 2013-09-09 15:02:36 --> Security Class Initialized
DEBUG - 2013-09-09 15:02:36 --> Input Class Initialized
DEBUG - 2013-09-09 15:02:36 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:36 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:02:36 --> Language Class Initialized
DEBUG - 2013-09-09 15:02:36 --> Loader Class Initialized
DEBUG - 2013-09-09 15:02:36 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:02:37 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:02:37 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:02:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:02:37 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:02:37 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:02:37 --> Session Class Initialized
DEBUG - 2013-09-09 15:02:37 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:02:37 --> Session routines successfully run
DEBUG - 2013-09-09 15:02:37 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:02:37 --> Controller Class Initialized
ERROR - 2013-09-09 15:02:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:37 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:02:37 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:02:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:02:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:02:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:37 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:37 --> Pagination Class Initialized
DEBUG - 2013-09-09 15:02:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:02:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:02:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:02:38 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:02:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:02:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:02:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:02:38 --> File loaded: application/views/staffs/index.php
DEBUG - 2013-09-09 15:02:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:02:38 --> Final output sent to browser
DEBUG - 2013-09-09 15:02:38 --> Total execution time: 1.9211
DEBUG - 2013-09-09 15:02:38 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:38 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:38 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:38 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:38 --> Router Class Initialized
ERROR - 2013-09-09 15:02:38 --> 404 Page Not Found --> css
DEBUG - 2013-09-09 15:02:40 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:40 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Router Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Output Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Security Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Input Class Initialized
DEBUG - 2013-09-09 15:02:40 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:40 --> XSS Filtering completed
DEBUG - 2013-09-09 15:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-09 15:02:40 --> Language Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Loader Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Helper loaded: url_helper
DEBUG - 2013-09-09 15:02:40 --> Helper loaded: file_helper
DEBUG - 2013-09-09 15:02:40 --> Helper loaded: form_helper
DEBUG - 2013-09-09 15:02:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-09 15:02:40 --> Helper loaded: application_helper
DEBUG - 2013-09-09 15:02:40 --> Database Driver Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Session Class Initialized
DEBUG - 2013-09-09 15:02:40 --> Helper loaded: string_helper
DEBUG - 2013-09-09 15:02:41 --> Session routines successfully run
DEBUG - 2013-09-09 15:02:41 --> XML-RPC Class Initialized
DEBUG - 2013-09-09 15:02:41 --> Controller Class Initialized
ERROR - 2013-09-09 15:02:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:41 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-09 15:02:41 --> Helper loaded: cookie_helper
DEBUG - 2013-09-09 15:02:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-09 15:02:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-09 15:02:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-09 15:02:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-09 15:02:41 --> Model Class Initialized
DEBUG - 2013-09-09 15:02:41 --> Pagination Class Initialized
DEBUG - 2013-09-09 15:02:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-09 15:02:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-09 15:02:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-09 15:02:41 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-09 15:02:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-09 15:02:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-09 15:02:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-09 15:02:41 --> File loaded: application/views/mata_pelajaran_persentases/index.php
DEBUG - 2013-09-09 15:02:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-09 15:02:41 --> Final output sent to browser
DEBUG - 2013-09-09 15:02:41 --> Total execution time: 1.8521
DEBUG - 2013-09-09 15:02:42 --> Config Class Initialized
DEBUG - 2013-09-09 15:02:42 --> Hooks Class Initialized
DEBUG - 2013-09-09 15:02:42 --> Utf8 Class Initialized
DEBUG - 2013-09-09 15:02:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-09 15:02:42 --> URI Class Initialized
DEBUG - 2013-09-09 15:02:42 --> Router Class Initialized
ERROR - 2013-09-09 15:02:42 --> 404 Page Not Found --> css
