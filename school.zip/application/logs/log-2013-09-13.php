<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-09-13 09:45:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 09:45:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 09:45:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 09:45:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:02:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:02:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:02:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:02:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:02:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:02:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:02:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:02:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:02:27 --> 404 Page Not Found --> css
ERROR - 2013-09-13 10:05:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:05:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:05:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:05:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:00 --> 404 Page Not Found --> css
ERROR - 2013-09-13 10:06:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:06:35 --> 404 Page Not Found --> css
ERROR - 2013-09-13 10:31:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:31:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:31:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:31:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:31:33 --> Severity: Notice  --> Undefined variable: _SESSION C:\xampp\htdocs\school\application\views\shared\user_menu.php 3
ERROR - 2013-09-13 10:32:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:32:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:32:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:32:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:32:06 --> Severity: Notice  --> Undefined variable: _SESSION C:\xampp\htdocs\school\application\views\shared\user_menu.php 3
ERROR - 2013-09-13 10:33:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:33:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:33:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:33:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:33:33 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\xampp\htdocs\school\application\views\shared\user_menu.php on line 3 and defined C:\xampp\htdocs\school\system\libraries\Session.php 431
ERROR - 2013-09-13 10:33:33 --> Severity: Notice  --> Undefined variable: item C:\xampp\htdocs\school\system\libraries\Session.php 433
ERROR - 2013-09-13 10:33:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:33:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:33:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:33:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:34:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:34:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:34:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:34:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:34:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:34:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:34:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:34:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:48:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:48:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:48:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:48:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:48:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:48:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:48:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:48:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:50:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:33 --> 404 Page Not Found --> css
ERROR - 2013-09-13 10:51:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:41 --> 404 Page Not Found --> css
ERROR - 2013-09-13 10:51:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 10:51:55 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:18:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:18:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:18:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:18:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:18:00 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:22:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:34 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:22:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:38 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:22:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:42 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:22:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:45 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:22:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:50 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:22:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:22:58 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:23:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:06 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:23:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:10 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:23:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:12 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:23:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:23:17 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:49:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:49:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:49:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:49:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:49:15 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:49:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:49:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:49:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:49:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:49:41 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:50:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:47 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:48 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:50:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:58 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:50:58 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:51:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:51:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:51:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:51:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:51:05 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:51:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:51:06 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:52:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:16 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:52:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:21 --> 404 Page Not Found --> css
ERROR - 2013-09-13 11:52:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 11:52:25 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:02:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:02:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:02:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:02:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:02:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:02:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:02:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:02:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:02:57 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:07 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:03:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:28 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:03:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:44 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:03:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:46 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:03:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:47 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:03:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:49 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:03:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:51 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:03:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:03:52 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:10:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:10:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:10:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:10:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:10:02 --> 404 Page Not Found --> css
ERROR - 2013-09-13 15:17:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:17:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:17:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:17:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-13 15:17:21 --> 404 Page Not Found --> css
