<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-06 15:24:41 --> Config Class Initialized
DEBUG - 2013-09-06 15:24:41 --> Hooks Class Initialized
DEBUG - 2013-09-06 15:24:41 --> Utf8 Class Initialized
DEBUG - 2013-09-06 15:24:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-06 15:24:41 --> URI Class Initialized
DEBUG - 2013-09-06 15:24:41 --> Router Class Initialized
ERROR - 2013-09-06 15:24:41 --> 404 Page Not Found --> spps
DEBUG - 2013-09-06 15:24:52 --> Config Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Hooks Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Utf8 Class Initialized
DEBUG - 2013-09-06 15:24:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-06 15:24:52 --> URI Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Router Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Output Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Security Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Input Class Initialized
DEBUG - 2013-09-06 15:24:52 --> XSS Filtering completed
DEBUG - 2013-09-06 15:24:52 --> XSS Filtering completed
DEBUG - 2013-09-06 15:24:52 --> XSS Filtering completed
DEBUG - 2013-09-06 15:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-06 15:24:52 --> Language Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Loader Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Helper loaded: url_helper
DEBUG - 2013-09-06 15:24:52 --> Helper loaded: file_helper
DEBUG - 2013-09-06 15:24:52 --> Helper loaded: form_helper
DEBUG - 2013-09-06 15:24:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-06 15:24:52 --> Helper loaded: application_helper
DEBUG - 2013-09-06 15:24:52 --> Database Driver Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Session Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Helper loaded: string_helper
DEBUG - 2013-09-06 15:24:52 --> A session cookie was not found.
DEBUG - 2013-09-06 15:24:52 --> Session routines successfully run
DEBUG - 2013-09-06 15:24:52 --> XML-RPC Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Controller Class Initialized
ERROR - 2013-09-06 15:24:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:24:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:24:52 --> Model Class Initialized
DEBUG - 2013-09-06 15:24:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-06 15:24:52 --> Helper loaded: cookie_helper
DEBUG - 2013-09-06 15:24:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-06 15:24:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-06 15:24:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:24:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:24:53 --> Config Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Hooks Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Utf8 Class Initialized
DEBUG - 2013-09-06 15:24:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-06 15:24:53 --> URI Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Router Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Output Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Security Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Input Class Initialized
DEBUG - 2013-09-06 15:24:53 --> XSS Filtering completed
DEBUG - 2013-09-06 15:24:53 --> XSS Filtering completed
DEBUG - 2013-09-06 15:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-06 15:24:53 --> Language Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Loader Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Helper loaded: url_helper
DEBUG - 2013-09-06 15:24:53 --> Helper loaded: file_helper
DEBUG - 2013-09-06 15:24:53 --> Helper loaded: form_helper
DEBUG - 2013-09-06 15:24:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-06 15:24:53 --> Helper loaded: application_helper
DEBUG - 2013-09-06 15:24:53 --> Database Driver Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Session Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Helper loaded: string_helper
DEBUG - 2013-09-06 15:24:53 --> Session routines successfully run
DEBUG - 2013-09-06 15:24:53 --> XML-RPC Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Controller Class Initialized
ERROR - 2013-09-06 15:24:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:24:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:24:53 --> Model Class Initialized
DEBUG - 2013-09-06 15:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-06 15:24:53 --> Helper loaded: cookie_helper
DEBUG - 2013-09-06 15:24:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-06 15:24:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-06 15:24:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:24:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:24:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-06 15:24:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-06 15:24:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-06 15:24:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-06 15:24:53 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-06 15:24:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-06 15:24:53 --> Final output sent to browser
DEBUG - 2013-09-06 15:24:53 --> Total execution time: 0.2800
DEBUG - 2013-09-06 15:24:54 --> Config Class Initialized
DEBUG - 2013-09-06 15:24:54 --> Hooks Class Initialized
DEBUG - 2013-09-06 15:24:54 --> Utf8 Class Initialized
DEBUG - 2013-09-06 15:24:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-06 15:24:54 --> URI Class Initialized
DEBUG - 2013-09-06 15:24:54 --> Router Class Initialized
ERROR - 2013-09-06 15:24:54 --> 404 Page Not Found --> css
DEBUG - 2013-09-06 15:25:02 --> Config Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Hooks Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Utf8 Class Initialized
DEBUG - 2013-09-06 15:25:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-06 15:25:02 --> URI Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Router Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Output Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Security Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Input Class Initialized
DEBUG - 2013-09-06 15:25:02 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:02 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:02 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:02 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:02 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:02 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-06 15:25:02 --> Language Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Loader Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Helper loaded: url_helper
DEBUG - 2013-09-06 15:25:02 --> Helper loaded: file_helper
DEBUG - 2013-09-06 15:25:02 --> Helper loaded: form_helper
DEBUG - 2013-09-06 15:25:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-06 15:25:02 --> Helper loaded: application_helper
DEBUG - 2013-09-06 15:25:02 --> Database Driver Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Session Class Initialized
DEBUG - 2013-09-06 15:25:02 --> Helper loaded: string_helper
DEBUG - 2013-09-06 15:25:02 --> Session routines successfully run
DEBUG - 2013-09-06 15:25:03 --> XML-RPC Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Controller Class Initialized
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:25:03 --> Model Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: cookie_helper
DEBUG - 2013-09-06 15:25:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-06 15:25:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:25:03 --> Model Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Form Validation Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-06 15:25:03 --> Config Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Hooks Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Utf8 Class Initialized
DEBUG - 2013-09-06 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-06 15:25:03 --> URI Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Router Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Output Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Security Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Input Class Initialized
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-06 15:25:03 --> Language Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Loader Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: url_helper
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: file_helper
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: form_helper
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: application_helper
DEBUG - 2013-09-06 15:25:03 --> Database Driver Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Session Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: string_helper
DEBUG - 2013-09-06 15:25:03 --> Session routines successfully run
DEBUG - 2013-09-06 15:25:03 --> XML-RPC Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Controller Class Initialized
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:25:03 --> Model Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: cookie_helper
DEBUG - 2013-09-06 15:25:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-06 15:25:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:25:03 --> Config Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Hooks Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Utf8 Class Initialized
DEBUG - 2013-09-06 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-06 15:25:03 --> URI Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Router Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Output Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Security Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Input Class Initialized
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> XSS Filtering completed
DEBUG - 2013-09-06 15:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-06 15:25:03 --> Language Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Loader Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: url_helper
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: file_helper
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: form_helper
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: application_helper
DEBUG - 2013-09-06 15:25:03 --> Database Driver Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Session Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: string_helper
DEBUG - 2013-09-06 15:25:03 --> Session routines successfully run
DEBUG - 2013-09-06 15:25:03 --> XML-RPC Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Controller Class Initialized
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:25:03 --> Model Class Initialized
DEBUG - 2013-09-06 15:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-06 15:25:03 --> Helper loaded: cookie_helper
DEBUG - 2013-09-06 15:25:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-06 15:25:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-06 15:25:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-06 15:25:03 --> Model Class Initialized
DEBUG - 2013-09-06 15:25:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-06 15:25:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-06 15:25:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-06 15:25:03 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-06 15:25:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-06 15:25:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-06 15:25:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-06 15:25:03 --> File loaded: application/views/home.php
DEBUG - 2013-09-06 15:25:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-06 15:25:03 --> Final output sent to browser
DEBUG - 2013-09-06 15:25:03 --> Total execution time: 0.4500
DEBUG - 2013-09-06 15:25:04 --> Config Class Initialized
DEBUG - 2013-09-06 15:25:04 --> Hooks Class Initialized
DEBUG - 2013-09-06 15:25:04 --> Utf8 Class Initialized
DEBUG - 2013-09-06 15:25:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-06 15:25:04 --> URI Class Initialized
DEBUG - 2013-09-06 15:25:04 --> Router Class Initialized
ERROR - 2013-09-06 15:25:04 --> 404 Page Not Found --> css
DEBUG - 2013-09-06 15:25:11 --> Config Class Initialized
DEBUG - 2013-09-06 15:25:11 --> Hooks Class Initialized
DEBUG - 2013-09-06 15:25:11 --> Utf8 Class Initialized
DEBUG - 2013-09-06 15:25:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-06 15:25:11 --> URI Class Initialized
DEBUG - 2013-09-06 15:25:11 --> Router Class Initialized
ERROR - 2013-09-06 15:25:11 --> 404 Page Not Found --> spps
