<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-25 03:08:21 --> Config Class Initialized
DEBUG - 2013-08-25 03:08:21 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:08:21 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:08:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:08:21 --> URI Class Initialized
DEBUG - 2013-08-25 03:08:21 --> Router Class Initialized
DEBUG - 2013-08-25 03:08:21 --> Output Class Initialized
DEBUG - 2013-08-25 03:08:21 --> Security Class Initialized
DEBUG - 2013-08-25 03:08:21 --> Input Class Initialized
DEBUG - 2013-08-25 03:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 03:08:21 --> Language Class Initialized
DEBUG - 2013-08-25 03:08:21 --> Loader Class Initialized
DEBUG - 2013-08-25 03:08:21 --> Helper loaded: url_helper
DEBUG - 2013-08-25 03:08:21 --> Helper loaded: file_helper
DEBUG - 2013-08-25 03:08:21 --> Helper loaded: form_helper
DEBUG - 2013-08-25 03:08:21 --> Database Driver Class Initialized
DEBUG - 2013-08-25 03:08:22 --> Session Class Initialized
DEBUG - 2013-08-25 03:08:22 --> Helper loaded: string_helper
DEBUG - 2013-08-25 03:08:22 --> A session cookie was not found.
DEBUG - 2013-08-25 03:08:22 --> Session routines successfully run
DEBUG - 2013-08-25 03:08:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 03:08:22 --> Controller Class Initialized
ERROR - 2013-08-25 03:08:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:08:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:08:22 --> Model Class Initialized
DEBUG - 2013-08-25 03:08:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 03:08:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 03:08:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 03:08:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 03:08:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:08:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:08:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 03:08:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 03:08:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 03:08:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 03:08:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 03:08:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 03:08:23 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-08-25 03:08:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 03:08:23 --> Final output sent to browser
DEBUG - 2013-08-25 03:08:23 --> Total execution time: 1.8921
DEBUG - 2013-08-25 03:08:23 --> Config Class Initialized
DEBUG - 2013-08-25 03:08:23 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:08:23 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:08:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:08:23 --> URI Class Initialized
DEBUG - 2013-08-25 03:08:23 --> Router Class Initialized
ERROR - 2013-08-25 03:08:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 03:08:27 --> Config Class Initialized
DEBUG - 2013-08-25 03:08:27 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:08:27 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:08:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:08:27 --> URI Class Initialized
DEBUG - 2013-08-25 03:08:27 --> Router Class Initialized
ERROR - 2013-08-25 03:08:27 --> 404 Page Not Found --> admin/tahunajarans
DEBUG - 2013-08-25 03:08:36 --> Config Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:08:36 --> URI Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Router Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Output Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Security Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Input Class Initialized
DEBUG - 2013-08-25 03:08:36 --> XSS Filtering completed
DEBUG - 2013-08-25 03:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 03:08:36 --> Language Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Loader Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Helper loaded: url_helper
DEBUG - 2013-08-25 03:08:36 --> Helper loaded: file_helper
DEBUG - 2013-08-25 03:08:36 --> Helper loaded: form_helper
DEBUG - 2013-08-25 03:08:36 --> Database Driver Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Session Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Helper loaded: string_helper
DEBUG - 2013-08-25 03:08:36 --> Session routines successfully run
DEBUG - 2013-08-25 03:08:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Controller Class Initialized
ERROR - 2013-08-25 03:08:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:08:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:08:36 --> Model Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 03:08:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 03:08:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 03:08:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 03:08:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:08:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:08:36 --> Pagination Class Initialized
DEBUG - 2013-08-25 03:08:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 03:08:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 03:08:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 03:08:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 03:08:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 03:08:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 03:08:36 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-25 03:08:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 03:08:36 --> Final output sent to browser
DEBUG - 2013-08-25 03:08:36 --> Total execution time: 0.4850
DEBUG - 2013-08-25 03:08:36 --> Config Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:08:36 --> URI Class Initialized
DEBUG - 2013-08-25 03:08:36 --> Router Class Initialized
ERROR - 2013-08-25 03:08:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 03:10:03 --> Config Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:10:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:10:03 --> URI Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Router Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Output Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Security Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Input Class Initialized
DEBUG - 2013-08-25 03:10:03 --> XSS Filtering completed
DEBUG - 2013-08-25 03:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 03:10:03 --> Language Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Loader Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Helper loaded: url_helper
DEBUG - 2013-08-25 03:10:03 --> Helper loaded: file_helper
DEBUG - 2013-08-25 03:10:03 --> Helper loaded: form_helper
DEBUG - 2013-08-25 03:10:03 --> Database Driver Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Session Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Helper loaded: string_helper
DEBUG - 2013-08-25 03:10:03 --> Session routines successfully run
DEBUG - 2013-08-25 03:10:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Controller Class Initialized
ERROR - 2013-08-25 03:10:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:10:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:10:03 --> Model Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 03:10:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 03:10:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 03:10:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 03:10:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:10:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:10:03 --> Pagination Class Initialized
DEBUG - 2013-08-25 03:10:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 03:10:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 03:10:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 03:10:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 03:10:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 03:10:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 03:10:03 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-25 03:10:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 03:10:03 --> Final output sent to browser
DEBUG - 2013-08-25 03:10:03 --> Total execution time: 0.3020
DEBUG - 2013-08-25 03:10:03 --> Config Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:10:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:10:03 --> URI Class Initialized
DEBUG - 2013-08-25 03:10:03 --> Router Class Initialized
ERROR - 2013-08-25 03:10:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 03:10:13 --> Config Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:10:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:10:13 --> URI Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Router Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Output Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Security Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Input Class Initialized
DEBUG - 2013-08-25 03:10:13 --> XSS Filtering completed
DEBUG - 2013-08-25 03:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 03:10:13 --> Language Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Loader Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Helper loaded: url_helper
DEBUG - 2013-08-25 03:10:13 --> Helper loaded: file_helper
DEBUG - 2013-08-25 03:10:13 --> Helper loaded: form_helper
DEBUG - 2013-08-25 03:10:13 --> Database Driver Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Session Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Helper loaded: string_helper
DEBUG - 2013-08-25 03:10:13 --> Session routines successfully run
DEBUG - 2013-08-25 03:10:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Controller Class Initialized
ERROR - 2013-08-25 03:10:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:10:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:10:13 --> Model Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 03:10:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 03:10:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 03:10:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 03:10:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:10:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:10:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 03:10:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 03:10:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 03:10:13 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 03:10:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 03:10:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 03:10:13 --> File loaded: application/views/tahun_ajarans/new.php
DEBUG - 2013-08-25 03:10:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 03:10:13 --> Final output sent to browser
DEBUG - 2013-08-25 03:10:13 --> Total execution time: 0.2630
DEBUG - 2013-08-25 03:10:13 --> Config Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:10:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:10:13 --> URI Class Initialized
DEBUG - 2013-08-25 03:10:13 --> Router Class Initialized
ERROR - 2013-08-25 03:10:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 03:10:55 --> Config Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:10:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:10:55 --> URI Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Router Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Output Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Security Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Input Class Initialized
DEBUG - 2013-08-25 03:10:55 --> XSS Filtering completed
DEBUG - 2013-08-25 03:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 03:10:55 --> Language Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Loader Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Helper loaded: url_helper
DEBUG - 2013-08-25 03:10:55 --> Helper loaded: file_helper
DEBUG - 2013-08-25 03:10:55 --> Helper loaded: form_helper
DEBUG - 2013-08-25 03:10:55 --> Database Driver Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Session Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Helper loaded: string_helper
DEBUG - 2013-08-25 03:10:55 --> Session routines successfully run
DEBUG - 2013-08-25 03:10:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Controller Class Initialized
ERROR - 2013-08-25 03:10:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:10:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:10:55 --> Model Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 03:10:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 03:10:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 03:10:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 03:10:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:10:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:10:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 03:10:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 03:10:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 03:10:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 03:10:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 03:10:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 03:10:55 --> File loaded: application/views/tahun_ajarans/new.php
DEBUG - 2013-08-25 03:10:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 03:10:55 --> Final output sent to browser
DEBUG - 2013-08-25 03:10:55 --> Total execution time: 0.2390
DEBUG - 2013-08-25 03:10:55 --> Config Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:10:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:10:55 --> URI Class Initialized
DEBUG - 2013-08-25 03:10:55 --> Router Class Initialized
ERROR - 2013-08-25 03:10:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 03:11:04 --> Config Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:11:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:11:04 --> URI Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Router Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Output Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Security Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Input Class Initialized
DEBUG - 2013-08-25 03:11:04 --> XSS Filtering completed
DEBUG - 2013-08-25 03:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 03:11:04 --> Language Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Loader Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Helper loaded: url_helper
DEBUG - 2013-08-25 03:11:04 --> Helper loaded: file_helper
DEBUG - 2013-08-25 03:11:04 --> Helper loaded: form_helper
DEBUG - 2013-08-25 03:11:04 --> Database Driver Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Session Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Helper loaded: string_helper
DEBUG - 2013-08-25 03:11:04 --> Session routines successfully run
DEBUG - 2013-08-25 03:11:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Controller Class Initialized
ERROR - 2013-08-25 03:11:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:11:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:11:04 --> Model Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 03:11:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 03:11:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 03:11:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 03:11:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:11:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:11:04 --> Pagination Class Initialized
DEBUG - 2013-08-25 03:11:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 03:11:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 03:11:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 03:11:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 03:11:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 03:11:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 03:11:04 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-25 03:11:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 03:11:04 --> Final output sent to browser
DEBUG - 2013-08-25 03:11:04 --> Total execution time: 0.3800
DEBUG - 2013-08-25 03:11:04 --> Config Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:11:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:11:04 --> URI Class Initialized
DEBUG - 2013-08-25 03:11:04 --> Router Class Initialized
ERROR - 2013-08-25 03:11:04 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 03:11:08 --> Config Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:11:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:11:08 --> URI Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Router Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Output Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Security Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Input Class Initialized
DEBUG - 2013-08-25 03:11:08 --> XSS Filtering completed
DEBUG - 2013-08-25 03:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 03:11:08 --> Language Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Loader Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Helper loaded: url_helper
DEBUG - 2013-08-25 03:11:08 --> Helper loaded: file_helper
DEBUG - 2013-08-25 03:11:08 --> Helper loaded: form_helper
DEBUG - 2013-08-25 03:11:08 --> Database Driver Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Session Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Helper loaded: string_helper
DEBUG - 2013-08-25 03:11:08 --> Session routines successfully run
DEBUG - 2013-08-25 03:11:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Controller Class Initialized
ERROR - 2013-08-25 03:11:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:11:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:11:08 --> Model Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 03:11:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 03:11:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 03:11:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 03:11:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:11:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:11:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 03:11:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 03:11:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 03:11:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 03:11:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 03:11:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 03:11:08 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-25 03:11:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 03:11:08 --> Final output sent to browser
DEBUG - 2013-08-25 03:11:08 --> Total execution time: 0.2680
DEBUG - 2013-08-25 03:11:08 --> Config Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:11:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:11:08 --> URI Class Initialized
DEBUG - 2013-08-25 03:11:08 --> Router Class Initialized
ERROR - 2013-08-25 03:11:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 03:16:28 --> Config Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:16:28 --> URI Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Router Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Output Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Security Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Input Class Initialized
DEBUG - 2013-08-25 03:16:28 --> XSS Filtering completed
DEBUG - 2013-08-25 03:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 03:16:28 --> Language Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Loader Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Helper loaded: url_helper
DEBUG - 2013-08-25 03:16:28 --> Helper loaded: file_helper
DEBUG - 2013-08-25 03:16:28 --> Helper loaded: form_helper
DEBUG - 2013-08-25 03:16:28 --> Database Driver Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Session Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Helper loaded: string_helper
DEBUG - 2013-08-25 03:16:28 --> Session routines successfully run
DEBUG - 2013-08-25 03:16:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Controller Class Initialized
ERROR - 2013-08-25 03:16:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:16:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:16:28 --> Model Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 03:16:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 03:16:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 03:16:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 03:16:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:16:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:16:28 --> Pagination Class Initialized
DEBUG - 2013-08-25 03:16:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 03:16:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 03:16:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 03:16:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 03:16:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 03:16:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 03:16:28 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-25 03:16:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 03:16:28 --> Final output sent to browser
DEBUG - 2013-08-25 03:16:28 --> Total execution time: 0.2700
DEBUG - 2013-08-25 03:16:28 --> Config Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:16:28 --> URI Class Initialized
DEBUG - 2013-08-25 03:16:28 --> Router Class Initialized
ERROR - 2013-08-25 03:16:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 03:16:32 --> Config Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:16:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:16:32 --> URI Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Router Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Output Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Security Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Input Class Initialized
DEBUG - 2013-08-25 03:16:32 --> XSS Filtering completed
DEBUG - 2013-08-25 03:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 03:16:32 --> Language Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Loader Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Helper loaded: url_helper
DEBUG - 2013-08-25 03:16:32 --> Helper loaded: file_helper
DEBUG - 2013-08-25 03:16:32 --> Helper loaded: form_helper
DEBUG - 2013-08-25 03:16:32 --> Database Driver Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Session Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Helper loaded: string_helper
DEBUG - 2013-08-25 03:16:32 --> Session routines successfully run
DEBUG - 2013-08-25 03:16:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Controller Class Initialized
ERROR - 2013-08-25 03:16:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:16:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:16:32 --> Model Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 03:16:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 03:16:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 03:16:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 03:16:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 03:16:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 03:16:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 03:16:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 03:16:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 03:16:32 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 03:16:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 03:16:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 03:16:32 --> File loaded: application/views/tahun_ajarans/new.php
DEBUG - 2013-08-25 03:16:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 03:16:32 --> Final output sent to browser
DEBUG - 2013-08-25 03:16:32 --> Total execution time: 0.2480
DEBUG - 2013-08-25 03:16:32 --> Config Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Hooks Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Utf8 Class Initialized
DEBUG - 2013-08-25 03:16:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 03:16:32 --> URI Class Initialized
DEBUG - 2013-08-25 03:16:32 --> Router Class Initialized
ERROR - 2013-08-25 03:16:32 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 06:48:18 --> Config Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:48:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:48:18 --> URI Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Router Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Output Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Security Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Input Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 06:48:18 --> Language Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Loader Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Helper loaded: url_helper
DEBUG - 2013-08-25 06:48:18 --> Helper loaded: file_helper
DEBUG - 2013-08-25 06:48:18 --> Helper loaded: form_helper
DEBUG - 2013-08-25 06:48:18 --> Database Driver Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Session Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Helper loaded: string_helper
DEBUG - 2013-08-25 06:48:18 --> A session cookie was not found.
DEBUG - 2013-08-25 06:48:18 --> Session routines successfully run
DEBUG - 2013-08-25 06:48:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 06:48:18 --> Controller Class Initialized
ERROR - 2013-08-25 06:48:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:48:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:48:18 --> Model Class Initialized
DEBUG - 2013-08-25 06:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 06:48:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 06:48:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 06:48:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 06:48:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:48:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:48:19 --> Pagination Class Initialized
DEBUG - 2013-08-25 06:48:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 06:48:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 06:48:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 06:48:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 06:48:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 06:48:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 06:48:19 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-08-25 06:48:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 06:48:19 --> Final output sent to browser
DEBUG - 2013-08-25 06:48:19 --> Total execution time: 0.9951
DEBUG - 2013-08-25 06:48:19 --> Config Class Initialized
DEBUG - 2013-08-25 06:48:19 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:48:19 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:48:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:48:19 --> URI Class Initialized
DEBUG - 2013-08-25 06:48:19 --> Router Class Initialized
ERROR - 2013-08-25 06:48:19 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 06:48:22 --> Config Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:48:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:48:22 --> URI Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Router Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Output Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Security Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Input Class Initialized
DEBUG - 2013-08-25 06:48:22 --> XSS Filtering completed
DEBUG - 2013-08-25 06:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 06:48:22 --> Language Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Loader Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Helper loaded: url_helper
DEBUG - 2013-08-25 06:48:22 --> Helper loaded: file_helper
DEBUG - 2013-08-25 06:48:22 --> Helper loaded: form_helper
DEBUG - 2013-08-25 06:48:22 --> Database Driver Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Session Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Helper loaded: string_helper
DEBUG - 2013-08-25 06:48:22 --> Session routines successfully run
DEBUG - 2013-08-25 06:48:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Controller Class Initialized
ERROR - 2013-08-25 06:48:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:48:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:48:22 --> Model Class Initialized
DEBUG - 2013-08-25 06:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 06:48:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 06:48:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 06:48:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 06:48:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:48:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:48:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 06:48:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 06:48:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 06:48:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 06:48:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 06:48:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 06:48:22 --> File loaded: application/views/mata_pelajarans/new.php
DEBUG - 2013-08-25 06:48:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 06:48:22 --> Final output sent to browser
DEBUG - 2013-08-25 06:48:23 --> Total execution time: 0.2820
DEBUG - 2013-08-25 06:48:23 --> Config Class Initialized
DEBUG - 2013-08-25 06:48:23 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:48:23 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:48:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:48:23 --> URI Class Initialized
DEBUG - 2013-08-25 06:48:23 --> Router Class Initialized
ERROR - 2013-08-25 06:48:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 06:48:36 --> Config Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:48:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:48:36 --> URI Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Router Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Output Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Security Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Input Class Initialized
DEBUG - 2013-08-25 06:48:36 --> XSS Filtering completed
DEBUG - 2013-08-25 06:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 06:48:36 --> Language Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Loader Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Helper loaded: url_helper
DEBUG - 2013-08-25 06:48:36 --> Helper loaded: file_helper
DEBUG - 2013-08-25 06:48:36 --> Helper loaded: form_helper
DEBUG - 2013-08-25 06:48:36 --> Database Driver Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Session Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Helper loaded: string_helper
DEBUG - 2013-08-25 06:48:36 --> Session routines successfully run
DEBUG - 2013-08-25 06:48:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Controller Class Initialized
ERROR - 2013-08-25 06:48:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:48:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:48:36 --> Model Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 06:48:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 06:48:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 06:48:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 06:48:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:48:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:48:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 06:48:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 06:48:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 06:48:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 06:48:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 06:48:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 06:48:36 --> File loaded: application/views/mata_pelajarans/new.php
DEBUG - 2013-08-25 06:48:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 06:48:36 --> Final output sent to browser
DEBUG - 2013-08-25 06:48:36 --> Total execution time: 0.2900
DEBUG - 2013-08-25 06:48:36 --> Config Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:48:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:48:36 --> URI Class Initialized
DEBUG - 2013-08-25 06:48:36 --> Router Class Initialized
ERROR - 2013-08-25 06:48:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 06:48:55 --> Config Class Initialized
DEBUG - 2013-08-25 06:48:55 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:48:55 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:48:55 --> URI Class Initialized
DEBUG - 2013-08-25 06:48:55 --> Router Class Initialized
ERROR - 2013-08-25 06:48:55 --> 404 Page Not Found --> mata_pelajarans
DEBUG - 2013-08-25 06:50:01 --> Config Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:50:01 --> URI Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Router Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Output Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Security Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Input Class Initialized
DEBUG - 2013-08-25 06:50:01 --> XSS Filtering completed
DEBUG - 2013-08-25 06:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 06:50:01 --> Language Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Loader Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Helper loaded: url_helper
DEBUG - 2013-08-25 06:50:01 --> Helper loaded: file_helper
DEBUG - 2013-08-25 06:50:01 --> Helper loaded: form_helper
DEBUG - 2013-08-25 06:50:01 --> Database Driver Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Session Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Helper loaded: string_helper
DEBUG - 2013-08-25 06:50:01 --> Session routines successfully run
DEBUG - 2013-08-25 06:50:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Controller Class Initialized
ERROR - 2013-08-25 06:50:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:50:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:50:01 --> Model Class Initialized
DEBUG - 2013-08-25 06:50:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 06:50:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 06:50:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 06:50:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 06:50:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:50:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:50:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 06:50:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 06:50:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 06:50:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 06:50:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 06:50:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 06:50:02 --> File loaded: application/views/mata_pelajarans/new.php
DEBUG - 2013-08-25 06:50:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 06:50:02 --> Final output sent to browser
DEBUG - 2013-08-25 06:50:02 --> Total execution time: 0.3480
DEBUG - 2013-08-25 06:50:02 --> Config Class Initialized
DEBUG - 2013-08-25 06:50:02 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:50:02 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:50:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:50:02 --> URI Class Initialized
DEBUG - 2013-08-25 06:50:02 --> Router Class Initialized
ERROR - 2013-08-25 06:50:02 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 06:50:04 --> Config Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:50:04 --> URI Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Router Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Output Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Security Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Input Class Initialized
DEBUG - 2013-08-25 06:50:04 --> XSS Filtering completed
DEBUG - 2013-08-25 06:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 06:50:04 --> Language Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Loader Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Helper loaded: url_helper
DEBUG - 2013-08-25 06:50:04 --> Helper loaded: file_helper
DEBUG - 2013-08-25 06:50:04 --> Helper loaded: form_helper
DEBUG - 2013-08-25 06:50:04 --> Database Driver Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Session Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Helper loaded: string_helper
DEBUG - 2013-08-25 06:50:04 --> Session routines successfully run
DEBUG - 2013-08-25 06:50:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Controller Class Initialized
ERROR - 2013-08-25 06:50:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:50:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:50:04 --> Model Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 06:50:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 06:50:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 06:50:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 06:50:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:50:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:50:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 06:50:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 06:50:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 06:50:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 06:50:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 06:50:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 06:50:04 --> File loaded: application/views/mata_pelajarans/new.php
DEBUG - 2013-08-25 06:50:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 06:50:04 --> Final output sent to browser
DEBUG - 2013-08-25 06:50:04 --> Total execution time: 0.3380
DEBUG - 2013-08-25 06:50:04 --> Config Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:50:04 --> URI Class Initialized
DEBUG - 2013-08-25 06:50:04 --> Router Class Initialized
ERROR - 2013-08-25 06:50:04 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 06:50:11 --> Config Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Hooks Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Utf8 Class Initialized
DEBUG - 2013-08-25 06:50:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 06:50:11 --> URI Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Router Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Output Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Security Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Input Class Initialized
DEBUG - 2013-08-25 06:50:11 --> XSS Filtering completed
DEBUG - 2013-08-25 06:50:11 --> XSS Filtering completed
DEBUG - 2013-08-25 06:50:11 --> XSS Filtering completed
DEBUG - 2013-08-25 06:50:11 --> XSS Filtering completed
DEBUG - 2013-08-25 06:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 06:50:11 --> Language Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Loader Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Helper loaded: url_helper
DEBUG - 2013-08-25 06:50:11 --> Helper loaded: file_helper
DEBUG - 2013-08-25 06:50:11 --> Helper loaded: form_helper
DEBUG - 2013-08-25 06:50:11 --> Database Driver Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Session Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Helper loaded: string_helper
DEBUG - 2013-08-25 06:50:11 --> Session routines successfully run
DEBUG - 2013-08-25 06:50:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Controller Class Initialized
ERROR - 2013-08-25 06:50:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:50:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:50:11 --> Model Class Initialized
DEBUG - 2013-08-25 06:50:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 06:50:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 06:50:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 06:50:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 06:50:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 06:50:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 06:50:11 --> Form Validation Class Initialized
DEBUG - 2013-08-25 06:50:11 --> XSS Filtering completed
DEBUG - 2013-08-25 06:50:11 --> XSS Filtering completed
DEBUG - 2013-08-25 06:50:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-25 06:50:12 --> DB Transaction Failure
ERROR - 2013-08-25 06:50:12 --> Query error: Field 'jumlah_jam' doesn't have a default value
DEBUG - 2013-08-25 06:50:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-25 07:00:02 --> Config Class Initialized
DEBUG - 2013-08-25 07:00:02 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:00:02 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:00:02 --> URI Class Initialized
DEBUG - 2013-08-25 07:00:02 --> Router Class Initialized
DEBUG - 2013-08-25 07:00:02 --> Output Class Initialized
DEBUG - 2013-08-25 07:00:02 --> Security Class Initialized
DEBUG - 2013-08-25 07:00:02 --> Input Class Initialized
DEBUG - 2013-08-25 07:00:02 --> XSS Filtering completed
DEBUG - 2013-08-25 07:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 07:00:02 --> Language Class Initialized
DEBUG - 2013-08-25 07:00:02 --> Loader Class Initialized
DEBUG - 2013-08-25 07:00:02 --> Helper loaded: url_helper
DEBUG - 2013-08-25 07:00:02 --> Helper loaded: file_helper
DEBUG - 2013-08-25 07:00:02 --> Helper loaded: form_helper
DEBUG - 2013-08-25 07:00:03 --> Database Driver Class Initialized
DEBUG - 2013-08-25 07:00:03 --> Session Class Initialized
DEBUG - 2013-08-25 07:00:03 --> Helper loaded: string_helper
DEBUG - 2013-08-25 07:00:03 --> Session routines successfully run
DEBUG - 2013-08-25 07:00:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 07:00:03 --> Controller Class Initialized
ERROR - 2013-08-25 07:00:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:00:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:00:03 --> Model Class Initialized
DEBUG - 2013-08-25 07:00:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 07:00:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 07:00:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 07:00:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 07:00:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:00:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:00:03 --> Form Validation Class Initialized
DEBUG - 2013-08-25 07:00:03 --> Config Class Initialized
DEBUG - 2013-08-25 07:00:03 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:00:03 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:00:03 --> URI Class Initialized
DEBUG - 2013-08-25 07:00:03 --> Router Class Initialized
ERROR - 2013-08-25 07:00:03 --> 404 Page Not Found --> mata_pelajarans
DEBUG - 2013-08-25 07:01:11 --> Config Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:01:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:01:11 --> URI Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Router Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Output Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Security Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Input Class Initialized
DEBUG - 2013-08-25 07:01:11 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 07:01:11 --> Language Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Loader Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Helper loaded: url_helper
DEBUG - 2013-08-25 07:01:11 --> Helper loaded: file_helper
DEBUG - 2013-08-25 07:01:11 --> Helper loaded: form_helper
DEBUG - 2013-08-25 07:01:11 --> Database Driver Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Session Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Helper loaded: string_helper
DEBUG - 2013-08-25 07:01:11 --> Session routines successfully run
DEBUG - 2013-08-25 07:01:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Controller Class Initialized
ERROR - 2013-08-25 07:01:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:01:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:01:11 --> Model Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 07:01:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 07:01:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 07:01:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 07:01:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:01:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:01:11 --> Pagination Class Initialized
DEBUG - 2013-08-25 07:01:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 07:01:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 07:01:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 07:01:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 07:01:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 07:01:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 07:01:11 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-08-25 07:01:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 07:01:11 --> Final output sent to browser
DEBUG - 2013-08-25 07:01:11 --> Total execution time: 0.3650
DEBUG - 2013-08-25 07:01:11 --> Config Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:01:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:01:11 --> URI Class Initialized
DEBUG - 2013-08-25 07:01:11 --> Router Class Initialized
ERROR - 2013-08-25 07:01:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 07:01:13 --> Config Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:01:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:01:13 --> URI Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Router Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Output Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Security Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Input Class Initialized
DEBUG - 2013-08-25 07:01:13 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 07:01:13 --> Language Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Loader Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Helper loaded: url_helper
DEBUG - 2013-08-25 07:01:13 --> Helper loaded: file_helper
DEBUG - 2013-08-25 07:01:13 --> Helper loaded: form_helper
DEBUG - 2013-08-25 07:01:13 --> Database Driver Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Session Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Helper loaded: string_helper
DEBUG - 2013-08-25 07:01:13 --> Session routines successfully run
DEBUG - 2013-08-25 07:01:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 07:01:13 --> Controller Class Initialized
ERROR - 2013-08-25 07:01:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:01:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:01:14 --> Model Class Initialized
DEBUG - 2013-08-25 07:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 07:01:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 07:01:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 07:01:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 07:01:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:01:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:01:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 07:01:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 07:01:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 07:01:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 07:01:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 07:01:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 07:01:14 --> File loaded: application/views/mata_pelajarans/new.php
DEBUG - 2013-08-25 07:01:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 07:01:14 --> Final output sent to browser
DEBUG - 2013-08-25 07:01:14 --> Total execution time: 0.3150
DEBUG - 2013-08-25 07:01:14 --> Config Class Initialized
DEBUG - 2013-08-25 07:01:14 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:01:14 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:01:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:01:14 --> URI Class Initialized
DEBUG - 2013-08-25 07:01:14 --> Router Class Initialized
ERROR - 2013-08-25 07:01:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 07:01:22 --> Config Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:01:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:01:22 --> URI Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Router Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Output Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Security Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Input Class Initialized
DEBUG - 2013-08-25 07:01:22 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:22 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:22 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:22 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:22 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 07:01:22 --> Language Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Loader Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: url_helper
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: file_helper
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: form_helper
DEBUG - 2013-08-25 07:01:22 --> Database Driver Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Session Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: string_helper
DEBUG - 2013-08-25 07:01:22 --> Session routines successfully run
DEBUG - 2013-08-25 07:01:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Controller Class Initialized
ERROR - 2013-08-25 07:01:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:01:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:01:22 --> Model Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 07:01:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 07:01:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 07:01:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:01:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:01:22 --> Form Validation Class Initialized
DEBUG - 2013-08-25 07:01:22 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:22 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:22 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-25 07:01:22 --> Config Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:01:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:01:22 --> URI Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Router Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Output Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Security Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Input Class Initialized
DEBUG - 2013-08-25 07:01:22 --> XSS Filtering completed
DEBUG - 2013-08-25 07:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 07:01:22 --> Language Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Loader Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: url_helper
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: file_helper
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: form_helper
DEBUG - 2013-08-25 07:01:22 --> Database Driver Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Session Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: string_helper
DEBUG - 2013-08-25 07:01:22 --> Session routines successfully run
DEBUG - 2013-08-25 07:01:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Controller Class Initialized
ERROR - 2013-08-25 07:01:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:01:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:01:22 --> Model Class Initialized
DEBUG - 2013-08-25 07:01:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 07:01:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 07:01:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 07:01:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 07:01:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:01:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:01:22 --> Pagination Class Initialized
DEBUG - 2013-08-25 07:01:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 07:01:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 07:01:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 07:01:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 07:01:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 07:01:22 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-25 07:01:22 --> Severity: Notice  --> Undefined variable: 1 C:\xampp\htdocs\school\application\views\mata_pelajarans\index.php 74
ERROR - 2013-08-25 07:01:22 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\mata_pelajarans\index.php 82
DEBUG - 2013-08-25 07:01:22 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-08-25 07:01:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 07:01:23 --> Final output sent to browser
DEBUG - 2013-08-25 07:01:23 --> Total execution time: 0.3970
DEBUG - 2013-08-25 07:01:23 --> Config Class Initialized
DEBUG - 2013-08-25 07:01:23 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:01:23 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:01:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:01:23 --> URI Class Initialized
DEBUG - 2013-08-25 07:01:23 --> Router Class Initialized
ERROR - 2013-08-25 07:01:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 07:02:07 --> Config Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:02:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:02:07 --> URI Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Router Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Output Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Security Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Input Class Initialized
DEBUG - 2013-08-25 07:02:07 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 07:02:07 --> Language Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Loader Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Helper loaded: url_helper
DEBUG - 2013-08-25 07:02:07 --> Helper loaded: file_helper
DEBUG - 2013-08-25 07:02:07 --> Helper loaded: form_helper
DEBUG - 2013-08-25 07:02:07 --> Database Driver Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Session Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Helper loaded: string_helper
DEBUG - 2013-08-25 07:02:07 --> Session routines successfully run
DEBUG - 2013-08-25 07:02:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Controller Class Initialized
ERROR - 2013-08-25 07:02:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:02:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:02:07 --> Model Class Initialized
DEBUG - 2013-08-25 07:02:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 07:02:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 07:02:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 07:02:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 07:02:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:02:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:02:07 --> Pagination Class Initialized
DEBUG - 2013-08-25 07:02:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 07:02:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 07:02:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 07:02:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 07:02:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 07:02:08 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-25 07:02:08 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\mata_pelajarans\index.php 82
DEBUG - 2013-08-25 07:02:08 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-08-25 07:02:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 07:02:08 --> Final output sent to browser
DEBUG - 2013-08-25 07:02:08 --> Total execution time: 0.3490
DEBUG - 2013-08-25 07:02:08 --> Config Class Initialized
DEBUG - 2013-08-25 07:02:08 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:02:08 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:02:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:02:08 --> URI Class Initialized
DEBUG - 2013-08-25 07:02:08 --> Router Class Initialized
ERROR - 2013-08-25 07:02:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 07:02:14 --> Config Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:02:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:02:14 --> URI Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Router Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Output Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Security Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Input Class Initialized
DEBUG - 2013-08-25 07:02:14 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 07:02:14 --> Language Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Loader Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Helper loaded: url_helper
DEBUG - 2013-08-25 07:02:14 --> Helper loaded: file_helper
DEBUG - 2013-08-25 07:02:14 --> Helper loaded: form_helper
DEBUG - 2013-08-25 07:02:14 --> Database Driver Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Session Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Helper loaded: string_helper
DEBUG - 2013-08-25 07:02:14 --> Session routines successfully run
DEBUG - 2013-08-25 07:02:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Controller Class Initialized
ERROR - 2013-08-25 07:02:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:02:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:02:14 --> Model Class Initialized
DEBUG - 2013-08-25 07:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 07:02:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 07:02:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 07:02:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 07:02:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:02:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:02:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 07:02:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 07:02:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 07:02:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 07:02:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 07:02:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 07:02:14 --> File loaded: application/views/mata_pelajarans/edit.php
DEBUG - 2013-08-25 07:02:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 07:02:15 --> Final output sent to browser
DEBUG - 2013-08-25 07:02:15 --> Total execution time: 0.3570
DEBUG - 2013-08-25 07:02:15 --> Config Class Initialized
DEBUG - 2013-08-25 07:02:15 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:02:15 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:02:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:02:15 --> URI Class Initialized
DEBUG - 2013-08-25 07:02:15 --> Router Class Initialized
ERROR - 2013-08-25 07:02:15 --> 404 Page Not Found --> css
DEBUG - 2013-08-25 07:02:23 --> Config Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:02:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:02:23 --> URI Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Router Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Output Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Security Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Input Class Initialized
DEBUG - 2013-08-25 07:02:23 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:23 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:23 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:23 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:23 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 07:02:23 --> Language Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Loader Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Helper loaded: url_helper
DEBUG - 2013-08-25 07:02:23 --> Helper loaded: file_helper
DEBUG - 2013-08-25 07:02:23 --> Helper loaded: form_helper
DEBUG - 2013-08-25 07:02:23 --> Database Driver Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Session Class Initialized
DEBUG - 2013-08-25 07:02:23 --> Helper loaded: string_helper
DEBUG - 2013-08-25 07:02:24 --> Session routines successfully run
DEBUG - 2013-08-25 07:02:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Controller Class Initialized
ERROR - 2013-08-25 07:02:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:02:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:02:24 --> Model Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 07:02:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 07:02:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 07:02:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 07:02:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:02:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:02:24 --> Form Validation Class Initialized
DEBUG - 2013-08-25 07:02:24 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:24 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:24 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-25 07:02:24 --> Config Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:02:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:02:24 --> URI Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Router Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Output Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Security Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Input Class Initialized
DEBUG - 2013-08-25 07:02:24 --> XSS Filtering completed
DEBUG - 2013-08-25 07:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-25 07:02:24 --> Language Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Loader Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Helper loaded: url_helper
DEBUG - 2013-08-25 07:02:24 --> Helper loaded: file_helper
DEBUG - 2013-08-25 07:02:24 --> Helper loaded: form_helper
DEBUG - 2013-08-25 07:02:24 --> Database Driver Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Session Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Helper loaded: string_helper
DEBUG - 2013-08-25 07:02:24 --> Session routines successfully run
DEBUG - 2013-08-25 07:02:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Controller Class Initialized
ERROR - 2013-08-25 07:02:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:02:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:02:24 --> Model Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-25 07:02:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-25 07:02:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-25 07:02:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-25 07:02:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-25 07:02:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-25 07:02:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-25 07:02:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-25 07:02:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-25 07:02:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-25 07:02:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-25 07:02:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-25 07:02:24 --> File loaded: application/views/mata_pelajarans/edit.php
DEBUG - 2013-08-25 07:02:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-25 07:02:24 --> Final output sent to browser
DEBUG - 2013-08-25 07:02:24 --> Total execution time: 0.3910
DEBUG - 2013-08-25 07:02:24 --> Config Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Hooks Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Utf8 Class Initialized
DEBUG - 2013-08-25 07:02:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-25 07:02:24 --> URI Class Initialized
DEBUG - 2013-08-25 07:02:24 --> Router Class Initialized
ERROR - 2013-08-25 07:02:24 --> 404 Page Not Found --> css
