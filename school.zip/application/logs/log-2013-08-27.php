<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-27 00:41:33 --> Config Class Initialized
DEBUG - 2013-08-27 00:41:33 --> Hooks Class Initialized
DEBUG - 2013-08-27 00:41:33 --> Utf8 Class Initialized
DEBUG - 2013-08-27 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 00:41:33 --> URI Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Router Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Output Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Security Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Input Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 00:41:34 --> Language Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Loader Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Helper loaded: url_helper
DEBUG - 2013-08-27 00:41:34 --> Helper loaded: file_helper
DEBUG - 2013-08-27 00:41:34 --> Helper loaded: form_helper
DEBUG - 2013-08-27 00:41:34 --> Database Driver Class Initialized
ERROR - 2013-08-27 00:41:34 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp\htdocs\school\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-08-27 00:41:34 --> Session Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Helper loaded: string_helper
DEBUG - 2013-08-27 00:41:34 --> A session cookie was not found.
DEBUG - 2013-08-27 00:41:34 --> Session routines successfully run
DEBUG - 2013-08-27 00:41:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Controller Class Initialized
ERROR - 2013-08-27 00:41:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 00:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 00:41:34 --> Model Class Initialized
DEBUG - 2013-08-27 00:41:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 00:41:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 00:41:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 00:41:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 00:41:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 00:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 00:41:34 --> Pagination Class Initialized
ERROR - 2013-08-27 00:41:34 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 00:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 00:41:53 --> Config Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Hooks Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Utf8 Class Initialized
DEBUG - 2013-08-27 00:41:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 00:41:53 --> URI Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Router Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Output Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Security Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Input Class Initialized
DEBUG - 2013-08-27 00:41:53 --> XSS Filtering completed
DEBUG - 2013-08-27 00:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 00:41:53 --> Language Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Loader Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Helper loaded: url_helper
DEBUG - 2013-08-27 00:41:53 --> Helper loaded: file_helper
DEBUG - 2013-08-27 00:41:53 --> Helper loaded: form_helper
DEBUG - 2013-08-27 00:41:53 --> Database Driver Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Session Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Helper loaded: string_helper
DEBUG - 2013-08-27 00:41:53 --> Session routines successfully run
DEBUG - 2013-08-27 00:41:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Controller Class Initialized
ERROR - 2013-08-27 00:41:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 00:41:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 00:41:53 --> Model Class Initialized
DEBUG - 2013-08-27 00:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 00:41:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 00:41:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 00:41:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 00:41:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 00:41:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 00:41:53 --> Pagination Class Initialized
ERROR - 2013-08-27 00:41:53 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 00:41:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 00:45:04 --> Config Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Hooks Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Utf8 Class Initialized
DEBUG - 2013-08-27 00:45:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 00:45:04 --> URI Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Router Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Output Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Security Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Input Class Initialized
DEBUG - 2013-08-27 00:45:04 --> XSS Filtering completed
DEBUG - 2013-08-27 00:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 00:45:04 --> Language Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Loader Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Helper loaded: url_helper
DEBUG - 2013-08-27 00:45:04 --> Helper loaded: file_helper
DEBUG - 2013-08-27 00:45:04 --> Helper loaded: form_helper
DEBUG - 2013-08-27 00:45:04 --> Database Driver Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Session Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Helper loaded: string_helper
DEBUG - 2013-08-27 00:45:04 --> Session routines successfully run
DEBUG - 2013-08-27 00:45:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Controller Class Initialized
ERROR - 2013-08-27 00:45:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 00:45:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 00:45:04 --> Model Class Initialized
DEBUG - 2013-08-27 00:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 00:45:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 00:45:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 00:45:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 00:45:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 00:45:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 00:45:04 --> Pagination Class Initialized
ERROR - 2013-08-27 00:45:04 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 00:45:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:04:00 --> Config Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Hooks Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Utf8 Class Initialized
DEBUG - 2013-08-27 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 01:04:00 --> URI Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Router Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Output Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Security Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Input Class Initialized
DEBUG - 2013-08-27 01:04:00 --> XSS Filtering completed
DEBUG - 2013-08-27 01:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 01:04:00 --> Language Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Loader Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Helper loaded: url_helper
DEBUG - 2013-08-27 01:04:00 --> Helper loaded: file_helper
DEBUG - 2013-08-27 01:04:00 --> Helper loaded: form_helper
DEBUG - 2013-08-27 01:04:00 --> Database Driver Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Session Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Helper loaded: string_helper
DEBUG - 2013-08-27 01:04:00 --> Session routines successfully run
DEBUG - 2013-08-27 01:04:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Controller Class Initialized
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:04:00 --> Model Class Initialized
DEBUG - 2013-08-27 01:04:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 01:04:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 01:04:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 01:04:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:04:00 --> Pagination Class Initialized
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Shared_String.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Shared_String.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/MY_Phpexcel.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Phpexcel.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation_Function.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation_Function.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_Logger.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_Logger.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_IComparable.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_IComparable.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorageFactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorageFactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_Memory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_Memory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_CacheBase.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_CacheBase.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_ICache.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_ICache.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageSetup.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageSetup.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageMargins.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageMargins.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_HeaderFooter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_HeaderFooter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_SheetView.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_SheetView.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_RowDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_RowDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_ColumnDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_ColumnDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_AutoFilter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_AutoFilter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentProperties.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentProperties.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentSecurity.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentSecurity.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Supervisor.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Supervisor.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Font.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Font.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Color.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Color.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Fill.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Fill.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Borders.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Borders.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Border.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Border.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Alignment.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Alignment.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_NumberFormat.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_NumberFormat.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/MY_Iofactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Iofactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(application/core/Iofactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Iofactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:00 --> Non-existent class: Iofactory
DEBUG - 2013-08-27 01:04:35 --> Config Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Hooks Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Utf8 Class Initialized
DEBUG - 2013-08-27 01:04:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 01:04:35 --> URI Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Router Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Output Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Security Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Input Class Initialized
DEBUG - 2013-08-27 01:04:35 --> XSS Filtering completed
DEBUG - 2013-08-27 01:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 01:04:35 --> Language Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Loader Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Helper loaded: url_helper
DEBUG - 2013-08-27 01:04:35 --> Helper loaded: file_helper
DEBUG - 2013-08-27 01:04:35 --> Helper loaded: form_helper
DEBUG - 2013-08-27 01:04:35 --> Database Driver Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Session Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Helper loaded: string_helper
DEBUG - 2013-08-27 01:04:35 --> Session routines successfully run
DEBUG - 2013-08-27 01:04:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Controller Class Initialized
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:04:35 --> Model Class Initialized
DEBUG - 2013-08-27 01:04:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 01:04:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 01:04:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 01:04:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:04:35 --> Pagination Class Initialized
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Shared_String.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Shared_String.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/MY_Phpexcel.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Phpexcel.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation_Function.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation_Function.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_Logger.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_Logger.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_IComparable.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_IComparable.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorageFactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorageFactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_Memory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_Memory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_CacheBase.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_CacheBase.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_ICache.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_ICache.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageSetup.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageSetup.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageMargins.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageMargins.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_HeaderFooter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_HeaderFooter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_SheetView.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_SheetView.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_RowDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_RowDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_ColumnDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_ColumnDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_AutoFilter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_AutoFilter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentProperties.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentProperties.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentSecurity.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentSecurity.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Supervisor.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Supervisor.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Font.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Font.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Color.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Color.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Fill.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Fill.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Borders.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Borders.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Border.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Border.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Alignment.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Alignment.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_NumberFormat.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_NumberFormat.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(application/core/MY_IOfactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_IOfactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:36 --> Severity: Warning  --> include_once(application/core/IOfactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/IOfactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:36 --> Non-existent class: IOfactory
DEBUG - 2013-08-27 01:04:42 --> Config Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Hooks Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Utf8 Class Initialized
DEBUG - 2013-08-27 01:04:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 01:04:42 --> URI Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Router Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Output Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Security Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Input Class Initialized
DEBUG - 2013-08-27 01:04:42 --> XSS Filtering completed
DEBUG - 2013-08-27 01:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 01:04:42 --> Language Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Loader Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Helper loaded: url_helper
DEBUG - 2013-08-27 01:04:42 --> Helper loaded: file_helper
DEBUG - 2013-08-27 01:04:42 --> Helper loaded: form_helper
DEBUG - 2013-08-27 01:04:42 --> Database Driver Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Session Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Helper loaded: string_helper
DEBUG - 2013-08-27 01:04:42 --> Session routines successfully run
DEBUG - 2013-08-27 01:04:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Controller Class Initialized
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:04:42 --> Model Class Initialized
DEBUG - 2013-08-27 01:04:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 01:04:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 01:04:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 01:04:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:04:42 --> Pagination Class Initialized
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Shared_String.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Shared_String.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/MY_Phpexcel.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Phpexcel.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation_Function.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation_Function.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_Logger.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_Logger.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_IComparable.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_IComparable.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorageFactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorageFactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_Memory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_Memory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_CacheBase.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_CacheBase.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_ICache.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_ICache.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageSetup.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageSetup.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageMargins.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageMargins.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_HeaderFooter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_HeaderFooter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_SheetView.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_SheetView.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_RowDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_RowDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_ColumnDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_ColumnDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_AutoFilter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_AutoFilter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentProperties.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentProperties.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentSecurity.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentSecurity.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Supervisor.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Supervisor.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Font.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Font.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Color.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Color.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Fill.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Fill.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Borders.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Borders.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Border.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Border.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Alignment.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Alignment.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_NumberFormat.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_NumberFormat.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/MY_IOFactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_IOFactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(application/core/IOFactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/IOFactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:04:42 --> Non-existent class: IOFactory
DEBUG - 2013-08-27 01:05:09 --> Config Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Hooks Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Utf8 Class Initialized
DEBUG - 2013-08-27 01:05:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 01:05:09 --> URI Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Router Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Output Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Security Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Input Class Initialized
DEBUG - 2013-08-27 01:05:09 --> XSS Filtering completed
DEBUG - 2013-08-27 01:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 01:05:09 --> Language Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Loader Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Helper loaded: url_helper
DEBUG - 2013-08-27 01:05:09 --> Helper loaded: file_helper
DEBUG - 2013-08-27 01:05:09 --> Helper loaded: form_helper
DEBUG - 2013-08-27 01:05:09 --> Database Driver Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Session Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Helper loaded: string_helper
DEBUG - 2013-08-27 01:05:09 --> Session routines successfully run
DEBUG - 2013-08-27 01:05:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Controller Class Initialized
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:05:09 --> Model Class Initialized
DEBUG - 2013-08-27 01:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 01:05:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 01:05:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 01:05:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:05:09 --> Pagination Class Initialized
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(application/core/PHPExcel_Shared_String.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Shared_String.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(application/core/MY_Phpexcel.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Phpexcel.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation_Function.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation_Function.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_Logger.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_Logger.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_IComparable.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_IComparable.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorageFactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorageFactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_Memory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_Memory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_CacheBase.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_CacheBase.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_ICache.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_ICache.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageSetup.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageSetup.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageMargins.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageMargins.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_HeaderFooter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_HeaderFooter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_SheetView.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_SheetView.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_RowDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_RowDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_ColumnDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_ColumnDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_AutoFilter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_AutoFilter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentProperties.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentProperties.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentSecurity.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentSecurity.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Supervisor.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Supervisor.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Font.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Font.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Color.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Color.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Fill.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Fill.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Borders.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Borders.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Border.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Border.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Alignment.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Alignment.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_NumberFormat.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_NumberFormat.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/MY_Iofactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Iofactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(application/core/Iofactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Iofactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:05:10 --> Non-existent class: Iofactory
DEBUG - 2013-08-27 01:08:33 --> Config Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Hooks Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Utf8 Class Initialized
DEBUG - 2013-08-27 01:08:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 01:08:33 --> URI Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Router Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Output Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Security Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Input Class Initialized
DEBUG - 2013-08-27 01:08:33 --> XSS Filtering completed
DEBUG - 2013-08-27 01:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 01:08:33 --> Language Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Loader Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Helper loaded: url_helper
DEBUG - 2013-08-27 01:08:33 --> Helper loaded: file_helper
DEBUG - 2013-08-27 01:08:33 --> Helper loaded: form_helper
DEBUG - 2013-08-27 01:08:33 --> Database Driver Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Session Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Helper loaded: string_helper
DEBUG - 2013-08-27 01:08:33 --> Session routines successfully run
DEBUG - 2013-08-27 01:08:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Controller Class Initialized
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:08:33 --> Model Class Initialized
DEBUG - 2013-08-27 01:08:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 01:08:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 01:08:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 01:08:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 01:08:33 --> Pagination Class Initialized
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Shared_String.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Shared_String.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/MY_Phpexcel.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Phpexcel.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Calculation_Function.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Calculation_Function.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_CyclicReferenceStack.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_CalcEngine_Logger.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CalcEngine_Logger.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_IComparable.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_IComparable.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorageFactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorageFactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_Memory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_Memory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_CacheBase.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_CacheBase.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_CachedObjectStorage_ICache.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_CachedObjectStorage_ICache.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageSetup.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageSetup.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_PageMargins.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_PageMargins.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_HeaderFooter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_HeaderFooter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_SheetView.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_SheetView.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_RowDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_RowDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_ColumnDimension.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_ColumnDimension.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Worksheet_AutoFilter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Worksheet_AutoFilter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentProperties.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentProperties.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_DocumentSecurity.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_DocumentSecurity.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Supervisor.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Supervisor.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Font.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Font.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Color.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Color.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Fill.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Fill.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Borders.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Borders.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:33 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Border.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Border.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Alignment.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Alignment.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_NumberFormat.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_NumberFormat.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Style_Protection.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Style_Protection.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_IOFactory.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_IOFactory.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Reader_Excel5.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Reader_Excel5.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Reader_Abstract.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Reader_Abstract.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Reader_IReader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Reader_IReader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Reader_DefaultReadFilter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Reader_DefaultReadFilter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Reader_IReadFilter.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Reader_IReadFilter.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Shared_OLERead.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Shared_OLERead.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Reader_Exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Reader_Exception.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(application/core/PHPExcel_Exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 01:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/PHPExcel_Exception.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:35:24 --> Config Class Initialized
DEBUG - 2013-08-27 03:35:24 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:35:24 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:35:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:35:24 --> URI Class Initialized
DEBUG - 2013-08-27 03:35:25 --> Router Class Initialized
DEBUG - 2013-08-27 03:35:25 --> Output Class Initialized
DEBUG - 2013-08-27 03:35:26 --> Security Class Initialized
DEBUG - 2013-08-27 03:35:26 --> Input Class Initialized
DEBUG - 2013-08-27 03:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:35:26 --> Language Class Initialized
DEBUG - 2013-08-27 03:35:27 --> Loader Class Initialized
DEBUG - 2013-08-27 03:35:27 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:35:27 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:35:27 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:35:27 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:35:29 --> Session Class Initialized
DEBUG - 2013-08-27 03:35:29 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:35:29 --> A session cookie was not found.
DEBUG - 2013-08-27 03:35:31 --> Session routines successfully run
DEBUG - 2013-08-27 03:35:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:35:31 --> Controller Class Initialized
ERROR - 2013-08-27 03:35:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:35:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:35:31 --> Model Class Initialized
DEBUG - 2013-08-27 03:35:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:35:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:35:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:35:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:35:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:35:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:35:33 --> Pagination Class Initialized
ERROR - 2013-08-27 03:35:33 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:35:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:41:19 --> Config Class Initialized
DEBUG - 2013-08-27 03:41:19 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:41:19 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:41:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:41:19 --> URI Class Initialized
DEBUG - 2013-08-27 03:41:19 --> Router Class Initialized
DEBUG - 2013-08-27 03:41:19 --> Output Class Initialized
DEBUG - 2013-08-27 03:41:19 --> Security Class Initialized
DEBUG - 2013-08-27 03:41:19 --> Input Class Initialized
DEBUG - 2013-08-27 03:41:19 --> XSS Filtering completed
DEBUG - 2013-08-27 03:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:41:20 --> Language Class Initialized
DEBUG - 2013-08-27 03:41:20 --> Loader Class Initialized
DEBUG - 2013-08-27 03:41:20 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:41:20 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:41:20 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:41:20 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:41:20 --> Session Class Initialized
DEBUG - 2013-08-27 03:41:20 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:41:20 --> Session routines successfully run
DEBUG - 2013-08-27 03:41:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:41:20 --> Controller Class Initialized
ERROR - 2013-08-27 03:41:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:41:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:41:20 --> Model Class Initialized
DEBUG - 2013-08-27 03:41:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:41:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:41:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:41:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:41:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:41:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:41:20 --> Pagination Class Initialized
DEBUG - 2013-08-27 03:41:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:41:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:41:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:41:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:41:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:41:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 03:41:20 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-27 03:41:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:41:20 --> Final output sent to browser
DEBUG - 2013-08-27 03:41:20 --> Total execution time: 1.0961
DEBUG - 2013-08-27 03:41:21 --> Config Class Initialized
DEBUG - 2013-08-27 03:41:21 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:41:21 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:41:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:41:21 --> URI Class Initialized
DEBUG - 2013-08-27 03:41:21 --> Router Class Initialized
ERROR - 2013-08-27 03:41:21 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 03:42:51 --> Config Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:42:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:42:51 --> URI Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Router Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Output Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Security Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Input Class Initialized
DEBUG - 2013-08-27 03:42:51 --> XSS Filtering completed
DEBUG - 2013-08-27 03:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:42:51 --> Language Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Loader Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:42:51 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:42:51 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:42:51 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Session Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:42:51 --> Session routines successfully run
DEBUG - 2013-08-27 03:42:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Controller Class Initialized
ERROR - 2013-08-27 03:42:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:42:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:42:51 --> Model Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:42:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:42:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:42:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:42:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:42:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:42:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:42:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:42:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:42:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:42:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:42:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 03:42:51 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-27 03:42:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:42:51 --> Final output sent to browser
DEBUG - 2013-08-27 03:42:51 --> Total execution time: 0.5390
DEBUG - 2013-08-27 03:42:51 --> Config Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:42:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:42:51 --> URI Class Initialized
DEBUG - 2013-08-27 03:42:51 --> Router Class Initialized
ERROR - 2013-08-27 03:42:51 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 03:42:57 --> Config Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:42:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:42:57 --> URI Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Router Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Output Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Security Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Input Class Initialized
DEBUG - 2013-08-27 03:42:57 --> XSS Filtering completed
DEBUG - 2013-08-27 03:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:42:57 --> Language Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Loader Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:42:57 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:42:57 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:42:57 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Session Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:42:57 --> Session routines successfully run
DEBUG - 2013-08-27 03:42:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Controller Class Initialized
ERROR - 2013-08-27 03:42:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:42:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:42:57 --> Model Class Initialized
DEBUG - 2013-08-27 03:42:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:42:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:42:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:42:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:42:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:42:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:42:57 --> Pagination Class Initialized
DEBUG - 2013-08-27 03:42:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:42:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:42:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:42:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:42:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:42:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 03:42:57 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-27 03:42:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:42:57 --> Final output sent to browser
DEBUG - 2013-08-27 03:42:57 --> Total execution time: 0.6400
DEBUG - 2013-08-27 03:42:58 --> Config Class Initialized
DEBUG - 2013-08-27 03:42:58 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:42:58 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:42:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:42:58 --> URI Class Initialized
DEBUG - 2013-08-27 03:42:58 --> Router Class Initialized
ERROR - 2013-08-27 03:42:58 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 03:43:49 --> Config Class Initialized
DEBUG - 2013-08-27 03:43:49 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:43:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:43:50 --> URI Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Router Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Output Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Security Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Input Class Initialized
DEBUG - 2013-08-27 03:43:50 --> XSS Filtering completed
DEBUG - 2013-08-27 03:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:43:50 --> Language Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Loader Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:43:50 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:43:50 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:43:50 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Session Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:43:50 --> Session routines successfully run
DEBUG - 2013-08-27 03:43:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Controller Class Initialized
ERROR - 2013-08-27 03:43:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:43:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:43:50 --> Model Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:43:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:43:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:43:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:43:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:43:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:43:50 --> Pagination Class Initialized
DEBUG - 2013-08-27 03:43:50 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:43:50 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:43:50 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:43:50 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:43:50 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:43:50 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 03:43:50 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-27 03:43:50 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:43:50 --> Final output sent to browser
DEBUG - 2013-08-27 03:43:50 --> Total execution time: 0.5820
DEBUG - 2013-08-27 03:43:50 --> Config Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:43:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:43:50 --> URI Class Initialized
DEBUG - 2013-08-27 03:43:50 --> Router Class Initialized
ERROR - 2013-08-27 03:43:50 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 03:43:52 --> Config Class Initialized
DEBUG - 2013-08-27 03:43:52 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:43:52 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:43:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:43:52 --> URI Class Initialized
DEBUG - 2013-08-27 03:43:52 --> Router Class Initialized
DEBUG - 2013-08-27 03:43:52 --> Output Class Initialized
DEBUG - 2013-08-27 03:43:52 --> Security Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Input Class Initialized
DEBUG - 2013-08-27 03:43:53 --> XSS Filtering completed
DEBUG - 2013-08-27 03:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:43:53 --> Language Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Loader Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:43:53 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:43:53 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:43:53 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Session Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:43:53 --> Session routines successfully run
DEBUG - 2013-08-27 03:43:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Controller Class Initialized
ERROR - 2013-08-27 03:43:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:43:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:43:53 --> Model Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:43:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:43:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:43:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:43:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:43:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:43:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:43:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:43:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:43:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:43:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:43:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 03:43:53 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-27 03:43:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:43:53 --> Final output sent to browser
DEBUG - 2013-08-27 03:43:53 --> Total execution time: 0.8661
DEBUG - 2013-08-27 03:43:53 --> Config Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:43:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:43:53 --> URI Class Initialized
DEBUG - 2013-08-27 03:43:53 --> Router Class Initialized
ERROR - 2013-08-27 03:43:53 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 03:43:58 --> Config Class Initialized
DEBUG - 2013-08-27 03:43:58 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:43:58 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:43:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:43:58 --> URI Class Initialized
DEBUG - 2013-08-27 03:43:58 --> Router Class Initialized
DEBUG - 2013-08-27 03:43:58 --> Output Class Initialized
DEBUG - 2013-08-27 03:43:58 --> Security Class Initialized
DEBUG - 2013-08-27 03:43:58 --> Input Class Initialized
DEBUG - 2013-08-27 03:43:58 --> XSS Filtering completed
DEBUG - 2013-08-27 03:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:43:58 --> Language Class Initialized
DEBUG - 2013-08-27 03:43:58 --> Loader Class Initialized
DEBUG - 2013-08-27 03:43:58 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:43:58 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:43:58 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:43:59 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:43:59 --> Session Class Initialized
DEBUG - 2013-08-27 03:43:59 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:43:59 --> Session routines successfully run
DEBUG - 2013-08-27 03:43:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:43:59 --> Controller Class Initialized
ERROR - 2013-08-27 03:43:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:43:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:43:59 --> Model Class Initialized
DEBUG - 2013-08-27 03:43:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:43:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:43:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:43:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:43:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:43:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:43:59 --> Pagination Class Initialized
DEBUG - 2013-08-27 03:43:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:43:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:43:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:43:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:43:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:43:59 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-27 03:43:59 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-27 03:43:59 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-27 03:43:59 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-27 03:43:59 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-27 03:43:59 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
DEBUG - 2013-08-27 03:43:59 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-27 03:43:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:43:59 --> Final output sent to browser
DEBUG - 2013-08-27 03:43:59 --> Total execution time: 0.9401
DEBUG - 2013-08-27 03:43:59 --> Config Class Initialized
DEBUG - 2013-08-27 03:43:59 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:43:59 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:43:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:43:59 --> URI Class Initialized
DEBUG - 2013-08-27 03:43:59 --> Router Class Initialized
ERROR - 2013-08-27 03:43:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 03:44:02 --> Config Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:44:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:44:02 --> URI Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Router Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Output Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Security Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Input Class Initialized
DEBUG - 2013-08-27 03:44:02 --> XSS Filtering completed
DEBUG - 2013-08-27 03:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:44:02 --> Language Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Loader Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:44:02 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:44:02 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:44:02 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Session Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:44:02 --> Session routines successfully run
DEBUG - 2013-08-27 03:44:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Controller Class Initialized
ERROR - 2013-08-27 03:44:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:44:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:44:02 --> Model Class Initialized
DEBUG - 2013-08-27 03:44:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:44:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:44:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:44:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:44:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:44:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:44:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:44:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:44:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:44:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:44:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:44:02 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-27 03:44:02 --> Severity: Notice  --> Undefined variable: jenis_kelamin C:\xampp\htdocs\school\application\views\siswas\new.php 20
ERROR - 2013-08-27 03:44:02 --> Severity: Notice  --> Undefined variable: jenis_kelamin C:\xampp\htdocs\school\application\views\siswas\new.php 21
DEBUG - 2013-08-27 03:44:02 --> File loaded: application/views/siswas/new.php
DEBUG - 2013-08-27 03:44:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:44:02 --> Final output sent to browser
DEBUG - 2013-08-27 03:44:02 --> Total execution time: 0.5500
DEBUG - 2013-08-27 03:44:03 --> Config Class Initialized
DEBUG - 2013-08-27 03:44:03 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:44:03 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:44:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:44:03 --> URI Class Initialized
DEBUG - 2013-08-27 03:44:03 --> Router Class Initialized
ERROR - 2013-08-27 03:44:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 03:44:34 --> Config Class Initialized
DEBUG - 2013-08-27 03:44:34 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:44:34 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:44:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:44:34 --> URI Class Initialized
DEBUG - 2013-08-27 03:44:34 --> Router Class Initialized
DEBUG - 2013-08-27 03:44:34 --> Output Class Initialized
DEBUG - 2013-08-27 03:44:34 --> Security Class Initialized
DEBUG - 2013-08-27 03:44:34 --> Input Class Initialized
DEBUG - 2013-08-27 03:44:34 --> XSS Filtering completed
DEBUG - 2013-08-27 03:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:44:34 --> Language Class Initialized
DEBUG - 2013-08-27 03:44:34 --> Loader Class Initialized
DEBUG - 2013-08-27 03:44:34 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:44:34 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:44:34 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:44:35 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:44:35 --> Session Class Initialized
DEBUG - 2013-08-27 03:44:35 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:44:35 --> Session routines successfully run
DEBUG - 2013-08-27 03:44:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:44:35 --> Controller Class Initialized
ERROR - 2013-08-27 03:44:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:44:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:44:35 --> Model Class Initialized
DEBUG - 2013-08-27 03:44:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:44:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:44:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:44:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:44:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:44:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:44:35 --> Pagination Class Initialized
DEBUG - 2013-08-27 03:44:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:44:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:44:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:44:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:44:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:44:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 03:44:35 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-27 03:44:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:44:35 --> Final output sent to browser
DEBUG - 2013-08-27 03:44:35 --> Total execution time: 0.6900
DEBUG - 2013-08-27 03:44:35 --> Config Class Initialized
DEBUG - 2013-08-27 03:44:35 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:44:35 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:44:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:44:35 --> URI Class Initialized
DEBUG - 2013-08-27 03:44:35 --> Router Class Initialized
ERROR - 2013-08-27 03:44:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 03:44:41 --> Config Class Initialized
DEBUG - 2013-08-27 03:44:41 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:44:41 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:44:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:44:41 --> URI Class Initialized
DEBUG - 2013-08-27 03:44:41 --> Router Class Initialized
DEBUG - 2013-08-27 03:44:41 --> Output Class Initialized
DEBUG - 2013-08-27 03:44:41 --> Security Class Initialized
DEBUG - 2013-08-27 03:44:41 --> Input Class Initialized
DEBUG - 2013-08-27 03:44:41 --> XSS Filtering completed
DEBUG - 2013-08-27 03:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:44:41 --> Language Class Initialized
DEBUG - 2013-08-27 03:44:41 --> Loader Class Initialized
DEBUG - 2013-08-27 03:44:41 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:44:41 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:44:41 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:44:42 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:44:42 --> Session Class Initialized
DEBUG - 2013-08-27 03:44:42 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:44:42 --> Session garbage collection performed.
DEBUG - 2013-08-27 03:44:42 --> Session routines successfully run
DEBUG - 2013-08-27 03:44:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:44:42 --> Controller Class Initialized
ERROR - 2013-08-27 03:44:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:44:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:44:42 --> Model Class Initialized
DEBUG - 2013-08-27 03:44:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:44:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:44:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:44:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:44:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:44:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:44:42 --> Pagination Class Initialized
DEBUG - 2013-08-27 03:44:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:44:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:44:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:44:42 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:44:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:44:42 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-27 03:44:42 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\mata_pelajarans\index.php 82
DEBUG - 2013-08-27 03:44:42 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-08-27 03:44:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:44:42 --> Final output sent to browser
DEBUG - 2013-08-27 03:44:42 --> Total execution time: 0.8681
DEBUG - 2013-08-27 03:44:42 --> Config Class Initialized
DEBUG - 2013-08-27 03:44:42 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:44:42 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:44:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:44:42 --> URI Class Initialized
DEBUG - 2013-08-27 03:44:42 --> Router Class Initialized
ERROR - 2013-08-27 03:44:42 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 03:44:44 --> Config Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:44:44 --> URI Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Router Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Output Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Security Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Input Class Initialized
DEBUG - 2013-08-27 03:44:44 --> XSS Filtering completed
DEBUG - 2013-08-27 03:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 03:44:44 --> Language Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Loader Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Helper loaded: url_helper
DEBUG - 2013-08-27 03:44:44 --> Helper loaded: file_helper
DEBUG - 2013-08-27 03:44:44 --> Helper loaded: form_helper
DEBUG - 2013-08-27 03:44:44 --> Database Driver Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Session Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Helper loaded: string_helper
DEBUG - 2013-08-27 03:44:44 --> Session routines successfully run
DEBUG - 2013-08-27 03:44:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 03:44:44 --> Controller Class Initialized
ERROR - 2013-08-27 03:44:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:44:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:44:44 --> Model Class Initialized
DEBUG - 2013-08-27 03:44:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 03:44:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 03:44:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 03:44:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 03:44:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 03:44:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 03:44:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 03:44:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 03:44:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 03:44:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 03:44:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 03:44:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 03:44:45 --> File loaded: application/views/mata_pelajarans/new.php
DEBUG - 2013-08-27 03:44:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 03:44:45 --> Final output sent to browser
DEBUG - 2013-08-27 03:44:45 --> Total execution time: 0.5680
DEBUG - 2013-08-27 03:44:45 --> Config Class Initialized
DEBUG - 2013-08-27 03:44:45 --> Hooks Class Initialized
DEBUG - 2013-08-27 03:44:45 --> Utf8 Class Initialized
DEBUG - 2013-08-27 03:44:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 03:44:45 --> URI Class Initialized
DEBUG - 2013-08-27 03:44:45 --> Router Class Initialized
ERROR - 2013-08-27 03:44:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 04:02:52 --> Config Class Initialized
DEBUG - 2013-08-27 04:02:52 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:02:52 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:02:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:02:52 --> URI Class Initialized
DEBUG - 2013-08-27 04:02:52 --> Router Class Initialized
DEBUG - 2013-08-27 04:02:52 --> Output Class Initialized
DEBUG - 2013-08-27 04:02:52 --> Security Class Initialized
DEBUG - 2013-08-27 04:02:52 --> Input Class Initialized
DEBUG - 2013-08-27 04:02:52 --> XSS Filtering completed
DEBUG - 2013-08-27 04:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 04:02:53 --> Language Class Initialized
DEBUG - 2013-08-27 04:02:53 --> Loader Class Initialized
DEBUG - 2013-08-27 04:02:53 --> Helper loaded: url_helper
DEBUG - 2013-08-27 04:02:53 --> Helper loaded: file_helper
DEBUG - 2013-08-27 04:02:53 --> Helper loaded: form_helper
DEBUG - 2013-08-27 04:02:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 04:02:53 --> Database Driver Class Initialized
DEBUG - 2013-08-27 04:02:53 --> Session Class Initialized
DEBUG - 2013-08-27 04:02:53 --> Helper loaded: string_helper
DEBUG - 2013-08-27 04:02:53 --> Session routines successfully run
DEBUG - 2013-08-27 04:02:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 04:02:53 --> Controller Class Initialized
ERROR - 2013-08-27 04:02:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:02:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:02:53 --> Model Class Initialized
DEBUG - 2013-08-27 04:02:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 04:02:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 04:02:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 04:02:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 04:02:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:02:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:02:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 04:02:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 04:02:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 04:02:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 04:02:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 04:02:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 04:02:53 --> File loaded: application/views/mata_pelajarans/new.php
DEBUG - 2013-08-27 04:02:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 04:02:53 --> Final output sent to browser
DEBUG - 2013-08-27 04:02:53 --> Total execution time: 1.2821
DEBUG - 2013-08-27 04:02:54 --> Config Class Initialized
DEBUG - 2013-08-27 04:02:54 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:02:54 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:02:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:02:54 --> URI Class Initialized
DEBUG - 2013-08-27 04:02:54 --> Router Class Initialized
ERROR - 2013-08-27 04:02:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 04:03:41 --> Config Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:03:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:03:41 --> URI Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Router Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Output Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Security Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Input Class Initialized
DEBUG - 2013-08-27 04:03:41 --> XSS Filtering completed
DEBUG - 2013-08-27 04:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 04:03:41 --> Language Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Loader Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Helper loaded: url_helper
DEBUG - 2013-08-27 04:03:41 --> Helper loaded: file_helper
DEBUG - 2013-08-27 04:03:41 --> Helper loaded: form_helper
DEBUG - 2013-08-27 04:03:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 04:03:41 --> Database Driver Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Session Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Helper loaded: string_helper
DEBUG - 2013-08-27 04:03:41 --> Session routines successfully run
DEBUG - 2013-08-27 04:03:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Controller Class Initialized
ERROR - 2013-08-27 04:03:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:03:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:03:41 --> Model Class Initialized
DEBUG - 2013-08-27 04:03:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 04:03:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 04:03:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 04:03:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 04:03:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:03:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:03:41 --> Pagination Class Initialized
DEBUG - 2013-08-27 04:03:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 04:03:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 04:03:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 04:03:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 04:03:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 04:03:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 04:03:41 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-27 04:03:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 04:03:41 --> Final output sent to browser
DEBUG - 2013-08-27 04:03:41 --> Total execution time: 0.6560
DEBUG - 2013-08-27 04:03:42 --> Config Class Initialized
DEBUG - 2013-08-27 04:03:42 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:03:42 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:03:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:03:42 --> URI Class Initialized
DEBUG - 2013-08-27 04:03:42 --> Router Class Initialized
ERROR - 2013-08-27 04:03:42 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 04:05:35 --> Config Class Initialized
DEBUG - 2013-08-27 04:05:35 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:05:35 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:05:35 --> URI Class Initialized
DEBUG - 2013-08-27 04:05:35 --> Router Class Initialized
DEBUG - 2013-08-27 04:05:35 --> Output Class Initialized
DEBUG - 2013-08-27 04:05:36 --> Security Class Initialized
DEBUG - 2013-08-27 04:05:36 --> Input Class Initialized
DEBUG - 2013-08-27 04:05:36 --> XSS Filtering completed
DEBUG - 2013-08-27 04:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 04:05:36 --> Language Class Initialized
DEBUG - 2013-08-27 04:05:36 --> Loader Class Initialized
DEBUG - 2013-08-27 04:05:36 --> Helper loaded: url_helper
DEBUG - 2013-08-27 04:05:36 --> Helper loaded: file_helper
DEBUG - 2013-08-27 04:05:36 --> Helper loaded: form_helper
DEBUG - 2013-08-27 04:05:36 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 04:05:36 --> Database Driver Class Initialized
DEBUG - 2013-08-27 04:05:36 --> Session Class Initialized
DEBUG - 2013-08-27 04:05:36 --> Helper loaded: string_helper
DEBUG - 2013-08-27 04:05:36 --> Session routines successfully run
DEBUG - 2013-08-27 04:05:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 04:05:36 --> Controller Class Initialized
ERROR - 2013-08-27 04:05:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:05:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:05:36 --> Model Class Initialized
DEBUG - 2013-08-27 04:05:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 04:05:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 04:05:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 04:05:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 04:05:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:05:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:05:36 --> Pagination Class Initialized
DEBUG - 2013-08-27 04:05:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 04:05:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 04:05:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 04:05:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 04:05:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 04:05:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 04:05:46 --> Config Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:05:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:05:46 --> URI Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Router Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Output Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Security Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Input Class Initialized
DEBUG - 2013-08-27 04:05:46 --> XSS Filtering completed
DEBUG - 2013-08-27 04:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 04:05:46 --> Language Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Loader Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Helper loaded: url_helper
DEBUG - 2013-08-27 04:05:46 --> Helper loaded: file_helper
DEBUG - 2013-08-27 04:05:46 --> Helper loaded: form_helper
DEBUG - 2013-08-27 04:05:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 04:05:46 --> Database Driver Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Session Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Helper loaded: string_helper
DEBUG - 2013-08-27 04:05:46 --> Session routines successfully run
DEBUG - 2013-08-27 04:05:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Controller Class Initialized
ERROR - 2013-08-27 04:05:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:05:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:05:46 --> Model Class Initialized
DEBUG - 2013-08-27 04:05:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 04:05:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 04:05:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 04:05:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 04:05:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:05:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:05:46 --> Pagination Class Initialized
DEBUG - 2013-08-27 04:05:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 04:05:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 04:05:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 04:05:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 04:05:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 04:05:46 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-27 04:05:46 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 4
ERROR - 2013-08-27 04:05:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 4
DEBUG - 2013-08-27 04:06:35 --> Config Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:06:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:06:35 --> URI Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Router Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Output Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Security Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Input Class Initialized
DEBUG - 2013-08-27 04:06:35 --> XSS Filtering completed
DEBUG - 2013-08-27 04:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 04:06:35 --> Language Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Loader Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Helper loaded: url_helper
DEBUG - 2013-08-27 04:06:35 --> Helper loaded: file_helper
DEBUG - 2013-08-27 04:06:35 --> Helper loaded: form_helper
DEBUG - 2013-08-27 04:06:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 04:06:35 --> Database Driver Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Session Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Helper loaded: string_helper
DEBUG - 2013-08-27 04:06:35 --> Session routines successfully run
DEBUG - 2013-08-27 04:06:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Controller Class Initialized
ERROR - 2013-08-27 04:06:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:06:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:06:35 --> Model Class Initialized
DEBUG - 2013-08-27 04:06:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 04:06:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 04:06:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 04:06:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 04:06:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:06:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:06:35 --> Pagination Class Initialized
DEBUG - 2013-08-27 04:06:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 04:06:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 04:06:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 04:06:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 04:06:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 04:06:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 04:06:46 --> Config Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:06:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:06:46 --> URI Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Router Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Output Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Security Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Input Class Initialized
DEBUG - 2013-08-27 04:06:46 --> XSS Filtering completed
DEBUG - 2013-08-27 04:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 04:06:46 --> Language Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Loader Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Helper loaded: url_helper
DEBUG - 2013-08-27 04:06:46 --> Helper loaded: file_helper
DEBUG - 2013-08-27 04:06:46 --> Helper loaded: form_helper
DEBUG - 2013-08-27 04:06:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 04:06:46 --> Database Driver Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Session Class Initialized
DEBUG - 2013-08-27 04:06:46 --> Helper loaded: string_helper
DEBUG - 2013-08-27 04:06:46 --> Session garbage collection performed.
DEBUG - 2013-08-27 04:06:46 --> Session routines successfully run
DEBUG - 2013-08-27 04:06:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 04:06:47 --> Controller Class Initialized
ERROR - 2013-08-27 04:06:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:06:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:06:47 --> Model Class Initialized
DEBUG - 2013-08-27 04:06:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 04:06:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 04:06:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 04:06:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 04:06:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:06:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:06:47 --> Pagination Class Initialized
DEBUG - 2013-08-27 04:06:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 04:06:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 04:06:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 04:06:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 04:06:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 04:06:47 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-27 04:06:47 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\application\views\kelas\index.php 12
DEBUG - 2013-08-27 04:06:47 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-27 04:06:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 04:06:47 --> Final output sent to browser
DEBUG - 2013-08-27 04:06:47 --> Total execution time: 0.7490
DEBUG - 2013-08-27 04:06:47 --> Config Class Initialized
DEBUG - 2013-08-27 04:06:47 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:06:47 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:06:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:06:47 --> URI Class Initialized
DEBUG - 2013-08-27 04:06:47 --> Router Class Initialized
ERROR - 2013-08-27 04:06:47 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 04:07:19 --> Config Class Initialized
DEBUG - 2013-08-27 04:07:19 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:07:19 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:07:19 --> URI Class Initialized
DEBUG - 2013-08-27 04:07:19 --> Router Class Initialized
DEBUG - 2013-08-27 04:07:19 --> Output Class Initialized
DEBUG - 2013-08-27 04:07:19 --> Security Class Initialized
DEBUG - 2013-08-27 04:07:19 --> Input Class Initialized
DEBUG - 2013-08-27 04:07:19 --> XSS Filtering completed
DEBUG - 2013-08-27 04:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 04:07:19 --> Language Class Initialized
DEBUG - 2013-08-27 04:07:19 --> Loader Class Initialized
DEBUG - 2013-08-27 04:07:19 --> Helper loaded: url_helper
DEBUG - 2013-08-27 04:07:20 --> Helper loaded: file_helper
DEBUG - 2013-08-27 04:07:20 --> Helper loaded: form_helper
DEBUG - 2013-08-27 04:07:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 04:07:20 --> Database Driver Class Initialized
DEBUG - 2013-08-27 04:07:20 --> Session Class Initialized
DEBUG - 2013-08-27 04:07:20 --> Helper loaded: string_helper
DEBUG - 2013-08-27 04:07:20 --> Session routines successfully run
DEBUG - 2013-08-27 04:07:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 04:07:20 --> Controller Class Initialized
ERROR - 2013-08-27 04:07:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:07:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:07:20 --> Model Class Initialized
DEBUG - 2013-08-27 04:07:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 04:07:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 04:07:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 04:07:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 04:07:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:07:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:07:20 --> Pagination Class Initialized
DEBUG - 2013-08-27 04:07:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 04:07:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 04:07:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 04:07:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 04:07:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 04:07:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 04:07:22 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-27 04:07:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 04:07:22 --> Final output sent to browser
DEBUG - 2013-08-27 04:07:22 --> Total execution time: 3.0872
DEBUG - 2013-08-27 04:07:23 --> Config Class Initialized
DEBUG - 2013-08-27 04:07:23 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:07:23 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:07:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:07:23 --> URI Class Initialized
DEBUG - 2013-08-27 04:07:23 --> Router Class Initialized
ERROR - 2013-08-27 04:07:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 04:08:51 --> Config Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:08:51 --> URI Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Router Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Output Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Security Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Input Class Initialized
DEBUG - 2013-08-27 04:08:51 --> XSS Filtering completed
DEBUG - 2013-08-27 04:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 04:08:51 --> Language Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Loader Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Helper loaded: url_helper
DEBUG - 2013-08-27 04:08:51 --> Helper loaded: file_helper
DEBUG - 2013-08-27 04:08:51 --> Helper loaded: form_helper
DEBUG - 2013-08-27 04:08:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 04:08:51 --> Database Driver Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Session Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Helper loaded: string_helper
DEBUG - 2013-08-27 04:08:51 --> Session routines successfully run
DEBUG - 2013-08-27 04:08:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Controller Class Initialized
ERROR - 2013-08-27 04:08:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:08:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:08:51 --> Model Class Initialized
DEBUG - 2013-08-27 04:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 04:08:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 04:08:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 04:08:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 04:08:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:08:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:08:51 --> Pagination Class Initialized
DEBUG - 2013-08-27 04:08:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 04:08:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 04:08:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 04:08:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 04:08:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 04:08:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 04:08:51 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-27 04:08:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 04:08:52 --> Final output sent to browser
DEBUG - 2013-08-27 04:08:52 --> Total execution time: 0.8140
DEBUG - 2013-08-27 04:08:52 --> Config Class Initialized
DEBUG - 2013-08-27 04:08:52 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:08:52 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:08:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:08:52 --> URI Class Initialized
DEBUG - 2013-08-27 04:08:52 --> Router Class Initialized
ERROR - 2013-08-27 04:08:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 04:09:09 --> Config Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:09:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:09:09 --> URI Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Router Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Output Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Security Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Input Class Initialized
DEBUG - 2013-08-27 04:09:09 --> XSS Filtering completed
DEBUG - 2013-08-27 04:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 04:09:09 --> Language Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Loader Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Helper loaded: url_helper
DEBUG - 2013-08-27 04:09:09 --> Helper loaded: file_helper
DEBUG - 2013-08-27 04:09:09 --> Helper loaded: form_helper
DEBUG - 2013-08-27 04:09:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 04:09:09 --> Database Driver Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Session Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Helper loaded: string_helper
DEBUG - 2013-08-27 04:09:09 --> Session routines successfully run
DEBUG - 2013-08-27 04:09:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Controller Class Initialized
ERROR - 2013-08-27 04:09:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:09:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:09:09 --> Model Class Initialized
DEBUG - 2013-08-27 04:09:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 04:09:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 04:09:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 04:09:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 04:09:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 04:09:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 04:09:09 --> Pagination Class Initialized
DEBUG - 2013-08-27 04:09:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 04:09:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 04:09:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 04:09:09 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 04:09:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 04:09:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 04:09:09 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-27 04:09:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 04:09:09 --> Final output sent to browser
DEBUG - 2013-08-27 04:09:09 --> Total execution time: 0.6320
DEBUG - 2013-08-27 04:09:10 --> Config Class Initialized
DEBUG - 2013-08-27 04:09:10 --> Hooks Class Initialized
DEBUG - 2013-08-27 04:09:10 --> Utf8 Class Initialized
DEBUG - 2013-08-27 04:09:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 04:09:10 --> URI Class Initialized
DEBUG - 2013-08-27 04:09:10 --> Router Class Initialized
ERROR - 2013-08-27 04:09:10 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 05:13:21 --> Config Class Initialized
DEBUG - 2013-08-27 05:13:21 --> Hooks Class Initialized
DEBUG - 2013-08-27 05:13:21 --> Utf8 Class Initialized
DEBUG - 2013-08-27 05:13:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 05:13:21 --> URI Class Initialized
DEBUG - 2013-08-27 05:13:21 --> Router Class Initialized
DEBUG - 2013-08-27 05:13:21 --> Output Class Initialized
DEBUG - 2013-08-27 05:13:21 --> Security Class Initialized
DEBUG - 2013-08-27 05:13:21 --> Input Class Initialized
DEBUG - 2013-08-27 05:13:21 --> XSS Filtering completed
DEBUG - 2013-08-27 05:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 05:13:22 --> Language Class Initialized
DEBUG - 2013-08-27 05:13:22 --> Loader Class Initialized
DEBUG - 2013-08-27 05:13:22 --> Helper loaded: url_helper
DEBUG - 2013-08-27 05:13:22 --> Helper loaded: file_helper
DEBUG - 2013-08-27 05:13:22 --> Helper loaded: form_helper
DEBUG - 2013-08-27 05:13:22 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 05:13:22 --> Database Driver Class Initialized
DEBUG - 2013-08-27 05:13:22 --> Session Class Initialized
DEBUG - 2013-08-27 05:13:22 --> Helper loaded: string_helper
DEBUG - 2013-08-27 05:13:23 --> Session routines successfully run
DEBUG - 2013-08-27 05:13:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 05:13:23 --> Controller Class Initialized
ERROR - 2013-08-27 05:13:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 05:13:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 05:13:23 --> Model Class Initialized
DEBUG - 2013-08-27 05:13:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 05:13:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 05:13:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 05:13:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 05:13:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 05:13:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 05:13:23 --> Pagination Class Initialized
DEBUG - 2013-08-27 05:13:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 05:13:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 05:13:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 05:13:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 05:13:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 05:13:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 05:13:23 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-27 05:13:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 05:13:23 --> Final output sent to browser
DEBUG - 2013-08-27 05:13:23 --> Total execution time: 3.6132
DEBUG - 2013-08-27 05:13:24 --> Config Class Initialized
DEBUG - 2013-08-27 05:13:24 --> Hooks Class Initialized
DEBUG - 2013-08-27 05:13:24 --> Utf8 Class Initialized
DEBUG - 2013-08-27 05:13:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 05:13:24 --> URI Class Initialized
DEBUG - 2013-08-27 05:13:24 --> Router Class Initialized
ERROR - 2013-08-27 05:13:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 05:37:56 --> Config Class Initialized
DEBUG - 2013-08-27 05:37:56 --> Hooks Class Initialized
DEBUG - 2013-08-27 05:37:56 --> Utf8 Class Initialized
DEBUG - 2013-08-27 05:37:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 05:37:57 --> URI Class Initialized
DEBUG - 2013-08-27 05:37:57 --> Router Class Initialized
DEBUG - 2013-08-27 05:38:03 --> Output Class Initialized
DEBUG - 2013-08-27 05:38:03 --> Security Class Initialized
DEBUG - 2013-08-27 05:38:04 --> Input Class Initialized
DEBUG - 2013-08-27 05:38:04 --> XSS Filtering completed
DEBUG - 2013-08-27 05:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 05:38:05 --> Language Class Initialized
DEBUG - 2013-08-27 05:38:08 --> Loader Class Initialized
DEBUG - 2013-08-27 05:38:09 --> Helper loaded: url_helper
DEBUG - 2013-08-27 05:38:09 --> Helper loaded: file_helper
DEBUG - 2013-08-27 05:38:09 --> Helper loaded: form_helper
DEBUG - 2013-08-27 05:38:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 05:38:09 --> Database Driver Class Initialized
DEBUG - 2013-08-27 05:38:09 --> Session Class Initialized
DEBUG - 2013-08-27 05:38:09 --> Helper loaded: string_helper
DEBUG - 2013-08-27 05:38:13 --> Session routines successfully run
DEBUG - 2013-08-27 05:38:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 05:38:13 --> Controller Class Initialized
ERROR - 2013-08-27 05:38:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 05:38:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 05:38:13 --> Model Class Initialized
DEBUG - 2013-08-27 05:38:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 05:38:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 05:38:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 05:38:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 05:38:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 05:38:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 05:38:14 --> Pagination Class Initialized
DEBUG - 2013-08-27 05:38:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-27 05:38:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-27 05:38:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-27 05:38:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-27 05:38:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-27 05:38:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-27 05:38:15 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-27 05:38:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-27 05:38:15 --> Final output sent to browser
DEBUG - 2013-08-27 05:38:15 --> Total execution time: 20.8242
DEBUG - 2013-08-27 05:38:15 --> Config Class Initialized
DEBUG - 2013-08-27 05:38:15 --> Hooks Class Initialized
DEBUG - 2013-08-27 05:38:15 --> Utf8 Class Initialized
DEBUG - 2013-08-27 05:38:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 05:38:15 --> URI Class Initialized
DEBUG - 2013-08-27 05:38:15 --> Router Class Initialized
ERROR - 2013-08-27 05:38:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-27 08:14:12 --> Config Class Initialized
DEBUG - 2013-08-27 08:14:12 --> Hooks Class Initialized
DEBUG - 2013-08-27 08:14:12 --> Utf8 Class Initialized
DEBUG - 2013-08-27 08:14:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 08:14:12 --> URI Class Initialized
DEBUG - 2013-08-27 08:14:12 --> Router Class Initialized
DEBUG - 2013-08-27 08:14:12 --> Output Class Initialized
DEBUG - 2013-08-27 08:14:12 --> Security Class Initialized
DEBUG - 2013-08-27 08:14:12 --> Input Class Initialized
DEBUG - 2013-08-27 08:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 08:14:12 --> Language Class Initialized
DEBUG - 2013-08-27 08:14:12 --> Loader Class Initialized
DEBUG - 2013-08-27 08:14:12 --> Helper loaded: url_helper
DEBUG - 2013-08-27 08:14:12 --> Helper loaded: file_helper
DEBUG - 2013-08-27 08:14:12 --> Helper loaded: form_helper
DEBUG - 2013-08-27 08:14:13 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 08:14:13 --> Database Driver Class Initialized
DEBUG - 2013-08-27 08:14:13 --> Session Class Initialized
DEBUG - 2013-08-27 08:14:13 --> Helper loaded: string_helper
DEBUG - 2013-08-27 08:14:13 --> A session cookie was not found.
DEBUG - 2013-08-27 08:14:13 --> Session routines successfully run
DEBUG - 2013-08-27 08:14:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 08:14:13 --> Controller Class Initialized
ERROR - 2013-08-27 08:14:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:14:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:14:13 --> Model Class Initialized
DEBUG - 2013-08-27 08:14:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 08:14:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 08:14:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 08:14:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 08:14:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:14:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:14:13 --> Pagination Class Initialized
ERROR - 2013-08-27 08:14:13 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:14:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:14:30 --> Config Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Hooks Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Utf8 Class Initialized
DEBUG - 2013-08-27 08:14:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 08:14:30 --> URI Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Router Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Output Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Security Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Input Class Initialized
DEBUG - 2013-08-27 08:14:30 --> XSS Filtering completed
DEBUG - 2013-08-27 08:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 08:14:30 --> Language Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Loader Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Helper loaded: url_helper
DEBUG - 2013-08-27 08:14:30 --> Helper loaded: file_helper
DEBUG - 2013-08-27 08:14:30 --> Helper loaded: form_helper
DEBUG - 2013-08-27 08:14:30 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 08:14:30 --> Database Driver Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Session Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Helper loaded: string_helper
DEBUG - 2013-08-27 08:14:30 --> Session routines successfully run
DEBUG - 2013-08-27 08:14:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Controller Class Initialized
ERROR - 2013-08-27 08:14:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:14:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:14:30 --> Model Class Initialized
DEBUG - 2013-08-27 08:14:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 08:14:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 08:14:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 08:14:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 08:14:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:14:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:14:31 --> Pagination Class Initialized
ERROR - 2013-08-27 08:14:31 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:14:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:14:39 --> Config Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Hooks Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Utf8 Class Initialized
DEBUG - 2013-08-27 08:14:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 08:14:39 --> URI Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Router Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Output Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Security Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Input Class Initialized
DEBUG - 2013-08-27 08:14:39 --> XSS Filtering completed
DEBUG - 2013-08-27 08:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 08:14:39 --> Language Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Loader Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Helper loaded: url_helper
DEBUG - 2013-08-27 08:14:39 --> Helper loaded: file_helper
DEBUG - 2013-08-27 08:14:39 --> Helper loaded: form_helper
DEBUG - 2013-08-27 08:14:39 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 08:14:39 --> Database Driver Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Session Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Helper loaded: string_helper
DEBUG - 2013-08-27 08:14:39 --> Session routines successfully run
DEBUG - 2013-08-27 08:14:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Controller Class Initialized
ERROR - 2013-08-27 08:14:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:14:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:14:39 --> Model Class Initialized
DEBUG - 2013-08-27 08:14:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 08:14:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 08:14:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 08:14:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 08:14:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:14:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:14:39 --> Pagination Class Initialized
ERROR - 2013-08-27 08:14:39 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:14:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:16:41 --> Config Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Hooks Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Utf8 Class Initialized
DEBUG - 2013-08-27 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-27 08:16:41 --> URI Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Router Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Output Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Security Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Input Class Initialized
DEBUG - 2013-08-27 08:16:41 --> XSS Filtering completed
DEBUG - 2013-08-27 08:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-27 08:16:41 --> Language Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Loader Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Helper loaded: url_helper
DEBUG - 2013-08-27 08:16:41 --> Helper loaded: file_helper
DEBUG - 2013-08-27 08:16:41 --> Helper loaded: form_helper
DEBUG - 2013-08-27 08:16:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-27 08:16:41 --> Database Driver Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Session Class Initialized
DEBUG - 2013-08-27 08:16:41 --> Helper loaded: string_helper
DEBUG - 2013-08-27 08:16:41 --> Session routines successfully run
DEBUG - 2013-08-27 08:16:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-27 08:16:42 --> Controller Class Initialized
ERROR - 2013-08-27 08:16:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:16:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:16:42 --> Model Class Initialized
DEBUG - 2013-08-27 08:16:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-27 08:16:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-27 08:16:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-27 08:16:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-27 08:16:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:16:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-27 08:16:42 --> Pagination Class Initialized
ERROR - 2013-08-27 08:16:42 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-27 08:16:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
