<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-16 12:08:42 --> Config Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:08:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:08:42 --> URI Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Router Class Initialized
DEBUG - 2013-08-16 12:08:42 --> No URI present. Default controller set.
DEBUG - 2013-08-16 12:08:42 --> Output Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Security Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Input Class Initialized
DEBUG - 2013-08-16 12:08:42 --> XSS Filtering completed
DEBUG - 2013-08-16 12:08:42 --> XSS Filtering completed
DEBUG - 2013-08-16 12:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:08:42 --> Language Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Loader Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:08:42 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:08:42 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:08:42 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Session Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:08:42 --> Session routines successfully run
DEBUG - 2013-08-16 12:08:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:08:42 --> Controller Class Initialized
DEBUG - 2013-08-16 12:08:42 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-16 12:08:42 --> Final output sent to browser
DEBUG - 2013-08-16 12:08:42 --> Total execution time: 0.1080
DEBUG - 2013-08-16 12:08:48 --> Config Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:08:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:08:48 --> URI Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Router Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Output Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Security Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Input Class Initialized
DEBUG - 2013-08-16 12:08:48 --> XSS Filtering completed
DEBUG - 2013-08-16 12:08:48 --> XSS Filtering completed
DEBUG - 2013-08-16 12:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:08:48 --> Language Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Loader Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:08:48 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:08:48 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:08:48 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Session Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:08:48 --> Session routines successfully run
DEBUG - 2013-08-16 12:08:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Controller Class Initialized
ERROR - 2013-08-16 12:08:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:08:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:08:48 --> Model Class Initialized
DEBUG - 2013-08-16 12:08:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:08:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:08:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:08:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:08:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:08:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:08:48 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:08:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:08:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:08:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:08:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:08:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:08:48 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:08:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:08:48 --> Final output sent to browser
DEBUG - 2013-08-16 12:08:48 --> Total execution time: 0.1580
DEBUG - 2013-08-16 12:08:49 --> Config Class Initialized
DEBUG - 2013-08-16 12:08:49 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:08:49 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:08:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:08:49 --> URI Class Initialized
DEBUG - 2013-08-16 12:08:49 --> Router Class Initialized
ERROR - 2013-08-16 12:08:49 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:12:24 --> Config Class Initialized
DEBUG - 2013-08-16 12:12:24 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:12:24 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:12:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:12:24 --> URI Class Initialized
DEBUG - 2013-08-16 12:12:24 --> Router Class Initialized
ERROR - 2013-08-16 12:12:24 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:13:01 --> Config Class Initialized
DEBUG - 2013-08-16 12:13:01 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:13:01 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:13:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:13:01 --> URI Class Initialized
DEBUG - 2013-08-16 12:13:01 --> Router Class Initialized
ERROR - 2013-08-16 12:13:01 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:17:09 --> Config Class Initialized
DEBUG - 2013-08-16 12:17:09 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:17:09 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:17:09 --> URI Class Initialized
DEBUG - 2013-08-16 12:17:09 --> Router Class Initialized
ERROR - 2013-08-16 12:17:09 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:17:14 --> Config Class Initialized
DEBUG - 2013-08-16 12:17:14 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:17:14 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:17:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:17:14 --> URI Class Initialized
DEBUG - 2013-08-16 12:17:14 --> Router Class Initialized
ERROR - 2013-08-16 12:17:14 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:17:17 --> Config Class Initialized
DEBUG - 2013-08-16 12:17:17 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:17:17 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:17:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:17:18 --> URI Class Initialized
DEBUG - 2013-08-16 12:17:18 --> Router Class Initialized
ERROR - 2013-08-16 12:17:18 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:17:20 --> Config Class Initialized
DEBUG - 2013-08-16 12:17:20 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:17:20 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:17:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:17:20 --> URI Class Initialized
DEBUG - 2013-08-16 12:17:20 --> Router Class Initialized
ERROR - 2013-08-16 12:17:20 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:17:23 --> Config Class Initialized
DEBUG - 2013-08-16 12:17:23 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:17:23 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:17:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:17:23 --> URI Class Initialized
DEBUG - 2013-08-16 12:17:23 --> Router Class Initialized
ERROR - 2013-08-16 12:17:23 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:18:54 --> Config Class Initialized
DEBUG - 2013-08-16 12:18:54 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:18:54 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:18:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:18:54 --> URI Class Initialized
DEBUG - 2013-08-16 12:18:54 --> Router Class Initialized
ERROR - 2013-08-16 12:18:54 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:18:57 --> Config Class Initialized
DEBUG - 2013-08-16 12:18:57 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:18:57 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:18:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:18:57 --> URI Class Initialized
DEBUG - 2013-08-16 12:18:57 --> Router Class Initialized
ERROR - 2013-08-16 12:18:57 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:19:01 --> Config Class Initialized
DEBUG - 2013-08-16 12:19:01 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:19:01 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:19:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:19:01 --> URI Class Initialized
DEBUG - 2013-08-16 12:19:01 --> Router Class Initialized
ERROR - 2013-08-16 12:19:01 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:19:04 --> Config Class Initialized
DEBUG - 2013-08-16 12:19:04 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:19:04 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:19:04 --> URI Class Initialized
DEBUG - 2013-08-16 12:19:04 --> Router Class Initialized
ERROR - 2013-08-16 12:19:04 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:19:07 --> Config Class Initialized
DEBUG - 2013-08-16 12:19:07 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:19:07 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:19:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:19:07 --> URI Class Initialized
DEBUG - 2013-08-16 12:19:07 --> Router Class Initialized
ERROR - 2013-08-16 12:19:07 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:19:09 --> Config Class Initialized
DEBUG - 2013-08-16 12:19:09 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:19:09 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:19:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:19:09 --> URI Class Initialized
DEBUG - 2013-08-16 12:19:09 --> Router Class Initialized
ERROR - 2013-08-16 12:19:10 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:24:08 --> Config Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:24:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:24:08 --> URI Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Router Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Output Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Security Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Input Class Initialized
DEBUG - 2013-08-16 12:24:08 --> XSS Filtering completed
DEBUG - 2013-08-16 12:24:08 --> XSS Filtering completed
DEBUG - 2013-08-16 12:24:08 --> XSS Filtering completed
DEBUG - 2013-08-16 12:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:24:08 --> Language Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Loader Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:24:08 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:24:08 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:24:08 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Session Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:24:08 --> Session routines successfully run
DEBUG - 2013-08-16 12:24:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Controller Class Initialized
ERROR - 2013-08-16 12:24:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:24:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:24:08 --> Model Class Initialized
DEBUG - 2013-08-16 12:24:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:24:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:24:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:24:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:24:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:24:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:24:08 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:24:08 --> DB Transaction Failure
ERROR - 2013-08-16 12:24:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-3, 5' at line 4
DEBUG - 2013-08-16 12:24:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-16 12:24:43 --> Config Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:24:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:24:43 --> URI Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Router Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Output Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Security Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Input Class Initialized
DEBUG - 2013-08-16 12:24:43 --> XSS Filtering completed
DEBUG - 2013-08-16 12:24:43 --> XSS Filtering completed
DEBUG - 2013-08-16 12:24:43 --> XSS Filtering completed
DEBUG - 2013-08-16 12:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:24:43 --> Language Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Loader Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:24:43 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:24:43 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:24:43 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Session Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:24:43 --> Session routines successfully run
DEBUG - 2013-08-16 12:24:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Controller Class Initialized
ERROR - 2013-08-16 12:24:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:24:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:24:43 --> Model Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:24:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:24:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:24:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:24:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:24:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:24:43 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:24:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:24:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:24:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:24:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:24:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:24:43 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:24:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:24:43 --> Final output sent to browser
DEBUG - 2013-08-16 12:24:43 --> Total execution time: 0.1870
DEBUG - 2013-08-16 12:24:43 --> Config Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:24:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:24:43 --> URI Class Initialized
DEBUG - 2013-08-16 12:24:43 --> Router Class Initialized
ERROR - 2013-08-16 12:24:43 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:24:47 --> Config Class Initialized
DEBUG - 2013-08-16 12:24:47 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:24:47 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:24:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:24:47 --> URI Class Initialized
DEBUG - 2013-08-16 12:24:47 --> Router Class Initialized
ERROR - 2013-08-16 12:24:47 --> 404 Page Not Found --> localhost
DEBUG - 2013-08-16 12:24:55 --> Config Class Initialized
DEBUG - 2013-08-16 12:24:55 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:24:55 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:24:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:24:55 --> URI Class Initialized
DEBUG - 2013-08-16 12:24:56 --> Router Class Initialized
ERROR - 2013-08-16 12:24:56 --> 404 Page Not Found --> localhost
DEBUG - 2013-08-16 12:25:11 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:11 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Router Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Output Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Security Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Input Class Initialized
DEBUG - 2013-08-16 12:25:11 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:11 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:11 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:25:11 --> Language Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Loader Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:25:11 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:25:11 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:25:11 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Session Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:25:11 --> Session routines successfully run
DEBUG - 2013-08-16 12:25:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Controller Class Initialized
ERROR - 2013-08-16 12:25:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:11 --> Model Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:25:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:25:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:25:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:25:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:11 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:25:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:25:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:25:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:25:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:25:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:25:11 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:25:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:25:11 --> Final output sent to browser
DEBUG - 2013-08-16 12:25:11 --> Total execution time: 0.2130
DEBUG - 2013-08-16 12:25:11 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:11 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:11 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:12 --> Router Class Initialized
ERROR - 2013-08-16 12:25:12 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:25:14 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:14 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Router Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Output Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Security Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Input Class Initialized
DEBUG - 2013-08-16 12:25:14 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:14 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:14 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:25:14 --> Language Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Loader Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:25:14 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:25:14 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:25:14 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Session Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:25:14 --> Session routines successfully run
DEBUG - 2013-08-16 12:25:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Controller Class Initialized
ERROR - 2013-08-16 12:25:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:14 --> Model Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:25:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:25:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:25:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:25:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:14 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:25:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:25:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:25:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:25:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:25:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:25:14 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:25:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:25:14 --> Final output sent to browser
DEBUG - 2013-08-16 12:25:14 --> Total execution time: 0.2170
DEBUG - 2013-08-16 12:25:14 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:14 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:14 --> Router Class Initialized
ERROR - 2013-08-16 12:25:14 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:25:16 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:16 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Router Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Output Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Security Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Input Class Initialized
DEBUG - 2013-08-16 12:25:16 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:16 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:16 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:25:16 --> Language Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Loader Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:25:16 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:25:16 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:25:16 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Session Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:25:16 --> Session routines successfully run
DEBUG - 2013-08-16 12:25:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Controller Class Initialized
ERROR - 2013-08-16 12:25:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:16 --> Model Class Initialized
DEBUG - 2013-08-16 12:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:25:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:25:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:25:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:25:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:16 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:25:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:25:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:25:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:25:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:25:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:25:17 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:25:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:25:17 --> Final output sent to browser
DEBUG - 2013-08-16 12:25:17 --> Total execution time: 0.2300
DEBUG - 2013-08-16 12:25:17 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:17 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:17 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:17 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:17 --> Router Class Initialized
ERROR - 2013-08-16 12:25:17 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:25:19 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:19 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:19 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:19 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:19 --> Router Class Initialized
DEBUG - 2013-08-16 12:25:19 --> Output Class Initialized
DEBUG - 2013-08-16 12:25:19 --> Security Class Initialized
DEBUG - 2013-08-16 12:25:19 --> Input Class Initialized
DEBUG - 2013-08-16 12:25:19 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:19 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:19 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:25:19 --> Language Class Initialized
DEBUG - 2013-08-16 12:25:19 --> Loader Class Initialized
DEBUG - 2013-08-16 12:25:19 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:25:19 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:25:19 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:25:19 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:25:20 --> Session Class Initialized
DEBUG - 2013-08-16 12:25:20 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:25:20 --> Session routines successfully run
DEBUG - 2013-08-16 12:25:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:25:20 --> Controller Class Initialized
ERROR - 2013-08-16 12:25:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:20 --> Model Class Initialized
DEBUG - 2013-08-16 12:25:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:25:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:25:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:25:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:25:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:20 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:25:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:25:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:25:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:25:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:25:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:25:20 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:25:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:25:20 --> Final output sent to browser
DEBUG - 2013-08-16 12:25:20 --> Total execution time: 0.2530
DEBUG - 2013-08-16 12:25:20 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:20 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:20 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:20 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:20 --> Router Class Initialized
ERROR - 2013-08-16 12:25:20 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:25:23 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:23 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Router Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Output Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Security Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Input Class Initialized
DEBUG - 2013-08-16 12:25:23 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:23 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:23 --> XSS Filtering completed
DEBUG - 2013-08-16 12:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:25:23 --> Language Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Loader Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:25:23 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:25:23 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:25:23 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Session Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:25:23 --> Session routines successfully run
DEBUG - 2013-08-16 12:25:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Controller Class Initialized
ERROR - 2013-08-16 12:25:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:23 --> Model Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:25:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:25:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:25:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:25:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:25:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:25:23 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:25:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:25:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:25:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:25:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:25:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:25:23 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:25:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:25:23 --> Final output sent to browser
DEBUG - 2013-08-16 12:25:23 --> Total execution time: 0.2460
DEBUG - 2013-08-16 12:25:23 --> Config Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:25:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:25:23 --> URI Class Initialized
DEBUG - 2013-08-16 12:25:23 --> Router Class Initialized
ERROR - 2013-08-16 12:25:23 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:27:32 --> Config Class Initialized
DEBUG - 2013-08-16 12:27:32 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:27:32 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:27:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:27:32 --> URI Class Initialized
DEBUG - 2013-08-16 12:27:32 --> Router Class Initialized
ERROR - 2013-08-16 12:27:32 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:27:36 --> Config Class Initialized
DEBUG - 2013-08-16 12:27:36 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:27:36 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:27:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:27:36 --> URI Class Initialized
DEBUG - 2013-08-16 12:27:36 --> Router Class Initialized
ERROR - 2013-08-16 12:27:36 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:27:38 --> Config Class Initialized
DEBUG - 2013-08-16 12:27:38 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:27:38 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:27:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:27:38 --> URI Class Initialized
DEBUG - 2013-08-16 12:27:38 --> Router Class Initialized
ERROR - 2013-08-16 12:27:38 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:27:41 --> Config Class Initialized
DEBUG - 2013-08-16 12:27:41 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:27:41 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:27:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:27:41 --> URI Class Initialized
DEBUG - 2013-08-16 12:27:41 --> Router Class Initialized
ERROR - 2013-08-16 12:27:41 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:27:43 --> Config Class Initialized
DEBUG - 2013-08-16 12:27:43 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:27:43 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:27:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:27:43 --> URI Class Initialized
DEBUG - 2013-08-16 12:27:43 --> Router Class Initialized
ERROR - 2013-08-16 12:27:43 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:27:52 --> Config Class Initialized
DEBUG - 2013-08-16 12:27:52 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:27:52 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:27:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:27:52 --> URI Class Initialized
DEBUG - 2013-08-16 12:27:52 --> Router Class Initialized
ERROR - 2013-08-16 12:27:52 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:27:56 --> Config Class Initialized
DEBUG - 2013-08-16 12:27:56 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:27:56 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:27:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:27:56 --> URI Class Initialized
DEBUG - 2013-08-16 12:27:56 --> Router Class Initialized
ERROR - 2013-08-16 12:27:56 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:31:32 --> Config Class Initialized
DEBUG - 2013-08-16 12:31:32 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:31:32 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:31:37 --> URI Class Initialized
DEBUG - 2013-08-16 12:31:38 --> Router Class Initialized
DEBUG - 2013-08-16 12:31:40 --> Output Class Initialized
DEBUG - 2013-08-16 12:31:40 --> Security Class Initialized
DEBUG - 2013-08-16 12:31:40 --> Input Class Initialized
DEBUG - 2013-08-16 12:31:40 --> XSS Filtering completed
DEBUG - 2013-08-16 12:31:40 --> XSS Filtering completed
DEBUG - 2013-08-16 12:31:40 --> XSS Filtering completed
DEBUG - 2013-08-16 12:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:31:40 --> Language Class Initialized
DEBUG - 2013-08-16 12:31:42 --> Loader Class Initialized
DEBUG - 2013-08-16 12:31:42 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:31:42 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:31:42 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:31:43 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:31:43 --> Session Class Initialized
DEBUG - 2013-08-16 12:31:43 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:31:43 --> Session routines successfully run
DEBUG - 2013-08-16 12:31:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:31:43 --> Controller Class Initialized
ERROR - 2013-08-16 12:31:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:31:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:31:44 --> Model Class Initialized
DEBUG - 2013-08-16 12:31:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:31:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:31:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:31:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:31:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:31:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:31:44 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:31:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:31:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:31:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:31:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:31:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:31:46 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:31:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:31:46 --> Final output sent to browser
DEBUG - 2013-08-16 12:31:46 --> Total execution time: 27.7876
DEBUG - 2013-08-16 12:31:46 --> Config Class Initialized
DEBUG - 2013-08-16 12:31:46 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:31:46 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:31:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:31:46 --> URI Class Initialized
DEBUG - 2013-08-16 12:31:46 --> Router Class Initialized
ERROR - 2013-08-16 12:31:46 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:31:56 --> Config Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:31:56 --> URI Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Router Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Output Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Security Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Input Class Initialized
DEBUG - 2013-08-16 12:31:56 --> XSS Filtering completed
DEBUG - 2013-08-16 12:31:56 --> XSS Filtering completed
DEBUG - 2013-08-16 12:31:56 --> XSS Filtering completed
DEBUG - 2013-08-16 12:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:31:56 --> Language Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Loader Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:31:56 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:31:56 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:31:56 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Session Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:31:56 --> Session routines successfully run
DEBUG - 2013-08-16 12:31:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Controller Class Initialized
ERROR - 2013-08-16 12:31:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:31:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:31:56 --> Model Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:31:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:31:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:31:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:31:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:31:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:31:56 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:31:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:31:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:31:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:31:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:31:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:31:56 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:31:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:31:56 --> Final output sent to browser
DEBUG - 2013-08-16 12:31:56 --> Total execution time: 0.3260
DEBUG - 2013-08-16 12:31:56 --> Config Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:31:56 --> URI Class Initialized
DEBUG - 2013-08-16 12:31:56 --> Router Class Initialized
ERROR - 2013-08-16 12:31:56 --> 404 Page Not Found --> includes
DEBUG - 2013-08-16 12:37:36 --> Config Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:37:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:37:36 --> URI Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Router Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Output Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Security Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Input Class Initialized
DEBUG - 2013-08-16 12:37:36 --> XSS Filtering completed
DEBUG - 2013-08-16 12:37:36 --> XSS Filtering completed
DEBUG - 2013-08-16 12:37:36 --> XSS Filtering completed
DEBUG - 2013-08-16 12:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-16 12:37:36 --> Language Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Loader Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Helper loaded: url_helper
DEBUG - 2013-08-16 12:37:36 --> Helper loaded: file_helper
DEBUG - 2013-08-16 12:37:36 --> Helper loaded: form_helper
DEBUG - 2013-08-16 12:37:36 --> Database Driver Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Session Class Initialized
DEBUG - 2013-08-16 12:37:36 --> Helper loaded: string_helper
DEBUG - 2013-08-16 12:37:37 --> Session routines successfully run
DEBUG - 2013-08-16 12:37:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-16 12:37:37 --> Controller Class Initialized
ERROR - 2013-08-16 12:37:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:37:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:37:37 --> Model Class Initialized
DEBUG - 2013-08-16 12:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-16 12:37:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-16 12:37:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-16 12:37:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-16 12:37:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-16 12:37:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-16 12:37:37 --> Pagination Class Initialized
DEBUG - 2013-08-16 12:37:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-16 12:37:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-16 12:37:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-16 12:37:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-16 12:37:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-16 12:37:37 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-16 12:37:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-16 12:37:37 --> Final output sent to browser
DEBUG - 2013-08-16 12:37:37 --> Total execution time: 1.5341
DEBUG - 2013-08-16 12:37:37 --> Config Class Initialized
DEBUG - 2013-08-16 12:37:37 --> Hooks Class Initialized
DEBUG - 2013-08-16 12:37:38 --> Utf8 Class Initialized
DEBUG - 2013-08-16 12:37:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-16 12:37:38 --> URI Class Initialized
DEBUG - 2013-08-16 12:37:38 --> Router Class Initialized
ERROR - 2013-08-16 12:37:38 --> 404 Page Not Found --> includes
