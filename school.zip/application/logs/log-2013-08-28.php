<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-28 06:36:38 --> Config Class Initialized
DEBUG - 2013-08-28 06:36:38 --> Hooks Class Initialized
DEBUG - 2013-08-28 06:36:38 --> Utf8 Class Initialized
DEBUG - 2013-08-28 06:36:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 06:36:38 --> URI Class Initialized
DEBUG - 2013-08-28 06:36:38 --> Router Class Initialized
DEBUG - 2013-08-28 06:36:38 --> Output Class Initialized
DEBUG - 2013-08-28 06:36:38 --> Security Class Initialized
DEBUG - 2013-08-28 06:36:38 --> Input Class Initialized
DEBUG - 2013-08-28 06:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 06:36:38 --> Language Class Initialized
DEBUG - 2013-08-28 06:36:38 --> Loader Class Initialized
DEBUG - 2013-08-28 06:36:38 --> Helper loaded: url_helper
DEBUG - 2013-08-28 06:36:38 --> Helper loaded: file_helper
DEBUG - 2013-08-28 06:36:38 --> Helper loaded: form_helper
DEBUG - 2013-08-28 06:36:38 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 06:36:38 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 06:36:38 --> Database Driver Class Initialized
DEBUG - 2013-08-28 06:36:39 --> Session Class Initialized
DEBUG - 2013-08-28 06:36:39 --> Helper loaded: string_helper
DEBUG - 2013-08-28 06:36:39 --> A session cookie was not found.
DEBUG - 2013-08-28 06:36:39 --> Session routines successfully run
DEBUG - 2013-08-28 06:36:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 06:36:39 --> Controller Class Initialized
ERROR - 2013-08-28 06:36:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 06:36:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 06:36:39 --> Model Class Initialized
DEBUG - 2013-08-28 06:36:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 06:36:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 06:36:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 06:36:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 06:36:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 06:36:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 06:36:39 --> Pagination Class Initialized
DEBUG - 2013-08-28 06:36:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 06:36:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 06:36:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 06:36:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 06:36:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 06:36:40 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 06:36:40 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-28 06:36:40 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-28 06:36:40 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-28 06:36:40 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-28 06:36:40 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
DEBUG - 2013-08-28 06:36:40 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-28 06:36:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 06:36:40 --> Final output sent to browser
DEBUG - 2013-08-28 06:36:40 --> Total execution time: 2.3221
DEBUG - 2013-08-28 06:36:40 --> Config Class Initialized
DEBUG - 2013-08-28 06:36:40 --> Hooks Class Initialized
DEBUG - 2013-08-28 06:36:40 --> Utf8 Class Initialized
DEBUG - 2013-08-28 06:36:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 06:36:40 --> URI Class Initialized
DEBUG - 2013-08-28 06:36:40 --> Router Class Initialized
ERROR - 2013-08-28 06:36:40 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 08:14:47 --> Config Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:14:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:14:47 --> URI Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Router Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Output Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Security Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Input Class Initialized
DEBUG - 2013-08-28 08:14:47 --> XSS Filtering completed
DEBUG - 2013-08-28 08:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 08:14:47 --> Language Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Loader Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Helper loaded: url_helper
DEBUG - 2013-08-28 08:14:47 --> Helper loaded: file_helper
DEBUG - 2013-08-28 08:14:47 --> Helper loaded: form_helper
DEBUG - 2013-08-28 08:14:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 08:14:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 08:14:47 --> Database Driver Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Session Class Initialized
DEBUG - 2013-08-28 08:14:47 --> Helper loaded: string_helper
DEBUG - 2013-08-28 08:14:48 --> Session garbage collection performed.
DEBUG - 2013-08-28 08:14:48 --> Session routines successfully run
DEBUG - 2013-08-28 08:14:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 08:14:48 --> Controller Class Initialized
ERROR - 2013-08-28 08:14:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:14:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:14:48 --> Model Class Initialized
DEBUG - 2013-08-28 08:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:14:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 08:14:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 08:14:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 08:14:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:14:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:14:48 --> Pagination Class Initialized
DEBUG - 2013-08-28 08:14:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 08:14:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 08:14:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 08:14:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 08:14:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 08:14:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 08:14:48 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-28 08:14:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 08:14:48 --> Final output sent to browser
DEBUG - 2013-08-28 08:14:48 --> Total execution time: 1.4321
DEBUG - 2013-08-28 08:14:48 --> Config Class Initialized
DEBUG - 2013-08-28 08:14:48 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:14:48 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:14:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:14:48 --> URI Class Initialized
DEBUG - 2013-08-28 08:14:48 --> Router Class Initialized
ERROR - 2013-08-28 08:14:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 08:14:51 --> Config Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:14:51 --> URI Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Router Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Output Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Security Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Input Class Initialized
DEBUG - 2013-08-28 08:14:51 --> XSS Filtering completed
DEBUG - 2013-08-28 08:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 08:14:51 --> Language Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Loader Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Helper loaded: url_helper
DEBUG - 2013-08-28 08:14:51 --> Helper loaded: file_helper
DEBUG - 2013-08-28 08:14:51 --> Helper loaded: form_helper
DEBUG - 2013-08-28 08:14:51 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 08:14:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 08:14:51 --> Database Driver Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Session Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Helper loaded: string_helper
DEBUG - 2013-08-28 08:14:51 --> Session garbage collection performed.
DEBUG - 2013-08-28 08:14:51 --> Session routines successfully run
DEBUG - 2013-08-28 08:14:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Controller Class Initialized
ERROR - 2013-08-28 08:14:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:14:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:14:51 --> Model Class Initialized
DEBUG - 2013-08-28 08:14:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:14:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 08:14:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 08:14:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 08:14:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:14:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:14:52 --> Pagination Class Initialized
DEBUG - 2013-08-28 08:14:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 08:14:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 08:14:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 08:14:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 08:14:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 08:14:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 08:14:52 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-28 08:14:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 08:14:52 --> Final output sent to browser
DEBUG - 2013-08-28 08:14:52 --> Total execution time: 0.4740
DEBUG - 2013-08-28 08:14:52 --> Config Class Initialized
DEBUG - 2013-08-28 08:14:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:14:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:14:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:14:52 --> URI Class Initialized
DEBUG - 2013-08-28 08:14:52 --> Router Class Initialized
ERROR - 2013-08-28 08:14:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 08:14:54 --> Config Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:14:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:14:54 --> URI Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Router Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Output Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Security Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Input Class Initialized
DEBUG - 2013-08-28 08:14:54 --> XSS Filtering completed
DEBUG - 2013-08-28 08:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 08:14:54 --> Language Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Loader Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Helper loaded: url_helper
DEBUG - 2013-08-28 08:14:54 --> Helper loaded: file_helper
DEBUG - 2013-08-28 08:14:54 --> Helper loaded: form_helper
DEBUG - 2013-08-28 08:14:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 08:14:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 08:14:54 --> Database Driver Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Session Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 08:14:54 --> Session routines successfully run
DEBUG - 2013-08-28 08:14:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Controller Class Initialized
ERROR - 2013-08-28 08:14:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:14:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:14:54 --> Model Class Initialized
DEBUG - 2013-08-28 08:14:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:14:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 08:14:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 08:14:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 08:14:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:14:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:14:54 --> Pagination Class Initialized
DEBUG - 2013-08-28 08:14:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 08:14:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 08:14:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 08:14:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 08:14:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 08:14:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 08:14:55 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-28 08:14:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 08:14:55 --> Final output sent to browser
DEBUG - 2013-08-28 08:14:55 --> Total execution time: 0.2720
DEBUG - 2013-08-28 08:14:55 --> Config Class Initialized
DEBUG - 2013-08-28 08:14:55 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:14:55 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:14:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:14:55 --> URI Class Initialized
DEBUG - 2013-08-28 08:14:55 --> Router Class Initialized
ERROR - 2013-08-28 08:14:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 08:14:55 --> Config Class Initialized
DEBUG - 2013-08-28 08:14:55 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:14:55 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:14:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:14:55 --> URI Class Initialized
DEBUG - 2013-08-28 08:14:55 --> Router Class Initialized
DEBUG - 2013-08-28 08:14:55 --> Output Class Initialized
DEBUG - 2013-08-28 08:14:55 --> Security Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Input Class Initialized
DEBUG - 2013-08-28 08:14:56 --> XSS Filtering completed
DEBUG - 2013-08-28 08:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 08:14:56 --> Language Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Loader Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Helper loaded: url_helper
DEBUG - 2013-08-28 08:14:56 --> Helper loaded: file_helper
DEBUG - 2013-08-28 08:14:56 --> Helper loaded: form_helper
DEBUG - 2013-08-28 08:14:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 08:14:56 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 08:14:56 --> Database Driver Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Session Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Helper loaded: string_helper
DEBUG - 2013-08-28 08:14:56 --> Session routines successfully run
DEBUG - 2013-08-28 08:14:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Controller Class Initialized
ERROR - 2013-08-28 08:14:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:14:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:14:56 --> Model Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:14:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 08:14:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 08:14:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 08:14:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:14:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:14:56 --> Pagination Class Initialized
DEBUG - 2013-08-28 08:14:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 08:14:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 08:14:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 08:14:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 08:14:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 08:14:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 08:14:56 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-28 08:14:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 08:14:56 --> Final output sent to browser
DEBUG - 2013-08-28 08:14:56 --> Total execution time: 0.3680
DEBUG - 2013-08-28 08:14:56 --> Config Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:14:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:14:56 --> URI Class Initialized
DEBUG - 2013-08-28 08:14:56 --> Router Class Initialized
ERROR - 2013-08-28 08:14:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 08:15:04 --> Config Class Initialized
DEBUG - 2013-08-28 08:15:04 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:15:04 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:15:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:15:04 --> URI Class Initialized
DEBUG - 2013-08-28 08:15:04 --> Router Class Initialized
DEBUG - 2013-08-28 08:15:04 --> Output Class Initialized
DEBUG - 2013-08-28 08:15:04 --> Security Class Initialized
DEBUG - 2013-08-28 08:15:04 --> Input Class Initialized
DEBUG - 2013-08-28 08:15:04 --> XSS Filtering completed
DEBUG - 2013-08-28 08:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 08:15:04 --> Language Class Initialized
DEBUG - 2013-08-28 08:15:04 --> Loader Class Initialized
DEBUG - 2013-08-28 08:15:04 --> Helper loaded: url_helper
DEBUG - 2013-08-28 08:15:04 --> Helper loaded: file_helper
DEBUG - 2013-08-28 08:15:04 --> Helper loaded: form_helper
DEBUG - 2013-08-28 08:15:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 08:15:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 08:15:05 --> Database Driver Class Initialized
DEBUG - 2013-08-28 08:15:05 --> Session Class Initialized
DEBUG - 2013-08-28 08:15:05 --> Helper loaded: string_helper
DEBUG - 2013-08-28 08:15:05 --> Session routines successfully run
DEBUG - 2013-08-28 08:15:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 08:15:05 --> Controller Class Initialized
ERROR - 2013-08-28 08:15:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:15:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:15:05 --> Model Class Initialized
DEBUG - 2013-08-28 08:15:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:15:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 08:15:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 08:15:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 08:15:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:15:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:15:05 --> Pagination Class Initialized
DEBUG - 2013-08-28 08:15:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 08:15:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 08:15:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 08:15:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 08:15:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 08:15:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 08:15:05 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-28 08:15:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 08:15:05 --> Final output sent to browser
DEBUG - 2013-08-28 08:15:05 --> Total execution time: 0.2800
DEBUG - 2013-08-28 08:15:05 --> Config Class Initialized
DEBUG - 2013-08-28 08:15:05 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:15:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:15:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:15:05 --> URI Class Initialized
DEBUG - 2013-08-28 08:15:05 --> Router Class Initialized
ERROR - 2013-08-28 08:15:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 08:15:07 --> Config Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:15:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:15:07 --> URI Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Router Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Output Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Security Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Input Class Initialized
DEBUG - 2013-08-28 08:15:07 --> XSS Filtering completed
DEBUG - 2013-08-28 08:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 08:15:07 --> Language Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Loader Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Helper loaded: url_helper
DEBUG - 2013-08-28 08:15:07 --> Helper loaded: file_helper
DEBUG - 2013-08-28 08:15:07 --> Helper loaded: form_helper
DEBUG - 2013-08-28 08:15:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 08:15:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 08:15:07 --> Database Driver Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Session Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Helper loaded: string_helper
DEBUG - 2013-08-28 08:15:07 --> Session routines successfully run
DEBUG - 2013-08-28 08:15:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Controller Class Initialized
ERROR - 2013-08-28 08:15:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:15:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:15:07 --> Model Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:15:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 08:15:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 08:15:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 08:15:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:15:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:15:07 --> Pagination Class Initialized
DEBUG - 2013-08-28 08:15:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 08:15:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 08:15:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 08:15:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 08:15:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 08:15:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 08:15:07 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-28 08:15:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 08:15:07 --> Final output sent to browser
DEBUG - 2013-08-28 08:15:07 --> Total execution time: 0.2870
DEBUG - 2013-08-28 08:15:07 --> Config Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:15:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:15:07 --> URI Class Initialized
DEBUG - 2013-08-28 08:15:07 --> Router Class Initialized
ERROR - 2013-08-28 08:15:07 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 08:15:09 --> Config Class Initialized
DEBUG - 2013-08-28 08:15:09 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:15:09 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:15:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:15:09 --> URI Class Initialized
DEBUG - 2013-08-28 08:15:09 --> Router Class Initialized
ERROR - 2013-08-28 08:15:09 --> 404 Page Not Found --> users
DEBUG - 2013-08-28 08:53:06 --> Config Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:53:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:53:06 --> URI Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Router Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Output Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Security Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Input Class Initialized
DEBUG - 2013-08-28 08:53:06 --> XSS Filtering completed
DEBUG - 2013-08-28 08:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 08:53:06 --> Language Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Loader Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Helper loaded: url_helper
DEBUG - 2013-08-28 08:53:06 --> Helper loaded: file_helper
DEBUG - 2013-08-28 08:53:06 --> Helper loaded: form_helper
DEBUG - 2013-08-28 08:53:06 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 08:53:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 08:53:06 --> Database Driver Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Session Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Helper loaded: string_helper
DEBUG - 2013-08-28 08:53:06 --> Session routines successfully run
DEBUG - 2013-08-28 08:53:06 --> XML-RPC Class Initialized
ERROR - 2013-08-28 08:53:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:53:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:53:06 --> Model Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:53:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 08:53:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 08:53:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 08:53:06 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\school\application\models\flexi_auth_lite_model.php 47
ERROR - 2013-08-28 08:53:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:53:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:53:06 --> Controller Class Initialized
DEBUG - 2013-08-28 08:53:06 --> Flexi_auth class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:53:07 --> Pagination Class Initialized
DEBUG - 2013-08-28 08:53:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 08:53:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 08:53:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 08:53:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 08:53:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 08:53:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 08:53:07 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 08:53:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 08:53:07 --> Final output sent to browser
DEBUG - 2013-08-28 08:53:07 --> Total execution time: 1.3031
DEBUG - 2013-08-28 08:53:07 --> Config Class Initialized
DEBUG - 2013-08-28 08:53:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:53:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:53:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:53:07 --> URI Class Initialized
DEBUG - 2013-08-28 08:53:07 --> Router Class Initialized
ERROR - 2013-08-28 08:53:07 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 08:59:10 --> Config Class Initialized
DEBUG - 2013-08-28 08:59:10 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:59:10 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:59:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:59:10 --> URI Class Initialized
DEBUG - 2013-08-28 08:59:10 --> Router Class Initialized
DEBUG - 2013-08-28 08:59:10 --> Output Class Initialized
DEBUG - 2013-08-28 08:59:10 --> Security Class Initialized
DEBUG - 2013-08-28 08:59:10 --> Input Class Initialized
DEBUG - 2013-08-28 08:59:10 --> XSS Filtering completed
DEBUG - 2013-08-28 08:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 08:59:10 --> Language Class Initialized
DEBUG - 2013-08-28 08:59:10 --> Loader Class Initialized
DEBUG - 2013-08-28 08:59:10 --> Helper loaded: url_helper
DEBUG - 2013-08-28 08:59:10 --> Helper loaded: file_helper
DEBUG - 2013-08-28 08:59:10 --> Helper loaded: form_helper
DEBUG - 2013-08-28 08:59:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 08:59:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 08:59:11 --> Database Driver Class Initialized
DEBUG - 2013-08-28 08:59:11 --> Session Class Initialized
DEBUG - 2013-08-28 08:59:11 --> Helper loaded: string_helper
DEBUG - 2013-08-28 08:59:11 --> Session routines successfully run
DEBUG - 2013-08-28 08:59:11 --> XML-RPC Class Initialized
ERROR - 2013-08-28 08:59:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:59:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:59:11 --> Model Class Initialized
DEBUG - 2013-08-28 08:59:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:59:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 08:59:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 08:59:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 08:59:12 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\school\application\models\flexi_auth_lite_model.php 47
ERROR - 2013-08-28 08:59:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 08:59:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 08:59:12 --> Controller Class Initialized
DEBUG - 2013-08-28 08:59:12 --> Flexi_auth class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 08:59:13 --> Pagination Class Initialized
DEBUG - 2013-08-28 08:59:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 08:59:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 08:59:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 08:59:13 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 08:59:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 08:59:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 08:59:13 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 08:59:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 08:59:13 --> Final output sent to browser
DEBUG - 2013-08-28 08:59:13 --> Total execution time: 3.6932
DEBUG - 2013-08-28 08:59:14 --> Config Class Initialized
DEBUG - 2013-08-28 08:59:14 --> Hooks Class Initialized
DEBUG - 2013-08-28 08:59:14 --> Utf8 Class Initialized
DEBUG - 2013-08-28 08:59:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 08:59:14 --> URI Class Initialized
DEBUG - 2013-08-28 08:59:14 --> Router Class Initialized
ERROR - 2013-08-28 08:59:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:00:38 --> Config Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:00:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:00:38 --> URI Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Router Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Output Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Security Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Input Class Initialized
DEBUG - 2013-08-28 09:00:38 --> XSS Filtering completed
DEBUG - 2013-08-28 09:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:00:38 --> Language Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Loader Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:00:38 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:00:38 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:00:38 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:00:38 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:00:38 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Session Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:00:38 --> Session routines successfully run
DEBUG - 2013-08-28 09:00:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Controller Class Initialized
ERROR - 2013-08-28 09:00:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:00:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:00:38 --> Model Class Initialized
DEBUG - 2013-08-28 09:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:00:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:00:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:00:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:00:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:00:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:00:38 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:00:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:00:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:00:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:00:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:00:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:00:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:00:38 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 09:00:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:00:38 --> Final output sent to browser
DEBUG - 2013-08-28 09:00:38 --> Total execution time: 0.2710
DEBUG - 2013-08-28 09:00:39 --> Config Class Initialized
DEBUG - 2013-08-28 09:00:39 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:00:39 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:00:39 --> URI Class Initialized
DEBUG - 2013-08-28 09:00:39 --> Router Class Initialized
ERROR - 2013-08-28 09:00:39 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:00:53 --> Config Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:00:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:00:53 --> URI Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Router Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Output Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Security Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Input Class Initialized
DEBUG - 2013-08-28 09:00:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:00:53 --> Language Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Loader Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:00:53 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:00:53 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:00:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:00:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:00:53 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Session Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:00:53 --> Session routines successfully run
DEBUG - 2013-08-28 09:00:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Controller Class Initialized
ERROR - 2013-08-28 09:00:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:00:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:00:53 --> Model Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:00:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:00:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:00:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:00:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:00:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:00:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:00:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:00:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:00:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:00:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:00:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:00:53 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-28 09:00:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:00:53 --> Final output sent to browser
DEBUG - 2013-08-28 09:00:53 --> Total execution time: 0.3710
DEBUG - 2013-08-28 09:00:53 --> Config Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:00:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:00:53 --> URI Class Initialized
DEBUG - 2013-08-28 09:00:53 --> Router Class Initialized
ERROR - 2013-08-28 09:00:53 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:02:54 --> Config Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:02:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:02:54 --> URI Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Router Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Output Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Security Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Input Class Initialized
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:02:54 --> Language Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Loader Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:02:54 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:02:54 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:02:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:02:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:02:54 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Session Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:02:54 --> Session routines successfully run
DEBUG - 2013-08-28 09:02:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Controller Class Initialized
ERROR - 2013-08-28 09:02:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:02:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:02:54 --> Model Class Initialized
DEBUG - 2013-08-28 09:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:02:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:02:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:02:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:02:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:02:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:02:57 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:57 --> XSS Filtering completed
DEBUG - 2013-08-28 09:02:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:03:11 --> Config Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:03:11 --> URI Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Router Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Output Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Security Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Input Class Initialized
DEBUG - 2013-08-28 09:03:11 --> XSS Filtering completed
DEBUG - 2013-08-28 09:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:03:11 --> Language Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Loader Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:03:11 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:03:11 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:03:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:03:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:03:11 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Session Class Initialized
DEBUG - 2013-08-28 09:03:11 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:03:17 --> Session routines successfully run
DEBUG - 2013-08-28 09:03:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:03:17 --> Controller Class Initialized
ERROR - 2013-08-28 09:03:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:03:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:03:17 --> Model Class Initialized
DEBUG - 2013-08-28 09:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:03:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:03:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:03:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:03:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:03:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:03:17 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:03:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:03:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:03:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:03:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:03:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:03:17 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 09:03:17 --> Severity: Notice  --> Undefined variable: 1 C:\xampp\htdocs\school\application\views\gurus\index.php 79
DEBUG - 2013-08-28 09:03:17 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 09:03:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:03:17 --> Final output sent to browser
DEBUG - 2013-08-28 09:03:17 --> Total execution time: 6.0653
DEBUG - 2013-08-28 09:03:19 --> Config Class Initialized
DEBUG - 2013-08-28 09:03:19 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:03:19 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:03:19 --> URI Class Initialized
DEBUG - 2013-08-28 09:03:19 --> Router Class Initialized
ERROR - 2013-08-28 09:03:19 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:04:03 --> Config Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:04:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:04:03 --> URI Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Router Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Output Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Security Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Input Class Initialized
DEBUG - 2013-08-28 09:04:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:04:03 --> Language Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Loader Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:04:03 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:04:03 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:04:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:04:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:04:03 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Session Class Initialized
DEBUG - 2013-08-28 09:04:03 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:04:04 --> Session routines successfully run
DEBUG - 2013-08-28 09:04:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:04:04 --> Controller Class Initialized
ERROR - 2013-08-28 09:04:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:04:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:04:04 --> Model Class Initialized
DEBUG - 2013-08-28 09:04:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:04:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:04:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:04:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:04:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:04:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:04:04 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:04:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:04:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:04:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:04:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:04:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:04:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:04:04 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 09:04:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:04:04 --> Final output sent to browser
DEBUG - 2013-08-28 09:04:04 --> Total execution time: 0.6360
DEBUG - 2013-08-28 09:04:04 --> Config Class Initialized
DEBUG - 2013-08-28 09:04:04 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:04:04 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:04:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:04:04 --> URI Class Initialized
DEBUG - 2013-08-28 09:04:04 --> Router Class Initialized
ERROR - 2013-08-28 09:04:04 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:05:16 --> Config Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:05:16 --> URI Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Router Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Output Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Security Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Input Class Initialized
DEBUG - 2013-08-28 09:05:16 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:05:16 --> Language Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Loader Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:05:16 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:05:16 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:05:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:05:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:05:16 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Session Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:05:16 --> Session routines successfully run
DEBUG - 2013-08-28 09:05:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:05:16 --> Controller Class Initialized
ERROR - 2013-08-28 09:05:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:17 --> Model Class Initialized
DEBUG - 2013-08-28 09:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:05:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:05:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:05:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:05:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:05:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:05:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:05:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:05:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:05:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:05:17 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-28 09:05:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:05:17 --> Final output sent to browser
DEBUG - 2013-08-28 09:05:17 --> Total execution time: 0.4730
DEBUG - 2013-08-28 09:05:17 --> Config Class Initialized
DEBUG - 2013-08-28 09:05:17 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:05:17 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:05:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:05:17 --> URI Class Initialized
DEBUG - 2013-08-28 09:05:17 --> Router Class Initialized
ERROR - 2013-08-28 09:05:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:05:47 --> Config Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:05:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:05:47 --> URI Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Router Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Output Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Security Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Input Class Initialized
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:05:47 --> Language Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Loader Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:05:47 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:05:47 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:05:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:05:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:05:47 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Session Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:05:47 --> Session routines successfully run
DEBUG - 2013-08-28 09:05:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Controller Class Initialized
ERROR - 2013-08-28 09:05:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:47 --> Model Class Initialized
DEBUG - 2013-08-28 09:05:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:05:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:05:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:05:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:05:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:47 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:05:48 --> Config Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:05:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:05:48 --> URI Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Router Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Output Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Security Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Input Class Initialized
DEBUG - 2013-08-28 09:05:48 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:05:48 --> Language Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Loader Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:05:48 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:05:48 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:05:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:05:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:05:48 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Session Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:05:48 --> Session routines successfully run
DEBUG - 2013-08-28 09:05:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Controller Class Initialized
ERROR - 2013-08-28 09:05:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:48 --> Model Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:05:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:05:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:05:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:05:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:05:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:05:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:05:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:05:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:05:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:05:48 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-28 09:05:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:05:48 --> Final output sent to browser
DEBUG - 2013-08-28 09:05:48 --> Total execution time: 0.3890
DEBUG - 2013-08-28 09:05:48 --> Config Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:05:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:05:48 --> URI Class Initialized
DEBUG - 2013-08-28 09:05:48 --> Router Class Initialized
ERROR - 2013-08-28 09:05:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:05:56 --> Config Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:05:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:05:56 --> URI Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Router Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Output Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Security Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Input Class Initialized
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:05:56 --> Language Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Loader Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:05:56 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Session Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:05:56 --> Session routines successfully run
DEBUG - 2013-08-28 09:05:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Controller Class Initialized
ERROR - 2013-08-28 09:05:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:56 --> Model Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:05:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:05:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:05:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:56 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:05:56 --> Config Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:05:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:05:56 --> URI Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Router Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Output Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Security Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Input Class Initialized
DEBUG - 2013-08-28 09:05:56 --> XSS Filtering completed
DEBUG - 2013-08-28 09:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:05:56 --> Language Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Loader Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:05:56 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Session Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:05:56 --> Session routines successfully run
DEBUG - 2013-08-28 09:05:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Controller Class Initialized
ERROR - 2013-08-28 09:05:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:56 --> Model Class Initialized
DEBUG - 2013-08-28 09:05:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:05:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:05:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:05:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:05:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:05:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:05:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:05:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:05:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:05:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:05:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:05:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:05:57 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-28 09:05:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:05:57 --> Final output sent to browser
DEBUG - 2013-08-28 09:05:57 --> Total execution time: 0.4140
DEBUG - 2013-08-28 09:05:57 --> Config Class Initialized
DEBUG - 2013-08-28 09:05:57 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:05:57 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:05:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:05:57 --> URI Class Initialized
DEBUG - 2013-08-28 09:05:57 --> Router Class Initialized
ERROR - 2013-08-28 09:05:57 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:06:08 --> Config Class Initialized
DEBUG - 2013-08-28 09:06:08 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:06:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:06:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:06:08 --> URI Class Initialized
DEBUG - 2013-08-28 09:06:08 --> Router Class Initialized
DEBUG - 2013-08-28 09:06:08 --> Output Class Initialized
DEBUG - 2013-08-28 09:06:08 --> Security Class Initialized
DEBUG - 2013-08-28 09:06:08 --> Input Class Initialized
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:06:09 --> Language Class Initialized
DEBUG - 2013-08-28 09:06:09 --> Loader Class Initialized
DEBUG - 2013-08-28 09:06:09 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:06:09 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:06:09 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:06:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:06:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:06:09 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:06:09 --> Session Class Initialized
DEBUG - 2013-08-28 09:06:09 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:06:09 --> Session routines successfully run
DEBUG - 2013-08-28 09:06:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:06:09 --> Controller Class Initialized
ERROR - 2013-08-28 09:06:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:06:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:06:09 --> Model Class Initialized
DEBUG - 2013-08-28 09:06:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:06:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:06:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:06:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:06:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:06:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:06:09 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:06:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:06:09 --> DB Transaction Failure
ERROR - 2013-08-28 09:06:09 --> Query error: Incorrect date value: '' for column 'tanggal_pengangkatan' at row 1
DEBUG - 2013-08-28 09:06:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-28 09:23:03 --> Config Class Initialized
DEBUG - 2013-08-28 09:23:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:23:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:23:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:23:03 --> URI Class Initialized
DEBUG - 2013-08-28 09:23:03 --> Router Class Initialized
DEBUG - 2013-08-28 09:23:03 --> Output Class Initialized
DEBUG - 2013-08-28 09:23:03 --> Security Class Initialized
DEBUG - 2013-08-28 09:23:03 --> Input Class Initialized
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:23:03 --> Language Class Initialized
DEBUG - 2013-08-28 09:24:02 --> Config Class Initialized
DEBUG - 2013-08-28 09:24:02 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:24:02 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:24:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:24:02 --> URI Class Initialized
DEBUG - 2013-08-28 09:24:02 --> Router Class Initialized
DEBUG - 2013-08-28 09:24:02 --> Output Class Initialized
DEBUG - 2013-08-28 09:24:02 --> Security Class Initialized
DEBUG - 2013-08-28 09:24:02 --> Input Class Initialized
DEBUG - 2013-08-28 09:24:02 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:02 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:02 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:02 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:02 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:02 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:02 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:24:03 --> Language Class Initialized
DEBUG - 2013-08-28 09:24:03 --> Loader Class Initialized
DEBUG - 2013-08-28 09:24:03 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:24:03 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:24:03 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:24:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:24:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:24:03 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:24:03 --> Session Class Initialized
DEBUG - 2013-08-28 09:24:03 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:24:04 --> Session routines successfully run
DEBUG - 2013-08-28 09:24:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:24:04 --> Controller Class Initialized
ERROR - 2013-08-28 09:24:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:24:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:24:04 --> Model Class Initialized
DEBUG - 2013-08-28 09:24:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:24:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:24:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:24:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:24:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:24:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:24:04 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:24:04 --> DB Transaction Failure
ERROR - 2013-08-28 09:24:04 --> Query error: Incorrect date value: '' for column 'tanggal_pengangkatan' at row 1
DEBUG - 2013-08-28 09:24:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-28 09:24:53 --> Config Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:24:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:24:53 --> URI Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Router Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Output Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Security Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Input Class Initialized
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:24:53 --> Language Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Loader Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:24:53 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:24:53 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:24:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:24:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:24:53 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Session Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:24:53 --> Session routines successfully run
DEBUG - 2013-08-28 09:24:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:24:53 --> Controller Class Initialized
ERROR - 2013-08-28 09:24:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:24:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:24:54 --> Model Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:24:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:24:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:24:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:24:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:24:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:24:54 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:24:54 --> Config Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:24:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:24:54 --> URI Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Router Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Output Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Security Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Input Class Initialized
DEBUG - 2013-08-28 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-28 09:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:24:54 --> Language Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Loader Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:24:54 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:24:54 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:24:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:24:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:24:54 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Session Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:24:54 --> Session routines successfully run
DEBUG - 2013-08-28 09:24:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Controller Class Initialized
ERROR - 2013-08-28 09:24:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:24:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:24:54 --> Model Class Initialized
DEBUG - 2013-08-28 09:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:24:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:24:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:24:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:24:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:24:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:24:54 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:24:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:24:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:24:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:24:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:24:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:24:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:24:55 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 09:24:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:24:55 --> Final output sent to browser
DEBUG - 2013-08-28 09:24:55 --> Total execution time: 0.6500
DEBUG - 2013-08-28 09:24:55 --> Config Class Initialized
DEBUG - 2013-08-28 09:24:55 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:24:55 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:24:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:24:55 --> URI Class Initialized
DEBUG - 2013-08-28 09:24:55 --> Router Class Initialized
ERROR - 2013-08-28 09:24:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:25:45 --> Config Class Initialized
DEBUG - 2013-08-28 09:25:45 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:25:45 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:25:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:25:45 --> URI Class Initialized
DEBUG - 2013-08-28 09:25:45 --> Router Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Output Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Security Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Input Class Initialized
DEBUG - 2013-08-28 09:25:46 --> XSS Filtering completed
DEBUG - 2013-08-28 09:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:25:46 --> Language Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Loader Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:25:46 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:25:46 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:25:46 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:25:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:25:46 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Session Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:25:46 --> Session routines successfully run
DEBUG - 2013-08-28 09:25:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Controller Class Initialized
ERROR - 2013-08-28 09:25:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:25:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:25:46 --> Model Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:25:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:25:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:25:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:25:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:25:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:25:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:25:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:25:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:25:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:25:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:25:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:25:46 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-28 09:25:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:25:46 --> Final output sent to browser
DEBUG - 2013-08-28 09:25:46 --> Total execution time: 0.6700
DEBUG - 2013-08-28 09:25:46 --> Config Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:25:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:25:46 --> URI Class Initialized
DEBUG - 2013-08-28 09:25:46 --> Router Class Initialized
ERROR - 2013-08-28 09:25:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:26:24 --> Config Class Initialized
DEBUG - 2013-08-28 09:26:24 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:26:24 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:26:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:26:25 --> URI Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Router Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Output Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Security Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Input Class Initialized
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:26:25 --> Language Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Loader Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:26:25 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:26:25 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:26:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:26:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:26:25 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Session Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:26:25 --> Session garbage collection performed.
DEBUG - 2013-08-28 09:26:25 --> Session routines successfully run
DEBUG - 2013-08-28 09:26:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Controller Class Initialized
ERROR - 2013-08-28 09:26:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:26:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:26:25 --> Model Class Initialized
DEBUG - 2013-08-28 09:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:26:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:26:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:26:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:26:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:26:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:26:25 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:26:26 --> Config Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:26:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:26:26 --> URI Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Router Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Output Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Security Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Input Class Initialized
DEBUG - 2013-08-28 09:26:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:26:26 --> Language Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Loader Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:26:26 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:26:26 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:26:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:26:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:26:26 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Session Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:26:26 --> Session routines successfully run
DEBUG - 2013-08-28 09:26:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Controller Class Initialized
ERROR - 2013-08-28 09:26:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:26:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:26:26 --> Model Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:26:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:26:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:26:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:26:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:26:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:26:26 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:26:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:26:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:26:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:26:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:26:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:26:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:26:26 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 09:26:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:26:26 --> Final output sent to browser
DEBUG - 2013-08-28 09:26:26 --> Total execution time: 0.6210
DEBUG - 2013-08-28 09:26:26 --> Config Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:26:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:26:26 --> URI Class Initialized
DEBUG - 2013-08-28 09:26:26 --> Router Class Initialized
ERROR - 2013-08-28 09:26:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:29:08 --> Config Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:29:08 --> URI Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Router Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Output Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Security Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Input Class Initialized
DEBUG - 2013-08-28 09:29:08 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:29:08 --> Language Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Loader Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:29:08 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:29:08 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:29:08 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:29:08 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:29:08 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Session Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:29:08 --> Session routines successfully run
DEBUG - 2013-08-28 09:29:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Controller Class Initialized
ERROR - 2013-08-28 09:29:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:29:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:29:08 --> Model Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:29:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:29:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:29:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:29:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:29:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:29:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:29:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:29:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:29:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:29:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:29:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:29:08 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-28 09:29:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:29:08 --> Final output sent to browser
DEBUG - 2013-08-28 09:29:08 --> Total execution time: 0.4880
DEBUG - 2013-08-28 09:29:08 --> Config Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:29:08 --> URI Class Initialized
DEBUG - 2013-08-28 09:29:08 --> Router Class Initialized
ERROR - 2013-08-28 09:29:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:29:26 --> Config Class Initialized
DEBUG - 2013-08-28 09:29:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:29:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:29:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:29:26 --> URI Class Initialized
DEBUG - 2013-08-28 09:29:26 --> Router Class Initialized
DEBUG - 2013-08-28 09:29:26 --> Output Class Initialized
DEBUG - 2013-08-28 09:29:26 --> Security Class Initialized
DEBUG - 2013-08-28 09:29:26 --> Input Class Initialized
DEBUG - 2013-08-28 09:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:29:27 --> Language Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Loader Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:29:27 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:29:27 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:29:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:29:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:29:27 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Session Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:29:27 --> Session garbage collection performed.
DEBUG - 2013-08-28 09:29:27 --> Session routines successfully run
DEBUG - 2013-08-28 09:29:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Controller Class Initialized
ERROR - 2013-08-28 09:29:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:29:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:29:27 --> Model Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:29:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:29:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:29:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:29:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:29:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:29:27 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:29:27 --> Config Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:29:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:29:27 --> URI Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Router Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Output Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Security Class Initialized
DEBUG - 2013-08-28 09:29:27 --> Input Class Initialized
DEBUG - 2013-08-28 09:29:28 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:29:28 --> Language Class Initialized
DEBUG - 2013-08-28 09:29:28 --> Loader Class Initialized
DEBUG - 2013-08-28 09:29:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:29:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:29:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:29:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:29:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:29:28 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:29:28 --> Session Class Initialized
DEBUG - 2013-08-28 09:29:28 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:29:28 --> Session routines successfully run
DEBUG - 2013-08-28 09:29:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:29:28 --> Controller Class Initialized
ERROR - 2013-08-28 09:29:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:29:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:29:28 --> Model Class Initialized
DEBUG - 2013-08-28 09:29:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:29:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:29:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:29:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:29:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:29:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:29:28 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:29:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:29:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:29:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:29:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:29:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:29:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:29:28 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 09:29:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:29:28 --> Final output sent to browser
DEBUG - 2013-08-28 09:29:28 --> Total execution time: 0.5080
DEBUG - 2013-08-28 09:29:28 --> Config Class Initialized
DEBUG - 2013-08-28 09:29:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:29:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:29:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:29:28 --> URI Class Initialized
DEBUG - 2013-08-28 09:29:28 --> Router Class Initialized
ERROR - 2013-08-28 09:29:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:29:40 --> Config Class Initialized
DEBUG - 2013-08-28 09:29:40 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:29:40 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:29:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:29:40 --> URI Class Initialized
DEBUG - 2013-08-28 09:29:40 --> Router Class Initialized
DEBUG - 2013-08-28 09:29:40 --> Output Class Initialized
DEBUG - 2013-08-28 09:29:40 --> Security Class Initialized
DEBUG - 2013-08-28 09:29:40 --> Input Class Initialized
DEBUG - 2013-08-28 09:29:40 --> XSS Filtering completed
DEBUG - 2013-08-28 09:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:29:40 --> Language Class Initialized
DEBUG - 2013-08-28 09:29:40 --> Loader Class Initialized
DEBUG - 2013-08-28 09:29:40 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:29:41 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:29:41 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:29:41 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:29:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:29:41 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:29:41 --> Session Class Initialized
DEBUG - 2013-08-28 09:29:41 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:29:41 --> Session routines successfully run
DEBUG - 2013-08-28 09:29:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:29:41 --> Controller Class Initialized
ERROR - 2013-08-28 09:29:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:29:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:29:41 --> Model Class Initialized
DEBUG - 2013-08-28 09:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:29:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:29:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:29:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:29:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:29:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:29:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:29:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:29:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:29:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:29:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:29:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:29:41 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-28 09:29:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:29:41 --> Final output sent to browser
DEBUG - 2013-08-28 09:29:41 --> Total execution time: 0.6990
DEBUG - 2013-08-28 09:29:41 --> Config Class Initialized
DEBUG - 2013-08-28 09:29:41 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:29:41 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:29:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:29:41 --> URI Class Initialized
DEBUG - 2013-08-28 09:29:41 --> Router Class Initialized
ERROR - 2013-08-28 09:29:41 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:30:22 --> Config Class Initialized
DEBUG - 2013-08-28 09:30:22 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:30:22 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:30:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:30:22 --> URI Class Initialized
DEBUG - 2013-08-28 09:30:22 --> Router Class Initialized
DEBUG - 2013-08-28 09:30:22 --> Output Class Initialized
DEBUG - 2013-08-28 09:30:22 --> Security Class Initialized
DEBUG - 2013-08-28 09:30:22 --> Input Class Initialized
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:22 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:30:23 --> Language Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Loader Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:30:23 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Session Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:30:23 --> Session garbage collection performed.
DEBUG - 2013-08-28 09:30:23 --> Session routines successfully run
DEBUG - 2013-08-28 09:30:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Controller Class Initialized
ERROR - 2013-08-28 09:30:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:30:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:30:23 --> Model Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:30:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:30:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:30:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:30:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:30:23 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:30:23 --> Config Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:30:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:30:23 --> URI Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Router Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Output Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Security Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Input Class Initialized
DEBUG - 2013-08-28 09:30:23 --> XSS Filtering completed
DEBUG - 2013-08-28 09:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:30:23 --> Language Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Loader Class Initialized
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:30:23 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:30:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:30:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:30:24 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:30:24 --> Session Class Initialized
DEBUG - 2013-08-28 09:30:24 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:30:24 --> Session routines successfully run
DEBUG - 2013-08-28 09:30:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:30:24 --> Controller Class Initialized
ERROR - 2013-08-28 09:30:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:30:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:30:24 --> Model Class Initialized
DEBUG - 2013-08-28 09:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:30:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:30:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:30:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:30:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:30:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:30:24 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:30:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:30:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:30:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:30:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:30:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:30:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:30:24 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 09:30:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:30:24 --> Final output sent to browser
DEBUG - 2013-08-28 09:30:24 --> Total execution time: 0.7060
DEBUG - 2013-08-28 09:30:24 --> Config Class Initialized
DEBUG - 2013-08-28 09:30:24 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:30:24 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:30:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:30:24 --> URI Class Initialized
DEBUG - 2013-08-28 09:30:24 --> Router Class Initialized
ERROR - 2013-08-28 09:30:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:31:37 --> Config Class Initialized
DEBUG - 2013-08-28 09:31:37 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:31:37 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:31:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:31:37 --> URI Class Initialized
DEBUG - 2013-08-28 09:31:37 --> Router Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Output Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Security Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Input Class Initialized
DEBUG - 2013-08-28 09:31:38 --> XSS Filtering completed
DEBUG - 2013-08-28 09:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:31:38 --> Language Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Loader Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:31:38 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:31:38 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:31:38 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:31:38 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:31:38 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Session Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:31:38 --> Session routines successfully run
DEBUG - 2013-08-28 09:31:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Controller Class Initialized
ERROR - 2013-08-28 09:31:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:31:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:31:38 --> Model Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:31:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:31:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:31:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:31:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:31:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:31:38 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:31:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:31:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:31:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:31:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:31:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:31:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:31:38 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-28 09:31:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:31:38 --> Final output sent to browser
DEBUG - 2013-08-28 09:31:38 --> Total execution time: 0.6120
DEBUG - 2013-08-28 09:31:38 --> Config Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:31:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:31:38 --> URI Class Initialized
DEBUG - 2013-08-28 09:31:38 --> Router Class Initialized
ERROR - 2013-08-28 09:31:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:33:28 --> Config Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:33:28 --> URI Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Router Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Output Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Security Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Input Class Initialized
DEBUG - 2013-08-28 09:33:28 --> XSS Filtering completed
DEBUG - 2013-08-28 09:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:33:28 --> Language Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Loader Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:33:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:33:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:33:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:33:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:33:28 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Session Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:33:28 --> Session routines successfully run
DEBUG - 2013-08-28 09:33:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Controller Class Initialized
ERROR - 2013-08-28 09:33:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:33:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:33:28 --> Model Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:33:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:33:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:33:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:33:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:33:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:33:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:33:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:33:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:33:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:33:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:33:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:33:28 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-28 09:33:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:33:28 --> Final output sent to browser
DEBUG - 2013-08-28 09:33:28 --> Total execution time: 0.5430
DEBUG - 2013-08-28 09:33:28 --> Config Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:33:28 --> URI Class Initialized
DEBUG - 2013-08-28 09:33:28 --> Router Class Initialized
ERROR - 2013-08-28 09:33:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:33:43 --> Config Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:33:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:33:43 --> URI Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Router Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Output Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Security Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Input Class Initialized
DEBUG - 2013-08-28 09:33:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:33:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:33:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:33:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:33:43 --> Language Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Loader Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:33:43 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:33:43 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:33:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:33:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:33:43 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Session Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:33:43 --> Session routines successfully run
DEBUG - 2013-08-28 09:33:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Controller Class Initialized
ERROR - 2013-08-28 09:33:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:33:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:33:43 --> Model Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:33:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:33:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:33:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:33:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:33:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:33:43 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:33:43 --> Config Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:33:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:33:43 --> URI Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Router Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Output Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Security Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Input Class Initialized
DEBUG - 2013-08-28 09:33:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:33:43 --> Language Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Loader Class Initialized
DEBUG - 2013-08-28 09:33:43 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:33:44 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:33:44 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:33:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:33:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:33:44 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:33:44 --> Session Class Initialized
DEBUG - 2013-08-28 09:33:44 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:33:44 --> Session routines successfully run
DEBUG - 2013-08-28 09:33:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:33:44 --> Controller Class Initialized
ERROR - 2013-08-28 09:33:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:33:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:33:44 --> Model Class Initialized
DEBUG - 2013-08-28 09:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:33:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:33:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:33:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:33:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:33:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:33:44 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:33:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:33:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:33:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:33:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:33:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:33:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:33:44 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-28 09:33:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:33:44 --> Final output sent to browser
DEBUG - 2013-08-28 09:33:44 --> Total execution time: 0.5990
DEBUG - 2013-08-28 09:33:44 --> Config Class Initialized
DEBUG - 2013-08-28 09:33:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:33:44 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:33:44 --> URI Class Initialized
DEBUG - 2013-08-28 09:33:44 --> Router Class Initialized
ERROR - 2013-08-28 09:33:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:33:52 --> Config Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:33:52 --> URI Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Router Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Output Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Security Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Input Class Initialized
DEBUG - 2013-08-28 09:33:52 --> XSS Filtering completed
DEBUG - 2013-08-28 09:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:33:52 --> Language Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Loader Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:33:52 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:33:52 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:33:52 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Session Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:33:52 --> Session routines successfully run
DEBUG - 2013-08-28 09:33:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Controller Class Initialized
ERROR - 2013-08-28 09:33:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:33:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:33:52 --> Model Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:33:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:33:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:33:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:33:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:33:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:33:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:33:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:33:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:33:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:33:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:33:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:33:52 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-28 09:33:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:33:52 --> Final output sent to browser
DEBUG - 2013-08-28 09:33:52 --> Total execution time: 0.5760
DEBUG - 2013-08-28 09:33:52 --> Config Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:33:52 --> URI Class Initialized
DEBUG - 2013-08-28 09:33:52 --> Router Class Initialized
ERROR - 2013-08-28 09:33:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:34:03 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:03 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Router Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Output Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Security Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Input Class Initialized
DEBUG - 2013-08-28 09:34:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:03 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:34:03 --> Language Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Loader Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:34:03 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:34:03 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:34:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:34:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:34:03 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Session Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:34:03 --> Session routines successfully run
DEBUG - 2013-08-28 09:34:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Controller Class Initialized
ERROR - 2013-08-28 09:34:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:03 --> Model Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:34:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:34:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:34:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:34:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:03 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:34:03 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:04 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Router Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Output Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Security Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Input Class Initialized
DEBUG - 2013-08-28 09:34:04 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:34:04 --> Language Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Loader Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:34:04 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:34:04 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:34:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:34:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:34:04 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Session Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:34:04 --> Session routines successfully run
DEBUG - 2013-08-28 09:34:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Controller Class Initialized
ERROR - 2013-08-28 09:34:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:04 --> Model Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:34:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:34:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:34:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:34:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:04 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:34:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:34:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:34:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:34:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:34:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:34:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:34:04 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-28 09:34:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:34:04 --> Final output sent to browser
DEBUG - 2013-08-28 09:34:04 --> Total execution time: 0.6390
DEBUG - 2013-08-28 09:34:04 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:04 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:04 --> Router Class Initialized
ERROR - 2013-08-28 09:34:04 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:34:09 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:09 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Router Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Output Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Security Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Input Class Initialized
DEBUG - 2013-08-28 09:34:09 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:34:09 --> Language Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Loader Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:34:09 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:34:09 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:34:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:34:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:34:09 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Session Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:34:09 --> Session routines successfully run
DEBUG - 2013-08-28 09:34:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Controller Class Initialized
ERROR - 2013-08-28 09:34:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:09 --> Model Class Initialized
DEBUG - 2013-08-28 09:34:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:34:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:34:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:34:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:34:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:34:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:34:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:34:09 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:34:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:34:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:34:09 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-28 09:34:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:34:09 --> Final output sent to browser
DEBUG - 2013-08-28 09:34:09 --> Total execution time: 0.8230
DEBUG - 2013-08-28 09:34:10 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:10 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:10 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:10 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:10 --> Router Class Initialized
ERROR - 2013-08-28 09:34:10 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:34:27 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:27 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:27 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:27 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Router Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Output Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Security Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Input Class Initialized
DEBUG - 2013-08-28 09:34:28 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:28 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:28 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:28 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:28 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:34:28 --> Language Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Loader Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:34:28 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Session Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:34:28 --> Session routines successfully run
DEBUG - 2013-08-28 09:34:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Controller Class Initialized
ERROR - 2013-08-28 09:34:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:28 --> Model Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:34:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:34:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:34:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:28 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:34:28 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:28 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Router Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Output Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Security Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Input Class Initialized
DEBUG - 2013-08-28 09:34:28 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:34:28 --> Language Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Loader Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:34:28 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Session Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:34:28 --> Session routines successfully run
DEBUG - 2013-08-28 09:34:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Controller Class Initialized
ERROR - 2013-08-28 09:34:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:28 --> Model Class Initialized
DEBUG - 2013-08-28 09:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:34:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:34:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:34:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:34:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:29 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:34:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:34:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:34:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:34:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:34:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:34:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:34:29 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-28 09:34:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:34:29 --> Final output sent to browser
DEBUG - 2013-08-28 09:34:29 --> Total execution time: 0.6040
DEBUG - 2013-08-28 09:34:29 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:29 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:29 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:29 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:29 --> Router Class Initialized
ERROR - 2013-08-28 09:34:29 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:34:32 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:32 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:32 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:32 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:32 --> Router Class Initialized
DEBUG - 2013-08-28 09:34:32 --> Output Class Initialized
DEBUG - 2013-08-28 09:34:32 --> Security Class Initialized
DEBUG - 2013-08-28 09:34:32 --> Input Class Initialized
DEBUG - 2013-08-28 09:34:32 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:34:32 --> Language Class Initialized
DEBUG - 2013-08-28 09:34:32 --> Loader Class Initialized
DEBUG - 2013-08-28 09:34:32 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:34:32 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:34:32 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:34:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:34:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:34:33 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:34:33 --> Session Class Initialized
DEBUG - 2013-08-28 09:34:33 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:34:33 --> Session routines successfully run
DEBUG - 2013-08-28 09:34:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:34:33 --> Controller Class Initialized
ERROR - 2013-08-28 09:34:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:33 --> Model Class Initialized
DEBUG - 2013-08-28 09:34:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:34:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:34:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:34:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:34:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:34:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:34:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:34:33 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:34:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:34:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:34:33 --> File loaded: application/views/user_groups/new.php
DEBUG - 2013-08-28 09:34:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:34:33 --> Final output sent to browser
DEBUG - 2013-08-28 09:34:33 --> Total execution time: 0.5760
DEBUG - 2013-08-28 09:34:33 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:33 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:33 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:33 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:33 --> Router Class Initialized
ERROR - 2013-08-28 09:34:33 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:34:43 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:43 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Router Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Output Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Security Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Input Class Initialized
DEBUG - 2013-08-28 09:34:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:43 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:34:43 --> Language Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Loader Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:34:43 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:34:43 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:34:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:34:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:34:43 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Session Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:34:43 --> Session routines successfully run
DEBUG - 2013-08-28 09:34:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Controller Class Initialized
ERROR - 2013-08-28 09:34:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:43 --> Model Class Initialized
DEBUG - 2013-08-28 09:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:34:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:34:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:34:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:34:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:43 --> Form Validation Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 09:34:44 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:44 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Router Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Output Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Security Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Input Class Initialized
DEBUG - 2013-08-28 09:34:44 --> XSS Filtering completed
DEBUG - 2013-08-28 09:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:34:44 --> Language Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Loader Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:34:44 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:34:44 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:34:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:34:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:34:44 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Session Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:34:44 --> Session routines successfully run
DEBUG - 2013-08-28 09:34:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Controller Class Initialized
ERROR - 2013-08-28 09:34:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:44 --> Model Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:34:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:34:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:34:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:34:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:34:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:34:44 --> Pagination Class Initialized
DEBUG - 2013-08-28 09:34:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:34:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:34:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:34:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:34:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 09:34:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:34:44 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-28 09:34:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:34:44 --> Final output sent to browser
DEBUG - 2013-08-28 09:34:44 --> Total execution time: 0.6770
DEBUG - 2013-08-28 09:34:44 --> Config Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:34:44 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:34:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:34:44 --> URI Class Initialized
DEBUG - 2013-08-28 09:34:45 --> Router Class Initialized
ERROR - 2013-08-28 09:34:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:50:06 --> Config Class Initialized
DEBUG - 2013-08-28 09:50:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:50:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:50:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:50:07 --> URI Class Initialized
DEBUG - 2013-08-28 09:50:07 --> Router Class Initialized
DEBUG - 2013-08-28 09:50:07 --> Output Class Initialized
DEBUG - 2013-08-28 09:50:07 --> Security Class Initialized
DEBUG - 2013-08-28 09:50:07 --> Input Class Initialized
DEBUG - 2013-08-28 09:50:07 --> XSS Filtering completed
DEBUG - 2013-08-28 09:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:50:07 --> Language Class Initialized
DEBUG - 2013-08-28 09:50:07 --> Loader Class Initialized
DEBUG - 2013-08-28 09:50:07 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:50:07 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:50:07 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:50:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:50:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:50:07 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:50:08 --> Session Class Initialized
DEBUG - 2013-08-28 09:50:08 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:50:08 --> Session routines successfully run
DEBUG - 2013-08-28 09:50:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:50:08 --> Controller Class Initialized
ERROR - 2013-08-28 09:50:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:50:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:50:08 --> Model Class Initialized
DEBUG - 2013-08-28 09:50:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:50:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:50:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:50:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:50:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:50:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:50:08 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-28 09:50:08 --> Final output sent to browser
DEBUG - 2013-08-28 09:50:08 --> Total execution time: 2.0381
DEBUG - 2013-08-28 09:51:13 --> Config Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:51:13 --> URI Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Router Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Output Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Security Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Input Class Initialized
DEBUG - 2013-08-28 09:51:13 --> XSS Filtering completed
DEBUG - 2013-08-28 09:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:51:13 --> Language Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Loader Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:51:13 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:51:13 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:51:13 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:51:13 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:51:13 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Session Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:51:13 --> Session routines successfully run
DEBUG - 2013-08-28 09:51:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:51:13 --> Controller Class Initialized
ERROR - 2013-08-28 09:51:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:51:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:51:14 --> Model Class Initialized
DEBUG - 2013-08-28 09:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:51:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:51:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:51:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:51:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:51:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:51:14 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\school\application\views\shared\head.php 14
DEBUG - 2013-08-28 09:51:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:51:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:51:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:51:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:51:14 --> File loaded: application/views/shared/breadcrumb.php
ERROR - 2013-08-28 09:51:14 --> Severity: Notice  --> Undefined variable: content_title C:\xampp\htdocs\school\application\views\shared\content_title.php 2
DEBUG - 2013-08-28 09:51:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:51:14 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-28 09:51:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:51:14 --> Final output sent to browser
DEBUG - 2013-08-28 09:51:14 --> Total execution time: 0.7660
DEBUG - 2013-08-28 09:51:14 --> Config Class Initialized
DEBUG - 2013-08-28 09:51:14 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:51:14 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:51:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:51:14 --> URI Class Initialized
DEBUG - 2013-08-28 09:51:14 --> Router Class Initialized
ERROR - 2013-08-28 09:51:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 09:51:41 --> Config Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:51:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:51:41 --> URI Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Router Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Output Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Security Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Input Class Initialized
DEBUG - 2013-08-28 09:51:41 --> XSS Filtering completed
DEBUG - 2013-08-28 09:51:41 --> XSS Filtering completed
DEBUG - 2013-08-28 09:51:41 --> XSS Filtering completed
DEBUG - 2013-08-28 09:51:41 --> XSS Filtering completed
DEBUG - 2013-08-28 09:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 09:51:41 --> Language Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Loader Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Helper loaded: url_helper
DEBUG - 2013-08-28 09:51:41 --> Helper loaded: file_helper
DEBUG - 2013-08-28 09:51:41 --> Helper loaded: form_helper
DEBUG - 2013-08-28 09:51:41 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 09:51:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 09:51:41 --> Database Driver Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Session Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Helper loaded: string_helper
DEBUG - 2013-08-28 09:51:41 --> Session routines successfully run
DEBUG - 2013-08-28 09:51:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Controller Class Initialized
ERROR - 2013-08-28 09:51:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:51:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 09:51:41 --> Model Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 09:51:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 09:51:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 09:51:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 09:51:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:51:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 09:51:41 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\school\application\views\shared\head.php 14
DEBUG - 2013-08-28 09:51:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 09:51:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 09:51:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 09:51:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 09:51:41 --> File loaded: application/views/shared/breadcrumb.php
ERROR - 2013-08-28 09:51:41 --> Severity: Notice  --> Undefined variable: content_title C:\xampp\htdocs\school\application\views\shared\content_title.php 2
DEBUG - 2013-08-28 09:51:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 09:51:41 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-28 09:51:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 09:51:41 --> Final output sent to browser
DEBUG - 2013-08-28 09:51:41 --> Total execution time: 0.7350
DEBUG - 2013-08-28 09:51:41 --> Config Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Hooks Class Initialized
DEBUG - 2013-08-28 09:51:41 --> Utf8 Class Initialized
DEBUG - 2013-08-28 09:51:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 09:51:42 --> URI Class Initialized
DEBUG - 2013-08-28 09:51:42 --> Router Class Initialized
ERROR - 2013-08-28 09:51:42 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:01:34 --> Config Class Initialized
DEBUG - 2013-08-28 11:01:34 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:01:34 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:01:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:01:34 --> URI Class Initialized
DEBUG - 2013-08-28 11:01:34 --> Router Class Initialized
DEBUG - 2013-08-28 11:01:34 --> Output Class Initialized
DEBUG - 2013-08-28 11:01:34 --> Security Class Initialized
DEBUG - 2013-08-28 11:01:34 --> Input Class Initialized
DEBUG - 2013-08-28 11:01:34 --> XSS Filtering completed
DEBUG - 2013-08-28 11:01:34 --> XSS Filtering completed
DEBUG - 2013-08-28 11:01:34 --> XSS Filtering completed
DEBUG - 2013-08-28 11:01:34 --> XSS Filtering completed
DEBUG - 2013-08-28 11:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:01:34 --> Language Class Initialized
DEBUG - 2013-08-28 11:01:34 --> Loader Class Initialized
DEBUG - 2013-08-28 11:01:34 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:01:34 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:01:35 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:01:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:01:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:01:35 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:01:35 --> Session Class Initialized
DEBUG - 2013-08-28 11:01:35 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:01:35 --> Session routines successfully run
DEBUG - 2013-08-28 11:01:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:01:35 --> Controller Class Initialized
ERROR - 2013-08-28 11:01:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:01:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:01:35 --> Model Class Initialized
DEBUG - 2013-08-28 11:01:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:01:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:01:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:01:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:01:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:01:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:01:35 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\school\application\views\shared\head.php 14
DEBUG - 2013-08-28 11:01:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:01:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:01:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:01:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:01:35 --> File loaded: application/views/shared/breadcrumb.php
ERROR - 2013-08-28 11:01:35 --> Severity: Notice  --> Undefined variable: content_title C:\xampp\htdocs\school\application\views\shared\content_title.php 2
DEBUG - 2013-08-28 11:01:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:01:36 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-28 11:01:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:01:36 --> Final output sent to browser
DEBUG - 2013-08-28 11:01:36 --> Total execution time: 2.0401
DEBUG - 2013-08-28 11:01:36 --> Config Class Initialized
DEBUG - 2013-08-28 11:01:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:01:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:01:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:01:36 --> URI Class Initialized
DEBUG - 2013-08-28 11:01:36 --> Router Class Initialized
ERROR - 2013-08-28 11:01:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:02:28 --> Config Class Initialized
DEBUG - 2013-08-28 11:02:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:02:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:02:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:02:28 --> URI Class Initialized
DEBUG - 2013-08-28 11:02:28 --> Router Class Initialized
DEBUG - 2013-08-28 11:02:28 --> Output Class Initialized
DEBUG - 2013-08-28 11:02:28 --> Security Class Initialized
DEBUG - 2013-08-28 11:02:28 --> Input Class Initialized
DEBUG - 2013-08-28 11:02:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:02:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:02:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:02:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:02:28 --> Language Class Initialized
DEBUG - 2013-08-28 11:02:28 --> Loader Class Initialized
DEBUG - 2013-08-28 11:02:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:02:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:02:29 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:02:29 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:02:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:02:29 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:02:29 --> Session Class Initialized
DEBUG - 2013-08-28 11:02:29 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:02:29 --> Session routines successfully run
DEBUG - 2013-08-28 11:02:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:02:29 --> Controller Class Initialized
ERROR - 2013-08-28 11:02:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:02:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:02:29 --> Model Class Initialized
DEBUG - 2013-08-28 11:02:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:02:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:02:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:02:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:02:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:02:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:02:29 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\school\application\views\shared\head.php 14
DEBUG - 2013-08-28 11:02:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:02:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:02:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:02:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:02:29 --> File loaded: application/views/shared/breadcrumb.php
ERROR - 2013-08-28 11:02:29 --> Severity: Notice  --> Undefined variable: content_title C:\xampp\htdocs\school\application\views\shared\content_title.php 2
DEBUG - 2013-08-28 11:02:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:02:29 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-28 11:02:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:02:29 --> Final output sent to browser
DEBUG - 2013-08-28 11:02:29 --> Total execution time: 0.7370
DEBUG - 2013-08-28 11:02:29 --> Config Class Initialized
DEBUG - 2013-08-28 11:02:29 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:02:29 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:02:29 --> URI Class Initialized
DEBUG - 2013-08-28 11:02:29 --> Router Class Initialized
ERROR - 2013-08-28 11:02:29 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:02:44 --> Config Class Initialized
DEBUG - 2013-08-28 11:02:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:02:44 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:02:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:02:44 --> URI Class Initialized
DEBUG - 2013-08-28 11:02:44 --> Router Class Initialized
DEBUG - 2013-08-28 11:02:44 --> Output Class Initialized
DEBUG - 2013-08-28 11:02:44 --> Security Class Initialized
DEBUG - 2013-08-28 11:02:44 --> Input Class Initialized
DEBUG - 2013-08-28 11:02:44 --> XSS Filtering completed
DEBUG - 2013-08-28 11:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:02:44 --> Language Class Initialized
DEBUG - 2013-08-28 11:02:44 --> Loader Class Initialized
DEBUG - 2013-08-28 11:02:44 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:02:44 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:02:44 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:02:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:02:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:02:45 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:02:45 --> Session Class Initialized
DEBUG - 2013-08-28 11:02:45 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:02:45 --> Session routines successfully run
DEBUG - 2013-08-28 11:02:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:02:45 --> Controller Class Initialized
ERROR - 2013-08-28 11:02:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:02:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:02:45 --> Model Class Initialized
DEBUG - 2013-08-28 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:02:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:02:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:02:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:02:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:02:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:02:45 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\school\application\views\shared\head.php 14
DEBUG - 2013-08-28 11:02:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:02:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:02:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:02:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:02:45 --> File loaded: application/views/shared/breadcrumb.php
ERROR - 2013-08-28 11:02:45 --> Severity: Notice  --> Undefined variable: content_title C:\xampp\htdocs\school\application\views\shared\content_title.php 2
DEBUG - 2013-08-28 11:02:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:02:45 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-28 11:02:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:02:45 --> Final output sent to browser
DEBUG - 2013-08-28 11:02:45 --> Total execution time: 0.7230
DEBUG - 2013-08-28 11:02:45 --> Config Class Initialized
DEBUG - 2013-08-28 11:02:45 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:02:45 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:02:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:02:45 --> URI Class Initialized
DEBUG - 2013-08-28 11:02:45 --> Router Class Initialized
ERROR - 2013-08-28 11:02:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:03:28 --> Config Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:03:28 --> URI Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Router Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Output Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Security Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Input Class Initialized
DEBUG - 2013-08-28 11:03:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:03:28 --> Language Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Loader Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:03:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:03:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:03:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:03:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:03:28 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Session Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:03:28 --> Session routines successfully run
DEBUG - 2013-08-28 11:03:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Controller Class Initialized
ERROR - 2013-08-28 11:03:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:03:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:03:28 --> Model Class Initialized
DEBUG - 2013-08-28 11:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:03:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:03:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:03:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:03:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:03:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:04:12 --> Config Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:04:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:04:12 --> URI Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Router Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Output Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Security Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Input Class Initialized
DEBUG - 2013-08-28 11:04:12 --> XSS Filtering completed
DEBUG - 2013-08-28 11:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:04:12 --> Language Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Loader Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:04:12 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:04:12 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:04:12 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:04:12 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:04:12 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Session Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:04:12 --> Session garbage collection performed.
DEBUG - 2013-08-28 11:04:12 --> Session routines successfully run
DEBUG - 2013-08-28 11:04:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Controller Class Initialized
ERROR - 2013-08-28 11:04:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:04:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:04:12 --> Model Class Initialized
DEBUG - 2013-08-28 11:04:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:04:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:04:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:04:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:04:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:04:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:04:12 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\controllers\user_sessions.php 46
DEBUG - 2013-08-28 11:04:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:04:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:04:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:04:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:04:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:04:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:04:12 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-28 11:04:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:04:12 --> Final output sent to browser
DEBUG - 2013-08-28 11:04:12 --> Total execution time: 0.8830
DEBUG - 2013-08-28 11:04:13 --> Config Class Initialized
DEBUG - 2013-08-28 11:04:13 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:04:13 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:04:13 --> URI Class Initialized
DEBUG - 2013-08-28 11:04:13 --> Router Class Initialized
ERROR - 2013-08-28 11:04:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:04:49 --> Config Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:04:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:04:49 --> URI Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Router Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Output Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Security Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Input Class Initialized
DEBUG - 2013-08-28 11:04:49 --> XSS Filtering completed
DEBUG - 2013-08-28 11:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:04:49 --> Language Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Loader Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:04:49 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:04:49 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:04:49 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:04:49 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:04:49 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Session Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:04:49 --> Session routines successfully run
DEBUG - 2013-08-28 11:04:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Controller Class Initialized
ERROR - 2013-08-28 11:04:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:04:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:04:49 --> Model Class Initialized
DEBUG - 2013-08-28 11:04:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:04:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:04:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:04:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:04:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:04:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:04:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:04:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:04:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:04:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:04:50 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:04:50 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:04:50 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-08-28 11:04:50 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:04:50 --> Final output sent to browser
DEBUG - 2013-08-28 11:04:50 --> Total execution time: 1.0251
DEBUG - 2013-08-28 11:04:51 --> Config Class Initialized
DEBUG - 2013-08-28 11:04:51 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:04:51 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:04:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:04:51 --> URI Class Initialized
DEBUG - 2013-08-28 11:04:51 --> Router Class Initialized
ERROR - 2013-08-28 11:04:51 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:09:24 --> Config Class Initialized
DEBUG - 2013-08-28 11:09:24 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:09:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:09:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:09:25 --> URI Class Initialized
DEBUG - 2013-08-28 11:09:27 --> Router Class Initialized
DEBUG - 2013-08-28 11:09:27 --> Output Class Initialized
DEBUG - 2013-08-28 11:09:27 --> Security Class Initialized
DEBUG - 2013-08-28 11:09:27 --> Input Class Initialized
DEBUG - 2013-08-28 11:09:27 --> XSS Filtering completed
DEBUG - 2013-08-28 11:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:09:29 --> Language Class Initialized
DEBUG - 2013-08-28 11:09:32 --> Loader Class Initialized
DEBUG - 2013-08-28 11:09:33 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:09:33 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:09:37 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:09:37 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:09:38 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:09:42 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:09:45 --> Session Class Initialized
DEBUG - 2013-08-28 11:09:49 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:09:59 --> Session routines successfully run
DEBUG - 2013-08-28 11:10:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:10:05 --> Controller Class Initialized
ERROR - 2013-08-28 11:10:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:10:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:10:11 --> Model Class Initialized
DEBUG - 2013-08-28 11:10:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:10:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:10:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:10:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:10:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:10:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:10:26 --> Pagination Class Initialized
DEBUG - 2013-08-28 11:10:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:10:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:10:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:10:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:10:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:10:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:10:39 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 11:10:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:10:39 --> Final output sent to browser
DEBUG - 2013-08-28 11:10:39 --> Total execution time: 83.2898
DEBUG - 2013-08-28 11:10:45 --> Config Class Initialized
DEBUG - 2013-08-28 11:10:45 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:10:45 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:10:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:10:46 --> URI Class Initialized
DEBUG - 2013-08-28 11:10:46 --> Router Class Initialized
ERROR - 2013-08-28 11:10:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:10:53 --> Config Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:10:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:10:53 --> URI Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Router Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Output Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Security Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Input Class Initialized
DEBUG - 2013-08-28 11:10:53 --> XSS Filtering completed
DEBUG - 2013-08-28 11:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:10:53 --> Language Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Loader Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:10:53 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:10:53 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:10:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:10:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:10:53 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Session Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:10:53 --> Session routines successfully run
DEBUG - 2013-08-28 11:10:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Controller Class Initialized
ERROR - 2013-08-28 11:10:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:10:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:10:53 --> Model Class Initialized
DEBUG - 2013-08-28 11:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:10:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:10:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:10:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:10:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:10:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:11:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:11:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:11:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:11:39 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:11:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:11:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:11:39 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-08-28 11:11:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:11:39 --> Final output sent to browser
DEBUG - 2013-08-28 11:11:39 --> Total execution time: 46.2286
DEBUG - 2013-08-28 11:11:39 --> Config Class Initialized
DEBUG - 2013-08-28 11:11:39 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:11:39 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:11:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:11:39 --> URI Class Initialized
DEBUG - 2013-08-28 11:11:39 --> Router Class Initialized
ERROR - 2013-08-28 11:11:39 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:14:42 --> Config Class Initialized
DEBUG - 2013-08-28 11:14:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:14:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:14:42 --> URI Class Initialized
DEBUG - 2013-08-28 11:14:42 --> Router Class Initialized
DEBUG - 2013-08-28 11:14:42 --> Output Class Initialized
DEBUG - 2013-08-28 11:14:42 --> Security Class Initialized
DEBUG - 2013-08-28 11:14:42 --> Input Class Initialized
DEBUG - 2013-08-28 11:14:42 --> XSS Filtering completed
DEBUG - 2013-08-28 11:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:14:42 --> Language Class Initialized
DEBUG - 2013-08-28 11:14:42 --> Loader Class Initialized
DEBUG - 2013-08-28 11:14:42 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:14:42 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:14:42 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:14:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:14:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:14:42 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:14:43 --> Session Class Initialized
DEBUG - 2013-08-28 11:14:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:14:43 --> Session routines successfully run
DEBUG - 2013-08-28 11:14:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:14:43 --> Controller Class Initialized
ERROR - 2013-08-28 11:14:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:14:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:14:43 --> Model Class Initialized
DEBUG - 2013-08-28 11:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:14:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:14:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:14:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:14:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:14:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:14:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:14:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:14:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:14:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:14:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:14:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:14:43 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-08-28 11:14:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:14:43 --> Final output sent to browser
DEBUG - 2013-08-28 11:14:43 --> Total execution time: 1.2551
DEBUG - 2013-08-28 11:14:43 --> Config Class Initialized
DEBUG - 2013-08-28 11:14:43 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:14:43 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:14:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:14:43 --> URI Class Initialized
DEBUG - 2013-08-28 11:14:43 --> Router Class Initialized
ERROR - 2013-08-28 11:14:43 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:15:14 --> Config Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:15:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:15:14 --> URI Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Router Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Output Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Security Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Input Class Initialized
DEBUG - 2013-08-28 11:15:14 --> XSS Filtering completed
DEBUG - 2013-08-28 11:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:15:14 --> Language Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Loader Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:15:14 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:15:14 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:15:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:15:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:15:14 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Session Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:15:14 --> Session routines successfully run
DEBUG - 2013-08-28 11:15:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Controller Class Initialized
ERROR - 2013-08-28 11:15:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:14 --> Model Class Initialized
DEBUG - 2013-08-28 11:15:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:15:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:15:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:15:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:15:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:14 --> Pagination Class Initialized
DEBUG - 2013-08-28 11:15:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:15:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:15:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:15:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:15:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:15:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:15:14 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 11:15:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:15:14 --> Final output sent to browser
DEBUG - 2013-08-28 11:15:14 --> Total execution time: 0.9121
DEBUG - 2013-08-28 11:15:15 --> Config Class Initialized
DEBUG - 2013-08-28 11:15:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:15:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:15:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:15:15 --> URI Class Initialized
DEBUG - 2013-08-28 11:15:15 --> Router Class Initialized
ERROR - 2013-08-28 11:15:15 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:15:17 --> Config Class Initialized
DEBUG - 2013-08-28 11:15:17 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:15:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:15:18 --> URI Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Router Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Output Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Security Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Input Class Initialized
DEBUG - 2013-08-28 11:15:18 --> XSS Filtering completed
DEBUG - 2013-08-28 11:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:15:18 --> Language Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Loader Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:15:18 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:15:18 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:15:18 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:15:18 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:15:18 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Session Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:15:18 --> Session routines successfully run
DEBUG - 2013-08-28 11:15:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Controller Class Initialized
ERROR - 2013-08-28 11:15:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:18 --> Model Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:15:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:15:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:15:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:15:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:15:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:15:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:15:18 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:15:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:15:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:15:18 --> File loaded: application/views/gurus/edit.php
DEBUG - 2013-08-28 11:15:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:15:18 --> Final output sent to browser
DEBUG - 2013-08-28 11:15:18 --> Total execution time: 0.8100
DEBUG - 2013-08-28 11:15:18 --> Config Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:15:18 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:15:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:15:19 --> URI Class Initialized
DEBUG - 2013-08-28 11:15:19 --> Router Class Initialized
ERROR - 2013-08-28 11:15:19 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:15:34 --> Config Class Initialized
DEBUG - 2013-08-28 11:15:34 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:15:34 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:15:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:15:34 --> URI Class Initialized
DEBUG - 2013-08-28 11:15:34 --> Router Class Initialized
DEBUG - 2013-08-28 11:15:34 --> Output Class Initialized
DEBUG - 2013-08-28 11:15:34 --> Security Class Initialized
DEBUG - 2013-08-28 11:15:34 --> Input Class Initialized
DEBUG - 2013-08-28 11:15:34 --> XSS Filtering completed
DEBUG - 2013-08-28 11:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:15:35 --> Language Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Loader Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:15:35 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Session Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:15:35 --> Session garbage collection performed.
DEBUG - 2013-08-28 11:15:35 --> Session routines successfully run
DEBUG - 2013-08-28 11:15:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Controller Class Initialized
ERROR - 2013-08-28 11:15:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:35 --> Model Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:15:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:15:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:15:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:35 --> Config Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:15:35 --> URI Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Router Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Output Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Security Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Input Class Initialized
DEBUG - 2013-08-28 11:15:35 --> XSS Filtering completed
DEBUG - 2013-08-28 11:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:15:35 --> Language Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Loader Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:15:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:15:35 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:15:35 --> Session Class Initialized
DEBUG - 2013-08-28 11:15:36 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:15:36 --> Session routines successfully run
DEBUG - 2013-08-28 11:15:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:15:36 --> Controller Class Initialized
ERROR - 2013-08-28 11:15:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:36 --> Model Class Initialized
DEBUG - 2013-08-28 11:15:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:15:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:15:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:15:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:15:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:15:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:15:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:15:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:15:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:15:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:15:36 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-08-28 11:15:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:15:36 --> Final output sent to browser
DEBUG - 2013-08-28 11:15:36 --> Total execution time: 0.8410
DEBUG - 2013-08-28 11:15:36 --> Config Class Initialized
DEBUG - 2013-08-28 11:15:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:15:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:15:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:15:36 --> URI Class Initialized
DEBUG - 2013-08-28 11:15:36 --> Router Class Initialized
ERROR - 2013-08-28 11:15:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:15:53 --> Config Class Initialized
DEBUG - 2013-08-28 11:15:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:15:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:15:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:15:53 --> URI Class Initialized
DEBUG - 2013-08-28 11:15:53 --> Router Class Initialized
DEBUG - 2013-08-28 11:15:53 --> Output Class Initialized
DEBUG - 2013-08-28 11:15:53 --> Security Class Initialized
DEBUG - 2013-08-28 11:15:53 --> Input Class Initialized
DEBUG - 2013-08-28 11:15:53 --> XSS Filtering completed
DEBUG - 2013-08-28 11:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:15:54 --> Language Class Initialized
DEBUG - 2013-08-28 11:15:54 --> Loader Class Initialized
DEBUG - 2013-08-28 11:15:54 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:15:54 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:15:54 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:15:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:15:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:15:54 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:15:54 --> Session Class Initialized
DEBUG - 2013-08-28 11:15:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:15:54 --> Session routines successfully run
DEBUG - 2013-08-28 11:15:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:15:54 --> Controller Class Initialized
ERROR - 2013-08-28 11:15:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:54 --> Model Class Initialized
DEBUG - 2013-08-28 11:15:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:15:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:15:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:15:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:15:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:15:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:15:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:15:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:15:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:15:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:15:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:15:54 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 11:15:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:15:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:15:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 9
ERROR - 2013-08-28 11:15:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 9
ERROR - 2013-08-28 11:15:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:15:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:15:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 9
ERROR - 2013-08-28 11:15:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 9
ERROR - 2013-08-28 11:15:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:15:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:15:55 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 9
ERROR - 2013-08-28 11:15:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 9
ERROR - 2013-08-28 11:15:55 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:15:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:15:55 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 9
ERROR - 2013-08-28 11:15:55 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 9
DEBUG - 2013-08-28 11:15:55 --> File loaded: application/views/guru_walis/new.php
DEBUG - 2013-08-28 11:15:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:15:55 --> Final output sent to browser
DEBUG - 2013-08-28 11:15:55 --> Total execution time: 1.3771
DEBUG - 2013-08-28 11:15:55 --> Config Class Initialized
DEBUG - 2013-08-28 11:15:55 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:15:55 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:15:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:15:55 --> URI Class Initialized
DEBUG - 2013-08-28 11:15:55 --> Router Class Initialized
ERROR - 2013-08-28 11:15:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:19:44 --> Config Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:19:44 --> URI Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Router Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Output Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Security Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Input Class Initialized
DEBUG - 2013-08-28 11:19:44 --> XSS Filtering completed
DEBUG - 2013-08-28 11:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:19:44 --> Language Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Loader Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:19:44 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:19:44 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:19:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:19:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:19:44 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Session Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:19:44 --> Session routines successfully run
DEBUG - 2013-08-28 11:19:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Controller Class Initialized
ERROR - 2013-08-28 11:19:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:19:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:19:44 --> Model Class Initialized
DEBUG - 2013-08-28 11:19:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:19:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:19:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:19:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:19:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:19:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:19:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:19:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:19:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:19:45 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'nama' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 7
ERROR - 2013-08-28 11:19:45 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:19:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
DEBUG - 2013-08-28 11:19:45 --> File loaded: application/views/guru_walis/new.php
DEBUG - 2013-08-28 11:19:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:19:45 --> Final output sent to browser
DEBUG - 2013-08-28 11:19:45 --> Total execution time: 1.3231
DEBUG - 2013-08-28 11:19:45 --> Config Class Initialized
DEBUG - 2013-08-28 11:19:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:19:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:19:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:19:46 --> URI Class Initialized
DEBUG - 2013-08-28 11:19:46 --> Router Class Initialized
ERROR - 2013-08-28 11:19:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:20:35 --> Config Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:20:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:20:35 --> URI Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Router Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Output Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Security Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Input Class Initialized
DEBUG - 2013-08-28 11:20:35 --> XSS Filtering completed
DEBUG - 2013-08-28 11:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:20:35 --> Language Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Loader Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:20:35 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:20:35 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:20:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:20:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:20:35 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Session Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:20:35 --> Session routines successfully run
DEBUG - 2013-08-28 11:20:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Controller Class Initialized
ERROR - 2013-08-28 11:20:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:20:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:20:35 --> Model Class Initialized
DEBUG - 2013-08-28 11:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:20:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:20:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:20:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:20:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:20:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:20:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:20:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:20:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:20:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:20:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:20:35 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 11:20:35 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:20:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:20:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:20:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:20:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:20:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:20:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:20:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:20:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:20:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:20:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:20:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:20:36 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:20:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:20:36 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:20:36 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
DEBUG - 2013-08-28 11:20:36 --> File loaded: application/views/guru_walis/new.php
DEBUG - 2013-08-28 11:20:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:20:36 --> Final output sent to browser
DEBUG - 2013-08-28 11:20:36 --> Total execution time: 1.1491
DEBUG - 2013-08-28 11:20:36 --> Config Class Initialized
DEBUG - 2013-08-28 11:20:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:20:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:20:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:20:36 --> URI Class Initialized
DEBUG - 2013-08-28 11:20:36 --> Router Class Initialized
ERROR - 2013-08-28 11:20:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:21:03 --> Config Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:21:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:21:04 --> URI Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Router Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Output Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Security Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Input Class Initialized
DEBUG - 2013-08-28 11:21:04 --> XSS Filtering completed
DEBUG - 2013-08-28 11:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:21:04 --> Language Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Loader Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:21:04 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:21:04 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:21:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:21:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:21:04 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Session Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:21:04 --> Session routines successfully run
DEBUG - 2013-08-28 11:21:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Controller Class Initialized
ERROR - 2013-08-28 11:21:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:21:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:21:04 --> Model Class Initialized
DEBUG - 2013-08-28 11:21:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:21:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:21:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:21:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:21:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:21:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:21:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:21:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:21:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:21:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:21:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:21:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:21:20 --> Config Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:21:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:21:20 --> URI Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Router Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Output Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Security Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Input Class Initialized
DEBUG - 2013-08-28 11:21:20 --> XSS Filtering completed
DEBUG - 2013-08-28 11:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:21:20 --> Language Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Loader Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:21:20 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:21:20 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:21:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:21:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:21:20 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Session Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:21:20 --> Session routines successfully run
DEBUG - 2013-08-28 11:21:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Controller Class Initialized
ERROR - 2013-08-28 11:21:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:21:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:21:20 --> Model Class Initialized
DEBUG - 2013-08-28 11:21:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:21:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:21:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:21:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:21:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:21:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:21:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:21:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:21:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:21:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:21:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:21:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:22:09 --> Config Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:22:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:22:09 --> URI Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Router Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Output Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Security Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Input Class Initialized
DEBUG - 2013-08-28 11:22:09 --> XSS Filtering completed
DEBUG - 2013-08-28 11:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:22:09 --> Language Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Loader Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:22:09 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:22:09 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:22:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:22:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:22:09 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Session Class Initialized
DEBUG - 2013-08-28 11:22:09 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:22:09 --> Session routines successfully run
DEBUG - 2013-08-28 11:22:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:22:10 --> Controller Class Initialized
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:22:10 --> Model Class Initialized
DEBUG - 2013-08-28 11:22:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:22:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:22:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:22:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:22:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:22:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:22:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:22:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:22:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:22:10 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:22:10 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:22:10 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:22:10 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:22:10 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:22:10 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:22:10 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:22:10 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 6
ERROR - 2013-08-28 11:22:10 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
ERROR - 2013-08-28 11:22:10 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\MY_application_helper.php 8
DEBUG - 2013-08-28 11:22:10 --> File loaded: application/views/guru_walis/new.php
DEBUG - 2013-08-28 11:22:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:22:10 --> Final output sent to browser
DEBUG - 2013-08-28 11:22:10 --> Total execution time: 1.1241
DEBUG - 2013-08-28 11:22:10 --> Config Class Initialized
DEBUG - 2013-08-28 11:22:10 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:22:10 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:22:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:22:10 --> URI Class Initialized
DEBUG - 2013-08-28 11:22:10 --> Router Class Initialized
ERROR - 2013-08-28 11:22:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:23:36 --> Config Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:23:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:23:36 --> URI Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Router Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Output Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Security Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Input Class Initialized
DEBUG - 2013-08-28 11:23:36 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:23:36 --> Language Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Loader Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:23:36 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:23:36 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:23:36 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:23:36 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:23:36 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Session Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:23:36 --> Session routines successfully run
DEBUG - 2013-08-28 11:23:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Controller Class Initialized
ERROR - 2013-08-28 11:23:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:23:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:23:36 --> Model Class Initialized
DEBUG - 2013-08-28 11:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:23:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:23:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:23:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:23:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:23:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:23:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:23:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:23:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:23:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:23:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:23:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:23:37 --> File loaded: application/views/guru_ijazahs/new.php
DEBUG - 2013-08-28 11:23:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:23:37 --> Final output sent to browser
DEBUG - 2013-08-28 11:23:37 --> Total execution time: 0.9181
DEBUG - 2013-08-28 11:23:37 --> Config Class Initialized
DEBUG - 2013-08-28 11:23:37 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:23:37 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:23:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:23:37 --> URI Class Initialized
DEBUG - 2013-08-28 11:23:37 --> Router Class Initialized
ERROR - 2013-08-28 11:23:37 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:23:41 --> Config Class Initialized
DEBUG - 2013-08-28 11:23:41 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:23:41 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:23:41 --> URI Class Initialized
DEBUG - 2013-08-28 11:23:41 --> Router Class Initialized
DEBUG - 2013-08-28 11:23:41 --> Output Class Initialized
DEBUG - 2013-08-28 11:23:41 --> Security Class Initialized
DEBUG - 2013-08-28 11:23:41 --> Input Class Initialized
DEBUG - 2013-08-28 11:23:41 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:41 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:41 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:41 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:41 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:41 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:23:42 --> Language Class Initialized
DEBUG - 2013-08-28 11:23:42 --> Loader Class Initialized
DEBUG - 2013-08-28 11:23:42 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:23:42 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:23:42 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:23:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:23:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:23:42 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:23:42 --> Session Class Initialized
DEBUG - 2013-08-28 11:23:42 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:23:42 --> Session routines successfully run
DEBUG - 2013-08-28 11:23:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:23:42 --> Controller Class Initialized
ERROR - 2013-08-28 11:23:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:23:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:23:42 --> Model Class Initialized
DEBUG - 2013-08-28 11:23:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:23:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:23:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:23:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:23:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:23:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:23:42 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:23:42 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:42 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:42 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:42 --> XSS Filtering completed
DEBUG - 2013-08-28 11:23:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 11:23:42 --> Config Class Initialized
DEBUG - 2013-08-28 11:23:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:23:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:23:42 --> URI Class Initialized
DEBUG - 2013-08-28 11:23:42 --> Router Class Initialized
ERROR - 2013-08-28 11:23:42 --> 404 Page Not Found --> guruijazahs
DEBUG - 2013-08-28 11:24:21 --> Config Class Initialized
DEBUG - 2013-08-28 11:24:21 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:24:21 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:24:21 --> URI Class Initialized
DEBUG - 2013-08-28 11:24:21 --> Router Class Initialized
DEBUG - 2013-08-28 11:24:21 --> Output Class Initialized
DEBUG - 2013-08-28 11:24:21 --> Security Class Initialized
DEBUG - 2013-08-28 11:24:21 --> Input Class Initialized
DEBUG - 2013-08-28 11:24:21 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:24:21 --> Language Class Initialized
DEBUG - 2013-08-28 11:24:21 --> Loader Class Initialized
DEBUG - 2013-08-28 11:24:21 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:24:22 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:24:22 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:24:22 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:24:22 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:24:22 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:24:22 --> Session Class Initialized
DEBUG - 2013-08-28 11:24:22 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:24:22 --> Session routines successfully run
DEBUG - 2013-08-28 11:24:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:24:22 --> Controller Class Initialized
ERROR - 2013-08-28 11:24:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:24:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:24:22 --> Model Class Initialized
DEBUG - 2013-08-28 11:24:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:24:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:24:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:24:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:24:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:24:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:24:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:24:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:24:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:24:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:24:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:24:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:24:22 --> File loaded: application/views/guru_ijazahs/new.php
DEBUG - 2013-08-28 11:24:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:24:22 --> Final output sent to browser
DEBUG - 2013-08-28 11:24:22 --> Total execution time: 0.9341
DEBUG - 2013-08-28 11:24:22 --> Config Class Initialized
DEBUG - 2013-08-28 11:24:22 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:24:22 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:24:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:24:22 --> URI Class Initialized
DEBUG - 2013-08-28 11:24:23 --> Router Class Initialized
ERROR - 2013-08-28 11:24:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:24:27 --> Config Class Initialized
DEBUG - 2013-08-28 11:24:27 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:24:27 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:24:27 --> URI Class Initialized
DEBUG - 2013-08-28 11:24:27 --> Router Class Initialized
DEBUG - 2013-08-28 11:24:27 --> Output Class Initialized
DEBUG - 2013-08-28 11:24:27 --> Security Class Initialized
DEBUG - 2013-08-28 11:24:27 --> Input Class Initialized
DEBUG - 2013-08-28 11:24:27 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:24:27 --> Language Class Initialized
DEBUG - 2013-08-28 11:24:28 --> Loader Class Initialized
DEBUG - 2013-08-28 11:24:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:24:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:24:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:24:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:24:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:24:28 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:24:28 --> Session Class Initialized
DEBUG - 2013-08-28 11:24:28 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:24:28 --> Session routines successfully run
DEBUG - 2013-08-28 11:24:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:24:28 --> Controller Class Initialized
ERROR - 2013-08-28 11:24:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:24:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:24:28 --> Model Class Initialized
DEBUG - 2013-08-28 11:24:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:24:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:24:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:24:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:24:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:24:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:24:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:24:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:24:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:24:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:24:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:24:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:24:28 --> File loaded: application/views/guru_ijazahs/new.php
DEBUG - 2013-08-28 11:24:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:24:28 --> Final output sent to browser
DEBUG - 2013-08-28 11:24:28 --> Total execution time: 0.8861
DEBUG - 2013-08-28 11:24:28 --> Config Class Initialized
DEBUG - 2013-08-28 11:24:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:24:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:24:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:24:28 --> URI Class Initialized
DEBUG - 2013-08-28 11:24:28 --> Router Class Initialized
ERROR - 2013-08-28 11:24:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:24:32 --> Config Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:24:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:24:32 --> URI Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Router Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Output Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Security Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Input Class Initialized
DEBUG - 2013-08-28 11:24:32 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:32 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:32 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:32 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:32 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:32 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:24:32 --> Language Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Loader Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:24:32 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:24:32 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:24:32 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:24:32 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:24:32 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Session Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:24:32 --> Session routines successfully run
DEBUG - 2013-08-28 11:24:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Controller Class Initialized
ERROR - 2013-08-28 11:24:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:24:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:24:32 --> Model Class Initialized
DEBUG - 2013-08-28 11:24:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:24:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:24:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:24:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:24:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:24:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:24:32 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:24:32 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:32 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:33 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:33 --> XSS Filtering completed
DEBUG - 2013-08-28 11:24:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 11:24:33 --> Config Class Initialized
DEBUG - 2013-08-28 11:24:33 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:24:33 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:24:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:24:33 --> URI Class Initialized
DEBUG - 2013-08-28 11:24:33 --> Router Class Initialized
ERROR - 2013-08-28 11:24:33 --> 404 Page Not Found --> guruijazahs
DEBUG - 2013-08-28 11:26:17 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:17 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:17 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:17 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:17 --> Router Class Initialized
DEBUG - 2013-08-28 11:26:17 --> Output Class Initialized
DEBUG - 2013-08-28 11:26:17 --> Security Class Initialized
DEBUG - 2013-08-28 11:26:17 --> Input Class Initialized
DEBUG - 2013-08-28 11:26:17 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:26:17 --> Language Class Initialized
DEBUG - 2013-08-28 11:26:17 --> Loader Class Initialized
DEBUG - 2013-08-28 11:26:17 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:26:17 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:26:17 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:26:18 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:26:18 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:26:18 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:26:18 --> Session Class Initialized
DEBUG - 2013-08-28 11:26:18 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:26:18 --> Session routines successfully run
DEBUG - 2013-08-28 11:26:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:26:18 --> Controller Class Initialized
ERROR - 2013-08-28 11:26:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:18 --> Model Class Initialized
DEBUG - 2013-08-28 11:26:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:26:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:26:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:26:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:26:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:26:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:26:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:26:18 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:26:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:26:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:26:18 --> File loaded: application/views/guru_ijazahs/new.php
DEBUG - 2013-08-28 11:26:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:26:18 --> Final output sent to browser
DEBUG - 2013-08-28 11:26:18 --> Total execution time: 1.0711
DEBUG - 2013-08-28 11:26:18 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:19 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:19 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:19 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:19 --> Router Class Initialized
ERROR - 2013-08-28 11:26:19 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:26:28 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:28 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:28 --> Router Class Initialized
DEBUG - 2013-08-28 11:26:28 --> Output Class Initialized
DEBUG - 2013-08-28 11:26:28 --> Security Class Initialized
DEBUG - 2013-08-28 11:26:28 --> Input Class Initialized
DEBUG - 2013-08-28 11:26:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:28 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:26:28 --> Language Class Initialized
DEBUG - 2013-08-28 11:26:28 --> Loader Class Initialized
DEBUG - 2013-08-28 11:26:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:26:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:26:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:26:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:26:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:26:29 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Session Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:26:29 --> Session routines successfully run
DEBUG - 2013-08-28 11:26:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Controller Class Initialized
ERROR - 2013-08-28 11:26:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:29 --> Model Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:26:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:26:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:26:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:26:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:29 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:26:29 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:29 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:29 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:29 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 11:26:29 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:29 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Router Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Output Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Security Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Input Class Initialized
DEBUG - 2013-08-28 11:26:29 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:26:29 --> Language Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Loader Class Initialized
DEBUG - 2013-08-28 11:26:29 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:26:29 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:26:30 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:26:30 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:26:30 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:26:30 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:26:30 --> Session Class Initialized
DEBUG - 2013-08-28 11:26:30 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:26:30 --> Session routines successfully run
DEBUG - 2013-08-28 11:26:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:26:30 --> Controller Class Initialized
ERROR - 2013-08-28 11:26:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:30 --> Model Class Initialized
DEBUG - 2013-08-28 11:26:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:26:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:26:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:26:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:26:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:26:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:26:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:26:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:26:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:26:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:26:30 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-08-28 11:26:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:26:30 --> Final output sent to browser
DEBUG - 2013-08-28 11:26:30 --> Total execution time: 1.1791
DEBUG - 2013-08-28 11:26:31 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:31 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:31 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:31 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:31 --> Router Class Initialized
ERROR - 2013-08-28 11:26:31 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:26:36 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:37 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Router Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Output Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Security Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Input Class Initialized
DEBUG - 2013-08-28 11:26:37 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:26:37 --> Language Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Loader Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:26:37 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:26:37 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:26:37 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:26:37 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:26:37 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Session Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:26:37 --> Session routines successfully run
DEBUG - 2013-08-28 11:26:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Controller Class Initialized
ERROR - 2013-08-28 11:26:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:37 --> Model Class Initialized
DEBUG - 2013-08-28 11:26:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:26:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:26:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:26:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:26:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:37 --> Pagination Class Initialized
DEBUG - 2013-08-28 11:26:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:26:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:26:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:26:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:26:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:26:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:26:37 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-28 11:26:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:26:37 --> Final output sent to browser
DEBUG - 2013-08-28 11:26:38 --> Total execution time: 1.0661
DEBUG - 2013-08-28 11:26:38 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:38 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:38 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:38 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:38 --> Router Class Initialized
ERROR - 2013-08-28 11:26:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:26:42 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:43 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Router Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Output Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Security Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Input Class Initialized
DEBUG - 2013-08-28 11:26:43 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:26:43 --> Language Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Loader Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:26:43 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:26:43 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:26:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:26:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:26:43 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Session Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:26:43 --> Session routines successfully run
DEBUG - 2013-08-28 11:26:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Controller Class Initialized
ERROR - 2013-08-28 11:26:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:43 --> Model Class Initialized
DEBUG - 2013-08-28 11:26:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:26:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:26:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:26:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:26:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:26:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:26:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:26:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:26:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:26:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:26:43 --> File loaded: application/views/gurus/edit.php
DEBUG - 2013-08-28 11:26:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:26:43 --> Final output sent to browser
DEBUG - 2013-08-28 11:26:43 --> Total execution time: 0.9761
DEBUG - 2013-08-28 11:26:44 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:44 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:44 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:44 --> Router Class Initialized
ERROR - 2013-08-28 11:26:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:26:48 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:48 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:48 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:48 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:48 --> Router Class Initialized
DEBUG - 2013-08-28 11:26:48 --> Output Class Initialized
DEBUG - 2013-08-28 11:26:48 --> Security Class Initialized
DEBUG - 2013-08-28 11:26:48 --> Input Class Initialized
DEBUG - 2013-08-28 11:26:48 --> XSS Filtering completed
DEBUG - 2013-08-28 11:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:26:49 --> Language Class Initialized
DEBUG - 2013-08-28 11:26:49 --> Loader Class Initialized
DEBUG - 2013-08-28 11:26:49 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:26:49 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:26:49 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:26:49 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:26:49 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:26:49 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:26:49 --> Session Class Initialized
DEBUG - 2013-08-28 11:26:49 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:26:49 --> Session routines successfully run
DEBUG - 2013-08-28 11:26:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:26:49 --> Controller Class Initialized
ERROR - 2013-08-28 11:26:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:49 --> Model Class Initialized
DEBUG - 2013-08-28 11:26:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:26:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:26:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:26:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:26:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:26:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:26:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:26:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:26:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:26:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:26:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:26:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:26:49 --> File loaded: application/views/guru_ijazahs/edit.php
DEBUG - 2013-08-28 11:26:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:26:49 --> Final output sent to browser
DEBUG - 2013-08-28 11:26:49 --> Total execution time: 0.9331
DEBUG - 2013-08-28 11:26:49 --> Config Class Initialized
DEBUG - 2013-08-28 11:26:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:26:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:26:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:26:50 --> URI Class Initialized
DEBUG - 2013-08-28 11:26:50 --> Router Class Initialized
ERROR - 2013-08-28 11:26:50 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:27:00 --> Config Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:27:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:27:00 --> URI Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Router Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Output Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Security Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Input Class Initialized
DEBUG - 2013-08-28 11:27:00 --> XSS Filtering completed
DEBUG - 2013-08-28 11:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:27:00 --> Language Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Loader Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:27:00 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:27:00 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:27:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:27:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:27:00 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Session Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:27:00 --> Session routines successfully run
DEBUG - 2013-08-28 11:27:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Controller Class Initialized
ERROR - 2013-08-28 11:27:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:27:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:27:00 --> Model Class Initialized
DEBUG - 2013-08-28 11:27:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:27:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:27:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:27:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:27:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:27:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:27:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:27:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:27:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:27:01 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:27:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:27:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:27:01 --> File loaded: application/views/guru_ijazahs/edit.php
DEBUG - 2013-08-28 11:27:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:27:01 --> Final output sent to browser
DEBUG - 2013-08-28 11:27:01 --> Total execution time: 0.9371
DEBUG - 2013-08-28 11:27:01 --> Config Class Initialized
DEBUG - 2013-08-28 11:27:01 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:27:01 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:27:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:27:01 --> URI Class Initialized
DEBUG - 2013-08-28 11:27:01 --> Router Class Initialized
ERROR - 2013-08-28 11:27:01 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:27:13 --> Config Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:27:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:27:14 --> URI Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Router Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Output Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Security Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Input Class Initialized
DEBUG - 2013-08-28 11:27:14 --> XSS Filtering completed
DEBUG - 2013-08-28 11:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:27:14 --> Language Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Loader Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:27:14 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:27:14 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:27:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:27:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:27:14 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Session Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:27:14 --> Session routines successfully run
DEBUG - 2013-08-28 11:27:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Controller Class Initialized
ERROR - 2013-08-28 11:27:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:27:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:27:14 --> Model Class Initialized
DEBUG - 2013-08-28 11:27:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:27:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:27:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:27:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:27:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:27:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:27:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:27:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:27:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:27:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:27:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:27:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:27:14 --> File loaded: application/views/guru_ijazahs/new.php
DEBUG - 2013-08-28 11:27:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:27:14 --> Final output sent to browser
DEBUG - 2013-08-28 11:27:15 --> Total execution time: 1.1081
DEBUG - 2013-08-28 11:27:15 --> Config Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:27:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:27:15 --> URI Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Router Class Initialized
ERROR - 2013-08-28 11:27:15 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:27:15 --> Config Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:27:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:27:15 --> URI Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Router Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Output Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Security Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Input Class Initialized
DEBUG - 2013-08-28 11:27:15 --> XSS Filtering completed
DEBUG - 2013-08-28 11:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:27:15 --> Language Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Loader Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:27:15 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:27:15 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:27:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:27:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:27:15 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Session Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:27:15 --> Session routines successfully run
DEBUG - 2013-08-28 11:27:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:27:15 --> Controller Class Initialized
ERROR - 2013-08-28 11:27:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:27:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:27:16 --> Model Class Initialized
DEBUG - 2013-08-28 11:27:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:27:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:27:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:27:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:27:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:27:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:27:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:27:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:27:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:27:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:27:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:27:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:27:16 --> File loaded: application/views/guru_ijazahs/edit.php
DEBUG - 2013-08-28 11:27:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:27:16 --> Final output sent to browser
DEBUG - 2013-08-28 11:27:16 --> Total execution time: 1.1301
DEBUG - 2013-08-28 11:27:16 --> Config Class Initialized
DEBUG - 2013-08-28 11:27:16 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:27:16 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:27:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:27:16 --> URI Class Initialized
DEBUG - 2013-08-28 11:27:16 --> Router Class Initialized
ERROR - 2013-08-28 11:27:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:29:00 --> Config Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:29:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:29:00 --> URI Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Router Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Output Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Security Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Input Class Initialized
DEBUG - 2013-08-28 11:29:00 --> XSS Filtering completed
DEBUG - 2013-08-28 11:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:29:00 --> Language Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Loader Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:29:00 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:29:00 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:29:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:29:00 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:29:00 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Session Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:29:00 --> Session routines successfully run
DEBUG - 2013-08-28 11:29:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Controller Class Initialized
ERROR - 2013-08-28 11:29:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:29:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:29:00 --> Model Class Initialized
DEBUG - 2013-08-28 11:29:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:29:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:29:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:29:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:29:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:29:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:29:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:29:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:29:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:29:01 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:29:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:29:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:29:01 --> File loaded: application/views/guru_ijazahs/edit.php
DEBUG - 2013-08-28 11:29:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:29:01 --> Final output sent to browser
DEBUG - 2013-08-28 11:29:01 --> Total execution time: 0.9771
DEBUG - 2013-08-28 11:29:01 --> Config Class Initialized
DEBUG - 2013-08-28 11:29:01 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:29:01 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:29:01 --> URI Class Initialized
DEBUG - 2013-08-28 11:29:01 --> Router Class Initialized
ERROR - 2013-08-28 11:29:01 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:29:12 --> Config Class Initialized
DEBUG - 2013-08-28 11:29:12 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:29:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:29:13 --> URI Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Router Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Output Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Security Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Input Class Initialized
DEBUG - 2013-08-28 11:29:13 --> XSS Filtering completed
DEBUG - 2013-08-28 11:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:29:13 --> Language Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Loader Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:29:13 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:29:13 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:29:13 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:29:13 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:29:13 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Session Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:29:13 --> Session routines successfully run
DEBUG - 2013-08-28 11:29:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Controller Class Initialized
ERROR - 2013-08-28 11:29:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:29:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:29:13 --> Model Class Initialized
DEBUG - 2013-08-28 11:29:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:29:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:29:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:29:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:29:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:29:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:29:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:29:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:29:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:29:13 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:29:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:29:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:29:13 --> File loaded: application/views/guru_ijazahs/edit.php
DEBUG - 2013-08-28 11:29:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:29:14 --> Final output sent to browser
DEBUG - 2013-08-28 11:29:14 --> Total execution time: 1.0851
DEBUG - 2013-08-28 11:29:14 --> Config Class Initialized
DEBUG - 2013-08-28 11:29:14 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:29:14 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:29:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:29:14 --> URI Class Initialized
DEBUG - 2013-08-28 11:29:14 --> Router Class Initialized
ERROR - 2013-08-28 11:29:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:29:52 --> Config Class Initialized
DEBUG - 2013-08-28 11:29:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:29:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:29:52 --> URI Class Initialized
DEBUG - 2013-08-28 11:29:52 --> Router Class Initialized
DEBUG - 2013-08-28 11:29:52 --> Output Class Initialized
DEBUG - 2013-08-28 11:29:52 --> Security Class Initialized
DEBUG - 2013-08-28 11:29:52 --> Input Class Initialized
DEBUG - 2013-08-28 11:29:52 --> XSS Filtering completed
DEBUG - 2013-08-28 11:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:29:53 --> Language Class Initialized
DEBUG - 2013-08-28 11:29:53 --> Loader Class Initialized
DEBUG - 2013-08-28 11:29:53 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:29:53 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:29:53 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:29:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:29:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:29:53 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:29:53 --> Session Class Initialized
DEBUG - 2013-08-28 11:29:53 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:29:53 --> Session routines successfully run
DEBUG - 2013-08-28 11:29:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:29:53 --> Controller Class Initialized
ERROR - 2013-08-28 11:29:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:29:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:29:53 --> Model Class Initialized
DEBUG - 2013-08-28 11:29:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:29:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:29:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:29:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:29:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:29:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:29:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:29:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:29:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:29:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:29:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:29:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:29:53 --> File loaded: application/views/guru_ijazahs/edit.php
DEBUG - 2013-08-28 11:29:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:29:53 --> Final output sent to browser
DEBUG - 2013-08-28 11:29:53 --> Total execution time: 0.9451
DEBUG - 2013-08-28 11:29:53 --> Config Class Initialized
DEBUG - 2013-08-28 11:29:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:29:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:29:54 --> URI Class Initialized
DEBUG - 2013-08-28 11:29:54 --> Router Class Initialized
ERROR - 2013-08-28 11:29:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:30:14 --> Config Class Initialized
DEBUG - 2013-08-28 11:30:14 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:30:14 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:30:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:30:14 --> URI Class Initialized
DEBUG - 2013-08-28 11:30:14 --> Router Class Initialized
DEBUG - 2013-08-28 11:30:14 --> Output Class Initialized
DEBUG - 2013-08-28 11:30:14 --> Security Class Initialized
DEBUG - 2013-08-28 11:30:14 --> Input Class Initialized
DEBUG - 2013-08-28 11:30:14 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:14 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:14 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:14 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:14 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:14 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:30:14 --> Language Class Initialized
DEBUG - 2013-08-28 11:30:14 --> Loader Class Initialized
DEBUG - 2013-08-28 11:30:14 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:30:14 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:30:14 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:30:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:30:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:30:14 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:30:14 --> Session Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:30:15 --> Session routines successfully run
DEBUG - 2013-08-28 11:30:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Controller Class Initialized
ERROR - 2013-08-28 11:30:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:30:15 --> Model Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:30:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:30:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:30:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:30:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:30:15 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:30:15 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:15 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:15 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:15 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 11:30:15 --> Config Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:30:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:30:15 --> URI Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Router Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Output Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Security Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Input Class Initialized
DEBUG - 2013-08-28 11:30:15 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:30:15 --> Language Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Loader Class Initialized
DEBUG - 2013-08-28 11:30:15 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:30:15 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:30:15 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:30:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:30:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:30:16 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:30:16 --> Session Class Initialized
DEBUG - 2013-08-28 11:30:16 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:30:16 --> Session routines successfully run
DEBUG - 2013-08-28 11:30:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:30:16 --> Controller Class Initialized
ERROR - 2013-08-28 11:30:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:30:16 --> Model Class Initialized
DEBUG - 2013-08-28 11:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:30:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:30:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:30:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:30:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:30:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:30:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:30:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:30:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:30:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:30:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:30:16 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-08-28 11:30:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:30:16 --> Final output sent to browser
DEBUG - 2013-08-28 11:30:16 --> Total execution time: 1.1811
DEBUG - 2013-08-28 11:30:17 --> Config Class Initialized
DEBUG - 2013-08-28 11:30:17 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:30:17 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:30:17 --> URI Class Initialized
DEBUG - 2013-08-28 11:30:17 --> Router Class Initialized
ERROR - 2013-08-28 11:30:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:30:35 --> Config Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:30:35 --> URI Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Router Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Output Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Security Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Input Class Initialized
DEBUG - 2013-08-28 11:30:35 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:30:35 --> Language Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Loader Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:30:35 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:30:35 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:30:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:30:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:30:35 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Session Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:30:35 --> Session routines successfully run
DEBUG - 2013-08-28 11:30:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:30:35 --> Controller Class Initialized
ERROR - 2013-08-28 11:30:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:30:36 --> Model Class Initialized
DEBUG - 2013-08-28 11:30:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:30:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:30:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:30:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:30:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:30:36 --> Pagination Class Initialized
DEBUG - 2013-08-28 11:30:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:30:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:30:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:30:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:30:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:30:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:30:36 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 11:30:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:30:36 --> Final output sent to browser
DEBUG - 2013-08-28 11:30:36 --> Total execution time: 1.1031
DEBUG - 2013-08-28 11:30:36 --> Config Class Initialized
DEBUG - 2013-08-28 11:30:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:30:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:30:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:30:36 --> URI Class Initialized
DEBUG - 2013-08-28 11:30:36 --> Router Class Initialized
ERROR - 2013-08-28 11:30:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:30:40 --> Config Class Initialized
DEBUG - 2013-08-28 11:30:40 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:30:40 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:30:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:30:40 --> URI Class Initialized
DEBUG - 2013-08-28 11:30:40 --> Router Class Initialized
DEBUG - 2013-08-28 11:30:40 --> Output Class Initialized
DEBUG - 2013-08-28 11:30:40 --> Security Class Initialized
DEBUG - 2013-08-28 11:30:40 --> Input Class Initialized
DEBUG - 2013-08-28 11:30:41 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:30:41 --> Language Class Initialized
DEBUG - 2013-08-28 11:30:41 --> Loader Class Initialized
DEBUG - 2013-08-28 11:30:41 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:30:41 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:30:41 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:30:41 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:30:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:30:41 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:30:41 --> Session Class Initialized
DEBUG - 2013-08-28 11:30:41 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:30:41 --> Session routines successfully run
DEBUG - 2013-08-28 11:30:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:30:41 --> Controller Class Initialized
ERROR - 2013-08-28 11:30:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:30:41 --> Model Class Initialized
DEBUG - 2013-08-28 11:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:30:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:30:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:30:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:30:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:30:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:30:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:30:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:30:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:30:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:30:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:30:41 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 11:30:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:30:41 --> Final output sent to browser
DEBUG - 2013-08-28 11:30:41 --> Total execution time: 1.1601
DEBUG - 2013-08-28 11:30:42 --> Config Class Initialized
DEBUG - 2013-08-28 11:30:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:30:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:30:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:30:42 --> URI Class Initialized
DEBUG - 2013-08-28 11:30:42 --> Router Class Initialized
ERROR - 2013-08-28 11:30:42 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:30:46 --> Config Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:30:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:30:46 --> URI Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Router Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Output Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Security Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Input Class Initialized
DEBUG - 2013-08-28 11:30:46 --> XSS Filtering completed
DEBUG - 2013-08-28 11:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:30:46 --> Language Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Loader Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:30:46 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:30:46 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:30:46 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:30:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:30:46 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Session Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:30:46 --> Session garbage collection performed.
DEBUG - 2013-08-28 11:30:46 --> Session routines successfully run
DEBUG - 2013-08-28 11:30:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:30:46 --> Controller Class Initialized
ERROR - 2013-08-28 11:30:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:30:46 --> Model Class Initialized
DEBUG - 2013-08-28 11:30:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:30:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:30:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:30:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:30:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:30:47 --> Severity: Notice  --> Undefined variable: kelas_id C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 56
DEBUG - 2013-08-28 11:30:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:30:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:30:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:30:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:30:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:30:47 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:30:47 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 11:30:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:30:47 --> Final output sent to browser
DEBUG - 2013-08-28 11:30:47 --> Total execution time: 1.2101
DEBUG - 2013-08-28 11:30:47 --> Config Class Initialized
DEBUG - 2013-08-28 11:30:47 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:30:47 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:30:47 --> URI Class Initialized
DEBUG - 2013-08-28 11:30:47 --> Router Class Initialized
ERROR - 2013-08-28 11:30:47 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:31:20 --> Config Class Initialized
DEBUG - 2013-08-28 11:31:20 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:31:20 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:31:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:31:20 --> URI Class Initialized
DEBUG - 2013-08-28 11:31:20 --> Router Class Initialized
DEBUG - 2013-08-28 11:31:20 --> Output Class Initialized
DEBUG - 2013-08-28 11:31:20 --> Security Class Initialized
DEBUG - 2013-08-28 11:31:20 --> Input Class Initialized
DEBUG - 2013-08-28 11:31:20 --> XSS Filtering completed
DEBUG - 2013-08-28 11:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:31:20 --> Language Class Initialized
DEBUG - 2013-08-28 11:31:20 --> Loader Class Initialized
DEBUG - 2013-08-28 11:31:20 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:31:20 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:31:20 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:31:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:31:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:31:20 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:31:21 --> Session Class Initialized
DEBUG - 2013-08-28 11:31:21 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:31:21 --> Session routines successfully run
DEBUG - 2013-08-28 11:31:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:31:21 --> Controller Class Initialized
ERROR - 2013-08-28 11:31:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:31:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:31:21 --> Model Class Initialized
DEBUG - 2013-08-28 11:31:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:31:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:31:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:31:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:31:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:31:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:31:21 --> Severity: Notice  --> Undefined index: kelas_id C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 56
DEBUG - 2013-08-28 11:31:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:31:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:31:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:31:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:31:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:31:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:31:21 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 11:31:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:31:21 --> Final output sent to browser
DEBUG - 2013-08-28 11:31:21 --> Total execution time: 1.3171
DEBUG - 2013-08-28 11:31:22 --> Config Class Initialized
DEBUG - 2013-08-28 11:31:22 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:31:22 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:31:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:31:22 --> URI Class Initialized
DEBUG - 2013-08-28 11:31:22 --> Router Class Initialized
ERROR - 2013-08-28 11:31:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:31:49 --> Config Class Initialized
DEBUG - 2013-08-28 11:31:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:31:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:31:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:31:49 --> URI Class Initialized
DEBUG - 2013-08-28 11:31:49 --> Router Class Initialized
DEBUG - 2013-08-28 11:31:49 --> Output Class Initialized
DEBUG - 2013-08-28 11:31:49 --> Security Class Initialized
DEBUG - 2013-08-28 11:31:50 --> Input Class Initialized
DEBUG - 2013-08-28 11:31:50 --> XSS Filtering completed
DEBUG - 2013-08-28 11:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:31:50 --> Language Class Initialized
DEBUG - 2013-08-28 11:31:50 --> Loader Class Initialized
DEBUG - 2013-08-28 11:31:50 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:31:50 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:31:50 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:31:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:31:50 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:31:50 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:31:50 --> Session Class Initialized
DEBUG - 2013-08-28 11:31:50 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:31:50 --> Session routines successfully run
DEBUG - 2013-08-28 11:31:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:31:50 --> Controller Class Initialized
ERROR - 2013-08-28 11:31:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:31:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:31:50 --> Model Class Initialized
DEBUG - 2013-08-28 11:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:31:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:31:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:31:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:31:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:31:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:31:50 --> Severity: Notice  --> Undefined index: kelas_id C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 56
DEBUG - 2013-08-28 11:31:50 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:31:50 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:31:50 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:31:50 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:31:50 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:31:50 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:31:50 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 11:31:50 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:31:50 --> Final output sent to browser
DEBUG - 2013-08-28 11:31:50 --> Total execution time: 1.1421
DEBUG - 2013-08-28 11:31:51 --> Config Class Initialized
DEBUG - 2013-08-28 11:31:51 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:31:51 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:31:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:31:51 --> URI Class Initialized
DEBUG - 2013-08-28 11:31:51 --> Router Class Initialized
ERROR - 2013-08-28 11:31:51 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:32:14 --> Config Class Initialized
DEBUG - 2013-08-28 11:32:14 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:32:14 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:32:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:32:14 --> URI Class Initialized
DEBUG - 2013-08-28 11:32:14 --> Router Class Initialized
DEBUG - 2013-08-28 11:32:14 --> Output Class Initialized
DEBUG - 2013-08-28 11:32:14 --> Security Class Initialized
DEBUG - 2013-08-28 11:32:15 --> Input Class Initialized
DEBUG - 2013-08-28 11:32:15 --> XSS Filtering completed
DEBUG - 2013-08-28 11:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:32:15 --> Language Class Initialized
DEBUG - 2013-08-28 11:32:15 --> Loader Class Initialized
DEBUG - 2013-08-28 11:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:32:15 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:32:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:32:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:32:15 --> Session Class Initialized
DEBUG - 2013-08-28 11:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:32:15 --> Session routines successfully run
DEBUG - 2013-08-28 11:32:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:32:15 --> Controller Class Initialized
ERROR - 2013-08-28 11:32:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:32:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:32:15 --> Model Class Initialized
DEBUG - 2013-08-28 11:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:32:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:32:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:32:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:32:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:32:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:32:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:32:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:32:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:32:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:32:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:32:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:32:15 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 11:32:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:32:16 --> Final output sent to browser
DEBUG - 2013-08-28 11:32:16 --> Total execution time: 1.3731
DEBUG - 2013-08-28 11:32:16 --> Config Class Initialized
DEBUG - 2013-08-28 11:32:16 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:32:16 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:32:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:32:16 --> URI Class Initialized
DEBUG - 2013-08-28 11:32:16 --> Router Class Initialized
ERROR - 2013-08-28 11:32:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:32:22 --> Config Class Initialized
DEBUG - 2013-08-28 11:32:22 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:32:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:32:23 --> URI Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Router Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Output Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Security Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Input Class Initialized
DEBUG - 2013-08-28 11:32:23 --> XSS Filtering completed
DEBUG - 2013-08-28 11:32:23 --> XSS Filtering completed
DEBUG - 2013-08-28 11:32:23 --> XSS Filtering completed
DEBUG - 2013-08-28 11:32:23 --> XSS Filtering completed
DEBUG - 2013-08-28 11:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:32:23 --> Language Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Loader Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:32:23 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:32:23 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:32:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:32:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:32:23 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Session Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:32:23 --> Session routines successfully run
DEBUG - 2013-08-28 11:32:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Controller Class Initialized
ERROR - 2013-08-28 11:32:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:32:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:32:23 --> Model Class Initialized
DEBUG - 2013-08-28 11:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:32:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:32:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:32:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:32:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:32:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:32:23 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:32:23 --> XSS Filtering completed
DEBUG - 2013-08-28 11:32:23 --> XSS Filtering completed
ERROR - 2013-08-28 11:32:23 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 129
DEBUG - 2013-08-28 11:32:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-28 11:32:24 --> Severity: Notice  --> Undefined variable: kelas_tingkat C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 160
DEBUG - 2013-08-28 11:32:24 --> Config Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:32:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:32:24 --> URI Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Router Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Output Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Security Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Input Class Initialized
DEBUG - 2013-08-28 11:32:24 --> XSS Filtering completed
DEBUG - 2013-08-28 11:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:32:24 --> Language Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Loader Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:32:24 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:32:24 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:32:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:32:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:32:24 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Session Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:32:24 --> Session routines successfully run
DEBUG - 2013-08-28 11:32:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Controller Class Initialized
ERROR - 2013-08-28 11:32:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:32:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:32:24 --> Model Class Initialized
DEBUG - 2013-08-28 11:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:32:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:32:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:32:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:32:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:32:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:32:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:32:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:32:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:32:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:32:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:32:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:32:25 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 11:32:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:32:25 --> Final output sent to browser
DEBUG - 2013-08-28 11:32:25 --> Total execution time: 1.3131
DEBUG - 2013-08-28 11:32:25 --> Config Class Initialized
DEBUG - 2013-08-28 11:32:25 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:32:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:32:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:32:25 --> URI Class Initialized
DEBUG - 2013-08-28 11:32:25 --> Router Class Initialized
ERROR - 2013-08-28 11:32:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:33:14 --> Config Class Initialized
DEBUG - 2013-08-28 11:33:14 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:33:14 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:33:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:33:14 --> URI Class Initialized
DEBUG - 2013-08-28 11:33:14 --> Router Class Initialized
DEBUG - 2013-08-28 11:33:14 --> Output Class Initialized
DEBUG - 2013-08-28 11:33:14 --> Security Class Initialized
DEBUG - 2013-08-28 11:33:14 --> Input Class Initialized
DEBUG - 2013-08-28 11:33:14 --> XSS Filtering completed
DEBUG - 2013-08-28 11:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:33:14 --> Language Class Initialized
DEBUG - 2013-08-28 11:33:14 --> Loader Class Initialized
DEBUG - 2013-08-28 11:33:14 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:33:14 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:33:14 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:33:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:33:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:33:15 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:33:15 --> Session Class Initialized
DEBUG - 2013-08-28 11:33:15 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:33:15 --> Session routines successfully run
DEBUG - 2013-08-28 11:33:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:33:15 --> Controller Class Initialized
ERROR - 2013-08-28 11:33:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:33:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:33:15 --> Model Class Initialized
DEBUG - 2013-08-28 11:33:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:33:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:33:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:33:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:33:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:33:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:33:15 --> Pagination Class Initialized
DEBUG - 2013-08-28 11:33:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:33:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:33:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:33:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:33:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:33:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:33:15 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 11:33:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:33:15 --> Final output sent to browser
DEBUG - 2013-08-28 11:33:15 --> Total execution time: 1.1661
DEBUG - 2013-08-28 11:33:15 --> Config Class Initialized
DEBUG - 2013-08-28 11:33:16 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:33:16 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:33:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:33:16 --> URI Class Initialized
DEBUG - 2013-08-28 11:33:16 --> Router Class Initialized
ERROR - 2013-08-28 11:33:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:33:19 --> Config Class Initialized
DEBUG - 2013-08-28 11:33:19 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:33:19 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:33:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:33:19 --> URI Class Initialized
DEBUG - 2013-08-28 11:33:19 --> Router Class Initialized
DEBUG - 2013-08-28 11:33:19 --> Output Class Initialized
DEBUG - 2013-08-28 11:33:20 --> Security Class Initialized
DEBUG - 2013-08-28 11:33:20 --> Input Class Initialized
DEBUG - 2013-08-28 11:33:20 --> XSS Filtering completed
DEBUG - 2013-08-28 11:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:33:20 --> Language Class Initialized
DEBUG - 2013-08-28 11:33:20 --> Loader Class Initialized
DEBUG - 2013-08-28 11:33:20 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:33:20 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:33:20 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:33:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:33:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:33:20 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:33:20 --> Session Class Initialized
DEBUG - 2013-08-28 11:33:20 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:33:20 --> Session routines successfully run
DEBUG - 2013-08-28 11:33:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:33:20 --> Controller Class Initialized
ERROR - 2013-08-28 11:33:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:33:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:33:20 --> Model Class Initialized
DEBUG - 2013-08-28 11:33:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:33:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:33:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:33:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:33:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:33:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:33:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:33:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:33:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:33:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:33:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:33:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:33:20 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 11:33:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:33:20 --> Final output sent to browser
DEBUG - 2013-08-28 11:33:20 --> Total execution time: 1.1261
DEBUG - 2013-08-28 11:33:21 --> Config Class Initialized
DEBUG - 2013-08-28 11:33:21 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:33:21 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:33:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:33:21 --> URI Class Initialized
DEBUG - 2013-08-28 11:33:21 --> Router Class Initialized
ERROR - 2013-08-28 11:33:21 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:33:26 --> Config Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:33:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:33:26 --> URI Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Router Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Output Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Security Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Input Class Initialized
DEBUG - 2013-08-28 11:33:26 --> XSS Filtering completed
DEBUG - 2013-08-28 11:33:26 --> XSS Filtering completed
DEBUG - 2013-08-28 11:33:26 --> XSS Filtering completed
DEBUG - 2013-08-28 11:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:33:26 --> Language Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Loader Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:33:26 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:33:26 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:33:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:33:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:33:26 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Session Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:33:26 --> Session routines successfully run
DEBUG - 2013-08-28 11:33:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Controller Class Initialized
ERROR - 2013-08-28 11:33:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:33:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:33:26 --> Model Class Initialized
DEBUG - 2013-08-28 11:33:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:33:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:33:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:33:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:33:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:33:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:33:27 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:33:27 --> XSS Filtering completed
DEBUG - 2013-08-28 11:33:27 --> XSS Filtering completed
ERROR - 2013-08-28 11:33:27 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\application\controllers\guru\kelas.php 185
DEBUG - 2013-08-28 11:33:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-28 11:33:27 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\controllers\guru\kelas.php 257
DEBUG - 2013-08-28 11:33:27 --> DB Transaction Failure
ERROR - 2013-08-28 11:33:27 --> Query error: Incorrect integer value: '' for column 'jurusan_id' at row 1
DEBUG - 2013-08-28 11:33:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-28 11:39:46 --> Config Class Initialized
DEBUG - 2013-08-28 11:39:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:39:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:39:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:39:48 --> URI Class Initialized
DEBUG - 2013-08-28 11:39:49 --> Router Class Initialized
DEBUG - 2013-08-28 11:39:50 --> Output Class Initialized
DEBUG - 2013-08-28 11:39:50 --> Security Class Initialized
DEBUG - 2013-08-28 11:39:52 --> Input Class Initialized
DEBUG - 2013-08-28 11:39:52 --> XSS Filtering completed
DEBUG - 2013-08-28 11:39:52 --> XSS Filtering completed
DEBUG - 2013-08-28 11:39:53 --> XSS Filtering completed
DEBUG - 2013-08-28 11:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:39:55 --> Language Class Initialized
DEBUG - 2013-08-28 11:39:56 --> Loader Class Initialized
DEBUG - 2013-08-28 11:40:02 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:40:03 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:40:05 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:40:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:40:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:40:11 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:40:13 --> Session Class Initialized
DEBUG - 2013-08-28 11:40:14 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:40:19 --> Session routines successfully run
DEBUG - 2013-08-28 11:40:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:40:21 --> Controller Class Initialized
ERROR - 2013-08-28 11:40:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:40:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:40:39 --> Model Class Initialized
DEBUG - 2013-08-28 11:40:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:40:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:40:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:40:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:40:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:40:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:40:55 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:40:55 --> XSS Filtering completed
DEBUG - 2013-08-28 11:40:55 --> XSS Filtering completed
DEBUG - 2013-08-28 11:41:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-28 11:41:20 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\controllers\guru\kelas.php 257
DEBUG - 2013-08-28 11:41:20 --> DB Transaction Failure
ERROR - 2013-08-28 11:41:20 --> Query error: Incorrect integer value: '' for column 'jurusan_id' at row 1
DEBUG - 2013-08-28 11:41:22 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-28 11:42:34 --> Config Class Initialized
DEBUG - 2013-08-28 11:42:34 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:42:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:42:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:42:37 --> URI Class Initialized
DEBUG - 2013-08-28 11:42:38 --> Router Class Initialized
DEBUG - 2013-08-28 11:42:38 --> Output Class Initialized
DEBUG - 2013-08-28 11:42:38 --> Security Class Initialized
DEBUG - 2013-08-28 11:42:38 --> Input Class Initialized
DEBUG - 2013-08-28 11:42:38 --> XSS Filtering completed
DEBUG - 2013-08-28 11:42:38 --> XSS Filtering completed
DEBUG - 2013-08-28 11:42:38 --> XSS Filtering completed
DEBUG - 2013-08-28 11:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:42:42 --> Language Class Initialized
DEBUG - 2013-08-28 11:42:48 --> Loader Class Initialized
DEBUG - 2013-08-28 11:42:49 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:42:49 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:42:49 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:42:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:42:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:42:51 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:42:52 --> Session Class Initialized
DEBUG - 2013-08-28 11:42:53 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:42:53 --> Session routines successfully run
DEBUG - 2013-08-28 11:42:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:42:53 --> Controller Class Initialized
ERROR - 2013-08-28 11:42:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:42:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:42:55 --> Model Class Initialized
DEBUG - 2013-08-28 11:42:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:42:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:42:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:42:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:42:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:42:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:42:56 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:42:56 --> XSS Filtering completed
DEBUG - 2013-08-28 11:42:56 --> XSS Filtering completed
DEBUG - 2013-08-28 11:42:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 11:43:25 --> Config Class Initialized
DEBUG - 2013-08-28 11:43:25 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:43:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:43:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:43:25 --> URI Class Initialized
DEBUG - 2013-08-28 11:43:25 --> Router Class Initialized
DEBUG - 2013-08-28 11:43:25 --> Output Class Initialized
DEBUG - 2013-08-28 11:43:25 --> Security Class Initialized
DEBUG - 2013-08-28 11:43:26 --> Input Class Initialized
DEBUG - 2013-08-28 11:43:26 --> XSS Filtering completed
DEBUG - 2013-08-28 11:43:26 --> XSS Filtering completed
DEBUG - 2013-08-28 11:43:26 --> XSS Filtering completed
DEBUG - 2013-08-28 11:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:43:26 --> Language Class Initialized
DEBUG - 2013-08-28 11:43:26 --> Loader Class Initialized
DEBUG - 2013-08-28 11:43:26 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:43:26 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:43:26 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:43:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:43:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:43:26 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:43:26 --> Session Class Initialized
DEBUG - 2013-08-28 11:43:26 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:43:26 --> Session garbage collection performed.
DEBUG - 2013-08-28 11:43:26 --> Session routines successfully run
DEBUG - 2013-08-28 11:43:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:43:26 --> Controller Class Initialized
ERROR - 2013-08-28 11:43:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:43:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:43:26 --> Model Class Initialized
DEBUG - 2013-08-28 11:43:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:43:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:43:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:43:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:43:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:43:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:43:27 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:43:27 --> XSS Filtering completed
DEBUG - 2013-08-28 11:43:27 --> XSS Filtering completed
DEBUG - 2013-08-28 11:43:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 11:46:26 --> Config Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:46:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:46:26 --> URI Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Router Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Output Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Security Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Input Class Initialized
DEBUG - 2013-08-28 11:46:26 --> XSS Filtering completed
DEBUG - 2013-08-28 11:46:26 --> XSS Filtering completed
DEBUG - 2013-08-28 11:46:26 --> XSS Filtering completed
DEBUG - 2013-08-28 11:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:46:26 --> Language Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Loader Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:46:26 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:46:26 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:46:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:46:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:46:26 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Session Class Initialized
DEBUG - 2013-08-28 11:46:26 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:46:27 --> Session routines successfully run
DEBUG - 2013-08-28 11:46:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:46:27 --> Controller Class Initialized
ERROR - 2013-08-28 11:46:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:46:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:46:27 --> Model Class Initialized
DEBUG - 2013-08-28 11:46:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:46:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:46:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:46:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:46:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:46:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:46:27 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:46:27 --> XSS Filtering completed
DEBUG - 2013-08-28 11:46:27 --> XSS Filtering completed
ERROR - 2013-08-28 11:46:27 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\school\application\controllers\guru\kelas.php 185
DEBUG - 2013-08-28 11:46:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 11:53:26 --> Config Class Initialized
DEBUG - 2013-08-28 11:53:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:53:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:53:26 --> URI Class Initialized
DEBUG - 2013-08-28 11:53:27 --> Router Class Initialized
DEBUG - 2013-08-28 11:53:32 --> Output Class Initialized
DEBUG - 2013-08-28 11:53:32 --> Security Class Initialized
DEBUG - 2013-08-28 11:53:32 --> Input Class Initialized
DEBUG - 2013-08-28 11:53:32 --> XSS Filtering completed
DEBUG - 2013-08-28 11:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:53:33 --> Language Class Initialized
DEBUG - 2013-08-28 11:53:35 --> Loader Class Initialized
DEBUG - 2013-08-28 11:53:38 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:53:38 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:53:39 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:53:41 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:53:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:53:52 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:53:52 --> Session Class Initialized
DEBUG - 2013-08-28 11:53:53 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:53:58 --> Session routines successfully run
DEBUG - 2013-08-28 11:53:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:53:59 --> Controller Class Initialized
ERROR - 2013-08-28 11:54:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:54:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:54:07 --> Model Class Initialized
DEBUG - 2013-08-28 11:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:54:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:54:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:54:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:54:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:54:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:54:11 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Config Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:54:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:54:27 --> URI Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Router Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Output Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Security Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Input Class Initialized
DEBUG - 2013-08-28 11:54:27 --> XSS Filtering completed
DEBUG - 2013-08-28 11:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:54:27 --> Language Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Loader Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:54:27 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:54:27 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:54:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:54:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:54:27 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Session Class Initialized
DEBUG - 2013-08-28 11:54:27 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:54:31 --> Session routines successfully run
DEBUG - 2013-08-28 11:54:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:54:31 --> Controller Class Initialized
ERROR - 2013-08-28 11:54:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:54:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:54:31 --> Model Class Initialized
DEBUG - 2013-08-28 11:54:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:54:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:54:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:54:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:54:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:54:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:54:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:54:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:54:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:54:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:54:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:54:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:54:40 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 11:54:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:54:44 --> Final output sent to browser
DEBUG - 2013-08-28 11:54:44 --> Total execution time: 19.9701
DEBUG - 2013-08-28 11:54:54 --> Config Class Initialized
DEBUG - 2013-08-28 11:54:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:54:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:54:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:54:54 --> URI Class Initialized
DEBUG - 2013-08-28 11:54:54 --> Router Class Initialized
ERROR - 2013-08-28 11:54:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:56:44 --> Config Class Initialized
DEBUG - 2013-08-28 11:56:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:56:44 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:56:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:56:44 --> URI Class Initialized
DEBUG - 2013-08-28 11:56:44 --> Router Class Initialized
DEBUG - 2013-08-28 11:56:44 --> Output Class Initialized
DEBUG - 2013-08-28 11:56:44 --> Security Class Initialized
DEBUG - 2013-08-28 11:56:44 --> Input Class Initialized
DEBUG - 2013-08-28 11:56:44 --> XSS Filtering completed
DEBUG - 2013-08-28 11:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:56:44 --> Language Class Initialized
DEBUG - 2013-08-28 11:56:44 --> Loader Class Initialized
DEBUG - 2013-08-28 11:56:44 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:56:44 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:56:44 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:56:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:56:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:56:45 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:56:45 --> Session Class Initialized
DEBUG - 2013-08-28 11:56:45 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:56:45 --> Session routines successfully run
DEBUG - 2013-08-28 11:56:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:56:45 --> Controller Class Initialized
ERROR - 2013-08-28 11:56:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:56:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:56:45 --> Model Class Initialized
DEBUG - 2013-08-28 11:56:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:56:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:56:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:56:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:56:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:56:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:56:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:56:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:56:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:56:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:56:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:56:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:56:46 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 11:56:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:56:46 --> Final output sent to browser
DEBUG - 2013-08-28 11:56:46 --> Total execution time: 1.7931
DEBUG - 2013-08-28 11:56:46 --> Config Class Initialized
DEBUG - 2013-08-28 11:56:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:56:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:56:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:56:46 --> URI Class Initialized
DEBUG - 2013-08-28 11:56:46 --> Router Class Initialized
ERROR - 2013-08-28 11:56:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:56:57 --> Config Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:56:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:56:57 --> URI Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Router Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Output Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Security Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Input Class Initialized
DEBUG - 2013-08-28 11:56:57 --> XSS Filtering completed
DEBUG - 2013-08-28 11:56:57 --> XSS Filtering completed
DEBUG - 2013-08-28 11:56:57 --> XSS Filtering completed
DEBUG - 2013-08-28 11:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:56:57 --> Language Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Loader Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:56:57 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:56:57 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:56:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:56:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:56:57 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Session Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:56:57 --> Session routines successfully run
DEBUG - 2013-08-28 11:56:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Controller Class Initialized
ERROR - 2013-08-28 11:56:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:56:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:56:57 --> Model Class Initialized
DEBUG - 2013-08-28 11:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:56:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:56:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:56:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:56:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:56:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:56:58 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:56:58 --> XSS Filtering completed
DEBUG - 2013-08-28 11:56:58 --> XSS Filtering completed
DEBUG - 2013-08-28 11:56:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 11:56:58 --> Config Class Initialized
DEBUG - 2013-08-28 11:56:58 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:56:58 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:56:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:56:58 --> URI Class Initialized
DEBUG - 2013-08-28 11:56:58 --> Router Class Initialized
DEBUG - 2013-08-28 11:56:58 --> Output Class Initialized
DEBUG - 2013-08-28 11:56:58 --> Security Class Initialized
DEBUG - 2013-08-28 11:56:58 --> Input Class Initialized
DEBUG - 2013-08-28 11:56:58 --> XSS Filtering completed
DEBUG - 2013-08-28 11:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:56:58 --> Language Class Initialized
DEBUG - 2013-08-28 11:56:58 --> Loader Class Initialized
DEBUG - 2013-08-28 11:56:58 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:56:58 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:56:58 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:56:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:56:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:56:59 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:56:59 --> Session Class Initialized
DEBUG - 2013-08-28 11:56:59 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:56:59 --> Session routines successfully run
DEBUG - 2013-08-28 11:56:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:56:59 --> Controller Class Initialized
ERROR - 2013-08-28 11:56:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:56:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:56:59 --> Model Class Initialized
DEBUG - 2013-08-28 11:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:56:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:56:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:56:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:56:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:56:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:56:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 11:56:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 11:56:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 11:56:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 11:56:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 11:56:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 11:56:59 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 11:56:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 11:57:00 --> Final output sent to browser
DEBUG - 2013-08-28 11:57:00 --> Total execution time: 1.6611
DEBUG - 2013-08-28 11:57:00 --> Config Class Initialized
DEBUG - 2013-08-28 11:57:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:57:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:57:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:57:01 --> URI Class Initialized
DEBUG - 2013-08-28 11:57:01 --> Router Class Initialized
ERROR - 2013-08-28 11:57:01 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 11:57:23 --> Config Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Hooks Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Utf8 Class Initialized
DEBUG - 2013-08-28 11:57:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 11:57:23 --> URI Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Router Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Output Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Security Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Input Class Initialized
DEBUG - 2013-08-28 11:57:23 --> XSS Filtering completed
DEBUG - 2013-08-28 11:57:23 --> XSS Filtering completed
DEBUG - 2013-08-28 11:57:23 --> XSS Filtering completed
DEBUG - 2013-08-28 11:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 11:57:23 --> Language Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Loader Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Helper loaded: url_helper
DEBUG - 2013-08-28 11:57:23 --> Helper loaded: file_helper
DEBUG - 2013-08-28 11:57:23 --> Helper loaded: form_helper
DEBUG - 2013-08-28 11:57:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 11:57:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 11:57:23 --> Database Driver Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Session Class Initialized
DEBUG - 2013-08-28 11:57:23 --> Helper loaded: string_helper
DEBUG - 2013-08-28 11:57:23 --> Session routines successfully run
DEBUG - 2013-08-28 11:57:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 11:57:24 --> Controller Class Initialized
ERROR - 2013-08-28 11:57:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:57:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:57:24 --> Model Class Initialized
DEBUG - 2013-08-28 11:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 11:57:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 11:57:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 11:57:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 11:57:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 11:57:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 11:57:24 --> Form Validation Class Initialized
DEBUG - 2013-08-28 11:57:24 --> XSS Filtering completed
DEBUG - 2013-08-28 11:57:24 --> XSS Filtering completed
DEBUG - 2013-08-28 11:57:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:03:24 --> Config Class Initialized
DEBUG - 2013-08-28 15:03:24 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:03:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:03:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:03:25 --> URI Class Initialized
DEBUG - 2013-08-28 15:03:25 --> Router Class Initialized
DEBUG - 2013-08-28 15:03:25 --> Output Class Initialized
DEBUG - 2013-08-28 15:03:25 --> Security Class Initialized
DEBUG - 2013-08-28 15:03:25 --> Input Class Initialized
DEBUG - 2013-08-28 15:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:03:25 --> Language Class Initialized
DEBUG - 2013-08-28 15:03:25 --> Loader Class Initialized
DEBUG - 2013-08-28 15:03:25 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:03:25 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:03:25 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:03:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:03:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:03:26 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:03:26 --> Session Class Initialized
DEBUG - 2013-08-28 15:03:26 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:03:26 --> A session cookie was not found.
DEBUG - 2013-08-28 15:03:26 --> Session routines successfully run
DEBUG - 2013-08-28 15:03:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:03:26 --> Controller Class Initialized
ERROR - 2013-08-28 15:03:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:03:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:03:27 --> Model Class Initialized
DEBUG - 2013-08-28 15:03:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:03:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:03:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:03:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:03:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:03:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:03:27 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:03:27 --> Config Class Initialized
DEBUG - 2013-08-28 15:03:27 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:03:27 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:03:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:03:27 --> URI Class Initialized
DEBUG - 2013-08-28 15:03:27 --> Router Class Initialized
DEBUG - 2013-08-28 15:03:27 --> Output Class Initialized
DEBUG - 2013-08-28 15:03:27 --> Security Class Initialized
DEBUG - 2013-08-28 15:03:27 --> Input Class Initialized
DEBUG - 2013-08-28 15:03:27 --> XSS Filtering completed
DEBUG - 2013-08-28 15:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:03:28 --> Language Class Initialized
DEBUG - 2013-08-28 15:03:28 --> Loader Class Initialized
DEBUG - 2013-08-28 15:03:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:03:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:03:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:03:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:03:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:03:28 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:03:28 --> Session Class Initialized
DEBUG - 2013-08-28 15:03:28 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:03:28 --> Session routines successfully run
DEBUG - 2013-08-28 15:03:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:03:28 --> Controller Class Initialized
ERROR - 2013-08-28 15:03:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:03:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:03:28 --> Model Class Initialized
DEBUG - 2013-08-28 15:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:03:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:03:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:03:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:03:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:03:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:03:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:03:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:03:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:03:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:03:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:03:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:03:29 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 15:03:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:03:29 --> Final output sent to browser
DEBUG - 2013-08-28 15:03:29 --> Total execution time: 1.5921
DEBUG - 2013-08-28 15:03:29 --> Config Class Initialized
DEBUG - 2013-08-28 15:03:29 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:03:29 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:03:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:03:29 --> URI Class Initialized
DEBUG - 2013-08-28 15:03:29 --> Router Class Initialized
ERROR - 2013-08-28 15:03:29 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:03:35 --> Config Class Initialized
DEBUG - 2013-08-28 15:03:35 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:03:35 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:03:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:03:35 --> URI Class Initialized
DEBUG - 2013-08-28 15:03:35 --> Router Class Initialized
DEBUG - 2013-08-28 15:03:35 --> Output Class Initialized
DEBUG - 2013-08-28 15:03:35 --> Security Class Initialized
DEBUG - 2013-08-28 15:03:35 --> Input Class Initialized
DEBUG - 2013-08-28 15:03:35 --> XSS Filtering completed
DEBUG - 2013-08-28 15:03:35 --> XSS Filtering completed
DEBUG - 2013-08-28 15:03:35 --> XSS Filtering completed
DEBUG - 2013-08-28 15:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:03:36 --> Language Class Initialized
DEBUG - 2013-08-28 15:03:36 --> Loader Class Initialized
DEBUG - 2013-08-28 15:03:36 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:03:36 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:03:36 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:03:36 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:03:36 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:03:36 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:03:36 --> Session Class Initialized
DEBUG - 2013-08-28 15:03:36 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:03:36 --> Session routines successfully run
DEBUG - 2013-08-28 15:03:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:03:36 --> Controller Class Initialized
ERROR - 2013-08-28 15:03:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:03:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:03:36 --> Model Class Initialized
DEBUG - 2013-08-28 15:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:03:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:03:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:03:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:03:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:03:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:03:36 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:03:36 --> XSS Filtering completed
DEBUG - 2013-08-28 15:03:36 --> XSS Filtering completed
DEBUG - 2013-08-28 15:03:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:04:42 --> Config Class Initialized
DEBUG - 2013-08-28 15:04:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:04:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:04:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:04:42 --> URI Class Initialized
DEBUG - 2013-08-28 15:04:42 --> Router Class Initialized
DEBUG - 2013-08-28 15:04:42 --> Output Class Initialized
DEBUG - 2013-08-28 15:04:42 --> Security Class Initialized
DEBUG - 2013-08-28 15:04:42 --> Input Class Initialized
DEBUG - 2013-08-28 15:04:42 --> XSS Filtering completed
DEBUG - 2013-08-28 15:04:43 --> XSS Filtering completed
DEBUG - 2013-08-28 15:04:43 --> XSS Filtering completed
DEBUG - 2013-08-28 15:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:04:43 --> Language Class Initialized
DEBUG - 2013-08-28 15:04:43 --> Loader Class Initialized
DEBUG - 2013-08-28 15:04:43 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:04:43 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:04:43 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:04:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:04:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:04:43 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:04:43 --> Session Class Initialized
DEBUG - 2013-08-28 15:04:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:04:43 --> Session routines successfully run
DEBUG - 2013-08-28 15:04:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:04:43 --> Controller Class Initialized
ERROR - 2013-08-28 15:04:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:04:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:04:43 --> Model Class Initialized
DEBUG - 2013-08-28 15:04:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:04:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:04:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:04:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:04:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:04:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:04:43 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:04:43 --> XSS Filtering completed
DEBUG - 2013-08-28 15:04:43 --> XSS Filtering completed
DEBUG - 2013-08-28 15:04:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:05:02 --> Config Class Initialized
DEBUG - 2013-08-28 15:05:02 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:05:02 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:05:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:05:02 --> URI Class Initialized
DEBUG - 2013-08-28 15:05:02 --> Router Class Initialized
DEBUG - 2013-08-28 15:05:02 --> Output Class Initialized
DEBUG - 2013-08-28 15:05:02 --> Security Class Initialized
DEBUG - 2013-08-28 15:05:02 --> Input Class Initialized
DEBUG - 2013-08-28 15:05:02 --> XSS Filtering completed
DEBUG - 2013-08-28 15:05:02 --> XSS Filtering completed
DEBUG - 2013-08-28 15:05:02 --> XSS Filtering completed
DEBUG - 2013-08-28 15:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:05:02 --> Language Class Initialized
DEBUG - 2013-08-28 15:05:02 --> Loader Class Initialized
DEBUG - 2013-08-28 15:05:02 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:05:03 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:05:03 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:05:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:05:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:05:03 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:05:03 --> Session Class Initialized
DEBUG - 2013-08-28 15:05:03 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:05:03 --> Session routines successfully run
DEBUG - 2013-08-28 15:05:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:05:03 --> Controller Class Initialized
ERROR - 2013-08-28 15:05:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:05:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:05:03 --> Model Class Initialized
DEBUG - 2013-08-28 15:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:05:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:05:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:05:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:05:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:05:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:05:03 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:05:03 --> XSS Filtering completed
DEBUG - 2013-08-28 15:05:03 --> XSS Filtering completed
DEBUG - 2013-08-28 15:05:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:09:46 --> Config Class Initialized
DEBUG - 2013-08-28 15:09:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:09:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:09:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:09:46 --> URI Class Initialized
DEBUG - 2013-08-28 15:09:46 --> Router Class Initialized
DEBUG - 2013-08-28 15:09:47 --> Output Class Initialized
DEBUG - 2013-08-28 15:09:47 --> Security Class Initialized
DEBUG - 2013-08-28 15:09:47 --> Input Class Initialized
DEBUG - 2013-08-28 15:09:47 --> XSS Filtering completed
DEBUG - 2013-08-28 15:09:47 --> XSS Filtering completed
DEBUG - 2013-08-28 15:09:47 --> XSS Filtering completed
DEBUG - 2013-08-28 15:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:09:47 --> Language Class Initialized
DEBUG - 2013-08-28 15:09:47 --> Loader Class Initialized
DEBUG - 2013-08-28 15:09:47 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:09:47 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:09:47 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:09:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:09:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:09:47 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:09:47 --> Session Class Initialized
DEBUG - 2013-08-28 15:09:47 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:09:47 --> Session routines successfully run
DEBUG - 2013-08-28 15:09:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:09:47 --> Controller Class Initialized
ERROR - 2013-08-28 15:09:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:09:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:09:47 --> Model Class Initialized
DEBUG - 2013-08-28 15:09:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:09:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:09:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:09:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:09:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:09:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:09:47 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:09:47 --> XSS Filtering completed
DEBUG - 2013-08-28 15:09:47 --> XSS Filtering completed
DEBUG - 2013-08-28 15:09:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:09:48 --> Config Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:09:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:09:48 --> URI Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Router Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Output Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Security Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Input Class Initialized
DEBUG - 2013-08-28 15:09:48 --> XSS Filtering completed
DEBUG - 2013-08-28 15:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:09:48 --> Language Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Loader Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:09:48 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:09:48 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:09:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:09:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:09:48 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Session Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:09:48 --> Session garbage collection performed.
DEBUG - 2013-08-28 15:09:48 --> Session routines successfully run
DEBUG - 2013-08-28 15:09:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Controller Class Initialized
ERROR - 2013-08-28 15:09:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:09:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:09:48 --> Model Class Initialized
DEBUG - 2013-08-28 15:09:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:09:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:09:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:09:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:09:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:09:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:09:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:09:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:09:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:09:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:09:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:09:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:09:49 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 15:09:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:09:49 --> Final output sent to browser
DEBUG - 2013-08-28 15:09:49 --> Total execution time: 1.3011
DEBUG - 2013-08-28 15:09:49 --> Config Class Initialized
DEBUG - 2013-08-28 15:09:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:09:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:09:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:09:49 --> URI Class Initialized
DEBUG - 2013-08-28 15:09:49 --> Router Class Initialized
ERROR - 2013-08-28 15:09:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:10:01 --> Config Class Initialized
DEBUG - 2013-08-28 15:10:01 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:10:01 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:10:02 --> URI Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Router Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Output Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Security Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Input Class Initialized
DEBUG - 2013-08-28 15:10:02 --> XSS Filtering completed
DEBUG - 2013-08-28 15:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:10:02 --> Language Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Loader Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:10:02 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:10:02 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:10:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:10:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:10:02 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Session Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:10:02 --> Session routines successfully run
DEBUG - 2013-08-28 15:10:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Controller Class Initialized
ERROR - 2013-08-28 15:10:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:10:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:10:02 --> Model Class Initialized
DEBUG - 2013-08-28 15:10:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:10:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:10:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:10:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:10:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:10:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:10:03 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:10:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:10:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:10:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:10:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:10:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:10:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:10:03 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 15:10:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:10:03 --> Final output sent to browser
DEBUG - 2013-08-28 15:10:03 --> Total execution time: 1.3481
DEBUG - 2013-08-28 15:10:03 --> Config Class Initialized
DEBUG - 2013-08-28 15:10:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:10:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:10:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:10:03 --> URI Class Initialized
DEBUG - 2013-08-28 15:10:03 --> Router Class Initialized
ERROR - 2013-08-28 15:10:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:11:36 --> Config Class Initialized
DEBUG - 2013-08-28 15:11:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:11:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:11:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:11:36 --> URI Class Initialized
DEBUG - 2013-08-28 15:11:36 --> Router Class Initialized
DEBUG - 2013-08-28 15:11:36 --> Output Class Initialized
DEBUG - 2013-08-28 15:11:36 --> Security Class Initialized
DEBUG - 2013-08-28 15:11:36 --> Input Class Initialized
DEBUG - 2013-08-28 15:11:36 --> XSS Filtering completed
DEBUG - 2013-08-28 15:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:11:36 --> Language Class Initialized
DEBUG - 2013-08-28 15:11:37 --> Loader Class Initialized
DEBUG - 2013-08-28 15:11:37 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:11:37 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:11:37 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:11:37 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:11:37 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:11:37 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:11:37 --> Session Class Initialized
DEBUG - 2013-08-28 15:11:37 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:11:37 --> Session routines successfully run
DEBUG - 2013-08-28 15:11:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:11:37 --> Controller Class Initialized
ERROR - 2013-08-28 15:11:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:11:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:11:37 --> Model Class Initialized
DEBUG - 2013-08-28 15:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:11:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:11:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:11:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:11:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:11:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:11:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:11:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:11:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:11:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:11:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:11:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:11:37 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 15:11:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:11:37 --> Final output sent to browser
DEBUG - 2013-08-28 15:11:37 --> Total execution time: 1.2621
DEBUG - 2013-08-28 15:11:38 --> Config Class Initialized
DEBUG - 2013-08-28 15:11:38 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:11:38 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:11:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:11:38 --> URI Class Initialized
DEBUG - 2013-08-28 15:11:38 --> Router Class Initialized
ERROR - 2013-08-28 15:11:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:11:42 --> Config Class Initialized
DEBUG - 2013-08-28 15:11:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:11:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:11:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:11:42 --> URI Class Initialized
DEBUG - 2013-08-28 15:11:42 --> Router Class Initialized
DEBUG - 2013-08-28 15:11:42 --> Output Class Initialized
DEBUG - 2013-08-28 15:11:42 --> Security Class Initialized
DEBUG - 2013-08-28 15:11:42 --> Input Class Initialized
DEBUG - 2013-08-28 15:11:42 --> XSS Filtering completed
DEBUG - 2013-08-28 15:11:42 --> XSS Filtering completed
DEBUG - 2013-08-28 15:11:42 --> XSS Filtering completed
DEBUG - 2013-08-28 15:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:11:42 --> Language Class Initialized
DEBUG - 2013-08-28 15:11:42 --> Loader Class Initialized
DEBUG - 2013-08-28 15:11:42 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:11:42 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:11:42 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:11:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:11:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:11:43 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:11:43 --> Session Class Initialized
DEBUG - 2013-08-28 15:11:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:11:43 --> Session routines successfully run
DEBUG - 2013-08-28 15:11:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:11:43 --> Controller Class Initialized
ERROR - 2013-08-28 15:11:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:11:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:11:43 --> Model Class Initialized
DEBUG - 2013-08-28 15:11:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:11:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:11:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:11:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:11:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:11:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:11:43 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:11:43 --> XSS Filtering completed
DEBUG - 2013-08-28 15:11:43 --> XSS Filtering completed
DEBUG - 2013-08-28 15:11:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:12:39 --> Config Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:12:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:12:39 --> URI Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Router Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Output Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Security Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Input Class Initialized
DEBUG - 2013-08-28 15:12:39 --> XSS Filtering completed
DEBUG - 2013-08-28 15:12:39 --> XSS Filtering completed
DEBUG - 2013-08-28 15:12:39 --> XSS Filtering completed
DEBUG - 2013-08-28 15:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:12:39 --> Language Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Loader Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:12:39 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:12:39 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:12:39 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:12:39 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:12:39 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Session Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:12:39 --> Session routines successfully run
DEBUG - 2013-08-28 15:12:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Controller Class Initialized
ERROR - 2013-08-28 15:12:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:12:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:12:39 --> Model Class Initialized
DEBUG - 2013-08-28 15:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:12:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:12:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:12:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:12:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:12:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:12:40 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:12:40 --> XSS Filtering completed
DEBUG - 2013-08-28 15:12:40 --> XSS Filtering completed
DEBUG - 2013-08-28 15:12:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:13:43 --> Config Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:13:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:13:43 --> URI Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Router Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Output Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Security Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Input Class Initialized
DEBUG - 2013-08-28 15:13:43 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:43 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:43 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:13:43 --> Language Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Loader Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:13:43 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:13:43 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:13:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:13:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:13:43 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Session Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:13:43 --> Session garbage collection performed.
DEBUG - 2013-08-28 15:13:43 --> Session routines successfully run
DEBUG - 2013-08-28 15:13:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:13:43 --> Controller Class Initialized
ERROR - 2013-08-28 15:13:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:13:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:13:44 --> Model Class Initialized
DEBUG - 2013-08-28 15:13:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:13:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:13:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:13:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:13:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:13:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:13:44 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:13:44 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:44 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:13:57 --> Config Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:13:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:13:57 --> URI Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Router Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Output Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Security Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Input Class Initialized
DEBUG - 2013-08-28 15:13:57 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:57 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:57 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:13:57 --> Language Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Loader Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:13:57 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:13:57 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:13:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:13:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:13:57 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Session Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:13:57 --> Session routines successfully run
DEBUG - 2013-08-28 15:13:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Controller Class Initialized
ERROR - 2013-08-28 15:13:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:13:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:13:57 --> Model Class Initialized
DEBUG - 2013-08-28 15:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:13:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:13:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:13:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:13:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:13:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:13:58 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:13:58 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:58 --> XSS Filtering completed
DEBUG - 2013-08-28 15:13:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:14:07 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:07 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:07 --> Router Class Initialized
DEBUG - 2013-08-28 15:14:07 --> Output Class Initialized
DEBUG - 2013-08-28 15:14:07 --> Security Class Initialized
DEBUG - 2013-08-28 15:14:07 --> Input Class Initialized
DEBUG - 2013-08-28 15:14:07 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:07 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:07 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:14:07 --> Language Class Initialized
DEBUG - 2013-08-28 15:14:07 --> Loader Class Initialized
DEBUG - 2013-08-28 15:14:07 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:14:07 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:14:07 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:14:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:14:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:14:07 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:14:07 --> Session Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:14:08 --> Session routines successfully run
DEBUG - 2013-08-28 15:14:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Controller Class Initialized
ERROR - 2013-08-28 15:14:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:08 --> Model Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:14:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:14:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:14:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:14:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:08 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:14:08 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:08 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:14:08 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:08 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Router Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Output Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Security Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Input Class Initialized
DEBUG - 2013-08-28 15:14:08 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:14:08 --> Language Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Loader Class Initialized
DEBUG - 2013-08-28 15:14:08 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:14:09 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:14:09 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:14:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:14:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:14:09 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:14:09 --> Session Class Initialized
DEBUG - 2013-08-28 15:14:09 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:14:09 --> Session routines successfully run
DEBUG - 2013-08-28 15:14:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:14:09 --> Controller Class Initialized
ERROR - 2013-08-28 15:14:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:09 --> Model Class Initialized
DEBUG - 2013-08-28 15:14:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:14:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:14:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:14:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:14:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:14:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:14:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:14:09 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:14:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:14:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:14:09 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 15:14:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:14:09 --> Final output sent to browser
DEBUG - 2013-08-28 15:14:09 --> Total execution time: 1.3591
DEBUG - 2013-08-28 15:14:10 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:10 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:10 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:10 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:10 --> Router Class Initialized
ERROR - 2013-08-28 15:14:10 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:14:18 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:18 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:18 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:18 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:18 --> Router Class Initialized
DEBUG - 2013-08-28 15:14:18 --> Output Class Initialized
DEBUG - 2013-08-28 15:14:18 --> Security Class Initialized
DEBUG - 2013-08-28 15:14:18 --> Input Class Initialized
DEBUG - 2013-08-28 15:14:19 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:19 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:19 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:14:19 --> Language Class Initialized
DEBUG - 2013-08-28 15:14:19 --> Loader Class Initialized
DEBUG - 2013-08-28 15:14:19 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:14:19 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:14:19 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:14:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:14:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:14:19 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:14:19 --> Session Class Initialized
DEBUG - 2013-08-28 15:14:19 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:14:19 --> Session routines successfully run
DEBUG - 2013-08-28 15:14:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:14:19 --> Controller Class Initialized
ERROR - 2013-08-28 15:14:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:19 --> Model Class Initialized
DEBUG - 2013-08-28 15:14:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:14:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:14:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:14:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:14:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:19 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:14:19 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:19 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:14:20 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:20 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Router Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Output Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Security Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Input Class Initialized
DEBUG - 2013-08-28 15:14:20 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:14:20 --> Language Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Loader Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:14:20 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:14:20 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:14:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:14:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:14:20 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Session Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:14:20 --> Session routines successfully run
DEBUG - 2013-08-28 15:14:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:14:20 --> Controller Class Initialized
ERROR - 2013-08-28 15:14:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:20 --> Model Class Initialized
DEBUG - 2013-08-28 15:14:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:14:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:14:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:14:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:14:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:14:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:14:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:14:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:14:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:14:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:14:21 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 15:14:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:14:21 --> Final output sent to browser
DEBUG - 2013-08-28 15:14:21 --> Total execution time: 1.4031
DEBUG - 2013-08-28 15:14:21 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:21 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:21 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:21 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:21 --> Router Class Initialized
ERROR - 2013-08-28 15:14:21 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:14:30 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:30 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:30 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:30 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:30 --> Router Class Initialized
DEBUG - 2013-08-28 15:14:30 --> Output Class Initialized
DEBUG - 2013-08-28 15:14:30 --> Security Class Initialized
DEBUG - 2013-08-28 15:14:31 --> Input Class Initialized
DEBUG - 2013-08-28 15:14:31 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:14:31 --> Language Class Initialized
DEBUG - 2013-08-28 15:14:31 --> Loader Class Initialized
DEBUG - 2013-08-28 15:14:31 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:14:31 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:14:31 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:14:31 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:14:31 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:14:31 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:14:31 --> Session Class Initialized
DEBUG - 2013-08-28 15:14:31 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:14:31 --> Session routines successfully run
DEBUG - 2013-08-28 15:14:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:14:31 --> Controller Class Initialized
ERROR - 2013-08-28 15:14:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:31 --> Model Class Initialized
DEBUG - 2013-08-28 15:14:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:14:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:14:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:14:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:14:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:31 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:14:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:14:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:14:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:14:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:14:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:14:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:14:32 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 15:14:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:14:32 --> Final output sent to browser
DEBUG - 2013-08-28 15:14:32 --> Total execution time: 1.3091
DEBUG - 2013-08-28 15:14:32 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:32 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:32 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:32 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:32 --> Router Class Initialized
ERROR - 2013-08-28 15:14:32 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:14:48 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:48 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Router Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Output Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Security Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Input Class Initialized
DEBUG - 2013-08-28 15:14:48 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:14:48 --> Language Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Loader Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:14:48 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:14:48 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:14:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:14:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:14:48 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Session Class Initialized
DEBUG - 2013-08-28 15:14:48 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:14:49 --> Session routines successfully run
DEBUG - 2013-08-28 15:14:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:14:49 --> Controller Class Initialized
ERROR - 2013-08-28 15:14:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:49 --> Model Class Initialized
DEBUG - 2013-08-28 15:14:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:14:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:14:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:14:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:14:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:14:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:14:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:14:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:14:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:14:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:14:49 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-28 15:14:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:14:49 --> Final output sent to browser
DEBUG - 2013-08-28 15:14:49 --> Total execution time: 1.6131
DEBUG - 2013-08-28 15:14:49 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:50 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:50 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:50 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:50 --> Router Class Initialized
ERROR - 2013-08-28 15:14:50 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:14:51 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:51 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:51 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:51 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:51 --> Router Class Initialized
DEBUG - 2013-08-28 15:14:51 --> Output Class Initialized
DEBUG - 2013-08-28 15:14:51 --> Security Class Initialized
DEBUG - 2013-08-28 15:14:51 --> Input Class Initialized
DEBUG - 2013-08-28 15:14:51 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:14:51 --> Language Class Initialized
DEBUG - 2013-08-28 15:14:51 --> Loader Class Initialized
DEBUG - 2013-08-28 15:14:51 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:14:51 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:14:52 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:14:52 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:14:52 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:14:52 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:14:52 --> Session Class Initialized
DEBUG - 2013-08-28 15:14:52 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:14:52 --> Session routines successfully run
DEBUG - 2013-08-28 15:14:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:14:52 --> Controller Class Initialized
ERROR - 2013-08-28 15:14:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:52 --> Model Class Initialized
DEBUG - 2013-08-28 15:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:14:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:14:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:14:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:14:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:52 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:14:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:14:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:14:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:14:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:14:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:14:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:14:52 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:14:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:14:52 --> Final output sent to browser
DEBUG - 2013-08-28 15:14:52 --> Total execution time: 1.4331
DEBUG - 2013-08-28 15:14:53 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:53 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:53 --> Router Class Initialized
ERROR - 2013-08-28 15:14:53 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:14:57 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:57 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:57 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:57 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:57 --> Router Class Initialized
DEBUG - 2013-08-28 15:14:57 --> Output Class Initialized
DEBUG - 2013-08-28 15:14:57 --> Security Class Initialized
DEBUG - 2013-08-28 15:14:57 --> Input Class Initialized
DEBUG - 2013-08-28 15:14:58 --> XSS Filtering completed
DEBUG - 2013-08-28 15:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:14:58 --> Language Class Initialized
DEBUG - 2013-08-28 15:14:58 --> Loader Class Initialized
DEBUG - 2013-08-28 15:14:58 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:14:58 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:14:58 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:14:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:14:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:14:58 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:14:58 --> Session Class Initialized
DEBUG - 2013-08-28 15:14:58 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:14:58 --> Session routines successfully run
DEBUG - 2013-08-28 15:14:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:14:58 --> Controller Class Initialized
ERROR - 2013-08-28 15:14:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:58 --> Model Class Initialized
DEBUG - 2013-08-28 15:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:14:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:14:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:14:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:14:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:14:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:14:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:14:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:14:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:14:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:14:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:14:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:14:58 --> File loaded: application/views/jurusans/new.php
DEBUG - 2013-08-28 15:14:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:14:59 --> Final output sent to browser
DEBUG - 2013-08-28 15:14:59 --> Total execution time: 1.2831
DEBUG - 2013-08-28 15:14:59 --> Config Class Initialized
DEBUG - 2013-08-28 15:14:59 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:14:59 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:14:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:14:59 --> URI Class Initialized
DEBUG - 2013-08-28 15:14:59 --> Router Class Initialized
ERROR - 2013-08-28 15:14:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:15:05 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:05 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:05 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:05 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:05 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:05 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:05 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:05 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:05 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:05 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:05 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:05 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:06 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:15:06 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:15:06 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:06 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:06 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:06 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:06 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:06 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:06 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:06 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:06 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:07 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:07 --> Session garbage collection performed.
DEBUG - 2013-08-28 15:15:07 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:07 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:07 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:07 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:15:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:15:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:15:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:15:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:15:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:15:07 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:15:07 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:15:07 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:15:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:15:07 --> Final output sent to browser
DEBUG - 2013-08-28 15:15:07 --> Total execution time: 1.4171
DEBUG - 2013-08-28 15:15:07 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:07 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:08 --> Router Class Initialized
ERROR - 2013-08-28 15:15:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:15:10 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:10 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:10 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:10 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:10 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:10 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:10 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:10 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:10 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:10 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:11 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:11 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:11 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:15:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:15:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:15:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:15:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:15:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:15:11 --> File loaded: application/views/jurusans/new.php
DEBUG - 2013-08-28 15:15:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:15:11 --> Final output sent to browser
DEBUG - 2013-08-28 15:15:11 --> Total execution time: 1.3061
DEBUG - 2013-08-28 15:15:11 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:11 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:11 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:11 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:11 --> Router Class Initialized
ERROR - 2013-08-28 15:15:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:15:15 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:15 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:15 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:15 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:15 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:15 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:15 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:15 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:15 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:15 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:15 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:16 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:16 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:15:16 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:15:16 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:16 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:16 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:16 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:16 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:16 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:16 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:16 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:16 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:16 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:16 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:16 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:16 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:16 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:17 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:17 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:17 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:17 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:17 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:17 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:17 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:15:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:15:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:15:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:15:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:15:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:15:17 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:15:17 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 15:15:17 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:15:17 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:15:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:15:17 --> Final output sent to browser
DEBUG - 2013-08-28 15:15:17 --> Total execution time: 1.4481
DEBUG - 2013-08-28 15:15:17 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:17 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:18 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:18 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:18 --> Router Class Initialized
ERROR - 2013-08-28 15:15:18 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:15:28 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:28 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:28 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:28 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:28 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:28 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:28 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:29 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:29 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:29 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:15:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:15:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:15:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:15:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:15:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:15:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:15:29 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 15:15:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:15:29 --> Final output sent to browser
DEBUG - 2013-08-28 15:15:29 --> Total execution time: 1.3131
DEBUG - 2013-08-28 15:15:29 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:29 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:29 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:30 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:30 --> Router Class Initialized
ERROR - 2013-08-28 15:15:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:15:33 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:33 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:33 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:33 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:33 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:33 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:33 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:33 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:33 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:34 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:15:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:15:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:15:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:15:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:15:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:15:34 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-28 15:15:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:15:35 --> Final output sent to browser
DEBUG - 2013-08-28 15:15:35 --> Total execution time: 1.8441
DEBUG - 2013-08-28 15:15:35 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:35 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:35 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:35 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:35 --> Router Class Initialized
ERROR - 2013-08-28 15:15:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:15:40 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:40 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:40 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:40 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:40 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:40 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:40 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:40 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:40 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:40 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:40 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:40 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:40 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:41 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:41 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:41 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:41 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:15:41 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:41 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:41 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:15:41 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:41 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:41 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:41 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:41 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:41 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:41 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:41 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:41 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:42 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:42 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:42 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:42 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:42 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:42 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:42 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:42 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:42 --> Session garbage collection performed.
DEBUG - 2013-08-28 15:15:42 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:42 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:42 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:42 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:15:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:15:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:15:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:15:42 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:15:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:15:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:15:43 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 15:15:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:15:43 --> Final output sent to browser
DEBUG - 2013-08-28 15:15:43 --> Total execution time: 1.4851
DEBUG - 2013-08-28 15:15:43 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:43 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:43 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:43 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:43 --> Router Class Initialized
ERROR - 2013-08-28 15:15:43 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:15:46 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:46 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:46 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:46 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:46 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:46 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:46 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:46 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:46 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:46 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:46 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:15:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:15:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:15:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:15:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:15:47 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:15:47 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-28 15:15:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:15:47 --> Final output sent to browser
DEBUG - 2013-08-28 15:15:47 --> Total execution time: 1.5021
DEBUG - 2013-08-28 15:15:47 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:47 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:47 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:47 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:47 --> Router Class Initialized
ERROR - 2013-08-28 15:15:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:15:52 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:52 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:52 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:52 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:52 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:52 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:53 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:53 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:53 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:53 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:53 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:53 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:53 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:53 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:53 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:53 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:53 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:53 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:53 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:53 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:53 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:53 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:15:53 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:53 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:53 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:15:54 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:54 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:54 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:54 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:54 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:54 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:54 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:54 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:54 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:55 --> Model Class Initialized
DEBUG - 2013-08-28 15:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:15:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:15:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:15:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:15:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:55 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:15:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:15:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:15:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:15:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:15:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:15:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:15:55 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 15:15:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:15:55 --> Final output sent to browser
DEBUG - 2013-08-28 15:15:55 --> Total execution time: 1.4501
DEBUG - 2013-08-28 15:15:55 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:55 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:55 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:55 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:55 --> Router Class Initialized
ERROR - 2013-08-28 15:15:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:15:59 --> Config Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:15:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:15:59 --> URI Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Router Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Output Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Security Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Input Class Initialized
DEBUG - 2013-08-28 15:15:59 --> XSS Filtering completed
DEBUG - 2013-08-28 15:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:15:59 --> Language Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Loader Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:15:59 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:15:59 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:15:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:15:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:15:59 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Session Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:15:59 --> Session routines successfully run
DEBUG - 2013-08-28 15:15:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:15:59 --> Controller Class Initialized
ERROR - 2013-08-28 15:15:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:15:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:15:59 --> Model Class Initialized
DEBUG - 2013-08-28 15:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:16:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:16:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:16:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:16:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:16:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:16:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:16:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:16:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:16:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:16:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:16:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:16:00 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-28 15:16:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:16:00 --> Final output sent to browser
DEBUG - 2013-08-28 15:16:00 --> Total execution time: 1.3341
DEBUG - 2013-08-28 15:16:00 --> Config Class Initialized
DEBUG - 2013-08-28 15:16:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:16:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:16:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:16:00 --> URI Class Initialized
DEBUG - 2013-08-28 15:16:00 --> Router Class Initialized
ERROR - 2013-08-28 15:16:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:16:05 --> Config Class Initialized
DEBUG - 2013-08-28 15:16:05 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:16:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:16:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:16:05 --> URI Class Initialized
DEBUG - 2013-08-28 15:16:05 --> Router Class Initialized
DEBUG - 2013-08-28 15:16:05 --> Output Class Initialized
DEBUG - 2013-08-28 15:16:05 --> Security Class Initialized
DEBUG - 2013-08-28 15:16:05 --> Input Class Initialized
DEBUG - 2013-08-28 15:16:05 --> XSS Filtering completed
DEBUG - 2013-08-28 15:16:05 --> XSS Filtering completed
DEBUG - 2013-08-28 15:16:05 --> XSS Filtering completed
DEBUG - 2013-08-28 15:16:05 --> XSS Filtering completed
DEBUG - 2013-08-28 15:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:16:05 --> Language Class Initialized
DEBUG - 2013-08-28 15:16:05 --> Loader Class Initialized
DEBUG - 2013-08-28 15:16:05 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:16:05 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:16:05 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:16:06 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:16:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:16:06 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:16:06 --> Session Class Initialized
DEBUG - 2013-08-28 15:16:06 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:16:06 --> Session routines successfully run
DEBUG - 2013-08-28 15:16:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:16:06 --> Controller Class Initialized
ERROR - 2013-08-28 15:16:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:16:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:16:06 --> Model Class Initialized
DEBUG - 2013-08-28 15:16:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:16:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:16:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:16:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:16:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:16:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:16:06 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:16:06 --> XSS Filtering completed
DEBUG - 2013-08-28 15:16:06 --> XSS Filtering completed
DEBUG - 2013-08-28 15:16:06 --> XSS Filtering completed
DEBUG - 2013-08-28 15:16:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:16:06 --> Config Class Initialized
DEBUG - 2013-08-28 15:16:06 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:16:06 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:16:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:16:07 --> URI Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Router Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Output Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Security Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Input Class Initialized
DEBUG - 2013-08-28 15:16:07 --> XSS Filtering completed
DEBUG - 2013-08-28 15:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:16:07 --> Language Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Loader Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:16:07 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:16:07 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:16:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:16:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:16:07 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Session Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:16:07 --> Session routines successfully run
DEBUG - 2013-08-28 15:16:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Controller Class Initialized
ERROR - 2013-08-28 15:16:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:16:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:16:07 --> Model Class Initialized
DEBUG - 2013-08-28 15:16:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:16:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:16:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:16:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:16:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:16:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:16:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:16:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:16:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:16:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:16:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:16:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:16:08 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-28 15:16:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:16:08 --> Final output sent to browser
DEBUG - 2013-08-28 15:16:08 --> Total execution time: 1.6411
DEBUG - 2013-08-28 15:16:08 --> Config Class Initialized
DEBUG - 2013-08-28 15:16:08 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:16:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:16:08 --> URI Class Initialized
DEBUG - 2013-08-28 15:16:08 --> Router Class Initialized
ERROR - 2013-08-28 15:16:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:16:11 --> Config Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:16:11 --> URI Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Router Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Output Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Security Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Input Class Initialized
DEBUG - 2013-08-28 15:16:11 --> XSS Filtering completed
DEBUG - 2013-08-28 15:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:16:11 --> Language Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Loader Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:16:11 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:16:11 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:16:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:16:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:16:11 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Session Class Initialized
DEBUG - 2013-08-28 15:16:11 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:16:11 --> Session routines successfully run
DEBUG - 2013-08-28 15:16:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:16:12 --> Controller Class Initialized
ERROR - 2013-08-28 15:16:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:16:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:16:12 --> Model Class Initialized
DEBUG - 2013-08-28 15:16:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:16:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:16:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:16:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:16:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:16:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:16:12 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:16:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:16:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:16:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:16:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:16:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:16:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:16:12 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 15:16:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:16:12 --> Final output sent to browser
DEBUG - 2013-08-28 15:16:12 --> Total execution time: 1.6001
DEBUG - 2013-08-28 15:16:12 --> Config Class Initialized
DEBUG - 2013-08-28 15:16:12 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:16:13 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:16:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:16:13 --> URI Class Initialized
DEBUG - 2013-08-28 15:16:13 --> Router Class Initialized
ERROR - 2013-08-28 15:16:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:17:36 --> Config Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:17:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:17:36 --> URI Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Router Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Output Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Security Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Input Class Initialized
DEBUG - 2013-08-28 15:17:36 --> XSS Filtering completed
DEBUG - 2013-08-28 15:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:17:36 --> Language Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Loader Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:17:36 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:17:36 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:17:36 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:17:36 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:17:36 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Session Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:17:36 --> Session routines successfully run
DEBUG - 2013-08-28 15:17:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:17:36 --> Controller Class Initialized
ERROR - 2013-08-28 15:17:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:17:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:17:37 --> Model Class Initialized
DEBUG - 2013-08-28 15:17:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:17:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:17:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:17:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:17:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:17:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:17:37 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:17:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:17:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:17:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:17:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:17:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:17:37 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:17:37 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 15:17:37 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:17:37 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:17:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:17:37 --> Final output sent to browser
DEBUG - 2013-08-28 15:17:37 --> Total execution time: 1.4961
DEBUG - 2013-08-28 15:17:37 --> Config Class Initialized
DEBUG - 2013-08-28 15:17:37 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:17:37 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:17:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:17:37 --> URI Class Initialized
DEBUG - 2013-08-28 15:17:37 --> Router Class Initialized
ERROR - 2013-08-28 15:17:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:17:40 --> Config Class Initialized
DEBUG - 2013-08-28 15:17:40 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:17:40 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:17:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:17:40 --> URI Class Initialized
DEBUG - 2013-08-28 15:17:40 --> Router Class Initialized
DEBUG - 2013-08-28 15:17:40 --> Output Class Initialized
DEBUG - 2013-08-28 15:17:40 --> Security Class Initialized
DEBUG - 2013-08-28 15:17:40 --> Input Class Initialized
DEBUG - 2013-08-28 15:17:40 --> XSS Filtering completed
DEBUG - 2013-08-28 15:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:17:40 --> Language Class Initialized
DEBUG - 2013-08-28 15:17:40 --> Loader Class Initialized
DEBUG - 2013-08-28 15:17:40 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:17:40 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:17:40 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:17:40 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:17:40 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:17:40 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:17:41 --> Session Class Initialized
DEBUG - 2013-08-28 15:17:41 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:17:41 --> Session garbage collection performed.
DEBUG - 2013-08-28 15:17:41 --> Session routines successfully run
DEBUG - 2013-08-28 15:17:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:17:41 --> Controller Class Initialized
ERROR - 2013-08-28 15:17:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:17:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:17:41 --> Model Class Initialized
DEBUG - 2013-08-28 15:17:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:17:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:17:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:17:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:17:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:17:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:17:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:17:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:17:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:17:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:17:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:17:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:17:41 --> File loaded: application/views/jurusans/new.php
DEBUG - 2013-08-28 15:17:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:17:41 --> Final output sent to browser
DEBUG - 2013-08-28 15:17:41 --> Total execution time: 1.4611
DEBUG - 2013-08-28 15:17:42 --> Config Class Initialized
DEBUG - 2013-08-28 15:17:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:17:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:17:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:17:42 --> URI Class Initialized
DEBUG - 2013-08-28 15:17:42 --> Router Class Initialized
ERROR - 2013-08-28 15:17:42 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:17:46 --> Config Class Initialized
DEBUG - 2013-08-28 15:17:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:17:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:17:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:17:46 --> URI Class Initialized
DEBUG - 2013-08-28 15:17:46 --> Router Class Initialized
DEBUG - 2013-08-28 15:17:46 --> Output Class Initialized
DEBUG - 2013-08-28 15:17:46 --> Security Class Initialized
DEBUG - 2013-08-28 15:17:46 --> Input Class Initialized
DEBUG - 2013-08-28 15:17:46 --> XSS Filtering completed
DEBUG - 2013-08-28 15:17:46 --> XSS Filtering completed
DEBUG - 2013-08-28 15:17:46 --> XSS Filtering completed
DEBUG - 2013-08-28 15:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:17:46 --> Language Class Initialized
DEBUG - 2013-08-28 15:17:47 --> Loader Class Initialized
DEBUG - 2013-08-28 15:17:47 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:17:47 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:17:47 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:17:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:17:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:17:47 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:17:47 --> Session Class Initialized
DEBUG - 2013-08-28 15:17:47 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:17:47 --> Session routines successfully run
DEBUG - 2013-08-28 15:17:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:17:47 --> Controller Class Initialized
ERROR - 2013-08-28 15:17:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:17:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:17:47 --> Model Class Initialized
DEBUG - 2013-08-28 15:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:17:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:17:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:17:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:17:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:17:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:17:47 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:17:47 --> XSS Filtering completed
DEBUG - 2013-08-28 15:17:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:17:47 --> Config Class Initialized
DEBUG - 2013-08-28 15:17:47 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:17:47 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:17:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:17:48 --> URI Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Router Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Output Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Security Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Input Class Initialized
DEBUG - 2013-08-28 15:17:48 --> XSS Filtering completed
DEBUG - 2013-08-28 15:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:17:48 --> Language Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Loader Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:17:48 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:17:48 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:17:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:17:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:17:48 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Session Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:17:48 --> Session routines successfully run
DEBUG - 2013-08-28 15:17:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Controller Class Initialized
ERROR - 2013-08-28 15:17:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:17:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:17:48 --> Model Class Initialized
DEBUG - 2013-08-28 15:17:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:17:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:17:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:17:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:17:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:17:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:17:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:17:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:17:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:17:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:17:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:17:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:17:49 --> File loaded: application/views/jurusans/new.php
DEBUG - 2013-08-28 15:17:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:17:49 --> Final output sent to browser
DEBUG - 2013-08-28 15:17:49 --> Total execution time: 1.5051
DEBUG - 2013-08-28 15:17:49 --> Config Class Initialized
DEBUG - 2013-08-28 15:17:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:17:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:17:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:17:49 --> URI Class Initialized
DEBUG - 2013-08-28 15:17:49 --> Router Class Initialized
ERROR - 2013-08-28 15:17:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:18:00 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:00 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Router Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Output Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Security Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Input Class Initialized
DEBUG - 2013-08-28 15:18:01 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:18:01 --> Language Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Loader Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:18:01 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:18:01 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:18:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:18:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:18:01 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Session Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:18:01 --> Session routines successfully run
DEBUG - 2013-08-28 15:18:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Controller Class Initialized
ERROR - 2013-08-28 15:18:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:01 --> Model Class Initialized
DEBUG - 2013-08-28 15:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:18:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:18:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:18:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:18:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:01 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:18:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:18:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:18:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:18:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:18:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:18:02 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:18:02 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 15:18:02 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:18:02 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:18:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:18:02 --> Final output sent to browser
DEBUG - 2013-08-28 15:18:02 --> Total execution time: 1.5111
DEBUG - 2013-08-28 15:18:02 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:02 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:02 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:02 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:02 --> Router Class Initialized
ERROR - 2013-08-28 15:18:02 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:18:06 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:07 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Router Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Output Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Security Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Input Class Initialized
DEBUG - 2013-08-28 15:18:07 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:18:07 --> Language Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Loader Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:18:07 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:18:07 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:18:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:18:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:18:07 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Session Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:18:07 --> Session routines successfully run
DEBUG - 2013-08-28 15:18:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Controller Class Initialized
ERROR - 2013-08-28 15:18:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:07 --> Model Class Initialized
DEBUG - 2013-08-28 15:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:18:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:18:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:18:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:18:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:18:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:18:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:18:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:18:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:18:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:18:08 --> File loaded: application/views/jurusans/edit.php
DEBUG - 2013-08-28 15:18:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:18:08 --> Final output sent to browser
DEBUG - 2013-08-28 15:18:08 --> Total execution time: 1.4411
DEBUG - 2013-08-28 15:18:08 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:08 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:08 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:08 --> Router Class Initialized
ERROR - 2013-08-28 15:18:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:18:13 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:13 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Router Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Output Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Security Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Input Class Initialized
DEBUG - 2013-08-28 15:18:13 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:13 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:13 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:18:13 --> Language Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Loader Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:18:13 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:18:13 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:18:13 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:18:13 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:18:13 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Session Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:18:13 --> Session routines successfully run
DEBUG - 2013-08-28 15:18:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:18:13 --> Controller Class Initialized
ERROR - 2013-08-28 15:18:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:14 --> Model Class Initialized
DEBUG - 2013-08-28 15:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:18:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:18:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:18:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:18:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:14 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:18:14 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:18:14 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:14 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:14 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:14 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:14 --> Router Class Initialized
DEBUG - 2013-08-28 15:18:14 --> Output Class Initialized
DEBUG - 2013-08-28 15:18:14 --> Security Class Initialized
DEBUG - 2013-08-28 15:18:14 --> Input Class Initialized
DEBUG - 2013-08-28 15:18:14 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:18:14 --> Language Class Initialized
DEBUG - 2013-08-28 15:18:14 --> Loader Class Initialized
DEBUG - 2013-08-28 15:18:14 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:18:15 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:18:15 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:18:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:18:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:18:15 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:18:15 --> Session Class Initialized
DEBUG - 2013-08-28 15:18:15 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:18:15 --> Session routines successfully run
DEBUG - 2013-08-28 15:18:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:18:15 --> Controller Class Initialized
ERROR - 2013-08-28 15:18:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:15 --> Model Class Initialized
DEBUG - 2013-08-28 15:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:18:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:18:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:18:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:18:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:18:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:18:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:18:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:18:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:18:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:18:15 --> File loaded: application/views/jurusans/edit.php
DEBUG - 2013-08-28 15:18:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:18:16 --> Final output sent to browser
DEBUG - 2013-08-28 15:18:16 --> Total execution time: 1.5681
DEBUG - 2013-08-28 15:18:16 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:16 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:16 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:16 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:16 --> Router Class Initialized
ERROR - 2013-08-28 15:18:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:18:19 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:19 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:19 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:19 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:19 --> Router Class Initialized
DEBUG - 2013-08-28 15:18:19 --> Output Class Initialized
DEBUG - 2013-08-28 15:18:19 --> Security Class Initialized
DEBUG - 2013-08-28 15:18:19 --> Input Class Initialized
DEBUG - 2013-08-28 15:18:19 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:18:19 --> Language Class Initialized
DEBUG - 2013-08-28 15:18:19 --> Loader Class Initialized
DEBUG - 2013-08-28 15:18:20 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:18:20 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:18:20 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:18:20 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:18:20 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:18:20 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:18:20 --> Session Class Initialized
DEBUG - 2013-08-28 15:18:20 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:18:20 --> Session routines successfully run
DEBUG - 2013-08-28 15:18:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:18:20 --> Controller Class Initialized
ERROR - 2013-08-28 15:18:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:20 --> Model Class Initialized
DEBUG - 2013-08-28 15:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:18:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:18:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:18:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:18:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:18:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:18:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:18:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:18:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:18:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:18:20 --> File loaded: application/views/jurusans/show.php
DEBUG - 2013-08-28 15:18:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:18:20 --> Final output sent to browser
DEBUG - 2013-08-28 15:18:21 --> Total execution time: 1.3761
DEBUG - 2013-08-28 15:18:21 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:21 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:21 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:21 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:21 --> Router Class Initialized
ERROR - 2013-08-28 15:18:21 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:18:24 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:24 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:25 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Router Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Output Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Security Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Input Class Initialized
DEBUG - 2013-08-28 15:18:25 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:18:25 --> Language Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Loader Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:18:25 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:18:25 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:18:25 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:18:25 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:18:25 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Session Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:18:25 --> Session routines successfully run
DEBUG - 2013-08-28 15:18:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Controller Class Initialized
ERROR - 2013-08-28 15:18:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:25 --> Model Class Initialized
DEBUG - 2013-08-28 15:18:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:18:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:18:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:18:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:18:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:26 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:18:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:18:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:18:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:18:26 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:18:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:18:26 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:18:26 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 15:18:26 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:18:26 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:18:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:18:26 --> Final output sent to browser
DEBUG - 2013-08-28 15:18:26 --> Total execution time: 1.5471
DEBUG - 2013-08-28 15:18:26 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:26 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:26 --> Router Class Initialized
ERROR - 2013-08-28 15:18:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:18:50 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:50 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:50 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:51 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Router Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Output Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Security Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Input Class Initialized
DEBUG - 2013-08-28 15:18:51 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:18:51 --> Language Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Loader Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:18:51 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:18:51 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:18:51 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:18:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:18:51 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Session Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:18:51 --> Session routines successfully run
DEBUG - 2013-08-28 15:18:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Controller Class Initialized
ERROR - 2013-08-28 15:18:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:51 --> Model Class Initialized
DEBUG - 2013-08-28 15:18:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:18:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:18:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:18:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:18:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:18:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:18:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:18:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:18:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:18:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:18:52 --> File loaded: application/views/jurusans/edit.php
DEBUG - 2013-08-28 15:18:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:18:52 --> Final output sent to browser
DEBUG - 2013-08-28 15:18:52 --> Total execution time: 1.4291
DEBUG - 2013-08-28 15:18:52 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:52 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:52 --> Router Class Initialized
ERROR - 2013-08-28 15:18:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:18:54 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:54 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Router Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Output Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Security Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Input Class Initialized
DEBUG - 2013-08-28 15:18:54 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:54 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:54 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:18:54 --> Language Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Loader Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:18:54 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:18:54 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:18:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:18:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:18:54 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Session Class Initialized
DEBUG - 2013-08-28 15:18:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:18:55 --> Session routines successfully run
DEBUG - 2013-08-28 15:18:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:18:55 --> Controller Class Initialized
ERROR - 2013-08-28 15:18:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:55 --> Model Class Initialized
DEBUG - 2013-08-28 15:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:18:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:18:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:18:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:18:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:55 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:18:55 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:18:55 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:55 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:55 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:55 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:55 --> Router Class Initialized
DEBUG - 2013-08-28 15:18:55 --> Output Class Initialized
DEBUG - 2013-08-28 15:18:55 --> Security Class Initialized
DEBUG - 2013-08-28 15:18:55 --> Input Class Initialized
DEBUG - 2013-08-28 15:18:55 --> XSS Filtering completed
DEBUG - 2013-08-28 15:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:18:56 --> Language Class Initialized
DEBUG - 2013-08-28 15:18:56 --> Loader Class Initialized
DEBUG - 2013-08-28 15:18:56 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:18:56 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:18:56 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:18:56 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:18:56 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:18:56 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:18:56 --> Session Class Initialized
DEBUG - 2013-08-28 15:18:56 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:18:56 --> Session routines successfully run
DEBUG - 2013-08-28 15:18:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:18:56 --> Controller Class Initialized
ERROR - 2013-08-28 15:18:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:56 --> Model Class Initialized
DEBUG - 2013-08-28 15:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:18:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:18:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:18:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:18:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:18:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:18:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:18:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:18:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:18:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:18:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:18:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:18:57 --> File loaded: application/views/jurusans/edit.php
DEBUG - 2013-08-28 15:18:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:18:57 --> Final output sent to browser
DEBUG - 2013-08-28 15:18:57 --> Total execution time: 1.5981
DEBUG - 2013-08-28 15:18:57 --> Config Class Initialized
DEBUG - 2013-08-28 15:18:57 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:18:57 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:18:57 --> URI Class Initialized
DEBUG - 2013-08-28 15:18:57 --> Router Class Initialized
ERROR - 2013-08-28 15:18:57 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:19:01 --> Config Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:19:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:19:01 --> URI Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Router Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Output Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Security Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Input Class Initialized
DEBUG - 2013-08-28 15:19:01 --> XSS Filtering completed
DEBUG - 2013-08-28 15:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:19:01 --> Language Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Loader Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:19:01 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:19:01 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:19:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:19:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:19:01 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Session Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:19:01 --> Session routines successfully run
DEBUG - 2013-08-28 15:19:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:19:01 --> Controller Class Initialized
ERROR - 2013-08-28 15:19:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:19:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:19:01 --> Model Class Initialized
DEBUG - 2013-08-28 15:19:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:19:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:19:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:19:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:19:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:19:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:19:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:19:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:19:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:19:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:19:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:19:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:19:02 --> File loaded: application/views/jurusans/show.php
DEBUG - 2013-08-28 15:19:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:19:02 --> Final output sent to browser
DEBUG - 2013-08-28 15:19:02 --> Total execution time: 1.4841
DEBUG - 2013-08-28 15:19:02 --> Config Class Initialized
DEBUG - 2013-08-28 15:19:02 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:19:02 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:19:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:19:02 --> URI Class Initialized
DEBUG - 2013-08-28 15:19:02 --> Router Class Initialized
ERROR - 2013-08-28 15:19:02 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:19:04 --> Config Class Initialized
DEBUG - 2013-08-28 15:19:04 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:19:04 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:19:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:19:04 --> URI Class Initialized
DEBUG - 2013-08-28 15:19:04 --> Router Class Initialized
DEBUG - 2013-08-28 15:19:04 --> Output Class Initialized
DEBUG - 2013-08-28 15:19:05 --> Security Class Initialized
DEBUG - 2013-08-28 15:19:05 --> Input Class Initialized
DEBUG - 2013-08-28 15:19:05 --> XSS Filtering completed
DEBUG - 2013-08-28 15:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:19:05 --> Language Class Initialized
DEBUG - 2013-08-28 15:19:05 --> Loader Class Initialized
DEBUG - 2013-08-28 15:19:05 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:19:05 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:19:05 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:19:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:19:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:19:05 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:19:05 --> Session Class Initialized
DEBUG - 2013-08-28 15:19:05 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:19:05 --> Session garbage collection performed.
DEBUG - 2013-08-28 15:19:05 --> Session routines successfully run
DEBUG - 2013-08-28 15:19:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:19:05 --> Controller Class Initialized
ERROR - 2013-08-28 15:19:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:19:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:19:05 --> Model Class Initialized
DEBUG - 2013-08-28 15:19:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:19:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:19:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:19:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:19:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:19:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:19:06 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:19:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:19:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:19:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:19:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:19:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:19:06 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:19:06 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 15:19:06 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:19:06 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:19:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:19:06 --> Final output sent to browser
DEBUG - 2013-08-28 15:19:06 --> Total execution time: 1.7231
DEBUG - 2013-08-28 15:19:06 --> Config Class Initialized
DEBUG - 2013-08-28 15:19:06 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:19:06 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:19:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:19:06 --> URI Class Initialized
DEBUG - 2013-08-28 15:19:06 --> Router Class Initialized
ERROR - 2013-08-28 15:19:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:23:57 --> Config Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:23:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:23:58 --> URI Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Router Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Output Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Security Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Input Class Initialized
DEBUG - 2013-08-28 15:23:58 --> XSS Filtering completed
DEBUG - 2013-08-28 15:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:23:58 --> Language Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Loader Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:23:58 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:23:58 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:23:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:23:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:23:58 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Session Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:23:58 --> Session routines successfully run
DEBUG - 2013-08-28 15:23:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:23:58 --> Controller Class Initialized
ERROR - 2013-08-28 15:23:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:23:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:23:59 --> Model Class Initialized
DEBUG - 2013-08-28 15:23:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:23:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:23:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:23:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:23:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:23:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:23:59 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:23:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:23:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:23:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:23:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:23:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:23:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:23:59 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 15:23:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:23:59 --> Final output sent to browser
DEBUG - 2013-08-28 15:23:59 --> Total execution time: 1.9651
DEBUG - 2013-08-28 15:24:00 --> Config Class Initialized
DEBUG - 2013-08-28 15:24:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:24:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:24:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:24:00 --> URI Class Initialized
DEBUG - 2013-08-28 15:24:00 --> Router Class Initialized
ERROR - 2013-08-28 15:24:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:25:23 --> Config Class Initialized
DEBUG - 2013-08-28 15:25:23 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:25:23 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:25:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:25:23 --> URI Class Initialized
DEBUG - 2013-08-28 15:25:23 --> Router Class Initialized
DEBUG - 2013-08-28 15:25:23 --> Output Class Initialized
DEBUG - 2013-08-28 15:25:23 --> Security Class Initialized
DEBUG - 2013-08-28 15:25:23 --> Input Class Initialized
DEBUG - 2013-08-28 15:25:23 --> XSS Filtering completed
DEBUG - 2013-08-28 15:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:25:23 --> Language Class Initialized
DEBUG - 2013-08-28 15:25:23 --> Loader Class Initialized
DEBUG - 2013-08-28 15:25:23 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:25:23 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:25:23 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:25:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:25:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:25:24 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:25:24 --> Session Class Initialized
DEBUG - 2013-08-28 15:25:24 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:25:24 --> Session routines successfully run
DEBUG - 2013-08-28 15:25:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:25:24 --> Controller Class Initialized
ERROR - 2013-08-28 15:25:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:25:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:25:24 --> Model Class Initialized
DEBUG - 2013-08-28 15:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:25:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:25:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:25:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:25:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:25:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:25:24 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:25:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:25:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:25:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:25:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:25:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:25:24 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:25:24 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 15:25:24 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:25:24 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:25:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:25:25 --> Final output sent to browser
DEBUG - 2013-08-28 15:25:25 --> Total execution time: 1.6351
DEBUG - 2013-08-28 15:25:25 --> Config Class Initialized
DEBUG - 2013-08-28 15:25:25 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:25:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:25:25 --> URI Class Initialized
DEBUG - 2013-08-28 15:25:25 --> Router Class Initialized
ERROR - 2013-08-28 15:25:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:29:23 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:23 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:23 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:23 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:23 --> Router Class Initialized
DEBUG - 2013-08-28 15:29:23 --> Output Class Initialized
DEBUG - 2013-08-28 15:29:23 --> Security Class Initialized
DEBUG - 2013-08-28 15:29:23 --> Input Class Initialized
DEBUG - 2013-08-28 15:29:23 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:29:23 --> Language Class Initialized
DEBUG - 2013-08-28 15:29:23 --> Loader Class Initialized
DEBUG - 2013-08-28 15:29:23 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:29:23 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:29:23 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:29:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:29:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:29:24 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:29:24 --> Session Class Initialized
DEBUG - 2013-08-28 15:29:24 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:29:24 --> Session routines successfully run
DEBUG - 2013-08-28 15:29:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:29:24 --> Controller Class Initialized
ERROR - 2013-08-28 15:29:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:24 --> Model Class Initialized
DEBUG - 2013-08-28 15:29:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:29:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:29:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:29:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:29:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:24 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:29:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:29:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:29:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:29:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:29:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:29:24 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:29:24 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 15:29:25 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:29:25 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:29:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:29:25 --> Final output sent to browser
DEBUG - 2013-08-28 15:29:25 --> Total execution time: 1.7681
DEBUG - 2013-08-28 15:29:25 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:25 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:25 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:25 --> Router Class Initialized
ERROR - 2013-08-28 15:29:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:29:26 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:26 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:26 --> Router Class Initialized
DEBUG - 2013-08-28 15:29:26 --> Output Class Initialized
DEBUG - 2013-08-28 15:29:26 --> Security Class Initialized
DEBUG - 2013-08-28 15:29:26 --> Input Class Initialized
DEBUG - 2013-08-28 15:29:26 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:29:26 --> Language Class Initialized
DEBUG - 2013-08-28 15:29:26 --> Loader Class Initialized
DEBUG - 2013-08-28 15:29:26 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:29:27 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:29:27 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:29:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:29:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:29:27 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:29:27 --> Session Class Initialized
DEBUG - 2013-08-28 15:29:27 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:29:27 --> Session routines successfully run
DEBUG - 2013-08-28 15:29:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:29:27 --> Controller Class Initialized
ERROR - 2013-08-28 15:29:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:27 --> Model Class Initialized
DEBUG - 2013-08-28 15:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:29:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:29:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:29:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:29:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:29:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:29:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:29:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:29:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:29:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:29:28 --> File loaded: application/views/jurusans/new.php
DEBUG - 2013-08-28 15:29:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:29:28 --> Final output sent to browser
DEBUG - 2013-08-28 15:29:28 --> Total execution time: 1.8351
DEBUG - 2013-08-28 15:29:28 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:28 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:28 --> Router Class Initialized
ERROR - 2013-08-28 15:29:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:29:36 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:36 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Router Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Output Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Security Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Input Class Initialized
DEBUG - 2013-08-28 15:29:36 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:36 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:36 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:29:36 --> Language Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Loader Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:29:36 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:29:36 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:29:36 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:29:36 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:29:36 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Session Class Initialized
DEBUG - 2013-08-28 15:29:36 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:29:37 --> Session routines successfully run
DEBUG - 2013-08-28 15:29:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:29:37 --> Controller Class Initialized
ERROR - 2013-08-28 15:29:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:37 --> Model Class Initialized
DEBUG - 2013-08-28 15:29:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:29:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:29:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:29:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:29:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:37 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:29:37 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:29:37 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:37 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:37 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:37 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:37 --> Router Class Initialized
DEBUG - 2013-08-28 15:29:37 --> Output Class Initialized
DEBUG - 2013-08-28 15:29:37 --> Security Class Initialized
DEBUG - 2013-08-28 15:29:38 --> Input Class Initialized
DEBUG - 2013-08-28 15:29:38 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:29:38 --> Language Class Initialized
DEBUG - 2013-08-28 15:29:38 --> Loader Class Initialized
DEBUG - 2013-08-28 15:29:38 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:29:38 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:29:38 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:29:38 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:29:38 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:29:38 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:29:38 --> Session Class Initialized
DEBUG - 2013-08-28 15:29:38 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:29:38 --> Session routines successfully run
DEBUG - 2013-08-28 15:29:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:29:38 --> Controller Class Initialized
ERROR - 2013-08-28 15:29:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:38 --> Model Class Initialized
DEBUG - 2013-08-28 15:29:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:29:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:29:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:29:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:29:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:29:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:29:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:29:39 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:29:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:29:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:29:39 --> File loaded: application/views/jurusans/new.php
DEBUG - 2013-08-28 15:29:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:29:39 --> Final output sent to browser
DEBUG - 2013-08-28 15:29:39 --> Total execution time: 1.7971
DEBUG - 2013-08-28 15:29:39 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:39 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:39 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:39 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:39 --> Router Class Initialized
ERROR - 2013-08-28 15:29:39 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:29:43 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:43 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:43 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:43 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:43 --> Router Class Initialized
DEBUG - 2013-08-28 15:29:43 --> Output Class Initialized
DEBUG - 2013-08-28 15:29:43 --> Security Class Initialized
DEBUG - 2013-08-28 15:29:44 --> Input Class Initialized
DEBUG - 2013-08-28 15:29:44 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:29:44 --> Language Class Initialized
DEBUG - 2013-08-28 15:29:44 --> Loader Class Initialized
DEBUG - 2013-08-28 15:29:44 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:29:44 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:29:44 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:29:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:29:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:29:44 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:29:44 --> Session Class Initialized
DEBUG - 2013-08-28 15:29:44 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:29:44 --> Session routines successfully run
DEBUG - 2013-08-28 15:29:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:29:44 --> Controller Class Initialized
ERROR - 2013-08-28 15:29:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:44 --> Model Class Initialized
DEBUG - 2013-08-28 15:29:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:29:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:29:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:29:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:29:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:44 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:29:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:29:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:29:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:29:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:29:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:29:45 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:29:45 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 15:29:45 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:29:45 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:29:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:29:45 --> Final output sent to browser
DEBUG - 2013-08-28 15:29:45 --> Total execution time: 1.7341
DEBUG - 2013-08-28 15:29:45 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:45 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:45 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:45 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:45 --> Router Class Initialized
ERROR - 2013-08-28 15:29:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:29:47 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:47 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:47 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:47 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:47 --> Router Class Initialized
DEBUG - 2013-08-28 15:29:47 --> Output Class Initialized
DEBUG - 2013-08-28 15:29:47 --> Security Class Initialized
DEBUG - 2013-08-28 15:29:47 --> Input Class Initialized
DEBUG - 2013-08-28 15:29:47 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:29:47 --> Language Class Initialized
DEBUG - 2013-08-28 15:29:47 --> Loader Class Initialized
DEBUG - 2013-08-28 15:29:47 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:29:47 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:29:47 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:29:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:29:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:29:47 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:29:47 --> Session Class Initialized
DEBUG - 2013-08-28 15:29:48 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:29:48 --> Session routines successfully run
DEBUG - 2013-08-28 15:29:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:29:48 --> Controller Class Initialized
ERROR - 2013-08-28 15:29:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:48 --> Model Class Initialized
DEBUG - 2013-08-28 15:29:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:29:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:29:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:29:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:29:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:29:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:29:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:29:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:29:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:29:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:29:48 --> File loaded: application/views/jurusans/edit.php
DEBUG - 2013-08-28 15:29:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:29:48 --> Final output sent to browser
DEBUG - 2013-08-28 15:29:49 --> Total execution time: 1.7271
DEBUG - 2013-08-28 15:29:49 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:49 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:49 --> Router Class Initialized
ERROR - 2013-08-28 15:29:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:29:50 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:50 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:50 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:50 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Router Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Output Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Security Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Input Class Initialized
DEBUG - 2013-08-28 15:29:51 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:51 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:51 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:29:51 --> Language Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Loader Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:29:51 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:29:51 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:29:51 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:29:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:29:51 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Session Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:29:51 --> Session routines successfully run
DEBUG - 2013-08-28 15:29:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Controller Class Initialized
ERROR - 2013-08-28 15:29:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:51 --> Model Class Initialized
DEBUG - 2013-08-28 15:29:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:29:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:29:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:29:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:29:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:52 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:29:52 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:29:52 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:52 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:52 --> Router Class Initialized
DEBUG - 2013-08-28 15:29:52 --> Output Class Initialized
DEBUG - 2013-08-28 15:29:52 --> Security Class Initialized
DEBUG - 2013-08-28 15:29:52 --> Input Class Initialized
DEBUG - 2013-08-28 15:29:52 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:29:52 --> Language Class Initialized
DEBUG - 2013-08-28 15:29:52 --> Loader Class Initialized
DEBUG - 2013-08-28 15:29:52 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:29:52 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:29:52 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:29:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:29:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:29:53 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:29:53 --> Session Class Initialized
DEBUG - 2013-08-28 15:29:53 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:29:53 --> Session garbage collection performed.
DEBUG - 2013-08-28 15:29:53 --> Session routines successfully run
DEBUG - 2013-08-28 15:29:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:29:53 --> Controller Class Initialized
ERROR - 2013-08-28 15:29:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:53 --> Model Class Initialized
DEBUG - 2013-08-28 15:29:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:29:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:29:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:29:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:29:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:29:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:29:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:29:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:29:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:29:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:29:54 --> File loaded: application/views/jurusans/show.php
DEBUG - 2013-08-28 15:29:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:29:54 --> Final output sent to browser
DEBUG - 2013-08-28 15:29:54 --> Total execution time: 1.8651
DEBUG - 2013-08-28 15:29:54 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:54 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:54 --> Router Class Initialized
ERROR - 2013-08-28 15:29:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:29:56 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:57 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Router Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Output Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Security Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Input Class Initialized
DEBUG - 2013-08-28 15:29:57 --> XSS Filtering completed
DEBUG - 2013-08-28 15:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:29:57 --> Language Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Loader Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:29:57 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:29:57 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:29:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:29:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:29:57 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Session Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:29:57 --> Session routines successfully run
DEBUG - 2013-08-28 15:29:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:29:57 --> Controller Class Initialized
ERROR - 2013-08-28 15:29:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:57 --> Model Class Initialized
DEBUG - 2013-08-28 15:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:29:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:29:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:29:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:29:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:29:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:29:58 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:29:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:29:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:29:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:29:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:29:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:29:58 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 15:29:58 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 15:29:58 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 15:29:58 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 15:29:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:29:58 --> Final output sent to browser
DEBUG - 2013-08-28 15:29:58 --> Total execution time: 1.7611
DEBUG - 2013-08-28 15:29:58 --> Config Class Initialized
DEBUG - 2013-08-28 15:29:58 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:29:58 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:29:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:29:59 --> URI Class Initialized
DEBUG - 2013-08-28 15:29:59 --> Router Class Initialized
ERROR - 2013-08-28 15:29:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:30:03 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:03 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:03 --> Router Class Initialized
DEBUG - 2013-08-28 15:30:03 --> Output Class Initialized
DEBUG - 2013-08-28 15:30:03 --> Security Class Initialized
DEBUG - 2013-08-28 15:30:04 --> Input Class Initialized
DEBUG - 2013-08-28 15:30:04 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:30:04 --> Language Class Initialized
DEBUG - 2013-08-28 15:30:04 --> Loader Class Initialized
DEBUG - 2013-08-28 15:30:04 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:30:04 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:30:04 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:30:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:30:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:30:04 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:30:04 --> Session Class Initialized
DEBUG - 2013-08-28 15:30:04 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:30:04 --> Session routines successfully run
DEBUG - 2013-08-28 15:30:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:30:04 --> Controller Class Initialized
ERROR - 2013-08-28 15:30:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:04 --> Model Class Initialized
DEBUG - 2013-08-28 15:30:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:30:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:30:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:30:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:30:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:30:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:30:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:30:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:30:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:30:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:30:05 --> File loaded: application/views/jurusans/edit.php
DEBUG - 2013-08-28 15:30:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:30:05 --> Final output sent to browser
DEBUG - 2013-08-28 15:30:05 --> Total execution time: 1.7861
DEBUG - 2013-08-28 15:30:05 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:05 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:05 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:05 --> Router Class Initialized
ERROR - 2013-08-28 15:30:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:30:08 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:08 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:08 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:08 --> Router Class Initialized
DEBUG - 2013-08-28 15:30:08 --> Output Class Initialized
DEBUG - 2013-08-28 15:30:08 --> Security Class Initialized
DEBUG - 2013-08-28 15:30:08 --> Input Class Initialized
DEBUG - 2013-08-28 15:30:08 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:08 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:08 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:30:09 --> Language Class Initialized
DEBUG - 2013-08-28 15:30:09 --> Loader Class Initialized
DEBUG - 2013-08-28 15:30:09 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:30:09 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:30:09 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:30:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:30:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:30:09 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:30:09 --> Session Class Initialized
DEBUG - 2013-08-28 15:30:09 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:30:09 --> Session routines successfully run
DEBUG - 2013-08-28 15:30:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:30:09 --> Controller Class Initialized
ERROR - 2013-08-28 15:30:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:09 --> Model Class Initialized
DEBUG - 2013-08-28 15:30:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:30:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:30:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:30:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:30:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:10 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:30:10 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:30:10 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:10 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:10 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:10 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:10 --> Router Class Initialized
DEBUG - 2013-08-28 15:30:10 --> Output Class Initialized
DEBUG - 2013-08-28 15:30:10 --> Security Class Initialized
DEBUG - 2013-08-28 15:30:10 --> Input Class Initialized
DEBUG - 2013-08-28 15:30:10 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:30:10 --> Language Class Initialized
DEBUG - 2013-08-28 15:30:10 --> Loader Class Initialized
DEBUG - 2013-08-28 15:30:10 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:30:10 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:30:10 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:30:10 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:30:10 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:30:10 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:30:11 --> Session Class Initialized
DEBUG - 2013-08-28 15:30:11 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:30:11 --> Session routines successfully run
DEBUG - 2013-08-28 15:30:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:30:11 --> Controller Class Initialized
ERROR - 2013-08-28 15:30:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:11 --> Model Class Initialized
DEBUG - 2013-08-28 15:30:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:30:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:30:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:30:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:30:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:30:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:30:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:30:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:30:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:30:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:30:11 --> File loaded: application/views/jurusans/edit.php
DEBUG - 2013-08-28 15:30:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:30:12 --> Final output sent to browser
DEBUG - 2013-08-28 15:30:12 --> Total execution time: 1.7981
DEBUG - 2013-08-28 15:30:12 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:12 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:12 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:12 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:12 --> Router Class Initialized
ERROR - 2013-08-28 15:30:12 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:30:14 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:15 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Router Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Output Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Security Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Input Class Initialized
DEBUG - 2013-08-28 15:30:15 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:30:15 --> Language Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Loader Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:30:15 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:30:15 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:30:15 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:30:15 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:30:15 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Session Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:30:15 --> Session routines successfully run
DEBUG - 2013-08-28 15:30:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:30:15 --> Controller Class Initialized
ERROR - 2013-08-28 15:30:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:16 --> Model Class Initialized
DEBUG - 2013-08-28 15:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:30:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:30:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:30:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:30:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:30:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:30:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:30:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:30:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:30:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:30:16 --> File loaded: application/views/jurusans/show.php
DEBUG - 2013-08-28 15:30:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:30:16 --> Final output sent to browser
DEBUG - 2013-08-28 15:30:16 --> Total execution time: 1.8031
DEBUG - 2013-08-28 15:30:16 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:17 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:17 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:17 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:17 --> Router Class Initialized
ERROR - 2013-08-28 15:30:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:30:24 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:24 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Router Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Output Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Security Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Input Class Initialized
DEBUG - 2013-08-28 15:30:24 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:30:24 --> Language Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Loader Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:30:24 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:30:24 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:30:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:30:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:30:24 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Session Class Initialized
DEBUG - 2013-08-28 15:30:24 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:30:24 --> Session routines successfully run
DEBUG - 2013-08-28 15:30:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:30:25 --> Controller Class Initialized
ERROR - 2013-08-28 15:30:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:25 --> Model Class Initialized
DEBUG - 2013-08-28 15:30:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:30:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:30:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:30:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:30:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:25 --> Pagination Class Initialized
DEBUG - 2013-08-28 15:30:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:30:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:30:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:30:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:30:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:30:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:30:25 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 15:30:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:30:25 --> Final output sent to browser
DEBUG - 2013-08-28 15:30:25 --> Total execution time: 1.7871
DEBUG - 2013-08-28 15:30:26 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:26 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:26 --> Router Class Initialized
ERROR - 2013-08-28 15:30:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:30:28 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:29 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:29 --> Router Class Initialized
DEBUG - 2013-08-28 15:30:29 --> Output Class Initialized
DEBUG - 2013-08-28 15:30:29 --> Security Class Initialized
DEBUG - 2013-08-28 15:30:29 --> Input Class Initialized
DEBUG - 2013-08-28 15:30:29 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:30:29 --> Language Class Initialized
DEBUG - 2013-08-28 15:30:29 --> Loader Class Initialized
DEBUG - 2013-08-28 15:30:29 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:30:29 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:30:29 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:30:29 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:30:29 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:30:29 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:30:29 --> Session Class Initialized
DEBUG - 2013-08-28 15:30:29 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:30:29 --> Session routines successfully run
DEBUG - 2013-08-28 15:30:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:30:29 --> Controller Class Initialized
ERROR - 2013-08-28 15:30:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:29 --> Model Class Initialized
DEBUG - 2013-08-28 15:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:30:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:30:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:30:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:30:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:30:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:30:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:30:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:30:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:30:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:30:30 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 15:30:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:30:30 --> Final output sent to browser
DEBUG - 2013-08-28 15:30:30 --> Total execution time: 1.7541
DEBUG - 2013-08-28 15:30:30 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:30 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:30 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:31 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:31 --> Router Class Initialized
ERROR - 2013-08-28 15:30:31 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 15:30:32 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:32 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:32 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:32 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:32 --> Router Class Initialized
DEBUG - 2013-08-28 15:30:32 --> Output Class Initialized
DEBUG - 2013-08-28 15:30:32 --> Security Class Initialized
DEBUG - 2013-08-28 15:30:32 --> Input Class Initialized
DEBUG - 2013-08-28 15:30:33 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:33 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:33 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:30:33 --> Language Class Initialized
DEBUG - 2013-08-28 15:30:33 --> Loader Class Initialized
DEBUG - 2013-08-28 15:30:33 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:30:33 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:30:33 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:30:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:30:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:30:33 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:30:33 --> Session Class Initialized
DEBUG - 2013-08-28 15:30:33 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:30:33 --> Session routines successfully run
DEBUG - 2013-08-28 15:30:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:30:33 --> Controller Class Initialized
ERROR - 2013-08-28 15:30:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:33 --> Model Class Initialized
DEBUG - 2013-08-28 15:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:30:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:30:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:30:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:30:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:34 --> Form Validation Class Initialized
DEBUG - 2013-08-28 15:30:34 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:34 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 15:30:34 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:34 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:34 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:34 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:34 --> Router Class Initialized
DEBUG - 2013-08-28 15:30:34 --> Output Class Initialized
DEBUG - 2013-08-28 15:30:34 --> Security Class Initialized
DEBUG - 2013-08-28 15:30:34 --> Input Class Initialized
DEBUG - 2013-08-28 15:30:34 --> XSS Filtering completed
DEBUG - 2013-08-28 15:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 15:30:34 --> Language Class Initialized
DEBUG - 2013-08-28 15:30:34 --> Loader Class Initialized
DEBUG - 2013-08-28 15:30:34 --> Helper loaded: url_helper
DEBUG - 2013-08-28 15:30:34 --> Helper loaded: file_helper
DEBUG - 2013-08-28 15:30:34 --> Helper loaded: form_helper
DEBUG - 2013-08-28 15:30:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 15:30:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 15:30:35 --> Database Driver Class Initialized
DEBUG - 2013-08-28 15:30:35 --> Session Class Initialized
DEBUG - 2013-08-28 15:30:35 --> Helper loaded: string_helper
DEBUG - 2013-08-28 15:30:35 --> Session routines successfully run
DEBUG - 2013-08-28 15:30:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 15:30:35 --> Controller Class Initialized
ERROR - 2013-08-28 15:30:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:35 --> Model Class Initialized
DEBUG - 2013-08-28 15:30:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 15:30:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 15:30:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 15:30:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 15:30:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 15:30:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 15:30:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 15:30:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 15:30:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 15:30:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 15:30:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 15:30:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 15:30:35 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 15:30:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 15:30:36 --> Final output sent to browser
DEBUG - 2013-08-28 15:30:36 --> Total execution time: 1.7551
DEBUG - 2013-08-28 15:30:36 --> Config Class Initialized
DEBUG - 2013-08-28 15:30:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 15:30:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 15:30:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 15:30:36 --> URI Class Initialized
DEBUG - 2013-08-28 15:30:36 --> Router Class Initialized
ERROR - 2013-08-28 15:30:36 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:09:15 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:15 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:15 --> Router Class Initialized
DEBUG - 2013-08-28 16:09:15 --> Output Class Initialized
DEBUG - 2013-08-28 16:09:15 --> Security Class Initialized
DEBUG - 2013-08-28 16:09:15 --> Input Class Initialized
DEBUG - 2013-08-28 16:09:15 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:09:15 --> Language Class Initialized
DEBUG - 2013-08-28 16:09:16 --> Loader Class Initialized
DEBUG - 2013-08-28 16:09:16 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:09:16 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:09:16 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:09:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:09:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:09:16 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:09:16 --> Session Class Initialized
DEBUG - 2013-08-28 16:09:16 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:09:16 --> Session routines successfully run
DEBUG - 2013-08-28 16:09:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:09:16 --> Controller Class Initialized
ERROR - 2013-08-28 16:09:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:16 --> Model Class Initialized
DEBUG - 2013-08-28 16:09:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:09:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:09:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:09:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:09:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:09:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:09:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:09:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:09:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:09:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:09:17 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:09:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:09:17 --> Final output sent to browser
DEBUG - 2013-08-28 16:09:17 --> Total execution time: 1.8461
DEBUG - 2013-08-28 16:09:17 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:17 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:17 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:17 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:17 --> Router Class Initialized
ERROR - 2013-08-28 16:09:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:09:23 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:23 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:23 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:23 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:23 --> Router Class Initialized
DEBUG - 2013-08-28 16:09:23 --> Output Class Initialized
DEBUG - 2013-08-28 16:09:23 --> Security Class Initialized
DEBUG - 2013-08-28 16:09:23 --> Input Class Initialized
DEBUG - 2013-08-28 16:09:23 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:09:23 --> Language Class Initialized
DEBUG - 2013-08-28 16:09:23 --> Loader Class Initialized
DEBUG - 2013-08-28 16:09:23 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:09:24 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:09:24 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:09:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:09:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:09:24 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:09:24 --> Session Class Initialized
DEBUG - 2013-08-28 16:09:24 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:09:24 --> Session routines successfully run
DEBUG - 2013-08-28 16:09:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:09:24 --> Controller Class Initialized
ERROR - 2013-08-28 16:09:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:24 --> Model Class Initialized
DEBUG - 2013-08-28 16:09:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:09:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:09:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:09:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:09:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:09:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:09:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:09:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:09:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:09:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:09:25 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-28 16:09:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:09:25 --> Final output sent to browser
DEBUG - 2013-08-28 16:09:25 --> Total execution time: 1.7251
DEBUG - 2013-08-28 16:09:25 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:25 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:25 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:25 --> Router Class Initialized
ERROR - 2013-08-28 16:09:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:09:30 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:30 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:30 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:30 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:30 --> Router Class Initialized
DEBUG - 2013-08-28 16:09:30 --> Output Class Initialized
DEBUG - 2013-08-28 16:09:30 --> Security Class Initialized
DEBUG - 2013-08-28 16:09:30 --> Input Class Initialized
DEBUG - 2013-08-28 16:09:30 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:30 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:31 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:31 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:09:31 --> Language Class Initialized
DEBUG - 2013-08-28 16:09:31 --> Loader Class Initialized
DEBUG - 2013-08-28 16:09:31 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:09:31 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:09:31 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:09:31 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:09:31 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:09:31 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:09:31 --> Session Class Initialized
DEBUG - 2013-08-28 16:09:31 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:09:31 --> Session routines successfully run
DEBUG - 2013-08-28 16:09:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:09:31 --> Controller Class Initialized
ERROR - 2013-08-28 16:09:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:31 --> Model Class Initialized
DEBUG - 2013-08-28 16:09:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:09:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:09:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:09:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:09:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:32 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:09:32 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:32 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 16:09:32 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:32 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:32 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:32 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:32 --> Router Class Initialized
DEBUG - 2013-08-28 16:09:32 --> Output Class Initialized
DEBUG - 2013-08-28 16:09:32 --> Security Class Initialized
DEBUG - 2013-08-28 16:09:32 --> Input Class Initialized
DEBUG - 2013-08-28 16:09:32 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:09:32 --> Language Class Initialized
DEBUG - 2013-08-28 16:09:33 --> Loader Class Initialized
DEBUG - 2013-08-28 16:09:33 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:09:33 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:09:33 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:09:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:09:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:09:33 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:09:33 --> Session Class Initialized
DEBUG - 2013-08-28 16:09:33 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:09:33 --> Session routines successfully run
DEBUG - 2013-08-28 16:09:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:09:33 --> Controller Class Initialized
ERROR - 2013-08-28 16:09:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:33 --> Model Class Initialized
DEBUG - 2013-08-28 16:09:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:09:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:09:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:09:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:09:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:09:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:09:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:09:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:09:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:09:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:09:34 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 16:09:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:09:34 --> Final output sent to browser
DEBUG - 2013-08-28 16:09:34 --> Total execution time: 1.8701
DEBUG - 2013-08-28 16:09:34 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:34 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:34 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:34 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:34 --> Router Class Initialized
ERROR - 2013-08-28 16:09:34 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:09:37 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:37 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:38 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Router Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Output Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Security Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Input Class Initialized
DEBUG - 2013-08-28 16:09:38 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:09:38 --> Language Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Loader Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:09:38 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:09:38 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:09:38 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:09:38 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:09:38 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Session Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:09:38 --> Session routines successfully run
DEBUG - 2013-08-28 16:09:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:09:38 --> Controller Class Initialized
ERROR - 2013-08-28 16:09:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:39 --> Model Class Initialized
DEBUG - 2013-08-28 16:09:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:09:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:09:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:09:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:09:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:09:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:09:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:09:39 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:09:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:09:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:09:39 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:09:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:09:39 --> Final output sent to browser
DEBUG - 2013-08-28 16:09:39 --> Total execution time: 1.8041
DEBUG - 2013-08-28 16:09:39 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:39 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:39 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:40 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:40 --> Router Class Initialized
ERROR - 2013-08-28 16:09:40 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:09:44 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:44 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Router Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Output Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Security Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Input Class Initialized
DEBUG - 2013-08-28 16:09:44 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:09:44 --> Language Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Loader Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:09:44 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:09:44 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:09:44 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:09:44 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:09:44 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Session Class Initialized
DEBUG - 2013-08-28 16:09:44 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:09:44 --> Session routines successfully run
DEBUG - 2013-08-28 16:09:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:09:45 --> Controller Class Initialized
ERROR - 2013-08-28 16:09:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:45 --> Model Class Initialized
DEBUG - 2013-08-28 16:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:09:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:09:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:09:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:09:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:09:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:09:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:09:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:09:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:09:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:09:45 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-28 16:09:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:09:45 --> Final output sent to browser
DEBUG - 2013-08-28 16:09:45 --> Total execution time: 1.7951
DEBUG - 2013-08-28 16:09:46 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:46 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:46 --> Router Class Initialized
ERROR - 2013-08-28 16:09:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:09:50 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:50 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:50 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:50 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:50 --> Router Class Initialized
DEBUG - 2013-08-28 16:09:50 --> Output Class Initialized
DEBUG - 2013-08-28 16:09:50 --> Security Class Initialized
DEBUG - 2013-08-28 16:09:50 --> Input Class Initialized
DEBUG - 2013-08-28 16:09:50 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:50 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:50 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:50 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:09:50 --> Language Class Initialized
DEBUG - 2013-08-28 16:09:50 --> Loader Class Initialized
DEBUG - 2013-08-28 16:09:50 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:09:50 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:09:50 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:09:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:09:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:09:51 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:09:51 --> Session Class Initialized
DEBUG - 2013-08-28 16:09:51 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:09:51 --> Session routines successfully run
DEBUG - 2013-08-28 16:09:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:09:51 --> Controller Class Initialized
ERROR - 2013-08-28 16:09:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:51 --> Model Class Initialized
DEBUG - 2013-08-28 16:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:09:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:09:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:09:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:09:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:51 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:09:51 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:51 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 16:09:51 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:52 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Router Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Output Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Security Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Input Class Initialized
DEBUG - 2013-08-28 16:09:52 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:09:52 --> Language Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Loader Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:09:52 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:09:52 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:09:52 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:09:52 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:09:52 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Session Class Initialized
DEBUG - 2013-08-28 16:09:52 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:09:53 --> Session routines successfully run
DEBUG - 2013-08-28 16:09:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:09:53 --> Controller Class Initialized
ERROR - 2013-08-28 16:09:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:53 --> Model Class Initialized
DEBUG - 2013-08-28 16:09:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:09:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:09:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:09:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:09:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:09:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:09:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:09:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:09:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:09:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:09:53 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 16:09:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:09:53 --> Final output sent to browser
DEBUG - 2013-08-28 16:09:53 --> Total execution time: 1.9751
DEBUG - 2013-08-28 16:09:54 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:54 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:54 --> Router Class Initialized
ERROR - 2013-08-28 16:09:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:09:57 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:57 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:57 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:57 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:57 --> Router Class Initialized
DEBUG - 2013-08-28 16:09:57 --> Output Class Initialized
DEBUG - 2013-08-28 16:09:57 --> Security Class Initialized
DEBUG - 2013-08-28 16:09:57 --> Input Class Initialized
DEBUG - 2013-08-28 16:09:57 --> XSS Filtering completed
DEBUG - 2013-08-28 16:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:09:57 --> Language Class Initialized
DEBUG - 2013-08-28 16:09:57 --> Loader Class Initialized
DEBUG - 2013-08-28 16:09:57 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:09:57 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:09:57 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:09:57 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:09:57 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:09:58 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:09:58 --> Session Class Initialized
DEBUG - 2013-08-28 16:09:58 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:09:58 --> Session routines successfully run
DEBUG - 2013-08-28 16:09:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:09:58 --> Controller Class Initialized
ERROR - 2013-08-28 16:09:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:58 --> Model Class Initialized
DEBUG - 2013-08-28 16:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:09:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:09:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:09:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:09:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:09:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:09:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:09:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:09:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:09:58 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:09:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:09:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:09:59 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:09:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:09:59 --> Final output sent to browser
DEBUG - 2013-08-28 16:09:59 --> Total execution time: 1.9431
DEBUG - 2013-08-28 16:09:59 --> Config Class Initialized
DEBUG - 2013-08-28 16:09:59 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:09:59 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:09:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:09:59 --> URI Class Initialized
DEBUG - 2013-08-28 16:09:59 --> Router Class Initialized
ERROR - 2013-08-28 16:09:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:10:10 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:10 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:10 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:10 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:10 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:10 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:10 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:10 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:10 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:10 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:10 --> Session garbage collection performed.
DEBUG - 2013-08-28 16:10:10 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:11 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:11 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:10:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:10:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:10:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:10:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:10:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:10:11 --> File loaded: application/views/kelas_bagians/new.php
DEBUG - 2013-08-28 16:10:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:10:11 --> Final output sent to browser
DEBUG - 2013-08-28 16:10:11 --> Total execution time: 1.8051
DEBUG - 2013-08-28 16:10:12 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:12 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:12 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:12 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:12 --> Router Class Initialized
ERROR - 2013-08-28 16:10:12 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:10:15 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:15 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:15 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:15 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:15 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:15 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:15 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:15 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:15 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:15 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:15 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:15 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:15 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:16 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:16 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:16 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:16 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:16 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:16 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:16 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:16 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:16 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:16 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:16 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:10:16 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:16 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 16:10:17 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:17 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:17 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:17 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:17 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:17 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:17 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:17 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:17 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:17 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:17 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:17 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:17 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:17 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:17 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:17 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:17 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:17 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:18 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:18 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:18 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:18 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:10:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:10:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:10:18 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:10:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:10:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:10:18 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 16:10:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:10:19 --> Final output sent to browser
DEBUG - 2013-08-28 16:10:19 --> Total execution time: 1.9501
DEBUG - 2013-08-28 16:10:19 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:19 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:19 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:19 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:19 --> Router Class Initialized
ERROR - 2013-08-28 16:10:19 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:10:21 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:22 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:22 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:22 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:22 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:22 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:22 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:22 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:22 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:22 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:22 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:23 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:10:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:10:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:10:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:10:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:10:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:10:23 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:10:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:10:23 --> Final output sent to browser
DEBUG - 2013-08-28 16:10:23 --> Total execution time: 1.8481
DEBUG - 2013-08-28 16:10:23 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:24 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:24 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:24 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:24 --> Router Class Initialized
ERROR - 2013-08-28 16:10:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:10:26 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:27 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:27 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:27 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:27 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:27 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:27 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:27 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:27 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:27 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:27 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:27 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:27 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:27 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:27 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:27 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:27 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:27 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:27 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:27 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:10:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:10:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:10:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:10:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:10:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:10:28 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 16:10:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:10:28 --> Final output sent to browser
DEBUG - 2013-08-28 16:10:28 --> Total execution time: 1.8941
DEBUG - 2013-08-28 16:10:28 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:29 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:29 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:29 --> Router Class Initialized
ERROR - 2013-08-28 16:10:29 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:10:32 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:32 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:33 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:33 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:33 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:33 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:33 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:33 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:33 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:33 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:33 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:33 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:33 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:33 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:33 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:33 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:33 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:33 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:33 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:33 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:33 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:33 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:33 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:34 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:34 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:34 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:10:34 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:34 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-28 16:10:34 --> Severity: Notice  --> Undefined variable: kelas_tingkat C:\xampp\htdocs\school\application\controllers\guru\kelas_bagians.php 160
DEBUG - 2013-08-28 16:10:34 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:35 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:35 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:35 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:35 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:35 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:35 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:35 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:35 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:36 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:10:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:10:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:10:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:10:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:10:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:10:36 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 16:10:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:10:36 --> Final output sent to browser
DEBUG - 2013-08-28 16:10:36 --> Total execution time: 1.9231
DEBUG - 2013-08-28 16:10:37 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:37 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:37 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:37 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:37 --> Router Class Initialized
ERROR - 2013-08-28 16:10:37 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:10:40 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:40 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:40 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:40 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:40 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:40 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:40 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:40 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:40 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:40 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:40 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:40 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:40 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:40 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:40 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:41 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:41 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:41 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:41 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:41 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:41 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:41 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:41 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:41 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:41 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:41 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:10:42 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:42 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 16:10:42 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:42 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:42 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:42 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:42 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:42 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:42 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:42 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:42 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:42 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:42 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:42 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:42 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:42 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:42 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:43 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:43 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:43 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:43 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:10:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:10:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:10:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:10:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:10:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:10:44 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 16:10:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:10:44 --> Final output sent to browser
DEBUG - 2013-08-28 16:10:44 --> Total execution time: 1.9261
DEBUG - 2013-08-28 16:10:44 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:44 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:44 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:44 --> Router Class Initialized
ERROR - 2013-08-28 16:10:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:10:46 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:47 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:47 --> Router Class Initialized
DEBUG - 2013-08-28 16:10:47 --> Output Class Initialized
DEBUG - 2013-08-28 16:10:47 --> Security Class Initialized
DEBUG - 2013-08-28 16:10:47 --> Input Class Initialized
DEBUG - 2013-08-28 16:10:47 --> XSS Filtering completed
DEBUG - 2013-08-28 16:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:10:47 --> Language Class Initialized
DEBUG - 2013-08-28 16:10:47 --> Loader Class Initialized
DEBUG - 2013-08-28 16:10:47 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:10:47 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:10:47 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:10:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:10:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:10:47 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:10:47 --> Session Class Initialized
DEBUG - 2013-08-28 16:10:47 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:10:47 --> Session routines successfully run
DEBUG - 2013-08-28 16:10:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:10:47 --> Controller Class Initialized
ERROR - 2013-08-28 16:10:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:48 --> Model Class Initialized
DEBUG - 2013-08-28 16:10:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:10:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:10:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:10:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:10:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:10:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:10:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:10:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:10:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:10:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:10:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:10:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:10:48 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:10:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:10:48 --> Final output sent to browser
DEBUG - 2013-08-28 16:10:48 --> Total execution time: 1.9501
DEBUG - 2013-08-28 16:10:49 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:49 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:49 --> Router Class Initialized
ERROR - 2013-08-28 16:10:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:10:54 --> Config Class Initialized
DEBUG - 2013-08-28 16:10:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:10:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:10:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:10:54 --> URI Class Initialized
DEBUG - 2013-08-28 16:10:55 --> Router Class Initialized
ERROR - 2013-08-28 16:10:55 --> 404 Page Not Found --> kelasbagians
DEBUG - 2013-08-28 16:11:03 --> Config Class Initialized
DEBUG - 2013-08-28 16:11:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:11:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:11:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:11:03 --> URI Class Initialized
DEBUG - 2013-08-28 16:11:03 --> Router Class Initialized
DEBUG - 2013-08-28 16:11:03 --> Output Class Initialized
DEBUG - 2013-08-28 16:11:03 --> Security Class Initialized
DEBUG - 2013-08-28 16:11:03 --> Input Class Initialized
DEBUG - 2013-08-28 16:11:03 --> XSS Filtering completed
DEBUG - 2013-08-28 16:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:11:03 --> Language Class Initialized
DEBUG - 2013-08-28 16:11:03 --> Loader Class Initialized
DEBUG - 2013-08-28 16:11:03 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:11:03 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:11:03 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:11:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:11:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:11:03 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:11:04 --> Session Class Initialized
DEBUG - 2013-08-28 16:11:04 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:11:04 --> Session routines successfully run
DEBUG - 2013-08-28 16:11:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:11:04 --> Controller Class Initialized
ERROR - 2013-08-28 16:11:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:11:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:11:04 --> Model Class Initialized
DEBUG - 2013-08-28 16:11:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:11:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:11:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:11:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:11:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:11:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:11:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:11:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:11:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:11:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:11:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:11:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:11:05 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:11:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:11:05 --> Final output sent to browser
DEBUG - 2013-08-28 16:11:05 --> Total execution time: 1.9481
DEBUG - 2013-08-28 16:11:05 --> Config Class Initialized
DEBUG - 2013-08-28 16:11:05 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:11:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:11:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:11:05 --> URI Class Initialized
DEBUG - 2013-08-28 16:11:05 --> Router Class Initialized
ERROR - 2013-08-28 16:11:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:12:18 --> Config Class Initialized
DEBUG - 2013-08-28 16:12:18 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:12:18 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:12:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:12:19 --> URI Class Initialized
DEBUG - 2013-08-28 16:12:19 --> Router Class Initialized
DEBUG - 2013-08-28 16:12:19 --> Output Class Initialized
DEBUG - 2013-08-28 16:12:19 --> Security Class Initialized
DEBUG - 2013-08-28 16:12:19 --> Input Class Initialized
DEBUG - 2013-08-28 16:12:19 --> XSS Filtering completed
DEBUG - 2013-08-28 16:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:12:19 --> Language Class Initialized
DEBUG - 2013-08-28 16:12:19 --> Loader Class Initialized
DEBUG - 2013-08-28 16:12:19 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:12:19 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:12:19 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:12:19 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:12:19 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:12:19 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:12:19 --> Session Class Initialized
DEBUG - 2013-08-28 16:12:19 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:12:19 --> Session routines successfully run
DEBUG - 2013-08-28 16:12:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:12:19 --> Controller Class Initialized
ERROR - 2013-08-28 16:12:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:20 --> Model Class Initialized
DEBUG - 2013-08-28 16:12:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:12:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:12:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:12:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:12:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:20 --> Config Class Initialized
DEBUG - 2013-08-28 16:12:20 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:12:20 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:12:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:12:20 --> URI Class Initialized
DEBUG - 2013-08-28 16:12:20 --> Router Class Initialized
DEBUG - 2013-08-28 16:12:20 --> Output Class Initialized
DEBUG - 2013-08-28 16:12:20 --> Security Class Initialized
DEBUG - 2013-08-28 16:12:20 --> Input Class Initialized
DEBUG - 2013-08-28 16:12:20 --> XSS Filtering completed
DEBUG - 2013-08-28 16:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:12:20 --> Language Class Initialized
DEBUG - 2013-08-28 16:12:21 --> Loader Class Initialized
DEBUG - 2013-08-28 16:12:21 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:12:21 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:12:21 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:12:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:12:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:12:21 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:12:21 --> Session Class Initialized
DEBUG - 2013-08-28 16:12:21 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:12:21 --> Session routines successfully run
DEBUG - 2013-08-28 16:12:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:12:21 --> Controller Class Initialized
ERROR - 2013-08-28 16:12:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:21 --> Model Class Initialized
DEBUG - 2013-08-28 16:12:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:12:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:12:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:12:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:12:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:12:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:12:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:12:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:12:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:12:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:12:22 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 16:12:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:12:22 --> Final output sent to browser
DEBUG - 2013-08-28 16:12:22 --> Total execution time: 2.0591
DEBUG - 2013-08-28 16:12:22 --> Config Class Initialized
DEBUG - 2013-08-28 16:12:22 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:12:22 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:12:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:12:22 --> URI Class Initialized
DEBUG - 2013-08-28 16:12:22 --> Router Class Initialized
ERROR - 2013-08-28 16:12:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:12:47 --> Config Class Initialized
DEBUG - 2013-08-28 16:12:47 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:12:47 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:12:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:12:47 --> URI Class Initialized
DEBUG - 2013-08-28 16:12:47 --> Router Class Initialized
DEBUG - 2013-08-28 16:12:47 --> Output Class Initialized
DEBUG - 2013-08-28 16:12:47 --> Security Class Initialized
DEBUG - 2013-08-28 16:12:47 --> Input Class Initialized
DEBUG - 2013-08-28 16:12:47 --> XSS Filtering completed
DEBUG - 2013-08-28 16:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:12:47 --> Language Class Initialized
DEBUG - 2013-08-28 16:12:48 --> Loader Class Initialized
DEBUG - 2013-08-28 16:12:48 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:12:48 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:12:48 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:12:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:12:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:12:48 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:12:48 --> Session Class Initialized
DEBUG - 2013-08-28 16:12:48 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:12:48 --> Session routines successfully run
DEBUG - 2013-08-28 16:12:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:12:48 --> Controller Class Initialized
ERROR - 2013-08-28 16:12:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:48 --> Model Class Initialized
DEBUG - 2013-08-28 16:12:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:12:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:12:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:12:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:12:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:12:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:12:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:12:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:12:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:12:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:12:49 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:12:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:12:49 --> Final output sent to browser
DEBUG - 2013-08-28 16:12:49 --> Total execution time: 1.9581
DEBUG - 2013-08-28 16:12:49 --> Config Class Initialized
DEBUG - 2013-08-28 16:12:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:12:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:12:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:12:49 --> URI Class Initialized
DEBUG - 2013-08-28 16:12:49 --> Router Class Initialized
ERROR - 2013-08-28 16:12:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:12:53 --> Config Class Initialized
DEBUG - 2013-08-28 16:12:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:12:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:12:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:12:53 --> URI Class Initialized
DEBUG - 2013-08-28 16:12:53 --> Router Class Initialized
DEBUG - 2013-08-28 16:12:53 --> Output Class Initialized
DEBUG - 2013-08-28 16:12:53 --> Security Class Initialized
DEBUG - 2013-08-28 16:12:53 --> Input Class Initialized
DEBUG - 2013-08-28 16:12:53 --> XSS Filtering completed
DEBUG - 2013-08-28 16:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:12:53 --> Language Class Initialized
DEBUG - 2013-08-28 16:12:53 --> Loader Class Initialized
DEBUG - 2013-08-28 16:12:53 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:12:53 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:12:53 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:12:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:12:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:12:53 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:12:53 --> Session Class Initialized
DEBUG - 2013-08-28 16:12:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:12:54 --> Session routines successfully run
DEBUG - 2013-08-28 16:12:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:12:54 --> Controller Class Initialized
ERROR - 2013-08-28 16:12:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:54 --> Model Class Initialized
DEBUG - 2013-08-28 16:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:12:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:12:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:12:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:12:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:54 --> Config Class Initialized
DEBUG - 2013-08-28 16:12:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:12:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:12:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:12:54 --> URI Class Initialized
DEBUG - 2013-08-28 16:12:55 --> Router Class Initialized
DEBUG - 2013-08-28 16:12:55 --> Output Class Initialized
DEBUG - 2013-08-28 16:12:55 --> Security Class Initialized
DEBUG - 2013-08-28 16:12:55 --> Input Class Initialized
DEBUG - 2013-08-28 16:12:55 --> XSS Filtering completed
DEBUG - 2013-08-28 16:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:12:55 --> Language Class Initialized
DEBUG - 2013-08-28 16:12:55 --> Loader Class Initialized
DEBUG - 2013-08-28 16:12:55 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:12:55 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:12:55 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:12:55 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:12:55 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:12:55 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:12:55 --> Session Class Initialized
DEBUG - 2013-08-28 16:12:55 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:12:55 --> Session routines successfully run
DEBUG - 2013-08-28 16:12:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:12:55 --> Controller Class Initialized
ERROR - 2013-08-28 16:12:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:55 --> Model Class Initialized
DEBUG - 2013-08-28 16:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:12:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:12:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:12:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:12:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:12:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:12:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:12:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:12:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:12:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:12:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:12:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:12:56 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 16:12:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:12:56 --> Final output sent to browser
DEBUG - 2013-08-28 16:12:56 --> Total execution time: 2.1271
DEBUG - 2013-08-28 16:12:57 --> Config Class Initialized
DEBUG - 2013-08-28 16:12:57 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:12:57 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:12:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:12:57 --> URI Class Initialized
DEBUG - 2013-08-28 16:12:57 --> Router Class Initialized
ERROR - 2013-08-28 16:12:57 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:12:59 --> Config Class Initialized
DEBUG - 2013-08-28 16:12:59 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:12:59 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:12:59 --> URI Class Initialized
DEBUG - 2013-08-28 16:12:59 --> Router Class Initialized
DEBUG - 2013-08-28 16:12:59 --> Output Class Initialized
DEBUG - 2013-08-28 16:12:59 --> Security Class Initialized
DEBUG - 2013-08-28 16:12:59 --> Input Class Initialized
DEBUG - 2013-08-28 16:12:59 --> XSS Filtering completed
DEBUG - 2013-08-28 16:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:12:59 --> Language Class Initialized
DEBUG - 2013-08-28 16:12:59 --> Loader Class Initialized
DEBUG - 2013-08-28 16:12:59 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:12:59 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:12:59 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:12:59 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:12:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:13:00 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:13:00 --> Session Class Initialized
DEBUG - 2013-08-28 16:13:00 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:13:00 --> Session routines successfully run
DEBUG - 2013-08-28 16:13:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:13:00 --> Controller Class Initialized
ERROR - 2013-08-28 16:13:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:00 --> Model Class Initialized
DEBUG - 2013-08-28 16:13:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:13:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:13:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:13:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:13:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:13:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:13:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:13:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:13:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:13:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:13:01 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:13:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:13:01 --> Final output sent to browser
DEBUG - 2013-08-28 16:13:01 --> Total execution time: 1.9401
DEBUG - 2013-08-28 16:13:01 --> Config Class Initialized
DEBUG - 2013-08-28 16:13:01 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:13:01 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:13:01 --> URI Class Initialized
DEBUG - 2013-08-28 16:13:01 --> Router Class Initialized
ERROR - 2013-08-28 16:13:01 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:13:06 --> Config Class Initialized
DEBUG - 2013-08-28 16:13:06 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:13:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:13:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:13:07 --> URI Class Initialized
DEBUG - 2013-08-28 16:13:07 --> Router Class Initialized
DEBUG - 2013-08-28 16:13:07 --> Output Class Initialized
DEBUG - 2013-08-28 16:13:07 --> Security Class Initialized
DEBUG - 2013-08-28 16:13:07 --> Input Class Initialized
DEBUG - 2013-08-28 16:13:07 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:07 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:07 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:07 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:13:07 --> Language Class Initialized
DEBUG - 2013-08-28 16:13:07 --> Loader Class Initialized
DEBUG - 2013-08-28 16:13:07 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:13:07 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:13:07 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:13:07 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:13:07 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:13:08 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:13:08 --> Session Class Initialized
DEBUG - 2013-08-28 16:13:08 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:13:08 --> Session routines successfully run
DEBUG - 2013-08-28 16:13:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:13:08 --> Controller Class Initialized
ERROR - 2013-08-28 16:13:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:08 --> Model Class Initialized
DEBUG - 2013-08-28 16:13:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:13:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:13:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:13:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:13:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:08 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:08 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:08 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:08 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:09 --> Config Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:13:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:13:09 --> URI Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Router Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Output Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Security Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Input Class Initialized
DEBUG - 2013-08-28 16:13:09 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:13:09 --> Language Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Loader Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:13:09 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:13:09 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:13:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:13:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:13:09 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Session Class Initialized
DEBUG - 2013-08-28 16:13:09 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:13:09 --> Session routines successfully run
DEBUG - 2013-08-28 16:13:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:13:10 --> Controller Class Initialized
ERROR - 2013-08-28 16:13:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:10 --> Model Class Initialized
DEBUG - 2013-08-28 16:13:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:13:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:13:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:13:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:13:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:13:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:13:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:13:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:13:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:13:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:13:10 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-28 16:13:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:13:10 --> Final output sent to browser
DEBUG - 2013-08-28 16:13:10 --> Total execution time: 1.9241
DEBUG - 2013-08-28 16:13:11 --> Config Class Initialized
DEBUG - 2013-08-28 16:13:11 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:13:11 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:13:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:13:11 --> URI Class Initialized
DEBUG - 2013-08-28 16:13:11 --> Router Class Initialized
ERROR - 2013-08-28 16:13:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:13:46 --> Config Class Initialized
DEBUG - 2013-08-28 16:13:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:13:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:13:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:13:46 --> URI Class Initialized
DEBUG - 2013-08-28 16:13:46 --> Router Class Initialized
DEBUG - 2013-08-28 16:13:46 --> Output Class Initialized
DEBUG - 2013-08-28 16:13:46 --> Security Class Initialized
DEBUG - 2013-08-28 16:13:46 --> Input Class Initialized
DEBUG - 2013-08-28 16:13:46 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:13:46 --> Language Class Initialized
DEBUG - 2013-08-28 16:13:46 --> Loader Class Initialized
DEBUG - 2013-08-28 16:13:47 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:13:47 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:13:47 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:13:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:13:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:13:47 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:13:47 --> Session Class Initialized
DEBUG - 2013-08-28 16:13:47 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:13:47 --> Session routines successfully run
DEBUG - 2013-08-28 16:13:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:13:47 --> Controller Class Initialized
ERROR - 2013-08-28 16:13:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:47 --> Model Class Initialized
DEBUG - 2013-08-28 16:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:13:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:13:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:13:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:13:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:47 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:13:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:13:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:13:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:13:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:13:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:13:48 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:13:48 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 16:13:48 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 16:13:48 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 16:13:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:13:48 --> Final output sent to browser
DEBUG - 2013-08-28 16:13:48 --> Total execution time: 2.0311
DEBUG - 2013-08-28 16:13:48 --> Config Class Initialized
DEBUG - 2013-08-28 16:13:48 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:13:48 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:13:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:13:48 --> URI Class Initialized
DEBUG - 2013-08-28 16:13:48 --> Router Class Initialized
ERROR - 2013-08-28 16:13:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:13:53 --> Config Class Initialized
DEBUG - 2013-08-28 16:13:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:13:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:13:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:13:53 --> URI Class Initialized
DEBUG - 2013-08-28 16:13:53 --> Router Class Initialized
DEBUG - 2013-08-28 16:13:53 --> Output Class Initialized
DEBUG - 2013-08-28 16:13:53 --> Security Class Initialized
DEBUG - 2013-08-28 16:13:53 --> Input Class Initialized
DEBUG - 2013-08-28 16:13:53 --> XSS Filtering completed
DEBUG - 2013-08-28 16:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:13:53 --> Language Class Initialized
DEBUG - 2013-08-28 16:13:53 --> Loader Class Initialized
DEBUG - 2013-08-28 16:13:53 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:13:53 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:13:54 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:13:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:13:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:13:54 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:13:54 --> Session Class Initialized
DEBUG - 2013-08-28 16:13:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:13:54 --> Session routines successfully run
DEBUG - 2013-08-28 16:13:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:13:54 --> Controller Class Initialized
ERROR - 2013-08-28 16:13:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:54 --> Model Class Initialized
DEBUG - 2013-08-28 16:13:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:13:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:13:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:13:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:13:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:13:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:13:54 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:13:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:13:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:13:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:13:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:13:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:13:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:13:55 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:13:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:13:55 --> Final output sent to browser
DEBUG - 2013-08-28 16:13:55 --> Total execution time: 2.0771
DEBUG - 2013-08-28 16:13:55 --> Config Class Initialized
DEBUG - 2013-08-28 16:13:55 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:13:55 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:13:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:13:55 --> URI Class Initialized
DEBUG - 2013-08-28 16:13:55 --> Router Class Initialized
ERROR - 2013-08-28 16:13:55 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:14:00 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:00 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:00 --> Router Class Initialized
DEBUG - 2013-08-28 16:14:01 --> Output Class Initialized
DEBUG - 2013-08-28 16:14:01 --> Security Class Initialized
DEBUG - 2013-08-28 16:14:01 --> Input Class Initialized
DEBUG - 2013-08-28 16:14:01 --> XSS Filtering completed
DEBUG - 2013-08-28 16:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:14:01 --> Language Class Initialized
DEBUG - 2013-08-28 16:14:01 --> Loader Class Initialized
DEBUG - 2013-08-28 16:14:01 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:14:01 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:14:01 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:14:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:14:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:14:01 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:14:01 --> Session Class Initialized
DEBUG - 2013-08-28 16:14:01 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:14:01 --> Session routines successfully run
DEBUG - 2013-08-28 16:14:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:14:01 --> Controller Class Initialized
ERROR - 2013-08-28 16:14:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:01 --> Model Class Initialized
DEBUG - 2013-08-28 16:14:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:14:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:14:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:14:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:14:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:02 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:14:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:14:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:14:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:14:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:14:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:14:02 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:14:02 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 16:14:02 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 16:14:02 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 16:14:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:14:02 --> Final output sent to browser
DEBUG - 2013-08-28 16:14:02 --> Total execution time: 2.0771
DEBUG - 2013-08-28 16:14:03 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:03 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:03 --> Router Class Initialized
ERROR - 2013-08-28 16:14:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:14:04 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:04 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:05 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:05 --> Router Class Initialized
DEBUG - 2013-08-28 16:14:05 --> Output Class Initialized
DEBUG - 2013-08-28 16:14:05 --> Security Class Initialized
DEBUG - 2013-08-28 16:14:05 --> Input Class Initialized
DEBUG - 2013-08-28 16:14:05 --> XSS Filtering completed
DEBUG - 2013-08-28 16:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:14:05 --> Language Class Initialized
DEBUG - 2013-08-28 16:14:05 --> Loader Class Initialized
DEBUG - 2013-08-28 16:14:05 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:14:05 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:14:05 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:14:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:14:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:14:05 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:14:05 --> Session Class Initialized
DEBUG - 2013-08-28 16:14:05 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:14:06 --> Session routines successfully run
DEBUG - 2013-08-28 16:14:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:14:06 --> Controller Class Initialized
ERROR - 2013-08-28 16:14:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:06 --> Model Class Initialized
DEBUG - 2013-08-28 16:14:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:14:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:14:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:14:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:14:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:06 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:14:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:14:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:14:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:14:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:14:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:14:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:14:06 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 16:14:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:14:07 --> Final output sent to browser
DEBUG - 2013-08-28 16:14:07 --> Total execution time: 2.1041
DEBUG - 2013-08-28 16:14:07 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:07 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:07 --> Router Class Initialized
ERROR - 2013-08-28 16:14:07 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:14:08 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:08 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:08 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:08 --> Router Class Initialized
DEBUG - 2013-08-28 16:14:09 --> Output Class Initialized
DEBUG - 2013-08-28 16:14:09 --> Security Class Initialized
DEBUG - 2013-08-28 16:14:09 --> Input Class Initialized
DEBUG - 2013-08-28 16:14:09 --> XSS Filtering completed
DEBUG - 2013-08-28 16:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:14:09 --> Language Class Initialized
DEBUG - 2013-08-28 16:14:09 --> Loader Class Initialized
DEBUG - 2013-08-28 16:14:09 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:14:09 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:14:09 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:14:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:14:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:14:09 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:14:09 --> Session Class Initialized
DEBUG - 2013-08-28 16:14:09 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:14:09 --> Session routines successfully run
DEBUG - 2013-08-28 16:14:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:14:09 --> Controller Class Initialized
ERROR - 2013-08-28 16:14:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:09 --> Model Class Initialized
DEBUG - 2013-08-28 16:14:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:14:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:14:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:14:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:14:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:10 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:14:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:14:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:14:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:14:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:14:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:14:10 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:14:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-28 16:14:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-28 16:14:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-28 16:14:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-28 16:14:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
DEBUG - 2013-08-28 16:14:10 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-28 16:14:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:14:10 --> Final output sent to browser
DEBUG - 2013-08-28 16:14:11 --> Total execution time: 2.3501
DEBUG - 2013-08-28 16:14:11 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:11 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:11 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:11 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:11 --> Router Class Initialized
ERROR - 2013-08-28 16:14:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:14:13 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:13 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:13 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:13 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:13 --> Router Class Initialized
DEBUG - 2013-08-28 16:14:13 --> Output Class Initialized
DEBUG - 2013-08-28 16:14:13 --> Security Class Initialized
DEBUG - 2013-08-28 16:14:13 --> Input Class Initialized
DEBUG - 2013-08-28 16:14:13 --> XSS Filtering completed
DEBUG - 2013-08-28 16:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:14:13 --> Language Class Initialized
DEBUG - 2013-08-28 16:14:13 --> Loader Class Initialized
DEBUG - 2013-08-28 16:14:14 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:14:14 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:14:14 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:14:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:14:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:14:14 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:14:14 --> Session Class Initialized
DEBUG - 2013-08-28 16:14:14 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:14:14 --> Session routines successfully run
DEBUG - 2013-08-28 16:14:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:14:14 --> Controller Class Initialized
ERROR - 2013-08-28 16:14:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:14 --> Model Class Initialized
DEBUG - 2013-08-28 16:14:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:14:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:14:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:14:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:14:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:14 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:14:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:14:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:14:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:14:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:14:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:14:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:14:15 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:14:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:14:15 --> Final output sent to browser
DEBUG - 2013-08-28 16:14:15 --> Total execution time: 1.9871
DEBUG - 2013-08-28 16:14:15 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:15 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:15 --> Router Class Initialized
ERROR - 2013-08-28 16:14:15 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:14:21 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:21 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:21 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:21 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:21 --> Router Class Initialized
DEBUG - 2013-08-28 16:14:21 --> Output Class Initialized
DEBUG - 2013-08-28 16:14:21 --> Security Class Initialized
DEBUG - 2013-08-28 16:14:21 --> Input Class Initialized
DEBUG - 2013-08-28 16:14:21 --> XSS Filtering completed
DEBUG - 2013-08-28 16:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:14:22 --> Language Class Initialized
DEBUG - 2013-08-28 16:14:22 --> Loader Class Initialized
DEBUG - 2013-08-28 16:14:22 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:14:22 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:14:22 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:14:22 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:14:22 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:14:22 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:14:22 --> Session Class Initialized
DEBUG - 2013-08-28 16:14:22 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:14:22 --> Session routines successfully run
DEBUG - 2013-08-28 16:14:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:14:22 --> Controller Class Initialized
ERROR - 2013-08-28 16:14:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:22 --> Model Class Initialized
DEBUG - 2013-08-28 16:14:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:14:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:14:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:14:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:14:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:23 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:14:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:14:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:14:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:14:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:14:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:14:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:14:23 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-28 16:14:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:14:23 --> Final output sent to browser
DEBUG - 2013-08-28 16:14:23 --> Total execution time: 2.2431
DEBUG - 2013-08-28 16:14:23 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:23 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:23 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:24 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:24 --> Router Class Initialized
ERROR - 2013-08-28 16:14:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:14:25 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:25 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:25 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:25 --> Router Class Initialized
DEBUG - 2013-08-28 16:14:25 --> Output Class Initialized
DEBUG - 2013-08-28 16:14:25 --> Security Class Initialized
DEBUG - 2013-08-28 16:14:25 --> Input Class Initialized
DEBUG - 2013-08-28 16:14:25 --> XSS Filtering completed
DEBUG - 2013-08-28 16:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:14:26 --> Language Class Initialized
DEBUG - 2013-08-28 16:14:26 --> Loader Class Initialized
DEBUG - 2013-08-28 16:14:26 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:14:26 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:14:26 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:14:26 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:14:26 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:14:26 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:14:26 --> Session Class Initialized
DEBUG - 2013-08-28 16:14:26 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:14:26 --> Session routines successfully run
DEBUG - 2013-08-28 16:14:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:14:26 --> Controller Class Initialized
ERROR - 2013-08-28 16:14:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:26 --> Model Class Initialized
DEBUG - 2013-08-28 16:14:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:14:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:14:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:14:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:14:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:14:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:14:27 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:14:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:14:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:14:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:14:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:14:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:14:27 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:14:27 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\mata_pelajarans\index.php 82
DEBUG - 2013-08-28 16:14:27 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-08-28 16:14:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:14:27 --> Final output sent to browser
DEBUG - 2013-08-28 16:14:27 --> Total execution time: 2.5051
DEBUG - 2013-08-28 16:14:28 --> Config Class Initialized
DEBUG - 2013-08-28 16:14:28 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:14:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:14:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:14:28 --> URI Class Initialized
DEBUG - 2013-08-28 16:14:28 --> Router Class Initialized
ERROR - 2013-08-28 16:14:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:17:05 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:05 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:05 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:05 --> Router Class Initialized
DEBUG - 2013-08-28 16:17:05 --> Output Class Initialized
DEBUG - 2013-08-28 16:17:05 --> Security Class Initialized
DEBUG - 2013-08-28 16:17:05 --> Input Class Initialized
DEBUG - 2013-08-28 16:17:06 --> XSS Filtering completed
DEBUG - 2013-08-28 16:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:17:06 --> Language Class Initialized
DEBUG - 2013-08-28 16:17:06 --> Loader Class Initialized
DEBUG - 2013-08-28 16:17:06 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:17:06 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:17:06 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:17:06 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:17:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:17:06 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:17:06 --> Session Class Initialized
DEBUG - 2013-08-28 16:17:06 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:17:06 --> Session routines successfully run
DEBUG - 2013-08-28 16:17:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:17:06 --> Controller Class Initialized
ERROR - 2013-08-28 16:17:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:06 --> Model Class Initialized
DEBUG - 2013-08-28 16:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:17:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:17:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:17:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:17:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:07 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:17:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:17:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:17:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:17:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:17:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:17:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:17:07 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:17:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:17:07 --> Final output sent to browser
DEBUG - 2013-08-28 16:17:07 --> Total execution time: 2.0561
DEBUG - 2013-08-28 16:17:07 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:08 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:08 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:08 --> Router Class Initialized
ERROR - 2013-08-28 16:17:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:17:09 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:09 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:09 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:09 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:10 --> Router Class Initialized
DEBUG - 2013-08-28 16:17:10 --> Output Class Initialized
DEBUG - 2013-08-28 16:17:10 --> Security Class Initialized
DEBUG - 2013-08-28 16:17:10 --> Input Class Initialized
DEBUG - 2013-08-28 16:17:10 --> XSS Filtering completed
DEBUG - 2013-08-28 16:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:17:10 --> Language Class Initialized
DEBUG - 2013-08-28 16:17:10 --> Loader Class Initialized
DEBUG - 2013-08-28 16:17:10 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:17:10 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:17:10 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:17:10 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:17:10 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:17:10 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:17:10 --> Session Class Initialized
DEBUG - 2013-08-28 16:17:10 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:17:10 --> Session routines successfully run
DEBUG - 2013-08-28 16:17:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:17:10 --> Controller Class Initialized
ERROR - 2013-08-28 16:17:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:11 --> Model Class Initialized
DEBUG - 2013-08-28 16:17:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:17:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:17:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:17:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:17:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:11 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:17:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:17:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:17:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:17:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:17:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:17:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:17:11 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-28 16:17:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:17:12 --> Final output sent to browser
DEBUG - 2013-08-28 16:17:12 --> Total execution time: 2.2891
DEBUG - 2013-08-28 16:17:12 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:12 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:12 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:12 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:12 --> Router Class Initialized
ERROR - 2013-08-28 16:17:12 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:17:13 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:13 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:13 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:14 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:14 --> Router Class Initialized
DEBUG - 2013-08-28 16:17:14 --> Output Class Initialized
DEBUG - 2013-08-28 16:17:14 --> Security Class Initialized
DEBUG - 2013-08-28 16:17:14 --> Input Class Initialized
DEBUG - 2013-08-28 16:17:14 --> XSS Filtering completed
DEBUG - 2013-08-28 16:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:17:14 --> Language Class Initialized
DEBUG - 2013-08-28 16:17:14 --> Loader Class Initialized
DEBUG - 2013-08-28 16:17:14 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:17:14 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:17:14 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:17:14 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:17:14 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:17:14 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:17:14 --> Session Class Initialized
DEBUG - 2013-08-28 16:17:14 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:17:14 --> Session routines successfully run
DEBUG - 2013-08-28 16:17:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:17:15 --> Controller Class Initialized
ERROR - 2013-08-28 16:17:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:15 --> Model Class Initialized
DEBUG - 2013-08-28 16:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:17:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:17:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:17:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:17:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:15 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:17:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:17:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:17:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:17:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:17:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:17:15 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:17:16 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\mata_pelajarans\index.php 82
DEBUG - 2013-08-28 16:17:16 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-08-28 16:17:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:17:16 --> Final output sent to browser
DEBUG - 2013-08-28 16:17:16 --> Total execution time: 2.2901
DEBUG - 2013-08-28 16:17:16 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:16 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:16 --> Router Class Initialized
ERROR - 2013-08-28 16:17:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:17:17 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:17 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:18 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:18 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:18 --> Router Class Initialized
DEBUG - 2013-08-28 16:17:18 --> Output Class Initialized
DEBUG - 2013-08-28 16:17:18 --> Security Class Initialized
DEBUG - 2013-08-28 16:17:18 --> Input Class Initialized
DEBUG - 2013-08-28 16:17:18 --> XSS Filtering completed
DEBUG - 2013-08-28 16:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:17:18 --> Language Class Initialized
DEBUG - 2013-08-28 16:17:18 --> Loader Class Initialized
DEBUG - 2013-08-28 16:17:18 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:17:18 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:17:18 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:17:18 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:17:18 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:17:18 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:17:18 --> Session Class Initialized
DEBUG - 2013-08-28 16:17:19 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:17:19 --> Session routines successfully run
DEBUG - 2013-08-28 16:17:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:17:19 --> Controller Class Initialized
ERROR - 2013-08-28 16:17:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:19 --> Model Class Initialized
DEBUG - 2013-08-28 16:17:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:17:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:17:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:17:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:17:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:19 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:17:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:17:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:17:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:17:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:17:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:17:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:17:19 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 16:17:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:17:20 --> Final output sent to browser
DEBUG - 2013-08-28 16:17:20 --> Total execution time: 2.1241
DEBUG - 2013-08-28 16:17:20 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:20 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:20 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:20 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:20 --> Router Class Initialized
ERROR - 2013-08-28 16:17:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:17:24 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:24 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Router Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Output Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Security Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Input Class Initialized
DEBUG - 2013-08-28 16:17:24 --> XSS Filtering completed
DEBUG - 2013-08-28 16:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:17:24 --> Language Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Loader Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:17:24 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:17:24 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:17:24 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:17:24 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:17:24 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Session Class Initialized
DEBUG - 2013-08-28 16:17:24 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:17:25 --> Session routines successfully run
DEBUG - 2013-08-28 16:17:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:17:25 --> Controller Class Initialized
ERROR - 2013-08-28 16:17:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:25 --> Model Class Initialized
DEBUG - 2013-08-28 16:17:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:17:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:17:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:17:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:17:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:17:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:17:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:17:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:17:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:17:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:17:26 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-28 16:17:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:17:26 --> Final output sent to browser
DEBUG - 2013-08-28 16:17:26 --> Total execution time: 2.1361
DEBUG - 2013-08-28 16:17:26 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:26 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:26 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:26 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:26 --> Router Class Initialized
ERROR - 2013-08-28 16:17:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:17:29 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:29 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:30 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:30 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:30 --> Router Class Initialized
DEBUG - 2013-08-28 16:17:30 --> Output Class Initialized
DEBUG - 2013-08-28 16:17:30 --> Security Class Initialized
DEBUG - 2013-08-28 16:17:30 --> Input Class Initialized
DEBUG - 2013-08-28 16:17:30 --> XSS Filtering completed
DEBUG - 2013-08-28 16:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:17:30 --> Language Class Initialized
DEBUG - 2013-08-28 16:17:30 --> Loader Class Initialized
DEBUG - 2013-08-28 16:17:30 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:17:30 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:17:30 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:17:30 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:17:30 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:17:30 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:17:30 --> Session Class Initialized
DEBUG - 2013-08-28 16:17:30 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:17:30 --> Session routines successfully run
DEBUG - 2013-08-28 16:17:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:17:31 --> Controller Class Initialized
ERROR - 2013-08-28 16:17:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:31 --> Model Class Initialized
DEBUG - 2013-08-28 16:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:17:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:17:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:17:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:17:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:17:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:17:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:17:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:17:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:17:31 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:17:31 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:17:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:17:32 --> Final output sent to browser
DEBUG - 2013-08-28 16:17:32 --> Total execution time: 2.1781
DEBUG - 2013-08-28 16:17:32 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:32 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:32 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:32 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:32 --> Router Class Initialized
ERROR - 2013-08-28 16:17:32 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:17:35 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:35 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:35 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:35 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:35 --> Router Class Initialized
DEBUG - 2013-08-28 16:17:35 --> Output Class Initialized
DEBUG - 2013-08-28 16:17:35 --> Security Class Initialized
DEBUG - 2013-08-28 16:17:35 --> Input Class Initialized
DEBUG - 2013-08-28 16:17:35 --> XSS Filtering completed
DEBUG - 2013-08-28 16:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:17:35 --> Language Class Initialized
DEBUG - 2013-08-28 16:17:35 --> Loader Class Initialized
DEBUG - 2013-08-28 16:17:35 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:17:36 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:17:36 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:17:36 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:17:36 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:17:36 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:17:36 --> Session Class Initialized
DEBUG - 2013-08-28 16:17:36 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:17:36 --> Session routines successfully run
DEBUG - 2013-08-28 16:17:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:17:36 --> Controller Class Initialized
ERROR - 2013-08-28 16:17:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:36 --> Model Class Initialized
DEBUG - 2013-08-28 16:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:17:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:17:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:17:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:17:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:17:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:17:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:17:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:17:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:17:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:17:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:17:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:17:37 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 16:17:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:17:37 --> Final output sent to browser
DEBUG - 2013-08-28 16:17:37 --> Total execution time: 2.2161
DEBUG - 2013-08-28 16:17:37 --> Config Class Initialized
DEBUG - 2013-08-28 16:17:37 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:17:37 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:17:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:17:38 --> URI Class Initialized
DEBUG - 2013-08-28 16:17:38 --> Router Class Initialized
ERROR - 2013-08-28 16:17:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:20:42 --> Config Class Initialized
DEBUG - 2013-08-28 16:20:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:20:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:20:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:20:42 --> URI Class Initialized
DEBUG - 2013-08-28 16:20:42 --> Router Class Initialized
DEBUG - 2013-08-28 16:20:42 --> Output Class Initialized
DEBUG - 2013-08-28 16:20:42 --> Security Class Initialized
DEBUG - 2013-08-28 16:20:42 --> Input Class Initialized
DEBUG - 2013-08-28 16:20:42 --> XSS Filtering completed
DEBUG - 2013-08-28 16:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:20:43 --> Language Class Initialized
DEBUG - 2013-08-28 16:20:43 --> Loader Class Initialized
DEBUG - 2013-08-28 16:20:43 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:20:43 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:20:43 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:20:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:20:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:20:43 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:20:43 --> Session Class Initialized
DEBUG - 2013-08-28 16:20:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:20:43 --> Session routines successfully run
DEBUG - 2013-08-28 16:20:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:20:43 --> Controller Class Initialized
ERROR - 2013-08-28 16:20:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:20:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:20:43 --> Model Class Initialized
DEBUG - 2013-08-28 16:20:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:20:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:20:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:20:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:20:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:20:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:20:44 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:20:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:20:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:20:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:20:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:20:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:20:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:20:44 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-28 16:20:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:20:44 --> Final output sent to browser
DEBUG - 2013-08-28 16:20:44 --> Total execution time: 2.1121
DEBUG - 2013-08-28 16:20:44 --> Config Class Initialized
DEBUG - 2013-08-28 16:20:44 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:20:45 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:20:45 --> URI Class Initialized
DEBUG - 2013-08-28 16:20:45 --> Router Class Initialized
ERROR - 2013-08-28 16:20:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:20:46 --> Config Class Initialized
DEBUG - 2013-08-28 16:20:46 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:20:46 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:20:47 --> URI Class Initialized
DEBUG - 2013-08-28 16:20:47 --> Router Class Initialized
DEBUG - 2013-08-28 16:20:47 --> Output Class Initialized
DEBUG - 2013-08-28 16:20:47 --> Security Class Initialized
DEBUG - 2013-08-28 16:20:47 --> Input Class Initialized
DEBUG - 2013-08-28 16:20:47 --> XSS Filtering completed
DEBUG - 2013-08-28 16:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:20:47 --> Language Class Initialized
DEBUG - 2013-08-28 16:20:47 --> Loader Class Initialized
DEBUG - 2013-08-28 16:20:47 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:20:47 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:20:47 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:20:47 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:20:47 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:20:47 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:20:47 --> Session Class Initialized
DEBUG - 2013-08-28 16:20:47 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:20:47 --> Session routines successfully run
DEBUG - 2013-08-28 16:20:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:20:47 --> Controller Class Initialized
ERROR - 2013-08-28 16:20:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:20:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:20:48 --> Model Class Initialized
DEBUG - 2013-08-28 16:20:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:20:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:20:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:20:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:20:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:20:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:20:48 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:20:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:20:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:20:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:20:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:20:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:20:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:20:48 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:20:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:20:49 --> Final output sent to browser
DEBUG - 2013-08-28 16:20:49 --> Total execution time: 2.2551
DEBUG - 2013-08-28 16:20:49 --> Config Class Initialized
DEBUG - 2013-08-28 16:20:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:20:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:20:49 --> URI Class Initialized
DEBUG - 2013-08-28 16:20:49 --> Router Class Initialized
ERROR - 2013-08-28 16:20:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:20:51 --> Config Class Initialized
DEBUG - 2013-08-28 16:20:51 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:20:51 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:20:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:20:51 --> URI Class Initialized
DEBUG - 2013-08-28 16:20:51 --> Router Class Initialized
DEBUG - 2013-08-28 16:20:51 --> Output Class Initialized
DEBUG - 2013-08-28 16:20:51 --> Security Class Initialized
DEBUG - 2013-08-28 16:20:52 --> Input Class Initialized
DEBUG - 2013-08-28 16:20:52 --> XSS Filtering completed
DEBUG - 2013-08-28 16:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:20:52 --> Language Class Initialized
DEBUG - 2013-08-28 16:20:52 --> Loader Class Initialized
DEBUG - 2013-08-28 16:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:20:52 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:20:52 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:20:52 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:20:52 --> Session Class Initialized
DEBUG - 2013-08-28 16:20:52 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:20:52 --> Session routines successfully run
DEBUG - 2013-08-28 16:20:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:20:52 --> Controller Class Initialized
ERROR - 2013-08-28 16:20:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:20:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:20:52 --> Model Class Initialized
DEBUG - 2013-08-28 16:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:20:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:20:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:20:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:20:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:20:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:20:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:20:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:20:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:20:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:20:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:20:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:20:53 --> File loaded: application/views/kurikulums/new.php
DEBUG - 2013-08-28 16:20:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:20:53 --> Final output sent to browser
DEBUG - 2013-08-28 16:20:53 --> Total execution time: 2.2011
DEBUG - 2013-08-28 16:20:54 --> Config Class Initialized
DEBUG - 2013-08-28 16:20:54 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:20:54 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:20:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:20:54 --> URI Class Initialized
DEBUG - 2013-08-28 16:20:54 --> Router Class Initialized
ERROR - 2013-08-28 16:20:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:21:03 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:03 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:03 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:03 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:03 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:03 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:03 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:03 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:03 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:03 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:03 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:03 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:03 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:04 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:04 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:04 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:04 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:04 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:04 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:04 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:04 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:21:05 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 16:21:05 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:05 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:05 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:05 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:05 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:05 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:05 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:05 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:05 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:05 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:05 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:05 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:05 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:06 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:06 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:06 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:06 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:06 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:06 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:06 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:21:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:21:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:21:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:21:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:21:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:21:07 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:21:07 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\kurikulums\index.php 72
DEBUG - 2013-08-28 16:21:07 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:21:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:21:07 --> Final output sent to browser
DEBUG - 2013-08-28 16:21:07 --> Total execution time: 2.2111
DEBUG - 2013-08-28 16:21:07 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:07 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:07 --> Router Class Initialized
ERROR - 2013-08-28 16:21:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:21:11 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:11 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:11 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:11 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:11 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:11 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:11 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:11 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:11 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:11 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:11 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:11 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:11 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:11 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:11 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:12 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:12 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:12 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:12 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:12 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:21:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:21:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:21:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:21:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:21:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:21:13 --> File loaded: application/views/kurikulums/edit.php
DEBUG - 2013-08-28 16:21:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:21:13 --> Final output sent to browser
DEBUG - 2013-08-28 16:21:13 --> Total execution time: 2.2001
DEBUG - 2013-08-28 16:21:13 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:13 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:13 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:13 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:13 --> Router Class Initialized
ERROR - 2013-08-28 16:21:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:21:20 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:20 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:20 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:20 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:20 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:20 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:20 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:21 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:21 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:21 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:21 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:21 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:21 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:21 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:21 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:21 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:21 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:21 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:21 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:21 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:21 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:22 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:22 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:21:22 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 16:21:22 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:22 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:22 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:22 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:22 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:23 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:23 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:23 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:23 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:23 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:23 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:23 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:23 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:23 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:23 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:23 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:23 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:23 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:23 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:23 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:23 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:24 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:21:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:21:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:21:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:21:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:21:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:21:24 --> File loaded: application/views/kurikulums/show.php
DEBUG - 2013-08-28 16:21:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:21:24 --> Final output sent to browser
DEBUG - 2013-08-28 16:21:24 --> Total execution time: 2.2151
DEBUG - 2013-08-28 16:21:25 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:25 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:25 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:25 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:25 --> Router Class Initialized
ERROR - 2013-08-28 16:21:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:21:27 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:27 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:28 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:28 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:28 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:28 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:28 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:28 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:28 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:28 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:28 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:28 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:28 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:28 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:28 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:28 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:28 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:28 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:28 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:29 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:29 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:29 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:29 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:21:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:21:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:21:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:21:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:21:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:21:30 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:21:30 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\kurikulums\index.php 72
DEBUG - 2013-08-28 16:21:30 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:21:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:21:30 --> Final output sent to browser
DEBUG - 2013-08-28 16:21:30 --> Total execution time: 2.3841
DEBUG - 2013-08-28 16:21:30 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:30 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:30 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:30 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:30 --> Router Class Initialized
ERROR - 2013-08-28 16:21:30 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:21:34 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:34 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:34 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:34 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:34 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:34 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:34 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:34 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:34 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:34 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:34 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:34 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:35 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:35 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:35 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:35 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:35 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:35 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:35 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:35 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:35 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:35 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:21:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:21:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:21:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:21:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:21:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:21:36 --> File loaded: application/views/kurikulums/new.php
DEBUG - 2013-08-28 16:21:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:21:36 --> Final output sent to browser
DEBUG - 2013-08-28 16:21:36 --> Total execution time: 2.2601
DEBUG - 2013-08-28 16:21:36 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:36 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:36 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:36 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:36 --> Router Class Initialized
ERROR - 2013-08-28 16:21:37 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:21:42 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:42 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:42 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:43 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:43 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:43 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:43 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:43 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:43 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:43 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:43 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:43 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:43 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:43 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:43 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:43 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:43 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:43 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:43 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:43 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:43 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:44 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:44 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:44 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:44 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:21:44 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 16:21:44 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:45 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:45 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:45 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:45 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:45 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:45 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:45 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:45 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:45 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:45 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:45 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:45 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:45 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:45 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:45 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:45 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:46 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:46 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:46 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:46 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:46 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:46 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:46 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:21:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:21:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:21:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:21:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:21:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:21:47 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:21:47 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\kurikulums\index.php 72
ERROR - 2013-08-28 16:21:47 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\kurikulums\index.php 72
DEBUG - 2013-08-28 16:21:47 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:21:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:21:47 --> Final output sent to browser
DEBUG - 2013-08-28 16:21:47 --> Total execution time: 2.4861
DEBUG - 2013-08-28 16:21:47 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:47 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:47 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:47 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:47 --> Router Class Initialized
ERROR - 2013-08-28 16:21:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:21:50 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:50 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:50 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:50 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:50 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:50 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:50 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:50 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:50 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:51 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:51 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:51 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:51 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:51 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:51 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:51 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:51 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:51 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:51 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:51 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:51 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:51 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:21:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:21:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:21:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:21:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:21:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:21:52 --> File loaded: application/views/kurikulums/edit.php
DEBUG - 2013-08-28 16:21:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:21:52 --> Final output sent to browser
DEBUG - 2013-08-28 16:21:52 --> Total execution time: 2.2661
DEBUG - 2013-08-28 16:21:52 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:53 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:53 --> Router Class Initialized
ERROR - 2013-08-28 16:21:53 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:21:58 --> Config Class Initialized
DEBUG - 2013-08-28 16:21:58 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:21:58 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:21:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:21:58 --> URI Class Initialized
DEBUG - 2013-08-28 16:21:58 --> Router Class Initialized
DEBUG - 2013-08-28 16:21:58 --> Output Class Initialized
DEBUG - 2013-08-28 16:21:58 --> Security Class Initialized
DEBUG - 2013-08-28 16:21:58 --> Input Class Initialized
DEBUG - 2013-08-28 16:21:58 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:58 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:58 --> XSS Filtering completed
DEBUG - 2013-08-28 16:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:21:58 --> Language Class Initialized
DEBUG - 2013-08-28 16:21:58 --> Loader Class Initialized
DEBUG - 2013-08-28 16:21:58 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:21:58 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:21:58 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:21:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:21:59 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:21:59 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:21:59 --> Session Class Initialized
DEBUG - 2013-08-28 16:21:59 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:21:59 --> Session routines successfully run
DEBUG - 2013-08-28 16:21:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:21:59 --> Controller Class Initialized
ERROR - 2013-08-28 16:21:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:59 --> Model Class Initialized
DEBUG - 2013-08-28 16:21:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:21:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:21:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:21:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:21:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:21:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:21:59 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:22:00 --> XSS Filtering completed
DEBUG - 2013-08-28 16:22:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 16:22:00 --> Config Class Initialized
DEBUG - 2013-08-28 16:22:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:22:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:22:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:22:00 --> URI Class Initialized
DEBUG - 2013-08-28 16:22:00 --> Router Class Initialized
DEBUG - 2013-08-28 16:22:00 --> Output Class Initialized
DEBUG - 2013-08-28 16:22:00 --> Security Class Initialized
DEBUG - 2013-08-28 16:22:00 --> Input Class Initialized
DEBUG - 2013-08-28 16:22:00 --> XSS Filtering completed
DEBUG - 2013-08-28 16:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:22:00 --> Language Class Initialized
DEBUG - 2013-08-28 16:22:00 --> Loader Class Initialized
DEBUG - 2013-08-28 16:22:00 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:22:00 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:22:00 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:22:00 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:22:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:22:01 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:22:01 --> Session Class Initialized
DEBUG - 2013-08-28 16:22:01 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:22:01 --> Session garbage collection performed.
DEBUG - 2013-08-28 16:22:01 --> Session routines successfully run
DEBUG - 2013-08-28 16:22:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:22:01 --> Controller Class Initialized
ERROR - 2013-08-28 16:22:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:22:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:22:01 --> Model Class Initialized
DEBUG - 2013-08-28 16:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:22:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:22:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:22:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:22:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:22:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:22:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:22:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:22:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:22:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:22:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:22:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:22:02 --> File loaded: application/views/kurikulums/edit.php
DEBUG - 2013-08-28 16:22:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:22:02 --> Final output sent to browser
DEBUG - 2013-08-28 16:22:02 --> Total execution time: 2.5271
DEBUG - 2013-08-28 16:22:02 --> Config Class Initialized
DEBUG - 2013-08-28 16:22:02 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:22:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:22:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:22:03 --> URI Class Initialized
DEBUG - 2013-08-28 16:22:03 --> Router Class Initialized
ERROR - 2013-08-28 16:22:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:22:04 --> Config Class Initialized
DEBUG - 2013-08-28 16:22:04 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:22:04 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:22:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:22:04 --> URI Class Initialized
DEBUG - 2013-08-28 16:22:04 --> Router Class Initialized
DEBUG - 2013-08-28 16:22:04 --> Output Class Initialized
DEBUG - 2013-08-28 16:22:04 --> Security Class Initialized
DEBUG - 2013-08-28 16:22:04 --> Input Class Initialized
DEBUG - 2013-08-28 16:22:04 --> XSS Filtering completed
DEBUG - 2013-08-28 16:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:22:05 --> Language Class Initialized
DEBUG - 2013-08-28 16:22:05 --> Loader Class Initialized
DEBUG - 2013-08-28 16:22:05 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:22:05 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:22:05 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:22:05 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:22:05 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:22:05 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:22:05 --> Session Class Initialized
DEBUG - 2013-08-28 16:22:05 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:22:05 --> Session routines successfully run
DEBUG - 2013-08-28 16:22:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:22:05 --> Controller Class Initialized
ERROR - 2013-08-28 16:22:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:22:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:22:05 --> Model Class Initialized
DEBUG - 2013-08-28 16:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:22:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:22:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:22:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:22:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:22:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:22:06 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:22:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:22:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:22:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:22:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:22:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:22:06 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:22:06 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\kurikulums\index.php 72
ERROR - 2013-08-28 16:22:06 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\kurikulums\index.php 72
DEBUG - 2013-08-28 16:22:06 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:22:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:22:06 --> Final output sent to browser
DEBUG - 2013-08-28 16:22:06 --> Total execution time: 2.5431
DEBUG - 2013-08-28 16:22:07 --> Config Class Initialized
DEBUG - 2013-08-28 16:22:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:22:07 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:22:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:22:07 --> URI Class Initialized
DEBUG - 2013-08-28 16:22:07 --> Router Class Initialized
ERROR - 2013-08-28 16:22:07 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:22:53 --> Config Class Initialized
DEBUG - 2013-08-28 16:22:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:22:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:22:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:22:53 --> URI Class Initialized
DEBUG - 2013-08-28 16:22:53 --> Router Class Initialized
DEBUG - 2013-08-28 16:22:53 --> Output Class Initialized
DEBUG - 2013-08-28 16:22:53 --> Security Class Initialized
DEBUG - 2013-08-28 16:22:53 --> Input Class Initialized
DEBUG - 2013-08-28 16:22:53 --> XSS Filtering completed
DEBUG - 2013-08-28 16:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:22:53 --> Language Class Initialized
DEBUG - 2013-08-28 16:22:54 --> Loader Class Initialized
DEBUG - 2013-08-28 16:22:54 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:22:54 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:22:54 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:22:54 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:22:54 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:22:54 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:22:54 --> Session Class Initialized
DEBUG - 2013-08-28 16:22:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:22:54 --> Session routines successfully run
DEBUG - 2013-08-28 16:22:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:22:54 --> Controller Class Initialized
ERROR - 2013-08-28 16:22:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:22:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:22:54 --> Model Class Initialized
DEBUG - 2013-08-28 16:22:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:22:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:22:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:22:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:22:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:22:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:22:55 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:22:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:22:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:22:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:22:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:22:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:22:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:22:55 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:22:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:22:55 --> Final output sent to browser
DEBUG - 2013-08-28 16:22:55 --> Total execution time: 2.3111
DEBUG - 2013-08-28 16:22:55 --> Config Class Initialized
DEBUG - 2013-08-28 16:22:56 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:22:56 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:22:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:22:56 --> URI Class Initialized
DEBUG - 2013-08-28 16:22:56 --> Router Class Initialized
ERROR - 2013-08-28 16:22:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:23:00 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:00 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:00 --> Router Class Initialized
DEBUG - 2013-08-28 16:23:00 --> Output Class Initialized
DEBUG - 2013-08-28 16:23:00 --> Security Class Initialized
DEBUG - 2013-08-28 16:23:00 --> Input Class Initialized
DEBUG - 2013-08-28 16:23:01 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:23:01 --> Language Class Initialized
DEBUG - 2013-08-28 16:23:01 --> Loader Class Initialized
DEBUG - 2013-08-28 16:23:01 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:23:01 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:23:01 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:23:01 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:23:01 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:23:01 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:23:01 --> Session Class Initialized
DEBUG - 2013-08-28 16:23:01 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:23:01 --> Session routines successfully run
DEBUG - 2013-08-28 16:23:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:23:01 --> Controller Class Initialized
ERROR - 2013-08-28 16:23:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:01 --> Model Class Initialized
DEBUG - 2013-08-28 16:23:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:23:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:23:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:23:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:23:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:02 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:02 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:02 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:02 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:02 --> Router Class Initialized
DEBUG - 2013-08-28 16:23:02 --> Output Class Initialized
DEBUG - 2013-08-28 16:23:02 --> Security Class Initialized
DEBUG - 2013-08-28 16:23:02 --> Input Class Initialized
DEBUG - 2013-08-28 16:23:02 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:23:03 --> Language Class Initialized
DEBUG - 2013-08-28 16:23:03 --> Loader Class Initialized
DEBUG - 2013-08-28 16:23:03 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:23:03 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:23:03 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:23:03 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:23:03 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:23:03 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:23:03 --> Session Class Initialized
DEBUG - 2013-08-28 16:23:03 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:23:03 --> Session routines successfully run
DEBUG - 2013-08-28 16:23:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:23:03 --> Controller Class Initialized
ERROR - 2013-08-28 16:23:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:03 --> Model Class Initialized
DEBUG - 2013-08-28 16:23:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:23:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:23:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:23:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:23:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:04 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:23:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:23:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:23:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:23:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:23:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:23:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:23:04 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:23:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:23:04 --> Final output sent to browser
DEBUG - 2013-08-28 16:23:05 --> Total execution time: 2.5681
DEBUG - 2013-08-28 16:23:05 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:05 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:05 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:05 --> Router Class Initialized
ERROR - 2013-08-28 16:23:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:23:10 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:10 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:10 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:10 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:11 --> Router Class Initialized
DEBUG - 2013-08-28 16:23:11 --> Output Class Initialized
DEBUG - 2013-08-28 16:23:11 --> Security Class Initialized
DEBUG - 2013-08-28 16:23:11 --> Input Class Initialized
DEBUG - 2013-08-28 16:23:11 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:11 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:11 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:23:11 --> Language Class Initialized
DEBUG - 2013-08-28 16:23:11 --> Loader Class Initialized
DEBUG - 2013-08-28 16:23:11 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:23:11 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:23:11 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:23:11 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:23:11 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:23:11 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:23:11 --> Session Class Initialized
DEBUG - 2013-08-28 16:23:11 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:23:11 --> Session routines successfully run
DEBUG - 2013-08-28 16:23:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:23:12 --> Controller Class Initialized
ERROR - 2013-08-28 16:23:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:12 --> Model Class Initialized
DEBUG - 2013-08-28 16:23:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:23:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:23:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:23:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:23:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:12 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:12 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:12 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:12 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:12 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:13 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:13 --> Router Class Initialized
DEBUG - 2013-08-28 16:23:13 --> Output Class Initialized
DEBUG - 2013-08-28 16:23:13 --> Security Class Initialized
DEBUG - 2013-08-28 16:23:13 --> Input Class Initialized
DEBUG - 2013-08-28 16:23:13 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:23:13 --> Language Class Initialized
DEBUG - 2013-08-28 16:23:13 --> Loader Class Initialized
DEBUG - 2013-08-28 16:23:13 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:23:13 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:23:13 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:23:13 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:23:13 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:23:13 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:23:13 --> Session Class Initialized
DEBUG - 2013-08-28 16:23:13 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:23:14 --> Session routines successfully run
DEBUG - 2013-08-28 16:23:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:23:14 --> Controller Class Initialized
ERROR - 2013-08-28 16:23:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:14 --> Model Class Initialized
DEBUG - 2013-08-28 16:23:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:23:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:23:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:23:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:23:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:14 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:23:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:23:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:23:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:23:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:23:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:23:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:23:15 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-08-28 16:23:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:23:15 --> Final output sent to browser
DEBUG - 2013-08-28 16:23:15 --> Total execution time: 2.5121
DEBUG - 2013-08-28 16:23:15 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:15 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:15 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:15 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:16 --> Router Class Initialized
ERROR - 2013-08-28 16:23:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:23:20 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:20 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:20 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:20 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:20 --> Router Class Initialized
DEBUG - 2013-08-28 16:23:20 --> Output Class Initialized
DEBUG - 2013-08-28 16:23:20 --> Security Class Initialized
DEBUG - 2013-08-28 16:23:20 --> Input Class Initialized
DEBUG - 2013-08-28 16:23:20 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:23:21 --> Language Class Initialized
DEBUG - 2013-08-28 16:23:21 --> Loader Class Initialized
DEBUG - 2013-08-28 16:23:21 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:23:21 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:23:21 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:23:21 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:23:21 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:23:21 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:23:21 --> Session Class Initialized
DEBUG - 2013-08-28 16:23:21 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:23:21 --> Session routines successfully run
DEBUG - 2013-08-28 16:23:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:23:21 --> Controller Class Initialized
ERROR - 2013-08-28 16:23:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:21 --> Model Class Initialized
DEBUG - 2013-08-28 16:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:23:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:23:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:23:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:23:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:22 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:23:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:23:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:23:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:23:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:23:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:23:22 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-28 16:23:22 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
ERROR - 2013-08-28 16:23:22 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\jurusans\index.php 72
DEBUG - 2013-08-28 16:23:22 --> File loaded: application/views/jurusans/index.php
DEBUG - 2013-08-28 16:23:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:23:22 --> Final output sent to browser
DEBUG - 2013-08-28 16:23:22 --> Total execution time: 2.4991
DEBUG - 2013-08-28 16:23:23 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:23 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:23 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:23 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:23 --> Router Class Initialized
ERROR - 2013-08-28 16:23:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:23:53 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:53 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:53 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:53 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:53 --> Router Class Initialized
DEBUG - 2013-08-28 16:23:53 --> Output Class Initialized
DEBUG - 2013-08-28 16:23:53 --> Security Class Initialized
DEBUG - 2013-08-28 16:23:53 --> Input Class Initialized
DEBUG - 2013-08-28 16:23:53 --> XSS Filtering completed
DEBUG - 2013-08-28 16:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:23:53 --> Language Class Initialized
DEBUG - 2013-08-28 16:23:53 --> Loader Class Initialized
DEBUG - 2013-08-28 16:23:53 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:23:53 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:23:53 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:23:53 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:23:53 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:23:54 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:23:54 --> Session Class Initialized
DEBUG - 2013-08-28 16:23:54 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:23:54 --> Session routines successfully run
DEBUG - 2013-08-28 16:23:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:23:54 --> Controller Class Initialized
ERROR - 2013-08-28 16:23:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:54 --> Model Class Initialized
DEBUG - 2013-08-28 16:23:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:23:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:23:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:23:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:23:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:23:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:23:54 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:23:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:23:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:23:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:23:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:23:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:23:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:23:55 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-28 16:23:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:23:55 --> Final output sent to browser
DEBUG - 2013-08-28 16:23:55 --> Total execution time: 2.3611
DEBUG - 2013-08-28 16:23:55 --> Config Class Initialized
DEBUG - 2013-08-28 16:23:55 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:23:55 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:23:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:23:55 --> URI Class Initialized
DEBUG - 2013-08-28 16:23:56 --> Router Class Initialized
ERROR - 2013-08-28 16:23:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:24:35 --> Config Class Initialized
DEBUG - 2013-08-28 16:24:35 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:24:35 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:24:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:24:35 --> URI Class Initialized
DEBUG - 2013-08-28 16:24:35 --> Router Class Initialized
DEBUG - 2013-08-28 16:24:36 --> Output Class Initialized
DEBUG - 2013-08-28 16:24:36 --> Security Class Initialized
DEBUG - 2013-08-28 16:24:36 --> Input Class Initialized
DEBUG - 2013-08-28 16:24:36 --> XSS Filtering completed
DEBUG - 2013-08-28 16:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:24:36 --> Language Class Initialized
DEBUG - 2013-08-28 16:24:36 --> Loader Class Initialized
DEBUG - 2013-08-28 16:24:36 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:24:36 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:24:36 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:24:36 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:24:36 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:24:36 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:24:36 --> Session Class Initialized
DEBUG - 2013-08-28 16:24:36 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:24:36 --> Session routines successfully run
DEBUG - 2013-08-28 16:24:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:24:36 --> Controller Class Initialized
ERROR - 2013-08-28 16:24:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:24:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:24:37 --> Model Class Initialized
DEBUG - 2013-08-28 16:24:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:24:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:24:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:24:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:24:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:24:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:24:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:24:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:24:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:24:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:24:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:24:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:24:37 --> File loaded: application/views/tahun_ajarans/new.php
DEBUG - 2013-08-28 16:24:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:24:38 --> Final output sent to browser
DEBUG - 2013-08-28 16:24:38 --> Total execution time: 2.2401
DEBUG - 2013-08-28 16:24:38 --> Config Class Initialized
DEBUG - 2013-08-28 16:24:38 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:24:38 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:24:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:24:38 --> URI Class Initialized
DEBUG - 2013-08-28 16:24:38 --> Router Class Initialized
ERROR - 2013-08-28 16:24:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:24:47 --> Config Class Initialized
DEBUG - 2013-08-28 16:24:47 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:24:47 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:24:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:24:47 --> URI Class Initialized
DEBUG - 2013-08-28 16:24:47 --> Router Class Initialized
DEBUG - 2013-08-28 16:24:47 --> Output Class Initialized
DEBUG - 2013-08-28 16:24:47 --> Security Class Initialized
DEBUG - 2013-08-28 16:24:47 --> Input Class Initialized
DEBUG - 2013-08-28 16:24:47 --> XSS Filtering completed
DEBUG - 2013-08-28 16:24:47 --> XSS Filtering completed
DEBUG - 2013-08-28 16:24:47 --> XSS Filtering completed
DEBUG - 2013-08-28 16:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:24:48 --> Language Class Initialized
DEBUG - 2013-08-28 16:24:48 --> Loader Class Initialized
DEBUG - 2013-08-28 16:24:48 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:24:48 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:24:48 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:24:48 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:24:48 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:24:48 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:24:48 --> Session Class Initialized
DEBUG - 2013-08-28 16:24:48 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:24:48 --> Session routines successfully run
DEBUG - 2013-08-28 16:24:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:24:48 --> Controller Class Initialized
ERROR - 2013-08-28 16:24:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:24:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:24:48 --> Model Class Initialized
DEBUG - 2013-08-28 16:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:24:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:24:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:24:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:24:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:24:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:24:49 --> Form Validation Class Initialized
DEBUG - 2013-08-28 16:24:49 --> XSS Filtering completed
DEBUG - 2013-08-28 16:24:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-28 16:24:49 --> Config Class Initialized
DEBUG - 2013-08-28 16:24:49 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:24:49 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:24:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:24:49 --> URI Class Initialized
DEBUG - 2013-08-28 16:24:49 --> Router Class Initialized
DEBUG - 2013-08-28 16:24:49 --> Output Class Initialized
DEBUG - 2013-08-28 16:24:49 --> Security Class Initialized
DEBUG - 2013-08-28 16:24:49 --> Input Class Initialized
DEBUG - 2013-08-28 16:24:50 --> XSS Filtering completed
DEBUG - 2013-08-28 16:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:24:50 --> Language Class Initialized
DEBUG - 2013-08-28 16:24:50 --> Loader Class Initialized
DEBUG - 2013-08-28 16:24:50 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:24:50 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:24:50 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:24:50 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:24:50 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:24:50 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:24:50 --> Session Class Initialized
DEBUG - 2013-08-28 16:24:50 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:24:50 --> Session routines successfully run
DEBUG - 2013-08-28 16:24:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:24:50 --> Controller Class Initialized
ERROR - 2013-08-28 16:24:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:24:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:24:51 --> Model Class Initialized
DEBUG - 2013-08-28 16:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:24:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:24:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:24:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:24:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:24:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:24:51 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:24:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:24:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:24:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:24:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:24:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:24:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:24:51 --> File loaded: application/views/tahun_ajarans/index.php
DEBUG - 2013-08-28 16:24:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:24:52 --> Final output sent to browser
DEBUG - 2013-08-28 16:24:52 --> Total execution time: 2.4681
DEBUG - 2013-08-28 16:24:52 --> Config Class Initialized
DEBUG - 2013-08-28 16:24:52 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:24:52 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:24:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:24:52 --> URI Class Initialized
DEBUG - 2013-08-28 16:24:52 --> Router Class Initialized
ERROR - 2013-08-28 16:24:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:25:05 --> Config Class Initialized
DEBUG - 2013-08-28 16:25:05 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:25:05 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:25:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:25:05 --> URI Class Initialized
DEBUG - 2013-08-28 16:25:05 --> Router Class Initialized
DEBUG - 2013-08-28 16:25:05 --> Output Class Initialized
DEBUG - 2013-08-28 16:25:05 --> Security Class Initialized
DEBUG - 2013-08-28 16:25:05 --> Input Class Initialized
DEBUG - 2013-08-28 16:25:05 --> XSS Filtering completed
DEBUG - 2013-08-28 16:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:25:05 --> Language Class Initialized
DEBUG - 2013-08-28 16:25:05 --> Loader Class Initialized
DEBUG - 2013-08-28 16:25:05 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:25:05 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:25:05 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:25:06 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:25:06 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:25:06 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:25:06 --> Session Class Initialized
DEBUG - 2013-08-28 16:25:06 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:25:06 --> Session routines successfully run
DEBUG - 2013-08-28 16:25:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:25:06 --> Controller Class Initialized
ERROR - 2013-08-28 16:25:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:25:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:25:06 --> Model Class Initialized
DEBUG - 2013-08-28 16:25:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:25:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:25:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:25:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:25:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:25:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:25:07 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:25:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:25:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:25:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:25:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:25:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:25:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:25:07 --> File loaded: application/views/mata_pelajarans/index.php
DEBUG - 2013-08-28 16:25:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:25:07 --> Final output sent to browser
DEBUG - 2013-08-28 16:25:07 --> Total execution time: 2.4131
DEBUG - 2013-08-28 16:25:07 --> Config Class Initialized
DEBUG - 2013-08-28 16:25:07 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:25:08 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:25:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:25:08 --> URI Class Initialized
DEBUG - 2013-08-28 16:25:08 --> Router Class Initialized
ERROR - 2013-08-28 16:25:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:25:50 --> Config Class Initialized
DEBUG - 2013-08-28 16:25:50 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:25:50 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:25:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:25:50 --> URI Class Initialized
DEBUG - 2013-08-28 16:25:50 --> Router Class Initialized
ERROR - 2013-08-28 16:25:50 --> 404 Page Not Found --> users
DEBUG - 2013-08-28 16:26:01 --> Config Class Initialized
DEBUG - 2013-08-28 16:26:01 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:26:01 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:26:02 --> URI Class Initialized
DEBUG - 2013-08-28 16:26:02 --> Router Class Initialized
DEBUG - 2013-08-28 16:26:02 --> Output Class Initialized
DEBUG - 2013-08-28 16:26:02 --> Security Class Initialized
DEBUG - 2013-08-28 16:26:02 --> Input Class Initialized
DEBUG - 2013-08-28 16:26:02 --> XSS Filtering completed
DEBUG - 2013-08-28 16:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:26:02 --> Language Class Initialized
DEBUG - 2013-08-28 16:26:02 --> Loader Class Initialized
DEBUG - 2013-08-28 16:26:02 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:26:02 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:26:02 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:26:02 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:26:02 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:26:02 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:26:02 --> Session Class Initialized
DEBUG - 2013-08-28 16:26:02 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:26:02 --> Session routines successfully run
DEBUG - 2013-08-28 16:26:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:26:03 --> Controller Class Initialized
ERROR - 2013-08-28 16:26:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:26:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:26:03 --> Model Class Initialized
DEBUG - 2013-08-28 16:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:26:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:26:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:26:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:26:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:26:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:26:03 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:26:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:26:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:26:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:26:04 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:26:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:26:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:26:04 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-28 16:26:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:26:04 --> Final output sent to browser
DEBUG - 2013-08-28 16:26:04 --> Total execution time: 2.4421
DEBUG - 2013-08-28 16:26:04 --> Config Class Initialized
DEBUG - 2013-08-28 16:26:04 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:26:04 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:26:04 --> URI Class Initialized
DEBUG - 2013-08-28 16:26:05 --> Router Class Initialized
ERROR - 2013-08-28 16:26:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:48:57 --> Config Class Initialized
DEBUG - 2013-08-28 16:48:57 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:48:57 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:48:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:48:57 --> URI Class Initialized
DEBUG - 2013-08-28 16:48:57 --> Router Class Initialized
DEBUG - 2013-08-28 16:48:57 --> Output Class Initialized
DEBUG - 2013-08-28 16:48:57 --> Security Class Initialized
DEBUG - 2013-08-28 16:48:57 --> Input Class Initialized
DEBUG - 2013-08-28 16:48:57 --> XSS Filtering completed
DEBUG - 2013-08-28 16:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:48:58 --> Language Class Initialized
DEBUG - 2013-08-28 16:48:58 --> Loader Class Initialized
DEBUG - 2013-08-28 16:48:58 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:48:58 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:48:58 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:48:58 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:48:58 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:48:58 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:48:58 --> Session Class Initialized
DEBUG - 2013-08-28 16:48:58 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:48:58 --> Session routines successfully run
DEBUG - 2013-08-28 16:48:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:48:58 --> Controller Class Initialized
ERROR - 2013-08-28 16:48:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:48:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:48:58 --> Model Class Initialized
DEBUG - 2013-08-28 16:48:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:48:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:48:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:48:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:48:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:48:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:48:59 --> Pagination Class Initialized
DEBUG - 2013-08-28 16:48:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:48:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:48:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:48:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:48:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:48:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:48:59 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-28 16:48:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:48:59 --> Final output sent to browser
DEBUG - 2013-08-28 16:48:59 --> Total execution time: 2.3781
DEBUG - 2013-08-28 16:49:00 --> Config Class Initialized
DEBUG - 2013-08-28 16:49:00 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:49:00 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:49:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:49:00 --> URI Class Initialized
DEBUG - 2013-08-28 16:49:00 --> Router Class Initialized
ERROR - 2013-08-28 16:49:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:49:03 --> Config Class Initialized
DEBUG - 2013-08-28 16:49:03 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:49:03 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:49:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:49:03 --> URI Class Initialized
DEBUG - 2013-08-28 16:49:03 --> Router Class Initialized
DEBUG - 2013-08-28 16:49:03 --> Output Class Initialized
DEBUG - 2013-08-28 16:49:03 --> Security Class Initialized
DEBUG - 2013-08-28 16:49:03 --> Input Class Initialized
DEBUG - 2013-08-28 16:49:03 --> XSS Filtering completed
DEBUG - 2013-08-28 16:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:49:03 --> Language Class Initialized
DEBUG - 2013-08-28 16:49:03 --> Loader Class Initialized
DEBUG - 2013-08-28 16:49:04 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:49:04 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:49:04 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:49:04 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:49:04 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:49:04 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:49:04 --> Session Class Initialized
DEBUG - 2013-08-28 16:49:04 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:49:04 --> Session routines successfully run
DEBUG - 2013-08-28 16:49:04 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:49:04 --> Controller Class Initialized
ERROR - 2013-08-28 16:49:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:49:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:49:04 --> Model Class Initialized
DEBUG - 2013-08-28 16:49:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:49:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:49:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:49:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:49:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:49:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:49:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:49:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:49:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:49:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:49:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:49:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:49:05 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-28 16:49:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:49:05 --> Final output sent to browser
DEBUG - 2013-08-28 16:49:05 --> Total execution time: 2.3021
DEBUG - 2013-08-28 16:49:05 --> Config Class Initialized
DEBUG - 2013-08-28 16:49:06 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:49:06 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:49:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:49:06 --> URI Class Initialized
DEBUG - 2013-08-28 16:49:06 --> Router Class Initialized
ERROR - 2013-08-28 16:49:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-28 16:49:08 --> Config Class Initialized
DEBUG - 2013-08-28 16:49:09 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:49:09 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:49:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:49:09 --> URI Class Initialized
DEBUG - 2013-08-28 16:49:09 --> Router Class Initialized
DEBUG - 2013-08-28 16:49:09 --> Output Class Initialized
DEBUG - 2013-08-28 16:49:09 --> Security Class Initialized
DEBUG - 2013-08-28 16:49:09 --> Input Class Initialized
DEBUG - 2013-08-28 16:49:09 --> XSS Filtering completed
DEBUG - 2013-08-28 16:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-28 16:49:09 --> Language Class Initialized
DEBUG - 2013-08-28 16:49:09 --> Loader Class Initialized
DEBUG - 2013-08-28 16:49:09 --> Helper loaded: url_helper
DEBUG - 2013-08-28 16:49:09 --> Helper loaded: file_helper
DEBUG - 2013-08-28 16:49:09 --> Helper loaded: form_helper
DEBUG - 2013-08-28 16:49:09 --> Helper loaded: inflector_helper
DEBUG - 2013-08-28 16:49:09 --> Helper loaded: my_application_helper
DEBUG - 2013-08-28 16:49:09 --> Database Driver Class Initialized
DEBUG - 2013-08-28 16:49:09 --> Session Class Initialized
DEBUG - 2013-08-28 16:49:10 --> Helper loaded: string_helper
DEBUG - 2013-08-28 16:49:10 --> Session routines successfully run
DEBUG - 2013-08-28 16:49:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-28 16:49:10 --> Controller Class Initialized
ERROR - 2013-08-28 16:49:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:49:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:49:10 --> Model Class Initialized
DEBUG - 2013-08-28 16:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-28 16:49:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-28 16:49:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-28 16:49:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-28 16:49:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-28 16:49:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-28 16:49:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-28 16:49:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-28 16:49:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-28 16:49:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-28 16:49:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-28 16:49:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-28 16:49:11 --> File loaded: application/views/kelas_bagians/edit.php
DEBUG - 2013-08-28 16:49:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-28 16:49:11 --> Final output sent to browser
DEBUG - 2013-08-28 16:49:11 --> Total execution time: 2.3601
DEBUG - 2013-08-28 16:49:11 --> Config Class Initialized
DEBUG - 2013-08-28 16:49:11 --> Hooks Class Initialized
DEBUG - 2013-08-28 16:49:11 --> Utf8 Class Initialized
DEBUG - 2013-08-28 16:49:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-28 16:49:11 --> URI Class Initialized
DEBUG - 2013-08-28 16:49:11 --> Router Class Initialized
ERROR - 2013-08-28 16:49:11 --> 404 Page Not Found --> css
