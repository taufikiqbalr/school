<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-07 03:08:44 --> Config Class Initialized
DEBUG - 2013-09-07 03:08:44 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:08:44 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:08:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:08:44 --> URI Class Initialized
DEBUG - 2013-09-07 03:08:44 --> Router Class Initialized
DEBUG - 2013-09-07 03:08:44 --> Output Class Initialized
DEBUG - 2013-09-07 03:08:44 --> Security Class Initialized
DEBUG - 2013-09-07 03:08:44 --> Input Class Initialized
DEBUG - 2013-09-07 03:08:44 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:44 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:44 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:44 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:08:44 --> Language Class Initialized
DEBUG - 2013-09-07 03:08:44 --> Loader Class Initialized
DEBUG - 2013-09-07 03:08:44 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:08:44 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:08:44 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:08:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:08:44 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:08:44 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Session Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:08:45 --> A session cookie was not found.
DEBUG - 2013-09-07 03:08:45 --> Session routines successfully run
DEBUG - 2013-09-07 03:08:45 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Controller Class Initialized
ERROR - 2013-09-07 03:08:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:45 --> Model Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:08:45 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:08:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:08:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:08:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:45 --> Config Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:08:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:08:45 --> URI Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Router Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Output Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Security Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Input Class Initialized
DEBUG - 2013-09-07 03:08:45 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:45 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:08:45 --> Language Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Loader Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:08:45 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:08:45 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:08:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:08:45 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:08:45 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Session Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:08:45 --> Session routines successfully run
DEBUG - 2013-09-07 03:08:45 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Controller Class Initialized
ERROR - 2013-09-07 03:08:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:45 --> Model Class Initialized
DEBUG - 2013-09-07 03:08:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:08:45 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:08:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:08:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:08:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:08:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:08:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:08:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:08:46 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-07 03:08:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:08:46 --> Final output sent to browser
DEBUG - 2013-09-07 03:08:46 --> Total execution time: 0.3940
DEBUG - 2013-09-07 03:08:46 --> Config Class Initialized
DEBUG - 2013-09-07 03:08:46 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:08:46 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:08:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:08:46 --> URI Class Initialized
DEBUG - 2013-09-07 03:08:46 --> Router Class Initialized
ERROR - 2013-09-07 03:08:46 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:08:56 --> Config Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:08:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:08:56 --> URI Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Router Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Output Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Security Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Input Class Initialized
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:08:56 --> Language Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Loader Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:08:56 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Session Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:08:56 --> Session routines successfully run
DEBUG - 2013-09-07 03:08:56 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Controller Class Initialized
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:56 --> Model Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:08:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:08:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:56 --> Model Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Form Validation Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-07 03:08:56 --> Config Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:08:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:08:56 --> URI Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Router Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Output Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Security Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Input Class Initialized
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:08:56 --> Language Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Loader Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:08:56 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Session Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:08:56 --> Session routines successfully run
DEBUG - 2013-09-07 03:08:56 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Controller Class Initialized
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:56 --> Model Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:08:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:08:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:56 --> Config Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:08:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:08:56 --> URI Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Router Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Output Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Security Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Input Class Initialized
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> XSS Filtering completed
DEBUG - 2013-09-07 03:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:08:56 --> Language Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Loader Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:08:56 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Session Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:08:56 --> Session routines successfully run
DEBUG - 2013-09-07 03:08:56 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Controller Class Initialized
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:56 --> Model Class Initialized
DEBUG - 2013-09-07 03:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:08:56 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:08:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:08:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:08:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:08:57 --> Model Class Initialized
DEBUG - 2013-09-07 03:08:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:08:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:08:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:08:57 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:08:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:08:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:08:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:08:57 --> File loaded: application/views/home.php
DEBUG - 2013-09-07 03:08:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:08:57 --> Final output sent to browser
DEBUG - 2013-09-07 03:08:57 --> Total execution time: 0.5680
DEBUG - 2013-09-07 03:08:57 --> Config Class Initialized
DEBUG - 2013-09-07 03:08:57 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:08:57 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:08:57 --> URI Class Initialized
DEBUG - 2013-09-07 03:08:57 --> Router Class Initialized
ERROR - 2013-09-07 03:08:57 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:09:04 --> Config Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:09:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:09:04 --> URI Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Router Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Output Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Security Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Input Class Initialized
DEBUG - 2013-09-07 03:09:04 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:04 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:04 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:04 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:04 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:09:04 --> Language Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Loader Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:09:04 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:09:04 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:09:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:09:04 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:09:04 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Session Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:09:04 --> Session routines successfully run
DEBUG - 2013-09-07 03:09:04 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Controller Class Initialized
ERROR - 2013-09-07 03:09:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:09:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:09:04 --> Model Class Initialized
DEBUG - 2013-09-07 03:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:09:04 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:09:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:09:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:09:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:09:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:09:04 --> Model Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Config Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:09:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:09:27 --> URI Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Router Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Output Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Security Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Input Class Initialized
DEBUG - 2013-09-07 03:09:27 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:27 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:27 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:27 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:27 --> XSS Filtering completed
DEBUG - 2013-09-07 03:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:09:27 --> Language Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Loader Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:09:27 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:09:27 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:09:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:09:27 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:09:27 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Session Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:09:27 --> Session routines successfully run
DEBUG - 2013-09-07 03:09:27 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Controller Class Initialized
ERROR - 2013-09-07 03:09:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:09:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:09:27 --> Model Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:09:27 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:09:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:09:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:09:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:09:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:09:27 --> Model Class Initialized
DEBUG - 2013-09-07 03:09:27 --> Pagination Class Initialized
DEBUG - 2013-09-07 03:09:27 --> DB Transaction Failure
ERROR - 2013-09-07 03:09:27 --> Query error: Unknown column 'spss.bulan_tempo' in 'field list'
DEBUG - 2013-09-07 03:09:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-07 03:13:17 --> Config Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:13:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:13:17 --> URI Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Router Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Output Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Security Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Input Class Initialized
DEBUG - 2013-09-07 03:13:17 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:17 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:17 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:17 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:17 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:13:17 --> Language Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Loader Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:13:17 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:13:17 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:13:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:13:17 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:13:17 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Session Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:13:17 --> Session routines successfully run
DEBUG - 2013-09-07 03:13:17 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Controller Class Initialized
ERROR - 2013-09-07 03:13:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:13:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:13:17 --> Model Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:13:17 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:13:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:13:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:13:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:13:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:13:17 --> Model Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Pagination Class Initialized
DEBUG - 2013-09-07 03:13:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:13:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:13:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:13:17 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:13:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:13:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:13:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:13:17 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-07 03:13:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:13:17 --> Final output sent to browser
DEBUG - 2013-09-07 03:13:17 --> Total execution time: 0.3350
DEBUG - 2013-09-07 03:13:17 --> Config Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:13:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:13:17 --> URI Class Initialized
DEBUG - 2013-09-07 03:13:17 --> Router Class Initialized
ERROR - 2013-09-07 03:13:17 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:13:25 --> Config Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:13:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:13:25 --> URI Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Router Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Output Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Security Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Input Class Initialized
DEBUG - 2013-09-07 03:13:25 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:25 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:25 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:25 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:25 --> XSS Filtering completed
DEBUG - 2013-09-07 03:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:13:25 --> Language Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Loader Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:13:25 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:13:25 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:13:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:13:25 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:13:25 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Session Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:13:25 --> Session routines successfully run
DEBUG - 2013-09-07 03:13:25 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Controller Class Initialized
ERROR - 2013-09-07 03:13:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:13:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:13:25 --> Model Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:13:25 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:13:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:13:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:13:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:13:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:13:25 --> Model Class Initialized
DEBUG - 2013-09-07 03:13:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:13:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:13:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:13:25 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:13:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:13:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:13:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:13:25 --> File loaded: application/views/spps/new.php
DEBUG - 2013-09-07 03:13:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:13:25 --> Final output sent to browser
DEBUG - 2013-09-07 03:13:25 --> Total execution time: 0.3060
DEBUG - 2013-09-07 03:13:25 --> Config Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:13:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:13:25 --> URI Class Initialized
DEBUG - 2013-09-07 03:13:25 --> Router Class Initialized
ERROR - 2013-09-07 03:13:25 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:25:06 --> Config Class Initialized
DEBUG - 2013-09-07 03:25:06 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:25:06 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:25:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:25:06 --> URI Class Initialized
DEBUG - 2013-09-07 03:25:06 --> Router Class Initialized
DEBUG - 2013-09-07 03:25:06 --> Output Class Initialized
DEBUG - 2013-09-07 03:25:06 --> Security Class Initialized
DEBUG - 2013-09-07 03:25:06 --> Input Class Initialized
DEBUG - 2013-09-07 03:25:06 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:06 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:06 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:06 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:06 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:25:06 --> Language Class Initialized
DEBUG - 2013-09-07 03:25:07 --> Loader Class Initialized
DEBUG - 2013-09-07 03:25:07 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:25:07 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:25:07 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:25:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:25:07 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:25:07 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:25:07 --> Session Class Initialized
DEBUG - 2013-09-07 03:25:07 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:25:07 --> Session routines successfully run
DEBUG - 2013-09-07 03:25:07 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:25:07 --> Controller Class Initialized
ERROR - 2013-09-07 03:25:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:25:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:25:07 --> Model Class Initialized
DEBUG - 2013-09-07 03:25:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:25:07 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:25:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:25:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:25:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:25:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:25:07 --> Model Class Initialized
DEBUG - 2013-09-07 03:25:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:25:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:25:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:25:07 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:25:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:25:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:25:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:25:07 --> File loaded: application/views/spps/new.php
DEBUG - 2013-09-07 03:25:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:25:07 --> Final output sent to browser
DEBUG - 2013-09-07 03:25:07 --> Total execution time: 0.3450
DEBUG - 2013-09-07 03:25:07 --> Config Class Initialized
DEBUG - 2013-09-07 03:25:07 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:25:07 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:25:07 --> URI Class Initialized
DEBUG - 2013-09-07 03:25:07 --> Router Class Initialized
ERROR - 2013-09-07 03:25:07 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:25:44 --> Config Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:25:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:25:44 --> URI Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Router Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Output Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Security Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Input Class Initialized
DEBUG - 2013-09-07 03:25:44 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:44 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:44 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:44 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:44 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:25:44 --> Language Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Loader Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:25:44 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:25:44 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:25:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:25:44 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:25:44 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Session Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:25:44 --> Session routines successfully run
DEBUG - 2013-09-07 03:25:44 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Controller Class Initialized
ERROR - 2013-09-07 03:25:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:25:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:25:44 --> Model Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:25:44 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:25:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:25:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:25:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:25:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:25:44 --> Model Class Initialized
DEBUG - 2013-09-07 03:25:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:25:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:25:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:25:44 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:25:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:25:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:25:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:25:44 --> File loaded: application/views/spps/new.php
DEBUG - 2013-09-07 03:25:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:25:44 --> Final output sent to browser
DEBUG - 2013-09-07 03:25:44 --> Total execution time: 0.3470
DEBUG - 2013-09-07 03:25:44 --> Config Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:25:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:25:44 --> URI Class Initialized
DEBUG - 2013-09-07 03:25:44 --> Router Class Initialized
ERROR - 2013-09-07 03:25:44 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:25:55 --> Config Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:25:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:25:55 --> URI Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Router Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Output Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Security Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Input Class Initialized
DEBUG - 2013-09-07 03:25:55 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:55 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:55 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:55 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:55 --> XSS Filtering completed
DEBUG - 2013-09-07 03:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:25:55 --> Language Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Loader Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:25:55 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:25:55 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:25:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:25:55 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:25:55 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Session Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:25:55 --> Session routines successfully run
DEBUG - 2013-09-07 03:25:55 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Controller Class Initialized
ERROR - 2013-09-07 03:25:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:25:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:25:55 --> Model Class Initialized
DEBUG - 2013-09-07 03:25:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:25:55 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:25:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:25:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:25:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:25:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:25:55 --> Model Class Initialized
DEBUG - 2013-09-07 03:25:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:25:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:25:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:25:55 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:25:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:25:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:25:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:25:55 --> File loaded: application/views/spps/new.php
DEBUG - 2013-09-07 03:25:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:25:55 --> Final output sent to browser
DEBUG - 2013-09-07 03:25:55 --> Total execution time: 0.3440
DEBUG - 2013-09-07 03:25:56 --> Config Class Initialized
DEBUG - 2013-09-07 03:25:56 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:25:56 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:25:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:25:56 --> URI Class Initialized
DEBUG - 2013-09-07 03:25:56 --> Router Class Initialized
ERROR - 2013-09-07 03:25:56 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:36:48 --> Config Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:36:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:36:48 --> URI Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Router Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Output Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Security Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Input Class Initialized
DEBUG - 2013-09-07 03:36:48 --> XSS Filtering completed
DEBUG - 2013-09-07 03:36:48 --> XSS Filtering completed
DEBUG - 2013-09-07 03:36:48 --> XSS Filtering completed
DEBUG - 2013-09-07 03:36:48 --> XSS Filtering completed
DEBUG - 2013-09-07 03:36:48 --> XSS Filtering completed
DEBUG - 2013-09-07 03:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:36:48 --> Language Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Loader Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:36:48 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:36:48 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:36:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:36:48 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:36:48 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Session Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:36:48 --> Session routines successfully run
DEBUG - 2013-09-07 03:36:48 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Controller Class Initialized
ERROR - 2013-09-07 03:36:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:36:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:36:48 --> Model Class Initialized
DEBUG - 2013-09-07 03:36:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:36:48 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:36:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:36:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:36:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:36:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:36:48 --> Model Class Initialized
DEBUG - 2013-09-07 03:36:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:36:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:36:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:36:48 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:36:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:36:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:36:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:36:48 --> File loaded: application/views/spps/new.php
DEBUG - 2013-09-07 03:36:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:36:49 --> Final output sent to browser
DEBUG - 2013-09-07 03:36:49 --> Total execution time: 0.3750
DEBUG - 2013-09-07 03:36:49 --> Config Class Initialized
DEBUG - 2013-09-07 03:36:49 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:36:49 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:36:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:36:49 --> URI Class Initialized
DEBUG - 2013-09-07 03:36:49 --> Router Class Initialized
ERROR - 2013-09-07 03:36:49 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:37:35 --> Config Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:37:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:37:35 --> URI Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Router Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Output Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Security Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Input Class Initialized
DEBUG - 2013-09-07 03:37:35 --> XSS Filtering completed
DEBUG - 2013-09-07 03:37:35 --> XSS Filtering completed
DEBUG - 2013-09-07 03:37:35 --> XSS Filtering completed
DEBUG - 2013-09-07 03:37:35 --> XSS Filtering completed
DEBUG - 2013-09-07 03:37:35 --> XSS Filtering completed
DEBUG - 2013-09-07 03:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:37:35 --> Language Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Loader Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:37:35 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:37:35 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:37:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:37:35 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:37:35 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Session Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:37:35 --> Session routines successfully run
DEBUG - 2013-09-07 03:37:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Controller Class Initialized
ERROR - 2013-09-07 03:37:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:37:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:37:35 --> Model Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:37:35 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:37:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:37:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:37:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:37:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:37:35 --> Model Class Initialized
DEBUG - 2013-09-07 03:37:35 --> Pagination Class Initialized
DEBUG - 2013-09-07 03:37:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:37:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:37:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:37:35 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:37:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:37:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:37:35 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-07 03:37:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-07 03:37:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-07 03:37:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-07 03:37:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-07 03:37:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-07 03:37:35 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-07 03:37:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:37:35 --> Final output sent to browser
DEBUG - 2013-09-07 03:37:35 --> Total execution time: 0.4750
DEBUG - 2013-09-07 03:37:36 --> Config Class Initialized
DEBUG - 2013-09-07 03:37:36 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:37:36 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:37:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:37:36 --> URI Class Initialized
DEBUG - 2013-09-07 03:37:36 --> Router Class Initialized
ERROR - 2013-09-07 03:37:36 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:39:21 --> Config Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:39:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:39:21 --> URI Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Router Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Output Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Security Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Input Class Initialized
DEBUG - 2013-09-07 03:39:21 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:21 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:21 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:21 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:21 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:39:21 --> Language Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Loader Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:39:21 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:39:21 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:39:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:39:21 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:39:21 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Session Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:39:21 --> Session routines successfully run
DEBUG - 2013-09-07 03:39:21 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Controller Class Initialized
ERROR - 2013-09-07 03:39:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:39:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:39:21 --> Model Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:39:21 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:39:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:39:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:39:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:39:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:39:21 --> Model Class Initialized
DEBUG - 2013-09-07 03:39:21 --> Pagination Class Initialized
DEBUG - 2013-09-07 03:39:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:39:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:39:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:39:21 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:39:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:39:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:39:21 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-07 03:39:21 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-07 03:39:21 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-07 03:39:21 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-07 03:39:21 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-07 03:39:21 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-07 03:39:21 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-07 03:39:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:39:22 --> Final output sent to browser
DEBUG - 2013-09-07 03:39:22 --> Total execution time: 0.4230
DEBUG - 2013-09-07 03:39:22 --> Config Class Initialized
DEBUG - 2013-09-07 03:39:22 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:39:22 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:39:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:39:22 --> URI Class Initialized
DEBUG - 2013-09-07 03:39:22 --> Router Class Initialized
ERROR - 2013-09-07 03:39:22 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:39:28 --> Config Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:39:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:39:28 --> URI Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Router Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Output Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Security Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Input Class Initialized
DEBUG - 2013-09-07 03:39:28 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:28 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:28 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:28 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:28 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:39:28 --> Language Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Loader Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:39:28 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:39:28 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:39:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:39:28 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:39:28 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Session Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:39:28 --> Session routines successfully run
DEBUG - 2013-09-07 03:39:28 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Controller Class Initialized
ERROR - 2013-09-07 03:39:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:39:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:39:28 --> Model Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:39:28 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:39:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:39:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:39:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:39:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:39:28 --> Model Class Initialized
DEBUG - 2013-09-07 03:39:28 --> Pagination Class Initialized
DEBUG - 2013-09-07 03:39:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:39:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:39:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:39:28 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:39:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:39:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:39:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:39:28 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-07 03:39:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:39:28 --> Final output sent to browser
DEBUG - 2013-09-07 03:39:28 --> Total execution time: 0.3910
DEBUG - 2013-09-07 03:39:29 --> Config Class Initialized
DEBUG - 2013-09-07 03:39:29 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:39:29 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:39:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:39:29 --> URI Class Initialized
DEBUG - 2013-09-07 03:39:29 --> Router Class Initialized
ERROR - 2013-09-07 03:39:29 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 03:39:33 --> Config Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:39:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:39:33 --> URI Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Router Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Output Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Security Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Input Class Initialized
DEBUG - 2013-09-07 03:39:33 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:33 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:33 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:33 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:33 --> XSS Filtering completed
DEBUG - 2013-09-07 03:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 03:39:33 --> Language Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Loader Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Helper loaded: url_helper
DEBUG - 2013-09-07 03:39:33 --> Helper loaded: file_helper
DEBUG - 2013-09-07 03:39:33 --> Helper loaded: form_helper
DEBUG - 2013-09-07 03:39:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 03:39:33 --> Helper loaded: application_helper
DEBUG - 2013-09-07 03:39:33 --> Database Driver Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Session Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Helper loaded: string_helper
DEBUG - 2013-09-07 03:39:33 --> Session routines successfully run
DEBUG - 2013-09-07 03:39:33 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Controller Class Initialized
ERROR - 2013-09-07 03:39:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:39:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:39:33 --> Model Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 03:39:33 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 03:39:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 03:39:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 03:39:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 03:39:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 03:39:33 --> Model Class Initialized
DEBUG - 2013-09-07 03:39:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 03:39:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 03:39:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 03:39:33 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 03:39:33 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 03:39:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 03:39:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 03:39:33 --> File loaded: application/views/spps/new.php
DEBUG - 2013-09-07 03:39:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 03:39:33 --> Final output sent to browser
DEBUG - 2013-09-07 03:39:33 --> Total execution time: 0.3860
DEBUG - 2013-09-07 03:39:33 --> Config Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Hooks Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Utf8 Class Initialized
DEBUG - 2013-09-07 03:39:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 03:39:33 --> URI Class Initialized
DEBUG - 2013-09-07 03:39:33 --> Router Class Initialized
ERROR - 2013-09-07 03:39:33 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:18:35 --> Config Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:18:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:18:35 --> URI Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Router Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Output Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Security Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Input Class Initialized
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:18:35 --> Language Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Loader Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:18:35 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:18:35 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:18:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:18:35 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:18:35 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Session Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:18:35 --> Session routines successfully run
DEBUG - 2013-09-07 04:18:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Controller Class Initialized
ERROR - 2013-09-07 04:18:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:18:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:18:35 --> Model Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:18:35 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:18:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:18:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:18:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:18:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:18:35 --> Model Class Initialized
DEBUG - 2013-09-07 04:18:35 --> Form Validation Class Initialized
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:18:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-07 04:18:35 --> DB Transaction Failure
ERROR - 2013-09-07 04:18:35 --> Query error: Unknown column 'nis' in 'field list'
DEBUG - 2013-09-07 04:18:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-07 04:20:57 --> Config Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:20:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:20:57 --> URI Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Router Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Output Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Security Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Input Class Initialized
DEBUG - 2013-09-07 04:20:57 --> XSS Filtering completed
DEBUG - 2013-09-07 04:20:57 --> XSS Filtering completed
DEBUG - 2013-09-07 04:20:57 --> XSS Filtering completed
DEBUG - 2013-09-07 04:20:57 --> XSS Filtering completed
DEBUG - 2013-09-07 04:20:57 --> XSS Filtering completed
DEBUG - 2013-09-07 04:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:20:57 --> Language Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Loader Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:20:57 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:20:57 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:20:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:20:57 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:20:57 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Session Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:20:57 --> Session routines successfully run
DEBUG - 2013-09-07 04:20:57 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Controller Class Initialized
ERROR - 2013-09-07 04:20:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:20:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:20:57 --> Model Class Initialized
DEBUG - 2013-09-07 04:20:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:20:57 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:20:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:20:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:20:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:20:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:20:57 --> Model Class Initialized
DEBUG - 2013-09-07 04:20:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:20:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:20:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:20:57 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:20:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:20:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:20:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:20:58 --> File loaded: application/views/spps/new.php
DEBUG - 2013-09-07 04:20:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:20:58 --> Final output sent to browser
DEBUG - 2013-09-07 04:20:58 --> Total execution time: 0.4490
DEBUG - 2013-09-07 04:20:58 --> Config Class Initialized
DEBUG - 2013-09-07 04:20:58 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:20:58 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:20:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:20:58 --> URI Class Initialized
DEBUG - 2013-09-07 04:20:58 --> Router Class Initialized
ERROR - 2013-09-07 04:20:58 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:21:18 --> Config Class Initialized
DEBUG - 2013-09-07 04:21:18 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:21:18 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:21:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:21:18 --> URI Class Initialized
DEBUG - 2013-09-07 04:21:18 --> Router Class Initialized
DEBUG - 2013-09-07 04:21:18 --> Output Class Initialized
DEBUG - 2013-09-07 04:21:18 --> Security Class Initialized
DEBUG - 2013-09-07 04:21:18 --> Input Class Initialized
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:21:19 --> Language Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Loader Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:21:19 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Session Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:21:19 --> Session routines successfully run
DEBUG - 2013-09-07 04:21:19 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Controller Class Initialized
ERROR - 2013-09-07 04:21:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:21:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:21:19 --> Model Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:21:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:21:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:21:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:21:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:21:19 --> Model Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Form Validation Class Initialized
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-07 04:21:19 --> Config Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:21:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:21:19 --> URI Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Router Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Output Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Security Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Input Class Initialized
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> XSS Filtering completed
DEBUG - 2013-09-07 04:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:21:19 --> Language Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Loader Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:21:19 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Session Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:21:19 --> Session routines successfully run
DEBUG - 2013-09-07 04:21:19 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Controller Class Initialized
ERROR - 2013-09-07 04:21:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:21:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:21:19 --> Model Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:21:19 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:21:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:21:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:21:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:21:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:21:19 --> Model Class Initialized
DEBUG - 2013-09-07 04:21:19 --> Pagination Class Initialized
DEBUG - 2013-09-07 04:21:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:21:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:21:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:21:19 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:21:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:21:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:21:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:21:19 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-07 04:21:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:21:19 --> Final output sent to browser
DEBUG - 2013-09-07 04:21:19 --> Total execution time: 0.5220
DEBUG - 2013-09-07 04:21:20 --> Config Class Initialized
DEBUG - 2013-09-07 04:21:20 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:21:20 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:21:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:21:20 --> URI Class Initialized
DEBUG - 2013-09-07 04:21:20 --> Router Class Initialized
ERROR - 2013-09-07 04:21:20 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:22:31 --> Config Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:22:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:22:31 --> URI Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Router Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Output Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Security Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Input Class Initialized
DEBUG - 2013-09-07 04:22:31 --> XSS Filtering completed
DEBUG - 2013-09-07 04:22:31 --> XSS Filtering completed
DEBUG - 2013-09-07 04:22:31 --> XSS Filtering completed
DEBUG - 2013-09-07 04:22:31 --> XSS Filtering completed
DEBUG - 2013-09-07 04:22:31 --> XSS Filtering completed
DEBUG - 2013-09-07 04:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:22:31 --> Language Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Loader Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:22:31 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:22:31 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:22:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:22:31 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:22:31 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Session Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:22:31 --> Session routines successfully run
DEBUG - 2013-09-07 04:22:31 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Controller Class Initialized
ERROR - 2013-09-07 04:22:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:22:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:22:31 --> Model Class Initialized
DEBUG - 2013-09-07 04:22:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:22:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:22:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:22:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:22:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:22:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:22:31 --> Model Class Initialized
DEBUG - 2013-09-07 04:22:31 --> DB Transaction Failure
ERROR - 2013-09-07 04:22:31 --> Query error: Column 'id' in where clause is ambiguous
DEBUG - 2013-09-07 04:22:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-07 04:23:36 --> Config Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:23:36 --> URI Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Router Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Output Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Security Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Input Class Initialized
DEBUG - 2013-09-07 04:23:36 --> XSS Filtering completed
DEBUG - 2013-09-07 04:23:36 --> XSS Filtering completed
DEBUG - 2013-09-07 04:23:36 --> XSS Filtering completed
DEBUG - 2013-09-07 04:23:36 --> XSS Filtering completed
DEBUG - 2013-09-07 04:23:36 --> XSS Filtering completed
DEBUG - 2013-09-07 04:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:23:36 --> Language Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Loader Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:23:36 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:23:36 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:23:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:23:36 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:23:36 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Session Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:23:36 --> Session routines successfully run
DEBUG - 2013-09-07 04:23:36 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Controller Class Initialized
ERROR - 2013-09-07 04:23:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:23:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:23:36 --> Model Class Initialized
DEBUG - 2013-09-07 04:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:23:36 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:23:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:23:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:23:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:23:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:23:36 --> Model Class Initialized
DEBUG - 2013-09-07 04:23:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:23:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:23:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:23:36 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:23:36 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:23:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:23:36 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-07 04:23:36 --> Severity: Notice  --> Undefined variable: staff C:\xampp\htdocs\school\application\views\spps\show.php 81
DEBUG - 2013-09-07 04:23:36 --> File loaded: application/views/spps/show.php
DEBUG - 2013-09-07 04:23:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:23:36 --> Final output sent to browser
DEBUG - 2013-09-07 04:23:36 --> Total execution time: 0.5310
DEBUG - 2013-09-07 04:23:37 --> Config Class Initialized
DEBUG - 2013-09-07 04:23:37 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:23:37 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:23:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:23:37 --> URI Class Initialized
DEBUG - 2013-09-07 04:23:37 --> Router Class Initialized
ERROR - 2013-09-07 04:23:37 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:24:35 --> Config Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:24:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:24:35 --> URI Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Router Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Output Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Security Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Input Class Initialized
DEBUG - 2013-09-07 04:24:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:24:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:24:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:24:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:24:35 --> XSS Filtering completed
DEBUG - 2013-09-07 04:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:24:35 --> Language Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Loader Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:24:35 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:24:35 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:24:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:24:35 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:24:35 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Session Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:24:35 --> Session routines successfully run
DEBUG - 2013-09-07 04:24:35 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Controller Class Initialized
ERROR - 2013-09-07 04:24:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:24:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:24:35 --> Model Class Initialized
DEBUG - 2013-09-07 04:24:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:24:35 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:24:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:24:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:24:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:24:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:24:35 --> Model Class Initialized
DEBUG - 2013-09-07 04:24:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:24:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:24:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:24:35 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:24:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:24:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:24:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:24:35 --> File loaded: application/views/spps/show.php
DEBUG - 2013-09-07 04:24:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:24:35 --> Final output sent to browser
DEBUG - 2013-09-07 04:24:35 --> Total execution time: 0.4670
DEBUG - 2013-09-07 04:24:36 --> Config Class Initialized
DEBUG - 2013-09-07 04:24:36 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:24:36 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:24:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:24:36 --> URI Class Initialized
DEBUG - 2013-09-07 04:24:36 --> Router Class Initialized
ERROR - 2013-09-07 04:24:36 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:46:44 --> Config Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:46:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:46:44 --> URI Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Router Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Output Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Security Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Input Class Initialized
DEBUG - 2013-09-07 04:46:44 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:44 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:44 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:44 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:44 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:46:44 --> Language Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Loader Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:46:44 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:46:44 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:46:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:46:44 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:46:44 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Session Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:46:44 --> Session routines successfully run
DEBUG - 2013-09-07 04:46:44 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Controller Class Initialized
ERROR - 2013-09-07 04:46:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:46:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:46:44 --> Model Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:46:44 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:46:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:46:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:46:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:46:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:46:44 --> Model Class Initialized
DEBUG - 2013-09-07 04:46:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:46:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:46:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:46:44 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:46:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:46:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:46:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:46:44 --> File loaded: application/views/spps/show.php
DEBUG - 2013-09-07 04:46:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:46:44 --> Final output sent to browser
DEBUG - 2013-09-07 04:46:44 --> Total execution time: 0.5220
DEBUG - 2013-09-07 04:46:44 --> Config Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:46:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:46:44 --> URI Class Initialized
DEBUG - 2013-09-07 04:46:44 --> Router Class Initialized
ERROR - 2013-09-07 04:46:44 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:46:56 --> Config Class Initialized
DEBUG - 2013-09-07 04:46:56 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:46:56 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:46:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:46:56 --> URI Class Initialized
DEBUG - 2013-09-07 04:46:56 --> Router Class Initialized
DEBUG - 2013-09-07 04:46:56 --> Output Class Initialized
DEBUG - 2013-09-07 04:46:56 --> Security Class Initialized
DEBUG - 2013-09-07 04:46:56 --> Input Class Initialized
DEBUG - 2013-09-07 04:46:56 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:56 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:56 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:56 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:56 --> XSS Filtering completed
DEBUG - 2013-09-07 04:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:46:56 --> Language Class Initialized
DEBUG - 2013-09-07 04:46:57 --> Loader Class Initialized
DEBUG - 2013-09-07 04:46:57 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:46:57 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:46:57 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:46:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:46:57 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:46:57 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:46:57 --> Session Class Initialized
DEBUG - 2013-09-07 04:46:57 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:46:57 --> Session routines successfully run
DEBUG - 2013-09-07 04:46:57 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:46:57 --> Controller Class Initialized
ERROR - 2013-09-07 04:46:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:46:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:46:57 --> Model Class Initialized
DEBUG - 2013-09-07 04:46:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:46:57 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:46:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:46:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:46:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:46:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:46:57 --> Model Class Initialized
DEBUG - 2013-09-07 04:46:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:46:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:46:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:46:57 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:46:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:46:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:46:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:46:57 --> File loaded: application/views/spps/show.php
DEBUG - 2013-09-07 04:46:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:46:57 --> Final output sent to browser
DEBUG - 2013-09-07 04:46:57 --> Total execution time: 0.5350
DEBUG - 2013-09-07 04:46:57 --> Config Class Initialized
DEBUG - 2013-09-07 04:46:57 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:46:57 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:46:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:46:57 --> URI Class Initialized
DEBUG - 2013-09-07 04:46:57 --> Router Class Initialized
ERROR - 2013-09-07 04:46:57 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:52:16 --> Config Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:52:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:52:16 --> URI Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Router Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Output Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Security Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Input Class Initialized
DEBUG - 2013-09-07 04:52:16 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:16 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:16 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:16 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:16 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:52:16 --> Language Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Loader Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:52:16 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:52:16 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:52:16 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:52:16 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:52:16 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Session Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:52:16 --> Session garbage collection performed.
DEBUG - 2013-09-07 04:52:16 --> Session routines successfully run
DEBUG - 2013-09-07 04:52:16 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Controller Class Initialized
ERROR - 2013-09-07 04:52:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:52:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:52:16 --> Model Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:52:16 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:52:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:52:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:52:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:52:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:52:16 --> Model Class Initialized
DEBUG - 2013-09-07 04:52:16 --> Pagination Class Initialized
DEBUG - 2013-09-07 04:52:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:52:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:52:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:52:17 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:52:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:52:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:52:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:52:17 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-07 04:52:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:52:17 --> Final output sent to browser
DEBUG - 2013-09-07 04:52:17 --> Total execution time: 0.6610
DEBUG - 2013-09-07 04:52:17 --> Config Class Initialized
DEBUG - 2013-09-07 04:52:17 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:52:17 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:52:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:52:17 --> URI Class Initialized
DEBUG - 2013-09-07 04:52:17 --> Router Class Initialized
ERROR - 2013-09-07 04:52:17 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:52:40 --> Config Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:52:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:52:40 --> URI Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Router Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Output Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Security Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Input Class Initialized
DEBUG - 2013-09-07 04:52:40 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:40 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:40 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:40 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:40 --> XSS Filtering completed
DEBUG - 2013-09-07 04:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:52:40 --> Language Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Loader Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:52:40 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:52:40 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:52:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:52:40 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:52:40 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Session Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:52:40 --> Session routines successfully run
DEBUG - 2013-09-07 04:52:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Controller Class Initialized
ERROR - 2013-09-07 04:52:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:52:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:52:40 --> Model Class Initialized
DEBUG - 2013-09-07 04:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:52:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:52:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:52:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:52:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:52:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:52:40 --> Model Class Initialized
DEBUG - 2013-09-07 04:52:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:52:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:52:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:52:40 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:52:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:52:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:52:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:52:41 --> File loaded: application/views/spps/edit.php
DEBUG - 2013-09-07 04:52:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:52:41 --> Final output sent to browser
DEBUG - 2013-09-07 04:52:41 --> Total execution time: 0.6140
DEBUG - 2013-09-07 04:52:41 --> Config Class Initialized
DEBUG - 2013-09-07 04:52:41 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:52:41 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:52:41 --> URI Class Initialized
DEBUG - 2013-09-07 04:52:41 --> Router Class Initialized
ERROR - 2013-09-07 04:52:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:53:28 --> Config Class Initialized
DEBUG - 2013-09-07 04:53:28 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:53:28 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:53:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:53:28 --> URI Class Initialized
DEBUG - 2013-09-07 04:53:28 --> Router Class Initialized
DEBUG - 2013-09-07 04:53:28 --> Output Class Initialized
DEBUG - 2013-09-07 04:53:28 --> Security Class Initialized
DEBUG - 2013-09-07 04:53:28 --> Input Class Initialized
DEBUG - 2013-09-07 04:53:28 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:28 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:28 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:28 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:28 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:53:28 --> Language Class Initialized
DEBUG - 2013-09-07 04:53:28 --> Loader Class Initialized
DEBUG - 2013-09-07 04:53:28 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:53:28 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:53:28 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:53:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:53:28 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:53:29 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:53:29 --> Session Class Initialized
DEBUG - 2013-09-07 04:53:29 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:53:29 --> Session routines successfully run
DEBUG - 2013-09-07 04:53:29 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:53:29 --> Controller Class Initialized
ERROR - 2013-09-07 04:53:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:53:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:53:29 --> Model Class Initialized
DEBUG - 2013-09-07 04:53:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:53:29 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:53:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:53:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:53:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:53:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:53:29 --> Model Class Initialized
DEBUG - 2013-09-07 04:53:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:53:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:53:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:53:29 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:53:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:53:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:53:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:53:29 --> File loaded: application/views/spps/edit.php
DEBUG - 2013-09-07 04:53:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:53:29 --> Final output sent to browser
DEBUG - 2013-09-07 04:53:29 --> Total execution time: 0.5250
DEBUG - 2013-09-07 04:53:29 --> Config Class Initialized
DEBUG - 2013-09-07 04:53:29 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:53:29 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:53:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:53:29 --> URI Class Initialized
DEBUG - 2013-09-07 04:53:29 --> Router Class Initialized
ERROR - 2013-09-07 04:53:29 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:53:58 --> Config Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:53:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:53:58 --> URI Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Router Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Output Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Security Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Input Class Initialized
DEBUG - 2013-09-07 04:53:58 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:58 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:58 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:58 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:58 --> XSS Filtering completed
DEBUG - 2013-09-07 04:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:53:58 --> Language Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Loader Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:53:58 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:53:58 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:53:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:53:58 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:53:58 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Session Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:53:58 --> Session routines successfully run
DEBUG - 2013-09-07 04:53:58 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Controller Class Initialized
ERROR - 2013-09-07 04:53:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:53:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:53:58 --> Model Class Initialized
DEBUG - 2013-09-07 04:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:53:58 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:53:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:53:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:53:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:53:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:53:58 --> Model Class Initialized
DEBUG - 2013-09-07 04:53:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:53:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:53:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:53:59 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:53:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:53:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:53:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:53:59 --> File loaded: application/views/spps/edit.php
DEBUG - 2013-09-07 04:53:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:53:59 --> Final output sent to browser
DEBUG - 2013-09-07 04:53:59 --> Total execution time: 0.5370
DEBUG - 2013-09-07 04:53:59 --> Config Class Initialized
DEBUG - 2013-09-07 04:53:59 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:53:59 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:53:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:53:59 --> URI Class Initialized
DEBUG - 2013-09-07 04:53:59 --> Router Class Initialized
ERROR - 2013-09-07 04:53:59 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:57:32 --> Config Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:57:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:57:32 --> URI Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Router Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Output Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Security Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Input Class Initialized
DEBUG - 2013-09-07 04:57:32 --> XSS Filtering completed
DEBUG - 2013-09-07 04:57:32 --> XSS Filtering completed
DEBUG - 2013-09-07 04:57:32 --> XSS Filtering completed
DEBUG - 2013-09-07 04:57:32 --> XSS Filtering completed
DEBUG - 2013-09-07 04:57:32 --> XSS Filtering completed
DEBUG - 2013-09-07 04:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:57:32 --> Language Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Loader Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:57:32 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:57:32 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:57:32 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:57:32 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:57:32 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Session Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:57:32 --> Session routines successfully run
DEBUG - 2013-09-07 04:57:32 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Controller Class Initialized
ERROR - 2013-09-07 04:57:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:57:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:57:32 --> Model Class Initialized
DEBUG - 2013-09-07 04:57:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:57:32 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:57:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:57:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:57:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:57:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:57:32 --> Model Class Initialized
DEBUG - 2013-09-07 04:57:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:57:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:57:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:57:32 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:57:32 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:57:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:57:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:57:32 --> File loaded: application/views/spps/edit.php
DEBUG - 2013-09-07 04:57:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:57:32 --> Final output sent to browser
DEBUG - 2013-09-07 04:57:32 --> Total execution time: 0.5680
DEBUG - 2013-09-07 04:57:33 --> Config Class Initialized
DEBUG - 2013-09-07 04:57:33 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:57:33 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:57:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:57:33 --> URI Class Initialized
DEBUG - 2013-09-07 04:57:33 --> Router Class Initialized
ERROR - 2013-09-07 04:57:33 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:58:22 --> Config Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:58:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:58:22 --> URI Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Router Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Output Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Security Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Input Class Initialized
DEBUG - 2013-09-07 04:58:22 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:22 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:22 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:22 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:22 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:58:22 --> Language Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Loader Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:58:22 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:58:22 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:58:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:58:22 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:58:22 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Session Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:58:22 --> Session routines successfully run
DEBUG - 2013-09-07 04:58:22 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Controller Class Initialized
ERROR - 2013-09-07 04:58:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:58:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:58:22 --> Model Class Initialized
DEBUG - 2013-09-07 04:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:58:22 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:58:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:58:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:58:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:58:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:58:22 --> Model Class Initialized
DEBUG - 2013-09-07 04:58:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:58:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:58:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:58:22 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:58:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:58:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:58:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:58:22 --> File loaded: application/views/spps/edit.php
DEBUG - 2013-09-07 04:58:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:58:23 --> Final output sent to browser
DEBUG - 2013-09-07 04:58:23 --> Total execution time: 0.6880
DEBUG - 2013-09-07 04:58:23 --> Config Class Initialized
DEBUG - 2013-09-07 04:58:23 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:58:23 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:58:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:58:23 --> URI Class Initialized
DEBUG - 2013-09-07 04:58:23 --> Router Class Initialized
ERROR - 2013-09-07 04:58:23 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 04:58:25 --> Config Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:58:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:58:25 --> URI Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Router Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Output Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Security Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Input Class Initialized
DEBUG - 2013-09-07 04:58:25 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:25 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:25 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:25 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:25 --> XSS Filtering completed
DEBUG - 2013-09-07 04:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 04:58:25 --> Language Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Loader Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Helper loaded: url_helper
DEBUG - 2013-09-07 04:58:25 --> Helper loaded: file_helper
DEBUG - 2013-09-07 04:58:25 --> Helper loaded: form_helper
DEBUG - 2013-09-07 04:58:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 04:58:25 --> Helper loaded: application_helper
DEBUG - 2013-09-07 04:58:25 --> Database Driver Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Session Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Helper loaded: string_helper
DEBUG - 2013-09-07 04:58:25 --> Session routines successfully run
DEBUG - 2013-09-07 04:58:25 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Controller Class Initialized
ERROR - 2013-09-07 04:58:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:58:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:58:25 --> Model Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 04:58:25 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 04:58:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 04:58:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 04:58:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 04:58:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 04:58:25 --> Model Class Initialized
DEBUG - 2013-09-07 04:58:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 04:58:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 04:58:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 04:58:25 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 04:58:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 04:58:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 04:58:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 04:58:25 --> File loaded: application/views/spps/show.php
DEBUG - 2013-09-07 04:58:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 04:58:25 --> Final output sent to browser
DEBUG - 2013-09-07 04:58:25 --> Total execution time: 0.6180
DEBUG - 2013-09-07 04:58:25 --> Config Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Hooks Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Utf8 Class Initialized
DEBUG - 2013-09-07 04:58:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 04:58:25 --> URI Class Initialized
DEBUG - 2013-09-07 04:58:25 --> Router Class Initialized
ERROR - 2013-09-07 04:58:25 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 05:06:00 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:00 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Router Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Output Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Security Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Input Class Initialized
DEBUG - 2013-09-07 05:06:00 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:00 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:00 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:00 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:00 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:06:00 --> Language Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Loader Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:06:00 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:06:00 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:06:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:06:00 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:06:00 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Session Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:06:00 --> Session routines successfully run
DEBUG - 2013-09-07 05:06:00 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Controller Class Initialized
ERROR - 2013-09-07 05:06:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:00 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:06:00 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:06:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:06:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:06:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:01 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:01 --> Pagination Class Initialized
DEBUG - 2013-09-07 05:06:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 05:06:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 05:06:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 05:06:01 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 05:06:01 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 05:06:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 05:06:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 05:06:01 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-07 05:06:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 05:06:01 --> Final output sent to browser
DEBUG - 2013-09-07 05:06:01 --> Total execution time: 0.6740
DEBUG - 2013-09-07 05:06:01 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:01 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:01 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:01 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:01 --> Router Class Initialized
ERROR - 2013-09-07 05:06:01 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 05:06:05 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:05 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:05 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:05 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:05 --> Router Class Initialized
DEBUG - 2013-09-07 05:06:05 --> Output Class Initialized
DEBUG - 2013-09-07 05:06:05 --> Security Class Initialized
DEBUG - 2013-09-07 05:06:05 --> Input Class Initialized
DEBUG - 2013-09-07 05:06:05 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:05 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:05 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:05 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:06 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:06:06 --> Language Class Initialized
DEBUG - 2013-09-07 05:06:06 --> Loader Class Initialized
DEBUG - 2013-09-07 05:06:06 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:06:06 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:06:06 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:06:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:06:06 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:06:06 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:06:06 --> Session Class Initialized
DEBUG - 2013-09-07 05:06:06 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:06:06 --> Session routines successfully run
DEBUG - 2013-09-07 05:06:06 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:06:06 --> Controller Class Initialized
ERROR - 2013-09-07 05:06:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:06 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:06:06 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:06:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:06:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:06:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:06 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 05:06:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 05:06:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 05:06:06 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 05:06:06 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 05:06:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 05:06:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 05:06:06 --> File loaded: application/views/spps/new.php
DEBUG - 2013-09-07 05:06:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 05:06:06 --> Final output sent to browser
DEBUG - 2013-09-07 05:06:06 --> Total execution time: 0.6250
DEBUG - 2013-09-07 05:06:06 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:06 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:06 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:06 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:06 --> Router Class Initialized
ERROR - 2013-09-07 05:06:06 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 05:06:30 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:30 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Router Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Output Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Security Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Input Class Initialized
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:06:30 --> Language Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Loader Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:06:30 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:06:30 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:06:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:06:30 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:06:30 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Session Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:06:30 --> Session routines successfully run
DEBUG - 2013-09-07 05:06:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Controller Class Initialized
ERROR - 2013-09-07 05:06:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:30 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:06:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:06:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:06:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:06:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:30 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:30 --> Form Validation Class Initialized
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-07 05:06:31 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:31 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Router Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Output Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Security Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Input Class Initialized
DEBUG - 2013-09-07 05:06:31 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:31 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:31 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:31 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:31 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:06:31 --> Language Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Loader Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:06:31 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:06:31 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:06:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:06:31 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:06:31 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Session Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:06:31 --> Session garbage collection performed.
DEBUG - 2013-09-07 05:06:31 --> Session routines successfully run
DEBUG - 2013-09-07 05:06:31 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Controller Class Initialized
ERROR - 2013-09-07 05:06:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:31 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:06:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:06:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:06:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:06:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:31 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Pagination Class Initialized
DEBUG - 2013-09-07 05:06:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 05:06:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 05:06:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 05:06:31 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 05:06:31 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 05:06:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 05:06:31 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 05:06:31 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-07 05:06:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 05:06:31 --> Final output sent to browser
DEBUG - 2013-09-07 05:06:31 --> Total execution time: 0.6830
DEBUG - 2013-09-07 05:06:31 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:31 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:31 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:32 --> Router Class Initialized
ERROR - 2013-09-07 05:06:32 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 05:06:40 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:40 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:40 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:40 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:40 --> Router Class Initialized
DEBUG - 2013-09-07 05:06:40 --> Output Class Initialized
DEBUG - 2013-09-07 05:06:40 --> Security Class Initialized
DEBUG - 2013-09-07 05:06:40 --> Input Class Initialized
DEBUG - 2013-09-07 05:06:40 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:40 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:40 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:40 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:40 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:06:40 --> Language Class Initialized
DEBUG - 2013-09-07 05:06:40 --> Loader Class Initialized
DEBUG - 2013-09-07 05:06:40 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:06:40 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:06:41 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:06:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:06:41 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:06:41 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:06:41 --> Session Class Initialized
DEBUG - 2013-09-07 05:06:41 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:06:41 --> Session routines successfully run
DEBUG - 2013-09-07 05:06:41 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:06:41 --> Controller Class Initialized
ERROR - 2013-09-07 05:06:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:41 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:06:41 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:06:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:06:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:06:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:41 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 05:06:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 05:06:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 05:06:41 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 05:06:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 05:06:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 05:06:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 05:06:41 --> File loaded: application/views/spps/show.php
DEBUG - 2013-09-07 05:06:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 05:06:41 --> Final output sent to browser
DEBUG - 2013-09-07 05:06:41 --> Total execution time: 0.6250
DEBUG - 2013-09-07 05:06:41 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:41 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:41 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:41 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:41 --> Router Class Initialized
ERROR - 2013-09-07 05:06:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 05:06:45 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:46 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Router Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Output Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Security Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Input Class Initialized
DEBUG - 2013-09-07 05:06:46 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:46 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:46 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:46 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:46 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:06:46 --> Language Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Loader Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:06:46 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:06:46 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:06:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:06:46 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:06:46 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Session Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:06:46 --> Session routines successfully run
DEBUG - 2013-09-07 05:06:46 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Controller Class Initialized
ERROR - 2013-09-07 05:06:46 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:46 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:06:46 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:06:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:06:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:06:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:46 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Pagination Class Initialized
DEBUG - 2013-09-07 05:06:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 05:06:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 05:06:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 05:06:46 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 05:06:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 05:06:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 05:06:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 05:06:46 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-07 05:06:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 05:06:46 --> Final output sent to browser
DEBUG - 2013-09-07 05:06:46 --> Total execution time: 0.7070
DEBUG - 2013-09-07 05:06:46 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:46 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:46 --> Router Class Initialized
ERROR - 2013-09-07 05:06:46 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 05:06:50 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:50 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Router Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Output Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Security Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Input Class Initialized
DEBUG - 2013-09-07 05:06:50 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:50 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:50 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:50 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:50 --> XSS Filtering completed
DEBUG - 2013-09-07 05:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:06:50 --> Language Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Loader Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:06:50 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:06:50 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:06:50 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:06:50 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:06:50 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Session Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:06:50 --> Session routines successfully run
DEBUG - 2013-09-07 05:06:50 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Controller Class Initialized
ERROR - 2013-09-07 05:06:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:50 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:06:50 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:06:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:06:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:06:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:06:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:06:50 --> Model Class Initialized
DEBUG - 2013-09-07 05:06:50 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 05:06:50 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 05:06:50 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 05:06:50 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 05:06:50 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 05:06:50 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 05:06:50 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 05:06:50 --> File loaded: application/views/spps/new.php
DEBUG - 2013-09-07 05:06:50 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 05:06:50 --> Final output sent to browser
DEBUG - 2013-09-07 05:06:50 --> Total execution time: 0.7550
DEBUG - 2013-09-07 05:06:51 --> Config Class Initialized
DEBUG - 2013-09-07 05:06:51 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:06:51 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:06:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:06:51 --> URI Class Initialized
DEBUG - 2013-09-07 05:06:51 --> Router Class Initialized
ERROR - 2013-09-07 05:06:51 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 05:07:09 --> Config Class Initialized
DEBUG - 2013-09-07 05:07:09 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:07:09 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:07:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:07:09 --> URI Class Initialized
DEBUG - 2013-09-07 05:07:09 --> Router Class Initialized
DEBUG - 2013-09-07 05:07:09 --> Output Class Initialized
DEBUG - 2013-09-07 05:07:09 --> Security Class Initialized
DEBUG - 2013-09-07 05:07:09 --> Input Class Initialized
DEBUG - 2013-09-07 05:07:09 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:09 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:09 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:09 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:07:10 --> Language Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Loader Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:07:10 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Session Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:07:10 --> Session routines successfully run
DEBUG - 2013-09-07 05:07:10 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Controller Class Initialized
ERROR - 2013-09-07 05:07:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:07:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:07:10 --> Model Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:07:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:07:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:07:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:07:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:07:10 --> Model Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Form Validation Class Initialized
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-07 05:07:10 --> Config Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:07:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:07:10 --> URI Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Router Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Output Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Security Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Input Class Initialized
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:07:10 --> Language Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Loader Class Initialized
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:07:10 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:07:11 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:07:11 --> Session Class Initialized
DEBUG - 2013-09-07 05:07:11 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:07:11 --> Session routines successfully run
DEBUG - 2013-09-07 05:07:11 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:07:11 --> Controller Class Initialized
ERROR - 2013-09-07 05:07:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:07:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:07:11 --> Model Class Initialized
DEBUG - 2013-09-07 05:07:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:07:11 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:07:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:07:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:07:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:07:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:07:11 --> Model Class Initialized
DEBUG - 2013-09-07 05:07:11 --> Pagination Class Initialized
DEBUG - 2013-09-07 05:07:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 05:07:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 05:07:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 05:07:11 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 05:07:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 05:07:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 05:07:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 05:07:11 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-07 05:07:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 05:07:11 --> Final output sent to browser
DEBUG - 2013-09-07 05:07:11 --> Total execution time: 0.7610
DEBUG - 2013-09-07 05:07:11 --> Config Class Initialized
DEBUG - 2013-09-07 05:07:11 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:07:11 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:07:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:07:11 --> URI Class Initialized
DEBUG - 2013-09-07 05:07:11 --> Router Class Initialized
ERROR - 2013-09-07 05:07:11 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 05:07:15 --> Config Class Initialized
DEBUG - 2013-09-07 05:07:15 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:07:15 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:07:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:07:15 --> URI Class Initialized
DEBUG - 2013-09-07 05:07:15 --> Router Class Initialized
DEBUG - 2013-09-07 05:07:15 --> Output Class Initialized
DEBUG - 2013-09-07 05:07:15 --> Security Class Initialized
DEBUG - 2013-09-07 05:07:15 --> Input Class Initialized
DEBUG - 2013-09-07 05:07:15 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:15 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:15 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:15 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:15 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:07:15 --> Language Class Initialized
DEBUG - 2013-09-07 05:07:15 --> Loader Class Initialized
DEBUG - 2013-09-07 05:07:15 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:07:15 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:07:15 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:07:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:07:15 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:07:16 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:07:16 --> Session Class Initialized
DEBUG - 2013-09-07 05:07:16 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:07:16 --> Session routines successfully run
DEBUG - 2013-09-07 05:07:16 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:07:16 --> Controller Class Initialized
ERROR - 2013-09-07 05:07:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:07:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:07:16 --> Model Class Initialized
DEBUG - 2013-09-07 05:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:07:16 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:07:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:07:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:07:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:07:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:07:16 --> Model Class Initialized
DEBUG - 2013-09-07 05:07:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 05:07:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 05:07:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 05:07:16 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 05:07:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 05:07:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 05:07:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 05:07:16 --> File loaded: application/views/spps/show.php
DEBUG - 2013-09-07 05:07:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 05:07:16 --> Final output sent to browser
DEBUG - 2013-09-07 05:07:16 --> Total execution time: 0.6760
DEBUG - 2013-09-07 05:07:16 --> Config Class Initialized
DEBUG - 2013-09-07 05:07:16 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:07:16 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:07:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:07:16 --> URI Class Initialized
DEBUG - 2013-09-07 05:07:16 --> Router Class Initialized
ERROR - 2013-09-07 05:07:16 --> 404 Page Not Found --> css
DEBUG - 2013-09-07 05:07:21 --> Config Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:07:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:07:21 --> URI Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Router Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Output Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Security Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Input Class Initialized
DEBUG - 2013-09-07 05:07:21 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:21 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:21 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:21 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:21 --> XSS Filtering completed
DEBUG - 2013-09-07 05:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-07 05:07:21 --> Language Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Loader Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Helper loaded: url_helper
DEBUG - 2013-09-07 05:07:21 --> Helper loaded: file_helper
DEBUG - 2013-09-07 05:07:21 --> Helper loaded: form_helper
DEBUG - 2013-09-07 05:07:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-07 05:07:21 --> Helper loaded: application_helper
DEBUG - 2013-09-07 05:07:21 --> Database Driver Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Session Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Helper loaded: string_helper
DEBUG - 2013-09-07 05:07:21 --> Session routines successfully run
DEBUG - 2013-09-07 05:07:21 --> XML-RPC Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Controller Class Initialized
ERROR - 2013-09-07 05:07:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:07:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:07:21 --> Model Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-07 05:07:21 --> Helper loaded: cookie_helper
DEBUG - 2013-09-07 05:07:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-07 05:07:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-07 05:07:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-07 05:07:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-07 05:07:21 --> Model Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Pagination Class Initialized
DEBUG - 2013-09-07 05:07:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-07 05:07:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-07 05:07:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-07 05:07:21 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-07 05:07:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-07 05:07:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-07 05:07:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-07 05:07:21 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-07 05:07:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-07 05:07:21 --> Final output sent to browser
DEBUG - 2013-09-07 05:07:21 --> Total execution time: 0.7210
DEBUG - 2013-09-07 05:07:21 --> Config Class Initialized
DEBUG - 2013-09-07 05:07:21 --> Hooks Class Initialized
DEBUG - 2013-09-07 05:07:22 --> Utf8 Class Initialized
DEBUG - 2013-09-07 05:07:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-07 05:07:22 --> URI Class Initialized
DEBUG - 2013-09-07 05:07:22 --> Router Class Initialized
ERROR - 2013-09-07 05:07:22 --> 404 Page Not Found --> css
