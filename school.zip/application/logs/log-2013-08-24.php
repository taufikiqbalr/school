<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-24 03:18:48 --> Config Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Hooks Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Utf8 Class Initialized
DEBUG - 2013-08-24 03:18:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-24 03:18:48 --> URI Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Router Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Output Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Security Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Input Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-24 03:18:48 --> Language Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Loader Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Helper loaded: url_helper
DEBUG - 2013-08-24 03:18:48 --> Helper loaded: file_helper
DEBUG - 2013-08-24 03:18:48 --> Helper loaded: form_helper
DEBUG - 2013-08-24 03:18:48 --> Database Driver Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Session Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Helper loaded: string_helper
DEBUG - 2013-08-24 03:18:48 --> A session cookie was not found.
DEBUG - 2013-08-24 03:18:48 --> Session routines successfully run
DEBUG - 2013-08-24 03:18:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Controller Class Initialized
ERROR - 2013-08-24 03:18:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-24 03:18:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-24 03:18:48 --> Model Class Initialized
DEBUG - 2013-08-24 03:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-24 03:18:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-24 03:18:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-24 03:18:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-24 03:18:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-24 03:18:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-24 03:18:49 --> Pagination Class Initialized
DEBUG - 2013-08-24 03:18:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-24 03:18:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-24 03:18:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-24 03:18:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-24 03:18:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-24 03:18:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-24 03:18:49 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-24 03:18:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-24 03:18:49 --> Final output sent to browser
DEBUG - 2013-08-24 03:18:49 --> Total execution time: 1.5901
DEBUG - 2013-08-24 03:18:49 --> Config Class Initialized
DEBUG - 2013-08-24 03:18:49 --> Hooks Class Initialized
DEBUG - 2013-08-24 03:18:49 --> Utf8 Class Initialized
DEBUG - 2013-08-24 03:18:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-24 03:18:49 --> URI Class Initialized
DEBUG - 2013-08-24 03:18:49 --> Router Class Initialized
ERROR - 2013-08-24 03:18:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-24 11:41:26 --> Config Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Hooks Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Utf8 Class Initialized
DEBUG - 2013-08-24 11:41:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-24 11:41:27 --> URI Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Router Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Output Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Security Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Input Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-24 11:41:27 --> Language Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Loader Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Helper loaded: url_helper
DEBUG - 2013-08-24 11:41:27 --> Helper loaded: file_helper
DEBUG - 2013-08-24 11:41:27 --> Helper loaded: form_helper
DEBUG - 2013-08-24 11:41:27 --> Database Driver Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Session Class Initialized
DEBUG - 2013-08-24 11:41:27 --> Helper loaded: string_helper
DEBUG - 2013-08-24 11:41:27 --> A session cookie was not found.
DEBUG - 2013-08-24 11:41:28 --> Session routines successfully run
DEBUG - 2013-08-24 11:41:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-24 11:41:28 --> Controller Class Initialized
ERROR - 2013-08-24 11:41:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-24 11:41:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-24 11:41:28 --> Model Class Initialized
DEBUG - 2013-08-24 11:41:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-24 11:41:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-24 11:41:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-24 11:41:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-24 11:41:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-24 11:41:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-24 11:41:28 --> Pagination Class Initialized
DEBUG - 2013-08-24 11:41:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-24 11:41:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-24 11:41:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-24 11:41:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-24 11:41:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-24 11:41:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-24 11:41:29 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-24 11:41:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-24 11:41:29 --> Final output sent to browser
DEBUG - 2013-08-24 11:41:29 --> Total execution time: 2.2801
DEBUG - 2013-08-24 11:41:29 --> Config Class Initialized
DEBUG - 2013-08-24 11:41:29 --> Hooks Class Initialized
DEBUG - 2013-08-24 11:41:29 --> Utf8 Class Initialized
DEBUG - 2013-08-24 11:41:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-24 11:41:29 --> URI Class Initialized
DEBUG - 2013-08-24 11:41:29 --> Router Class Initialized
ERROR - 2013-08-24 11:41:29 --> 404 Page Not Found --> css
