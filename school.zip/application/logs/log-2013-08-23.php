<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-23 09:01:54 --> Config Class Initialized
DEBUG - 2013-08-23 09:01:54 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:01:54 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:01:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:01:54 --> URI Class Initialized
DEBUG - 2013-08-23 09:01:54 --> Router Class Initialized
DEBUG - 2013-08-23 09:01:54 --> Output Class Initialized
DEBUG - 2013-08-23 09:01:54 --> Security Class Initialized
DEBUG - 2013-08-23 09:01:54 --> Input Class Initialized
DEBUG - 2013-08-23 09:01:54 --> XSS Filtering completed
DEBUG - 2013-08-23 09:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:01:54 --> Language Class Initialized
DEBUG - 2013-08-23 09:01:54 --> Loader Class Initialized
DEBUG - 2013-08-23 09:01:54 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:01:54 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:01:54 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:01:55 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:01:55 --> Session Class Initialized
DEBUG - 2013-08-23 09:01:55 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:01:55 --> A session cookie was not found.
DEBUG - 2013-08-23 09:01:55 --> Session routines successfully run
DEBUG - 2013-08-23 09:01:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:01:55 --> Controller Class Initialized
ERROR - 2013-08-23 09:01:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:01:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:01:55 --> Model Class Initialized
DEBUG - 2013-08-23 09:01:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:01:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:01:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:01:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:01:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:01:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:01:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:01:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:01:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:01:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:01:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:01:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:01:55 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-23 09:01:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:01:55 --> Final output sent to browser
DEBUG - 2013-08-23 09:01:55 --> Total execution time: 1.5351
DEBUG - 2013-08-23 09:01:56 --> Config Class Initialized
DEBUG - 2013-08-23 09:01:56 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:01:56 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:01:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:01:56 --> URI Class Initialized
DEBUG - 2013-08-23 09:01:56 --> Router Class Initialized
ERROR - 2013-08-23 09:01:56 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:01:58 --> Config Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:01:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:01:58 --> URI Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Router Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Output Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Security Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Input Class Initialized
DEBUG - 2013-08-23 09:01:58 --> XSS Filtering completed
DEBUG - 2013-08-23 09:01:58 --> XSS Filtering completed
DEBUG - 2013-08-23 09:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:01:58 --> Language Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Loader Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:01:58 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:01:58 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:01:58 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Session Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:01:58 --> Session routines successfully run
DEBUG - 2013-08-23 09:01:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Controller Class Initialized
ERROR - 2013-08-23 09:01:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:01:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:01:58 --> Model Class Initialized
DEBUG - 2013-08-23 09:01:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:01:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:01:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:01:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:01:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:01:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:01:58 --> Pagination Class Initialized
DEBUG - 2013-08-23 09:01:58 --> DB Transaction Failure
ERROR - 2013-08-23 09:01:58 --> Query error: Table 'school.siswas' doesn't exist
DEBUG - 2013-08-23 09:01:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-23 09:02:35 --> Config Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:02:35 --> URI Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Router Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Output Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Security Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Input Class Initialized
DEBUG - 2013-08-23 09:02:35 --> XSS Filtering completed
DEBUG - 2013-08-23 09:02:35 --> XSS Filtering completed
DEBUG - 2013-08-23 09:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:02:35 --> Language Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Loader Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:02:35 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:02:35 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:02:35 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Session Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:02:35 --> Session routines successfully run
DEBUG - 2013-08-23 09:02:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Controller Class Initialized
ERROR - 2013-08-23 09:02:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:02:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:02:35 --> Model Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:02:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:02:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:02:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:02:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:02:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:02:35 --> Pagination Class Initialized
DEBUG - 2013-08-23 09:02:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:02:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:02:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:02:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:02:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:02:35 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined variable: 1 C:\xampp\htdocs\school\application\views\siswas\index.php 79
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined variable: 2 C:\xampp\htdocs\school\application\views\siswas\index.php 79
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined variable: 3 C:\xampp\htdocs\school\application\views\siswas\index.php 79
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined variable: 4 C:\xampp\htdocs\school\application\views\siswas\index.php 79
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined variable: 5 C:\xampp\htdocs\school\application\views\siswas\index.php 79
ERROR - 2013-08-23 09:02:35 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
DEBUG - 2013-08-23 09:02:35 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-23 09:02:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:02:35 --> Final output sent to browser
DEBUG - 2013-08-23 09:02:35 --> Total execution time: 0.3360
DEBUG - 2013-08-23 09:02:35 --> Config Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:02:35 --> URI Class Initialized
DEBUG - 2013-08-23 09:02:35 --> Router Class Initialized
ERROR - 2013-08-23 09:02:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:03:10 --> Config Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:03:10 --> URI Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Router Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Output Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Security Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Input Class Initialized
DEBUG - 2013-08-23 09:03:10 --> XSS Filtering completed
DEBUG - 2013-08-23 09:03:10 --> XSS Filtering completed
DEBUG - 2013-08-23 09:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:03:10 --> Language Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Loader Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:03:10 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:03:10 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:03:10 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Session Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:03:10 --> Session routines successfully run
DEBUG - 2013-08-23 09:03:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Controller Class Initialized
ERROR - 2013-08-23 09:03:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:03:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:03:10 --> Model Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:03:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:03:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:03:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:03:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:03:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:03:10 --> Pagination Class Initialized
DEBUG - 2013-08-23 09:03:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:03:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:03:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:03:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:03:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:03:10 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-23 09:03:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:03:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:03:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:03:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:03:10 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
DEBUG - 2013-08-23 09:03:10 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-23 09:03:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:03:10 --> Final output sent to browser
DEBUG - 2013-08-23 09:03:10 --> Total execution time: 0.2890
DEBUG - 2013-08-23 09:03:10 --> Config Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:03:10 --> URI Class Initialized
DEBUG - 2013-08-23 09:03:10 --> Router Class Initialized
ERROR - 2013-08-23 09:03:10 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:20:20 --> Config Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:20:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:20:20 --> URI Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Router Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Output Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Security Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Input Class Initialized
DEBUG - 2013-08-23 09:20:20 --> XSS Filtering completed
DEBUG - 2013-08-23 09:20:20 --> XSS Filtering completed
DEBUG - 2013-08-23 09:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:20:20 --> Language Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Loader Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:20:20 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:20:20 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:20:20 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Session Class Initialized
DEBUG - 2013-08-23 09:20:20 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:20:21 --> Session routines successfully run
DEBUG - 2013-08-23 09:20:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:20:21 --> Controller Class Initialized
ERROR - 2013-08-23 09:20:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:20:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:20:21 --> Model Class Initialized
DEBUG - 2013-08-23 09:20:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:20:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:20:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:20:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:20:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:20:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:20:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:20:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:20:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:20:21 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:20:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:20:21 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-23 09:20:21 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\show.php 19
DEBUG - 2013-08-23 09:20:21 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-08-23 09:20:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:20:21 --> Final output sent to browser
DEBUG - 2013-08-23 09:20:21 --> Total execution time: 1.3061
DEBUG - 2013-08-23 09:20:21 --> Config Class Initialized
DEBUG - 2013-08-23 09:20:21 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:20:21 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:20:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:20:21 --> URI Class Initialized
DEBUG - 2013-08-23 09:20:21 --> Router Class Initialized
ERROR - 2013-08-23 09:20:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:20:39 --> Config Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:20:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:20:40 --> URI Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Router Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Output Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Security Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Input Class Initialized
DEBUG - 2013-08-23 09:20:40 --> XSS Filtering completed
DEBUG - 2013-08-23 09:20:40 --> XSS Filtering completed
DEBUG - 2013-08-23 09:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:20:40 --> Language Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Loader Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:20:40 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:20:40 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:20:40 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Session Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:20:40 --> Session garbage collection performed.
DEBUG - 2013-08-23 09:20:40 --> Session routines successfully run
DEBUG - 2013-08-23 09:20:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Controller Class Initialized
ERROR - 2013-08-23 09:20:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:20:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:20:40 --> Model Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:20:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:20:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:20:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:20:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:20:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:20:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:20:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:20:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:20:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:20:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:20:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:20:40 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-08-23 09:20:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:20:40 --> Final output sent to browser
DEBUG - 2013-08-23 09:20:40 --> Total execution time: 0.3210
DEBUG - 2013-08-23 09:20:40 --> Config Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:20:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:20:40 --> URI Class Initialized
DEBUG - 2013-08-23 09:20:40 --> Router Class Initialized
ERROR - 2013-08-23 09:20:40 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:20:48 --> Config Class Initialized
DEBUG - 2013-08-23 09:20:48 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:20:48 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:20:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:20:49 --> URI Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Router Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Output Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Security Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Input Class Initialized
DEBUG - 2013-08-23 09:20:49 --> XSS Filtering completed
DEBUG - 2013-08-23 09:20:49 --> XSS Filtering completed
DEBUG - 2013-08-23 09:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:20:49 --> Language Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Loader Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:20:49 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:20:49 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:20:49 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Session Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:20:49 --> Session routines successfully run
DEBUG - 2013-08-23 09:20:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Controller Class Initialized
ERROR - 2013-08-23 09:20:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:20:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:20:49 --> Model Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:20:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:20:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:20:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:20:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:20:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:20:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:20:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:20:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:20:49 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:20:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:20:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:20:49 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-08-23 09:20:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:20:49 --> Final output sent to browser
DEBUG - 2013-08-23 09:20:49 --> Total execution time: 0.3310
DEBUG - 2013-08-23 09:20:49 --> Config Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:20:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:20:49 --> URI Class Initialized
DEBUG - 2013-08-23 09:20:49 --> Router Class Initialized
ERROR - 2013-08-23 09:20:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:21:07 --> Config Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:21:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:21:07 --> URI Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Router Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Output Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Security Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Input Class Initialized
DEBUG - 2013-08-23 09:21:07 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:07 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:21:07 --> Language Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Loader Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:21:07 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:21:07 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:21:07 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Session Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:21:07 --> Session routines successfully run
DEBUG - 2013-08-23 09:21:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Controller Class Initialized
ERROR - 2013-08-23 09:21:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:21:07 --> Model Class Initialized
DEBUG - 2013-08-23 09:21:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:21:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:21:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:21:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:21:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:07 --> 404 Page Not Found --> 
DEBUG - 2013-08-23 09:21:13 --> Config Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:21:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:21:13 --> URI Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Router Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Output Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Security Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Input Class Initialized
DEBUG - 2013-08-23 09:21:13 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:13 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:21:13 --> Language Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Loader Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:21:13 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:21:13 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:21:13 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Session Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:21:13 --> Session routines successfully run
DEBUG - 2013-08-23 09:21:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Controller Class Initialized
ERROR - 2013-08-23 09:21:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:21:13 --> Model Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:21:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:21:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:21:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:21:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:21:13 --> Pagination Class Initialized
DEBUG - 2013-08-23 09:21:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:21:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:21:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:21:13 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:21:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:21:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:21:13 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-23 09:21:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:21:13 --> Final output sent to browser
DEBUG - 2013-08-23 09:21:13 --> Total execution time: 0.3280
DEBUG - 2013-08-23 09:21:13 --> Config Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:21:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:21:13 --> URI Class Initialized
DEBUG - 2013-08-23 09:21:13 --> Router Class Initialized
ERROR - 2013-08-23 09:21:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:21:16 --> Config Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:21:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:21:16 --> URI Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Router Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Output Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Security Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Input Class Initialized
DEBUG - 2013-08-23 09:21:16 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:16 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:21:16 --> Language Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Loader Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:21:16 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:21:16 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:21:16 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Session Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:21:16 --> Session routines successfully run
DEBUG - 2013-08-23 09:21:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Controller Class Initialized
ERROR - 2013-08-23 09:21:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:21:16 --> Model Class Initialized
DEBUG - 2013-08-23 09:21:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:21:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:21:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:21:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:21:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:21:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:21:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:21:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:21:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:21:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:21:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:21:16 --> File loaded: application/views/kelas/show.php
DEBUG - 2013-08-23 09:21:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:21:16 --> Final output sent to browser
DEBUG - 2013-08-23 09:21:16 --> Total execution time: 0.3150
DEBUG - 2013-08-23 09:21:17 --> Config Class Initialized
DEBUG - 2013-08-23 09:21:17 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:21:17 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:21:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:21:17 --> URI Class Initialized
DEBUG - 2013-08-23 09:21:17 --> Router Class Initialized
ERROR - 2013-08-23 09:21:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:21:45 --> Config Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:21:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:21:45 --> URI Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Router Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Output Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Security Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Input Class Initialized
DEBUG - 2013-08-23 09:21:45 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:45 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:21:45 --> Language Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Loader Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:21:45 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:21:45 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:21:45 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Session Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:21:45 --> Session routines successfully run
DEBUG - 2013-08-23 09:21:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Controller Class Initialized
ERROR - 2013-08-23 09:21:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:21:45 --> Model Class Initialized
DEBUG - 2013-08-23 09:21:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:21:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:21:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:21:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:21:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:21:45 --> Pagination Class Initialized
DEBUG - 2013-08-23 09:21:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:21:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:21:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:21:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:21:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:21:45 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-23 09:21:45 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:21:45 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:21:45 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:21:45 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
ERROR - 2013-08-23 09:21:45 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 87
DEBUG - 2013-08-23 09:21:45 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-08-23 09:21:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:21:45 --> Final output sent to browser
DEBUG - 2013-08-23 09:21:45 --> Total execution time: 0.5700
DEBUG - 2013-08-23 09:21:46 --> Config Class Initialized
DEBUG - 2013-08-23 09:21:46 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:21:46 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:21:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:21:46 --> URI Class Initialized
DEBUG - 2013-08-23 09:21:46 --> Router Class Initialized
ERROR - 2013-08-23 09:21:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:21:48 --> Config Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:21:48 --> URI Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Router Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Output Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Security Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Input Class Initialized
DEBUG - 2013-08-23 09:21:48 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:48 --> XSS Filtering completed
DEBUG - 2013-08-23 09:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:21:48 --> Language Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Loader Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:21:48 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:21:48 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:21:48 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Session Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:21:48 --> Session routines successfully run
DEBUG - 2013-08-23 09:21:48 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Controller Class Initialized
ERROR - 2013-08-23 09:21:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:21:48 --> Model Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:21:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:21:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:21:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:21:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:21:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:21:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:21:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:21:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:21:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:21:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:21:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:21:48 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-08-23 09:21:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:21:48 --> Final output sent to browser
DEBUG - 2013-08-23 09:21:48 --> Total execution time: 0.3120
DEBUG - 2013-08-23 09:21:48 --> Config Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:21:48 --> URI Class Initialized
DEBUG - 2013-08-23 09:21:48 --> Router Class Initialized
ERROR - 2013-08-23 09:21:48 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:22:10 --> Config Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:22:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:22:10 --> URI Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Router Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Output Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Security Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Input Class Initialized
DEBUG - 2013-08-23 09:22:10 --> XSS Filtering completed
DEBUG - 2013-08-23 09:22:10 --> XSS Filtering completed
DEBUG - 2013-08-23 09:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:22:10 --> Language Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Loader Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:22:10 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:22:10 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:22:10 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Session Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:22:10 --> Session routines successfully run
DEBUG - 2013-08-23 09:22:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Controller Class Initialized
ERROR - 2013-08-23 09:22:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:22:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:22:10 --> Model Class Initialized
DEBUG - 2013-08-23 09:22:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:22:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:22:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:22:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:22:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:22:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:22:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:22:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:22:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:22:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:22:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:22:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:22:10 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-08-23 09:22:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:22:10 --> Final output sent to browser
DEBUG - 2013-08-23 09:22:10 --> Total execution time: 0.3060
DEBUG - 2013-08-23 09:22:11 --> Config Class Initialized
DEBUG - 2013-08-23 09:22:11 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:22:11 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:22:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:22:11 --> URI Class Initialized
DEBUG - 2013-08-23 09:22:11 --> Router Class Initialized
ERROR - 2013-08-23 09:22:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:23:44 --> Config Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:23:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:23:45 --> URI Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Router Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Output Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Security Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Input Class Initialized
DEBUG - 2013-08-23 09:23:45 --> XSS Filtering completed
DEBUG - 2013-08-23 09:23:45 --> XSS Filtering completed
DEBUG - 2013-08-23 09:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:23:45 --> Language Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Loader Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:23:45 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:23:45 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:23:45 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Session Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:23:45 --> Session routines successfully run
DEBUG - 2013-08-23 09:23:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Controller Class Initialized
ERROR - 2013-08-23 09:23:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:23:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:23:45 --> Model Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:23:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:23:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:23:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:23:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:23:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:23:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:23:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:23:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:23:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:23:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:23:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:23:45 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-08-23 09:23:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:23:45 --> Final output sent to browser
DEBUG - 2013-08-23 09:23:45 --> Total execution time: 0.3160
DEBUG - 2013-08-23 09:23:45 --> Config Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:23:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:23:45 --> URI Class Initialized
DEBUG - 2013-08-23 09:23:45 --> Router Class Initialized
ERROR - 2013-08-23 09:23:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:38:13 --> Config Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:38:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:38:13 --> URI Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Router Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Output Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Security Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Input Class Initialized
DEBUG - 2013-08-23 09:38:13 --> XSS Filtering completed
DEBUG - 2013-08-23 09:38:13 --> XSS Filtering completed
DEBUG - 2013-08-23 09:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:38:13 --> Language Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Loader Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:38:13 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:38:13 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:38:13 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Session Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:38:13 --> Session routines successfully run
DEBUG - 2013-08-23 09:38:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:38:13 --> Controller Class Initialized
ERROR - 2013-08-23 09:38:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:38:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:38:14 --> Model Class Initialized
DEBUG - 2013-08-23 09:38:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:38:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:38:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:38:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:38:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:38:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:38:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:38:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:38:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:38:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:38:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:38:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:38:14 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-08-23 09:38:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:38:14 --> Final output sent to browser
DEBUG - 2013-08-23 09:38:14 --> Total execution time: 1.6631
DEBUG - 2013-08-23 09:38:14 --> Config Class Initialized
DEBUG - 2013-08-23 09:38:14 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:38:14 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:38:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:38:14 --> URI Class Initialized
DEBUG - 2013-08-23 09:38:14 --> Router Class Initialized
ERROR - 2013-08-23 09:38:14 --> 404 Page Not Found --> css
DEBUG - 2013-08-23 09:39:19 --> Config Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:39:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:39:19 --> URI Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Router Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Output Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Security Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Input Class Initialized
DEBUG - 2013-08-23 09:39:19 --> XSS Filtering completed
DEBUG - 2013-08-23 09:39:19 --> XSS Filtering completed
DEBUG - 2013-08-23 09:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-23 09:39:19 --> Language Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Loader Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Helper loaded: url_helper
DEBUG - 2013-08-23 09:39:19 --> Helper loaded: file_helper
DEBUG - 2013-08-23 09:39:19 --> Helper loaded: form_helper
DEBUG - 2013-08-23 09:39:19 --> Database Driver Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Session Class Initialized
DEBUG - 2013-08-23 09:39:19 --> Helper loaded: string_helper
DEBUG - 2013-08-23 09:39:19 --> Session routines successfully run
DEBUG - 2013-08-23 09:39:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-23 09:39:20 --> Controller Class Initialized
ERROR - 2013-08-23 09:39:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:39:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:39:20 --> Model Class Initialized
DEBUG - 2013-08-23 09:39:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-23 09:39:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-23 09:39:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-23 09:39:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-23 09:39:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-23 09:39:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-23 09:39:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-23 09:39:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-23 09:39:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-23 09:39:20 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-23 09:39:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-23 09:39:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-23 09:39:20 --> File loaded: application/views/siswas/show.php
DEBUG - 2013-08-23 09:39:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-23 09:39:20 --> Final output sent to browser
DEBUG - 2013-08-23 09:39:20 --> Total execution time: 0.3350
DEBUG - 2013-08-23 09:39:20 --> Config Class Initialized
DEBUG - 2013-08-23 09:39:20 --> Hooks Class Initialized
DEBUG - 2013-08-23 09:39:20 --> Utf8 Class Initialized
DEBUG - 2013-08-23 09:39:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-23 09:39:20 --> URI Class Initialized
DEBUG - 2013-08-23 09:39:20 --> Router Class Initialized
ERROR - 2013-08-23 09:39:20 --> 404 Page Not Found --> css
