<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-19 03:51:27 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:27 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Router Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Output Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Security Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Input Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 03:51:27 --> Language Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Loader Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Helper loaded: url_helper
DEBUG - 2013-08-19 03:51:27 --> Helper loaded: file_helper
DEBUG - 2013-08-19 03:51:27 --> Helper loaded: form_helper
DEBUG - 2013-08-19 03:51:27 --> Database Driver Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Session Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Helper loaded: string_helper
DEBUG - 2013-08-19 03:51:27 --> A session cookie was not found.
DEBUG - 2013-08-19 03:51:27 --> Session routines successfully run
DEBUG - 2013-08-19 03:51:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Controller Class Initialized
ERROR - 2013-08-19 03:51:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 03:51:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 03:51:27 --> Model Class Initialized
DEBUG - 2013-08-19 03:51:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 03:51:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 03:51:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 03:51:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 03:51:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 03:51:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 03:51:28 --> Pagination Class Initialized
DEBUG - 2013-08-19 03:51:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 03:51:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 03:51:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 03:51:28 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 03:51:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 03:51:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 03:51:28 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 03:51:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 03:51:28 --> Final output sent to browser
DEBUG - 2013-08-19 03:51:28 --> Total execution time: 1.8921
DEBUG - 2013-08-19 03:51:29 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:29 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Router Class Initialized
DEBUG - 2013-08-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:29 --> URI Class Initialized
ERROR - 2013-08-19 03:51:29 --> 404 Page Not Found --> includescss
DEBUG - 2013-08-19 03:51:29 --> Router Class Initialized
DEBUG - 2013-08-19 03:51:29 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Router Class Initialized
ERROR - 2013-08-19 03:51:29 --> 404 Page Not Found --> includescss
ERROR - 2013-08-19 03:51:29 --> 404 Page Not Found --> includescss
DEBUG - 2013-08-19 03:51:29 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:29 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:29 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:29 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Router Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Router Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Router Class Initialized
ERROR - 2013-08-19 03:51:29 --> 404 Page Not Found --> includesjs
ERROR - 2013-08-19 03:51:29 --> 404 Page Not Found --> includesjs
ERROR - 2013-08-19 03:51:29 --> 404 Page Not Found --> includesjs
DEBUG - 2013-08-19 03:51:29 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:29 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Router Class Initialized
ERROR - 2013-08-19 03:51:29 --> 404 Page Not Found --> includesjs
DEBUG - 2013-08-19 03:51:29 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:29 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:29 --> Router Class Initialized
ERROR - 2013-08-19 03:51:29 --> 404 Page Not Found --> includesjs
DEBUG - 2013-08-19 03:51:41 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:41 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Router Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Output Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Security Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Input Class Initialized
DEBUG - 2013-08-19 03:51:41 --> XSS Filtering completed
DEBUG - 2013-08-19 03:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 03:51:41 --> Language Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Loader Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Helper loaded: url_helper
DEBUG - 2013-08-19 03:51:41 --> Helper loaded: file_helper
DEBUG - 2013-08-19 03:51:41 --> Helper loaded: form_helper
DEBUG - 2013-08-19 03:51:41 --> Database Driver Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Session Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Helper loaded: string_helper
DEBUG - 2013-08-19 03:51:41 --> Session routines successfully run
DEBUG - 2013-08-19 03:51:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Controller Class Initialized
ERROR - 2013-08-19 03:51:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 03:51:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 03:51:41 --> Model Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 03:51:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 03:51:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 03:51:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 03:51:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 03:51:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 03:51:41 --> Pagination Class Initialized
DEBUG - 2013-08-19 03:51:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 03:51:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 03:51:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 03:51:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 03:51:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 03:51:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 03:51:41 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 03:51:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 03:51:41 --> Final output sent to browser
DEBUG - 2013-08-19 03:51:41 --> Total execution time: 0.2680
DEBUG - 2013-08-19 03:51:41 --> Config Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Hooks Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Utf8 Class Initialized
DEBUG - 2013-08-19 03:51:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 03:51:41 --> URI Class Initialized
DEBUG - 2013-08-19 03:51:41 --> Router Class Initialized
ERROR - 2013-08-19 03:51:41 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 04:04:28 --> Config Class Initialized
DEBUG - 2013-08-19 04:04:28 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:04:28 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:04:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:04:28 --> URI Class Initialized
DEBUG - 2013-08-19 04:04:28 --> Router Class Initialized
ERROR - 2013-08-19 04:04:28 --> 404 Page Not Found --> includes
DEBUG - 2013-08-19 04:17:09 --> Config Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:17:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:17:09 --> URI Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Router Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Output Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Security Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Input Class Initialized
DEBUG - 2013-08-19 04:17:09 --> XSS Filtering completed
DEBUG - 2013-08-19 04:17:09 --> XSS Filtering completed
DEBUG - 2013-08-19 04:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 04:17:09 --> Language Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Loader Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Helper loaded: url_helper
DEBUG - 2013-08-19 04:17:09 --> Helper loaded: file_helper
DEBUG - 2013-08-19 04:17:09 --> Helper loaded: form_helper
DEBUG - 2013-08-19 04:17:09 --> Database Driver Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Session Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Helper loaded: string_helper
DEBUG - 2013-08-19 04:17:09 --> Session routines successfully run
DEBUG - 2013-08-19 04:17:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Controller Class Initialized
ERROR - 2013-08-19 04:17:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:17:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:17:09 --> Model Class Initialized
DEBUG - 2013-08-19 04:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 04:17:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 04:17:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 04:17:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 04:17:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:17:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:17:09 --> Pagination Class Initialized
DEBUG - 2013-08-19 04:17:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 04:17:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 04:17:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 04:17:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 04:17:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 04:17:10 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-19 04:17:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\school\application\views\user_groups\index.php 54
DEBUG - 2013-08-19 04:17:10 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 04:17:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 04:17:10 --> Final output sent to browser
DEBUG - 2013-08-19 04:17:10 --> Total execution time: 0.9671
DEBUG - 2013-08-19 04:17:10 --> Config Class Initialized
DEBUG - 2013-08-19 04:17:10 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:17:10 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:17:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:17:10 --> URI Class Initialized
DEBUG - 2013-08-19 04:17:10 --> Router Class Initialized
ERROR - 2013-08-19 04:17:10 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 04:18:36 --> Config Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:18:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:18:36 --> URI Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Router Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Output Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Security Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Input Class Initialized
DEBUG - 2013-08-19 04:18:36 --> XSS Filtering completed
DEBUG - 2013-08-19 04:18:36 --> XSS Filtering completed
DEBUG - 2013-08-19 04:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 04:18:36 --> Language Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Loader Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Helper loaded: url_helper
DEBUG - 2013-08-19 04:18:36 --> Helper loaded: file_helper
DEBUG - 2013-08-19 04:18:36 --> Helper loaded: form_helper
DEBUG - 2013-08-19 04:18:36 --> Database Driver Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Session Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Helper loaded: string_helper
DEBUG - 2013-08-19 04:18:36 --> Session routines successfully run
DEBUG - 2013-08-19 04:18:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 04:18:36 --> Controller Class Initialized
ERROR - 2013-08-19 04:18:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:18:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:18:37 --> Model Class Initialized
DEBUG - 2013-08-19 04:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 04:18:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 04:18:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 04:18:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 04:18:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:18:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:18:37 --> Pagination Class Initialized
DEBUG - 2013-08-19 04:18:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 04:18:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 04:18:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 04:18:37 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 04:18:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 04:18:37 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-19 04:18:37 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\school\application\views\user_groups\index.php 57
DEBUG - 2013-08-19 04:18:37 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 04:18:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 04:18:37 --> Final output sent to browser
DEBUG - 2013-08-19 04:18:37 --> Total execution time: 0.2220
DEBUG - 2013-08-19 04:18:37 --> Config Class Initialized
DEBUG - 2013-08-19 04:18:37 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:18:37 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:18:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:18:37 --> URI Class Initialized
DEBUG - 2013-08-19 04:18:37 --> Router Class Initialized
ERROR - 2013-08-19 04:18:37 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 04:19:00 --> Config Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:19:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:19:00 --> URI Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Router Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Output Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Security Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Input Class Initialized
DEBUG - 2013-08-19 04:19:00 --> XSS Filtering completed
DEBUG - 2013-08-19 04:19:00 --> XSS Filtering completed
DEBUG - 2013-08-19 04:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 04:19:00 --> Language Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Loader Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Helper loaded: url_helper
DEBUG - 2013-08-19 04:19:00 --> Helper loaded: file_helper
DEBUG - 2013-08-19 04:19:00 --> Helper loaded: form_helper
DEBUG - 2013-08-19 04:19:00 --> Database Driver Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Session Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Helper loaded: string_helper
DEBUG - 2013-08-19 04:19:00 --> Session routines successfully run
DEBUG - 2013-08-19 04:19:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Controller Class Initialized
ERROR - 2013-08-19 04:19:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:19:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:19:00 --> Model Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 04:19:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 04:19:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 04:19:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 04:19:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:19:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:19:00 --> Pagination Class Initialized
DEBUG - 2013-08-19 04:19:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 04:19:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 04:19:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 04:19:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 04:19:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 04:19:00 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-19 04:19:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\school\application\views\user_groups\index.php 57
DEBUG - 2013-08-19 04:19:00 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 04:19:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 04:19:00 --> Final output sent to browser
DEBUG - 2013-08-19 04:19:00 --> Total execution time: 0.2350
DEBUG - 2013-08-19 04:19:00 --> Config Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:19:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:19:00 --> URI Class Initialized
DEBUG - 2013-08-19 04:19:00 --> Router Class Initialized
ERROR - 2013-08-19 04:19:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 04:20:35 --> Config Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:20:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:20:35 --> URI Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Router Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Output Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Security Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Input Class Initialized
DEBUG - 2013-08-19 04:20:35 --> XSS Filtering completed
DEBUG - 2013-08-19 04:20:35 --> XSS Filtering completed
DEBUG - 2013-08-19 04:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 04:20:35 --> Language Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Loader Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Helper loaded: url_helper
DEBUG - 2013-08-19 04:20:35 --> Helper loaded: file_helper
DEBUG - 2013-08-19 04:20:35 --> Helper loaded: form_helper
DEBUG - 2013-08-19 04:20:35 --> Database Driver Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Session Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Helper loaded: string_helper
DEBUG - 2013-08-19 04:20:35 --> Session routines successfully run
DEBUG - 2013-08-19 04:20:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Controller Class Initialized
ERROR - 2013-08-19 04:20:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:20:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:20:35 --> Model Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 04:20:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 04:20:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 04:20:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 04:20:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:20:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:20:35 --> Pagination Class Initialized
DEBUG - 2013-08-19 04:20:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 04:20:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 04:20:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 04:20:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 04:20:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 04:20:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 04:20:35 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 04:20:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 04:20:35 --> Final output sent to browser
DEBUG - 2013-08-19 04:20:35 --> Total execution time: 0.2630
DEBUG - 2013-08-19 04:20:35 --> Config Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:20:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:20:35 --> URI Class Initialized
DEBUG - 2013-08-19 04:20:35 --> Router Class Initialized
ERROR - 2013-08-19 04:20:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 04:21:05 --> Config Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:21:05 --> URI Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Router Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Output Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Security Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Input Class Initialized
DEBUG - 2013-08-19 04:21:05 --> XSS Filtering completed
DEBUG - 2013-08-19 04:21:05 --> XSS Filtering completed
DEBUG - 2013-08-19 04:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 04:21:05 --> Language Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Loader Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Helper loaded: url_helper
DEBUG - 2013-08-19 04:21:05 --> Helper loaded: file_helper
DEBUG - 2013-08-19 04:21:05 --> Helper loaded: form_helper
DEBUG - 2013-08-19 04:21:05 --> Database Driver Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Session Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Helper loaded: string_helper
DEBUG - 2013-08-19 04:21:05 --> Session routines successfully run
DEBUG - 2013-08-19 04:21:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Controller Class Initialized
ERROR - 2013-08-19 04:21:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:21:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:21:05 --> Model Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 04:21:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 04:21:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 04:21:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 04:21:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:21:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:21:05 --> Pagination Class Initialized
DEBUG - 2013-08-19 04:21:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 04:21:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 04:21:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 04:21:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 04:21:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 04:21:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 04:21:05 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 04:21:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 04:21:05 --> Final output sent to browser
DEBUG - 2013-08-19 04:21:05 --> Total execution time: 0.2780
DEBUG - 2013-08-19 04:21:05 --> Config Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:21:05 --> URI Class Initialized
DEBUG - 2013-08-19 04:21:05 --> Router Class Initialized
ERROR - 2013-08-19 04:21:05 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 04:21:45 --> Config Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:21:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:21:45 --> URI Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Router Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Output Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Security Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Input Class Initialized
DEBUG - 2013-08-19 04:21:45 --> XSS Filtering completed
DEBUG - 2013-08-19 04:21:45 --> XSS Filtering completed
DEBUG - 2013-08-19 04:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 04:21:45 --> Language Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Loader Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Helper loaded: url_helper
DEBUG - 2013-08-19 04:21:45 --> Helper loaded: file_helper
DEBUG - 2013-08-19 04:21:45 --> Helper loaded: form_helper
DEBUG - 2013-08-19 04:21:45 --> Database Driver Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Session Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Helper loaded: string_helper
DEBUG - 2013-08-19 04:21:45 --> Session routines successfully run
DEBUG - 2013-08-19 04:21:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 04:21:45 --> Controller Class Initialized
ERROR - 2013-08-19 04:21:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:21:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:21:45 --> Model Class Initialized
DEBUG - 2013-08-19 04:21:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 04:21:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 04:21:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 04:21:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 04:21:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:21:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:21:46 --> Pagination Class Initialized
DEBUG - 2013-08-19 04:21:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 04:21:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 04:21:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 04:21:46 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 04:21:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 04:21:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 04:21:46 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 04:21:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 04:21:46 --> Final output sent to browser
DEBUG - 2013-08-19 04:21:46 --> Total execution time: 0.2570
DEBUG - 2013-08-19 04:21:46 --> Config Class Initialized
DEBUG - 2013-08-19 04:21:46 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:21:46 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:21:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:21:46 --> URI Class Initialized
DEBUG - 2013-08-19 04:21:46 --> Router Class Initialized
ERROR - 2013-08-19 04:21:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 04:22:29 --> Config Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:22:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:22:29 --> URI Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Router Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Output Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Security Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Input Class Initialized
DEBUG - 2013-08-19 04:22:29 --> XSS Filtering completed
DEBUG - 2013-08-19 04:22:29 --> XSS Filtering completed
DEBUG - 2013-08-19 04:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 04:22:29 --> Language Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Loader Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Helper loaded: url_helper
DEBUG - 2013-08-19 04:22:29 --> Helper loaded: file_helper
DEBUG - 2013-08-19 04:22:29 --> Helper loaded: form_helper
DEBUG - 2013-08-19 04:22:29 --> Database Driver Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Session Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Helper loaded: string_helper
DEBUG - 2013-08-19 04:22:29 --> Session routines successfully run
DEBUG - 2013-08-19 04:22:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Controller Class Initialized
ERROR - 2013-08-19 04:22:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:22:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:22:29 --> Model Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 04:22:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 04:22:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 04:22:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 04:22:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:22:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:22:29 --> Pagination Class Initialized
DEBUG - 2013-08-19 04:22:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 04:22:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 04:22:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 04:22:29 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 04:22:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 04:22:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 04:22:29 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 04:22:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 04:22:29 --> Final output sent to browser
DEBUG - 2013-08-19 04:22:29 --> Total execution time: 0.3150
DEBUG - 2013-08-19 04:22:29 --> Config Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:22:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:22:29 --> URI Class Initialized
DEBUG - 2013-08-19 04:22:29 --> Router Class Initialized
ERROR - 2013-08-19 04:22:29 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 04:22:59 --> Config Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:22:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:22:59 --> URI Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Router Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Output Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Security Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Input Class Initialized
DEBUG - 2013-08-19 04:22:59 --> XSS Filtering completed
DEBUG - 2013-08-19 04:22:59 --> XSS Filtering completed
DEBUG - 2013-08-19 04:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 04:22:59 --> Language Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Loader Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Helper loaded: url_helper
DEBUG - 2013-08-19 04:22:59 --> Helper loaded: file_helper
DEBUG - 2013-08-19 04:22:59 --> Helper loaded: form_helper
DEBUG - 2013-08-19 04:22:59 --> Database Driver Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Session Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Helper loaded: string_helper
DEBUG - 2013-08-19 04:22:59 --> Session routines successfully run
DEBUG - 2013-08-19 04:22:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Controller Class Initialized
ERROR - 2013-08-19 04:22:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:22:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:22:59 --> Model Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 04:22:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 04:22:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 04:22:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 04:22:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:22:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:22:59 --> Pagination Class Initialized
DEBUG - 2013-08-19 04:22:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 04:22:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 04:22:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 04:22:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 04:22:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 04:22:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 04:22:59 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 04:22:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 04:22:59 --> Final output sent to browser
DEBUG - 2013-08-19 04:22:59 --> Total execution time: 0.3380
DEBUG - 2013-08-19 04:22:59 --> Config Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:22:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:22:59 --> URI Class Initialized
DEBUG - 2013-08-19 04:22:59 --> Router Class Initialized
ERROR - 2013-08-19 04:22:59 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 04:25:37 --> Config Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:25:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:25:37 --> URI Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Router Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Output Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Security Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Input Class Initialized
DEBUG - 2013-08-19 04:25:37 --> XSS Filtering completed
DEBUG - 2013-08-19 04:25:37 --> XSS Filtering completed
DEBUG - 2013-08-19 04:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 04:25:37 --> Language Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Loader Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Helper loaded: url_helper
DEBUG - 2013-08-19 04:25:37 --> Helper loaded: file_helper
DEBUG - 2013-08-19 04:25:37 --> Helper loaded: form_helper
DEBUG - 2013-08-19 04:25:37 --> Database Driver Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Session Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Helper loaded: string_helper
DEBUG - 2013-08-19 04:25:37 --> Session routines successfully run
DEBUG - 2013-08-19 04:25:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Controller Class Initialized
ERROR - 2013-08-19 04:25:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:25:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:25:37 --> Model Class Initialized
DEBUG - 2013-08-19 04:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 04:25:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 04:25:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 04:25:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 04:25:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 04:25:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 04:25:37 --> Pagination Class Initialized
DEBUG - 2013-08-19 04:25:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 04:25:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 04:25:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 04:25:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 04:25:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 04:25:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 04:25:38 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-19 04:25:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 04:25:38 --> Final output sent to browser
DEBUG - 2013-08-19 04:25:38 --> Total execution time: 0.3430
DEBUG - 2013-08-19 04:25:38 --> Config Class Initialized
DEBUG - 2013-08-19 04:25:38 --> Hooks Class Initialized
DEBUG - 2013-08-19 04:25:38 --> Utf8 Class Initialized
DEBUG - 2013-08-19 04:25:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 04:25:38 --> URI Class Initialized
DEBUG - 2013-08-19 04:25:38 --> Router Class Initialized
ERROR - 2013-08-19 04:25:38 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 06:35:02 --> Config Class Initialized
DEBUG - 2013-08-19 06:35:02 --> Hooks Class Initialized
DEBUG - 2013-08-19 06:35:02 --> Utf8 Class Initialized
DEBUG - 2013-08-19 06:35:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 06:35:02 --> URI Class Initialized
DEBUG - 2013-08-19 06:35:03 --> Router Class Initialized
DEBUG - 2013-08-19 06:35:04 --> Output Class Initialized
DEBUG - 2013-08-19 06:35:04 --> Security Class Initialized
DEBUG - 2013-08-19 06:35:04 --> Input Class Initialized
DEBUG - 2013-08-19 06:35:04 --> XSS Filtering completed
DEBUG - 2013-08-19 06:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 06:35:04 --> Language Class Initialized
DEBUG - 2013-08-19 06:35:05 --> Loader Class Initialized
DEBUG - 2013-08-19 06:35:05 --> Helper loaded: url_helper
DEBUG - 2013-08-19 06:35:05 --> Helper loaded: file_helper
DEBUG - 2013-08-19 06:35:05 --> Helper loaded: form_helper
DEBUG - 2013-08-19 06:35:05 --> Database Driver Class Initialized
DEBUG - 2013-08-19 06:35:06 --> Session Class Initialized
DEBUG - 2013-08-19 06:35:06 --> Helper loaded: string_helper
DEBUG - 2013-08-19 06:35:06 --> A session cookie was not found.
DEBUG - 2013-08-19 06:35:07 --> Session routines successfully run
DEBUG - 2013-08-19 06:35:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 06:35:07 --> Controller Class Initialized
ERROR - 2013-08-19 06:35:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 06:35:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 06:35:07 --> Model Class Initialized
DEBUG - 2013-08-19 06:35:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 06:35:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 06:35:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 06:35:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 06:35:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 06:35:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 06:35:08 --> Pagination Class Initialized
DEBUG - 2013-08-19 06:35:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 06:35:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 06:35:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 06:35:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 06:35:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 06:35:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 06:35:08 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-19 06:35:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 06:35:08 --> Final output sent to browser
DEBUG - 2013-08-19 06:35:08 --> Total execution time: 10.4386
DEBUG - 2013-08-19 06:35:08 --> Config Class Initialized
DEBUG - 2013-08-19 06:35:08 --> Hooks Class Initialized
DEBUG - 2013-08-19 06:35:08 --> Utf8 Class Initialized
DEBUG - 2013-08-19 06:35:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 06:35:08 --> URI Class Initialized
DEBUG - 2013-08-19 06:35:08 --> Router Class Initialized
ERROR - 2013-08-19 06:35:08 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 06:38:21 --> Config Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Hooks Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Utf8 Class Initialized
DEBUG - 2013-08-19 06:38:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 06:38:21 --> URI Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Router Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Output Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Security Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Input Class Initialized
DEBUG - 2013-08-19 06:38:21 --> XSS Filtering completed
DEBUG - 2013-08-19 06:38:21 --> XSS Filtering completed
DEBUG - 2013-08-19 06:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 06:38:21 --> Language Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Loader Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Helper loaded: url_helper
DEBUG - 2013-08-19 06:38:21 --> Helper loaded: file_helper
DEBUG - 2013-08-19 06:38:21 --> Helper loaded: form_helper
DEBUG - 2013-08-19 06:38:21 --> Database Driver Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Session Class Initialized
DEBUG - 2013-08-19 06:38:21 --> Helper loaded: string_helper
DEBUG - 2013-08-19 06:38:21 --> Session routines successfully run
DEBUG - 2013-08-19 06:38:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 06:38:22 --> Controller Class Initialized
ERROR - 2013-08-19 06:38:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 06:38:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 06:38:22 --> Model Class Initialized
DEBUG - 2013-08-19 06:38:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 06:38:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 06:38:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 06:38:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 06:38:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 06:38:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 06:38:22 --> Pagination Class Initialized
DEBUG - 2013-08-19 06:38:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 06:38:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 06:38:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 06:38:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 06:38:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 06:38:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 06:38:22 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-19 06:38:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 06:38:22 --> Final output sent to browser
DEBUG - 2013-08-19 06:38:22 --> Total execution time: 0.3200
DEBUG - 2013-08-19 06:38:22 --> Config Class Initialized
DEBUG - 2013-08-19 06:38:22 --> Hooks Class Initialized
DEBUG - 2013-08-19 06:38:22 --> Utf8 Class Initialized
DEBUG - 2013-08-19 06:38:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 06:38:22 --> URI Class Initialized
DEBUG - 2013-08-19 06:38:22 --> Router Class Initialized
ERROR - 2013-08-19 06:38:22 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 06:38:53 --> Config Class Initialized
DEBUG - 2013-08-19 06:38:53 --> Hooks Class Initialized
DEBUG - 2013-08-19 06:38:53 --> Utf8 Class Initialized
DEBUG - 2013-08-19 06:38:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 06:38:53 --> URI Class Initialized
DEBUG - 2013-08-19 06:38:53 --> Router Class Initialized
ERROR - 2013-08-19 06:38:53 --> 404 Page Not Found --> groupprivileges
DEBUG - 2013-08-19 06:39:51 --> Config Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Hooks Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Utf8 Class Initialized
DEBUG - 2013-08-19 06:39:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 06:39:51 --> URI Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Router Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Output Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Security Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Input Class Initialized
DEBUG - 2013-08-19 06:39:51 --> XSS Filtering completed
DEBUG - 2013-08-19 06:39:51 --> XSS Filtering completed
DEBUG - 2013-08-19 06:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 06:39:51 --> Language Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Loader Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Helper loaded: url_helper
DEBUG - 2013-08-19 06:39:51 --> Helper loaded: file_helper
DEBUG - 2013-08-19 06:39:51 --> Helper loaded: form_helper
DEBUG - 2013-08-19 06:39:51 --> Database Driver Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Session Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Helper loaded: string_helper
DEBUG - 2013-08-19 06:39:51 --> Session routines successfully run
DEBUG - 2013-08-19 06:39:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Controller Class Initialized
ERROR - 2013-08-19 06:39:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 06:39:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 06:39:51 --> Model Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 06:39:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 06:39:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 06:39:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 06:39:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 06:39:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 06:39:51 --> Pagination Class Initialized
DEBUG - 2013-08-19 06:39:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 06:39:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 06:39:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 06:39:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 06:39:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 06:39:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 06:39:51 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 06:39:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 06:39:51 --> Final output sent to browser
DEBUG - 2013-08-19 06:39:51 --> Total execution time: 0.3750
DEBUG - 2013-08-19 06:39:51 --> Config Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Hooks Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Utf8 Class Initialized
DEBUG - 2013-08-19 06:39:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 06:39:51 --> URI Class Initialized
DEBUG - 2013-08-19 06:39:51 --> Router Class Initialized
ERROR - 2013-08-19 06:39:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 07:31:16 --> Config Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Hooks Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Utf8 Class Initialized
DEBUG - 2013-08-19 07:31:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 07:31:16 --> URI Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Router Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Output Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Security Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Input Class Initialized
DEBUG - 2013-08-19 07:31:16 --> XSS Filtering completed
DEBUG - 2013-08-19 07:31:16 --> XSS Filtering completed
DEBUG - 2013-08-19 07:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 07:31:16 --> Language Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Loader Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Helper loaded: url_helper
DEBUG - 2013-08-19 07:31:16 --> Helper loaded: file_helper
DEBUG - 2013-08-19 07:31:16 --> Helper loaded: form_helper
DEBUG - 2013-08-19 07:31:16 --> Database Driver Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Session Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Helper loaded: string_helper
DEBUG - 2013-08-19 07:31:16 --> Session garbage collection performed.
DEBUG - 2013-08-19 07:31:16 --> Session routines successfully run
DEBUG - 2013-08-19 07:31:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 07:31:16 --> Controller Class Initialized
ERROR - 2013-08-19 07:31:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 07:31:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 07:31:17 --> Model Class Initialized
DEBUG - 2013-08-19 07:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 07:31:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 07:31:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 07:31:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 07:31:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 07:31:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 07:31:17 --> Pagination Class Initialized
DEBUG - 2013-08-19 07:31:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 07:31:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 07:31:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 07:31:18 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 07:31:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 07:31:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 07:31:18 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-19 07:31:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 07:31:18 --> Final output sent to browser
DEBUG - 2013-08-19 07:31:18 --> Total execution time: 2.8312
DEBUG - 2013-08-19 07:31:18 --> Config Class Initialized
DEBUG - 2013-08-19 07:31:18 --> Hooks Class Initialized
DEBUG - 2013-08-19 07:31:18 --> Utf8 Class Initialized
DEBUG - 2013-08-19 07:31:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 07:31:18 --> URI Class Initialized
DEBUG - 2013-08-19 07:31:18 --> Router Class Initialized
ERROR - 2013-08-19 07:31:18 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 07:31:22 --> Config Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Hooks Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Utf8 Class Initialized
DEBUG - 2013-08-19 07:31:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 07:31:22 --> URI Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Router Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Output Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Security Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Input Class Initialized
DEBUG - 2013-08-19 07:31:22 --> XSS Filtering completed
DEBUG - 2013-08-19 07:31:22 --> XSS Filtering completed
DEBUG - 2013-08-19 07:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 07:31:22 --> Language Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Loader Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Helper loaded: url_helper
DEBUG - 2013-08-19 07:31:22 --> Helper loaded: file_helper
DEBUG - 2013-08-19 07:31:22 --> Helper loaded: form_helper
DEBUG - 2013-08-19 07:31:22 --> Database Driver Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Session Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Helper loaded: string_helper
DEBUG - 2013-08-19 07:31:22 --> Session routines successfully run
DEBUG - 2013-08-19 07:31:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Controller Class Initialized
ERROR - 2013-08-19 07:31:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 07:31:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 07:31:22 --> Model Class Initialized
DEBUG - 2013-08-19 07:31:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 07:31:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 07:31:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 07:31:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 07:31:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 07:31:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 07:31:22 --> Pagination Class Initialized
DEBUG - 2013-08-19 07:31:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 07:31:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 07:31:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 07:31:22 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 07:31:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 07:31:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 07:31:22 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-19 07:31:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 07:31:22 --> Final output sent to browser
DEBUG - 2013-08-19 07:31:22 --> Total execution time: 0.4960
DEBUG - 2013-08-19 07:31:23 --> Config Class Initialized
DEBUG - 2013-08-19 07:31:23 --> Hooks Class Initialized
DEBUG - 2013-08-19 07:31:23 --> Utf8 Class Initialized
DEBUG - 2013-08-19 07:31:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 07:31:23 --> URI Class Initialized
DEBUG - 2013-08-19 07:31:23 --> Router Class Initialized
ERROR - 2013-08-19 07:31:23 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 07:31:57 --> Config Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Hooks Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Utf8 Class Initialized
DEBUG - 2013-08-19 07:31:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 07:31:57 --> URI Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Router Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Output Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Security Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Input Class Initialized
DEBUG - 2013-08-19 07:31:57 --> XSS Filtering completed
DEBUG - 2013-08-19 07:31:57 --> XSS Filtering completed
DEBUG - 2013-08-19 07:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 07:31:57 --> Language Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Loader Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Helper loaded: url_helper
DEBUG - 2013-08-19 07:31:57 --> Helper loaded: file_helper
DEBUG - 2013-08-19 07:31:57 --> Helper loaded: form_helper
DEBUG - 2013-08-19 07:31:57 --> Database Driver Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Session Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Helper loaded: string_helper
DEBUG - 2013-08-19 07:31:57 --> Session routines successfully run
DEBUG - 2013-08-19 07:31:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Controller Class Initialized
ERROR - 2013-08-19 07:31:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 07:31:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 07:31:57 --> Model Class Initialized
DEBUG - 2013-08-19 07:31:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 07:31:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 07:31:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 07:31:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 07:31:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 07:31:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 07:31:57 --> Pagination Class Initialized
DEBUG - 2013-08-19 07:31:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 07:31:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 07:31:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 07:31:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 07:31:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 07:31:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 07:31:57 --> File loaded: application/views/user_groups/index.php
DEBUG - 2013-08-19 07:31:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 07:31:57 --> Final output sent to browser
DEBUG - 2013-08-19 07:31:57 --> Total execution time: 0.4380
DEBUG - 2013-08-19 07:31:58 --> Config Class Initialized
DEBUG - 2013-08-19 07:31:58 --> Hooks Class Initialized
DEBUG - 2013-08-19 07:31:58 --> Utf8 Class Initialized
DEBUG - 2013-08-19 07:31:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 07:31:58 --> URI Class Initialized
DEBUG - 2013-08-19 07:31:58 --> Router Class Initialized
ERROR - 2013-08-19 07:31:58 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 07:31:59 --> Config Class Initialized
DEBUG - 2013-08-19 07:31:59 --> Hooks Class Initialized
DEBUG - 2013-08-19 07:31:59 --> Utf8 Class Initialized
DEBUG - 2013-08-19 07:31:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 07:31:59 --> URI Class Initialized
DEBUG - 2013-08-19 07:31:59 --> Router Class Initialized
DEBUG - 2013-08-19 07:31:59 --> Output Class Initialized
DEBUG - 2013-08-19 07:31:59 --> Security Class Initialized
DEBUG - 2013-08-19 07:31:59 --> Input Class Initialized
DEBUG - 2013-08-19 07:31:59 --> XSS Filtering completed
DEBUG - 2013-08-19 07:31:59 --> XSS Filtering completed
DEBUG - 2013-08-19 07:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 07:31:59 --> Language Class Initialized
DEBUG - 2013-08-19 07:31:59 --> Loader Class Initialized
DEBUG - 2013-08-19 07:31:59 --> Helper loaded: url_helper
DEBUG - 2013-08-19 07:31:59 --> Helper loaded: file_helper
DEBUG - 2013-08-19 07:32:00 --> Helper loaded: form_helper
DEBUG - 2013-08-19 07:32:00 --> Database Driver Class Initialized
DEBUG - 2013-08-19 07:32:00 --> Session Class Initialized
DEBUG - 2013-08-19 07:32:00 --> Helper loaded: string_helper
DEBUG - 2013-08-19 07:32:00 --> Session routines successfully run
DEBUG - 2013-08-19 07:32:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 07:32:00 --> Controller Class Initialized
ERROR - 2013-08-19 07:32:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 07:32:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 07:32:00 --> Model Class Initialized
DEBUG - 2013-08-19 07:32:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 07:32:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 07:32:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 07:32:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 07:32:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 07:32:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 07:32:00 --> Pagination Class Initialized
DEBUG - 2013-08-19 07:32:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 07:32:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 07:32:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 07:32:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 07:32:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 07:32:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 07:32:00 --> File loaded: application/views/privileges/index.php
DEBUG - 2013-08-19 07:32:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 07:32:00 --> Final output sent to browser
DEBUG - 2013-08-19 07:32:00 --> Total execution time: 0.4630
DEBUG - 2013-08-19 07:32:02 --> Config Class Initialized
DEBUG - 2013-08-19 07:32:02 --> Hooks Class Initialized
DEBUG - 2013-08-19 07:32:03 --> Utf8 Class Initialized
DEBUG - 2013-08-19 07:32:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 07:32:03 --> URI Class Initialized
DEBUG - 2013-08-19 07:32:03 --> Router Class Initialized
ERROR - 2013-08-19 07:32:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 09:44:51 --> Config Class Initialized
DEBUG - 2013-08-19 09:44:51 --> Hooks Class Initialized
DEBUG - 2013-08-19 09:44:51 --> Utf8 Class Initialized
DEBUG - 2013-08-19 09:44:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 09:44:51 --> URI Class Initialized
DEBUG - 2013-08-19 09:44:51 --> Router Class Initialized
DEBUG - 2013-08-19 09:44:51 --> Output Class Initialized
DEBUG - 2013-08-19 09:44:51 --> Security Class Initialized
DEBUG - 2013-08-19 09:44:51 --> Input Class Initialized
DEBUG - 2013-08-19 09:44:51 --> XSS Filtering completed
DEBUG - 2013-08-19 09:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 09:44:51 --> Language Class Initialized
DEBUG - 2013-08-19 09:44:51 --> Loader Class Initialized
DEBUG - 2013-08-19 09:44:51 --> Helper loaded: url_helper
DEBUG - 2013-08-19 09:44:51 --> Helper loaded: file_helper
DEBUG - 2013-08-19 09:44:51 --> Helper loaded: form_helper
DEBUG - 2013-08-19 09:44:52 --> Database Driver Class Initialized
DEBUG - 2013-08-19 09:44:52 --> Session Class Initialized
DEBUG - 2013-08-19 09:44:52 --> Helper loaded: string_helper
DEBUG - 2013-08-19 09:44:52 --> A session cookie was not found.
DEBUG - 2013-08-19 09:44:52 --> Session routines successfully run
DEBUG - 2013-08-19 09:44:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 09:44:52 --> Controller Class Initialized
ERROR - 2013-08-19 09:44:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 09:44:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 09:44:52 --> Model Class Initialized
DEBUG - 2013-08-19 09:44:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 09:44:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 09:44:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 09:44:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 09:44:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 09:44:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 09:44:52 --> Pagination Class Initialized
DEBUG - 2013-08-19 09:44:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 09:44:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 09:44:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 09:44:52 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 09:44:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 09:44:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 09:44:52 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-19 09:44:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 09:44:52 --> Final output sent to browser
DEBUG - 2013-08-19 09:44:52 --> Total execution time: 1.6671
DEBUG - 2013-08-19 09:44:53 --> Config Class Initialized
DEBUG - 2013-08-19 09:44:53 --> Hooks Class Initialized
DEBUG - 2013-08-19 09:44:53 --> Utf8 Class Initialized
DEBUG - 2013-08-19 09:44:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 09:44:53 --> URI Class Initialized
DEBUG - 2013-08-19 09:44:53 --> Router Class Initialized
ERROR - 2013-08-19 09:44:53 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 09:45:00 --> Config Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Hooks Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Utf8 Class Initialized
DEBUG - 2013-08-19 09:45:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 09:45:00 --> URI Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Router Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Output Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Security Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Input Class Initialized
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 09:45:00 --> Language Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Loader Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Helper loaded: url_helper
DEBUG - 2013-08-19 09:45:00 --> Helper loaded: file_helper
DEBUG - 2013-08-19 09:45:00 --> Helper loaded: form_helper
DEBUG - 2013-08-19 09:45:00 --> Database Driver Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Session Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Helper loaded: string_helper
DEBUG - 2013-08-19 09:45:00 --> Session routines successfully run
DEBUG - 2013-08-19 09:45:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Controller Class Initialized
ERROR - 2013-08-19 09:45:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 09:45:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 09:45:00 --> Model Class Initialized
DEBUG - 2013-08-19 09:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 09:45:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 09:45:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 09:45:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 09:45:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 09:45:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 09:45:00 --> Pagination Class Initialized
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 09:45:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 09:45:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 09:45:00 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 09:45:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 09:45:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 09:45:00 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-19 09:45:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 09:45:00 --> Final output sent to browser
DEBUG - 2013-08-19 09:45:00 --> Total execution time: 0.6170
DEBUG - 2013-08-19 09:45:01 --> Config Class Initialized
DEBUG - 2013-08-19 09:45:01 --> Hooks Class Initialized
DEBUG - 2013-08-19 09:45:01 --> Utf8 Class Initialized
DEBUG - 2013-08-19 09:45:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 09:45:01 --> URI Class Initialized
DEBUG - 2013-08-19 09:45:01 --> Router Class Initialized
ERROR - 2013-08-19 09:45:01 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 09:45:07 --> Config Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Hooks Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Utf8 Class Initialized
DEBUG - 2013-08-19 09:45:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 09:45:07 --> URI Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Router Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Output Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Security Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Input Class Initialized
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 09:45:07 --> Language Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Loader Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Helper loaded: url_helper
DEBUG - 2013-08-19 09:45:07 --> Helper loaded: file_helper
DEBUG - 2013-08-19 09:45:07 --> Helper loaded: form_helper
DEBUG - 2013-08-19 09:45:07 --> Database Driver Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Session Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Helper loaded: string_helper
DEBUG - 2013-08-19 09:45:07 --> Session routines successfully run
DEBUG - 2013-08-19 09:45:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Controller Class Initialized
ERROR - 2013-08-19 09:45:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 09:45:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 09:45:07 --> Model Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 09:45:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 09:45:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 09:45:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 09:45:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 09:45:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 09:45:07 --> Pagination Class Initialized
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> XSS Filtering completed
DEBUG - 2013-08-19 09:45:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 09:45:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 09:45:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 09:45:07 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 09:45:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 09:45:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 09:45:07 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-19 09:45:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 09:45:07 --> Final output sent to browser
DEBUG - 2013-08-19 09:45:07 --> Total execution time: 0.5630
DEBUG - 2013-08-19 09:45:07 --> Config Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Hooks Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Utf8 Class Initialized
DEBUG - 2013-08-19 09:45:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 09:45:07 --> URI Class Initialized
DEBUG - 2013-08-19 09:45:07 --> Router Class Initialized
ERROR - 2013-08-19 09:45:07 --> 404 Page Not Found --> css
DEBUG - 2013-08-19 11:13:27 --> Config Class Initialized
DEBUG - 2013-08-19 11:13:27 --> Hooks Class Initialized
DEBUG - 2013-08-19 11:13:27 --> Utf8 Class Initialized
DEBUG - 2013-08-19 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 11:13:27 --> URI Class Initialized
DEBUG - 2013-08-19 11:13:27 --> Router Class Initialized
DEBUG - 2013-08-19 11:13:27 --> Output Class Initialized
DEBUG - 2013-08-19 11:13:27 --> Security Class Initialized
DEBUG - 2013-08-19 11:13:27 --> Input Class Initialized
DEBUG - 2013-08-19 11:13:27 --> XSS Filtering completed
DEBUG - 2013-08-19 11:13:27 --> XSS Filtering completed
DEBUG - 2013-08-19 11:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 11:13:27 --> Language Class Initialized
DEBUG - 2013-08-19 11:13:27 --> Loader Class Initialized
DEBUG - 2013-08-19 11:13:27 --> Helper loaded: url_helper
DEBUG - 2013-08-19 11:13:27 --> Helper loaded: file_helper
DEBUG - 2013-08-19 11:13:28 --> Helper loaded: form_helper
DEBUG - 2013-08-19 11:13:28 --> Database Driver Class Initialized
DEBUG - 2013-08-19 11:13:28 --> Session Class Initialized
DEBUG - 2013-08-19 11:13:28 --> Helper loaded: string_helper
DEBUG - 2013-08-19 11:13:28 --> Session routines successfully run
DEBUG - 2013-08-19 11:13:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 11:13:28 --> Controller Class Initialized
ERROR - 2013-08-19 11:13:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 11:13:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 11:13:28 --> Model Class Initialized
DEBUG - 2013-08-19 11:13:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 11:13:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 11:13:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 11:13:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 11:13:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 11:13:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 11:13:28 --> Pagination Class Initialized
DEBUG - 2013-08-19 11:13:28 --> DB Transaction Failure
ERROR - 2013-08-19 11:13:28 --> Query error: Unknown column 'user_privileges.ugrp_id' in 'on clause'
DEBUG - 2013-08-19 11:13:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-19 11:14:14 --> Config Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Hooks Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Utf8 Class Initialized
DEBUG - 2013-08-19 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 11:14:14 --> URI Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Router Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Output Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Security Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Input Class Initialized
DEBUG - 2013-08-19 11:14:14 --> XSS Filtering completed
DEBUG - 2013-08-19 11:14:14 --> XSS Filtering completed
DEBUG - 2013-08-19 11:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-19 11:14:14 --> Language Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Loader Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Helper loaded: url_helper
DEBUG - 2013-08-19 11:14:14 --> Helper loaded: file_helper
DEBUG - 2013-08-19 11:14:14 --> Helper loaded: form_helper
DEBUG - 2013-08-19 11:14:14 --> Database Driver Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Session Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Helper loaded: string_helper
DEBUG - 2013-08-19 11:14:14 --> Session routines successfully run
DEBUG - 2013-08-19 11:14:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Controller Class Initialized
ERROR - 2013-08-19 11:14:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 11:14:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 11:14:14 --> Model Class Initialized
DEBUG - 2013-08-19 11:14:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-19 11:14:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-19 11:14:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-19 11:14:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-19 11:14:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-19 11:14:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-19 11:14:14 --> Pagination Class Initialized
DEBUG - 2013-08-19 11:14:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-19 11:14:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-19 11:14:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-19 11:14:14 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-19 11:14:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-19 11:14:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-19 11:14:14 --> File loaded: application/views/group_privileges/index.php
DEBUG - 2013-08-19 11:14:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-19 11:14:14 --> Final output sent to browser
DEBUG - 2013-08-19 11:14:14 --> Total execution time: 0.5690
DEBUG - 2013-08-19 11:14:15 --> Config Class Initialized
DEBUG - 2013-08-19 11:14:15 --> Hooks Class Initialized
DEBUG - 2013-08-19 11:14:15 --> Utf8 Class Initialized
DEBUG - 2013-08-19 11:14:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-19 11:14:15 --> URI Class Initialized
DEBUG - 2013-08-19 11:14:15 --> Router Class Initialized
ERROR - 2013-08-19 11:14:15 --> 404 Page Not Found --> css
