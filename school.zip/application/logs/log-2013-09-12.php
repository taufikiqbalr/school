<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-09-12 16:06:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:14 --> 404 Page Not Found --> css
ERROR - 2013-09-12 16:06:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:24 --> 404 Page Not Found --> css
ERROR - 2013-09-12 16:06:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:27 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:28 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:28 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:28 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:28 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:28 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:28 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:28 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:28 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:28 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:28 --> 404 Page Not Found --> css
ERROR - 2013-09-12 16:06:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:39 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:42 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\school\application\models\absensi_model.php 155
ERROR - 2013-09-12 16:06:44 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\school\application\models\absensi_model.php 155
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:45 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:45 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:45 --> 404 Page Not Found --> css
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 16:06:49 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:49 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 16:06:49 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:24:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:24:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:24:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:24:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:24:53 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:24:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:24:53 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:24:53 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:24:53 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:24:53 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:24:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:24:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:24:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:24:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:24:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:24:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:24:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:24:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:24:54 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:24:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:24:54 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:24:54 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:24:54 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:25:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:16 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\school\application\models\absensi_model.php 155
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\school\application\models\absensi_model.php 155
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:17 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:17 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:17 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\school\application\models\absensi_model.php 155
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:22 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:22 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:22 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:23 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:32 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:32 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:32 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:50 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:50 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:51 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:51 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:51 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:51 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:51 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:51 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:51 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:51 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:51 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:51 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:51 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:51 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:51 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:51 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:51 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:25:56 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:56 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:25:56 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:01 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:01 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:01 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:04 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:04 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:04 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:26:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:18 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:18 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:18 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:26:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:21 --> 404 Page Not Found --> css
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 112
ERROR - 2013-09-12 17:26:23 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:23 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 114
ERROR - 2013-09-12 17:26:23 --> 404 Page Not Found --> css
ERROR - 2013-09-12 18:44:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 18:44:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 18:44:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 18:44:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-12 18:44:50 --> 404 Page Not Found --> css
