<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-22 04:23:42 --> Config Class Initialized
DEBUG - 2013-08-22 04:23:42 --> Hooks Class Initialized
DEBUG - 2013-08-22 04:23:42 --> Utf8 Class Initialized
DEBUG - 2013-08-22 04:23:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 04:23:42 --> URI Class Initialized
DEBUG - 2013-08-22 04:23:42 --> Router Class Initialized
DEBUG - 2013-08-22 04:23:42 --> Output Class Initialized
DEBUG - 2013-08-22 04:23:42 --> Security Class Initialized
DEBUG - 2013-08-22 04:23:42 --> Input Class Initialized
DEBUG - 2013-08-22 04:23:42 --> XSS Filtering completed
DEBUG - 2013-08-22 04:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 04:23:42 --> Language Class Initialized
DEBUG - 2013-08-22 04:23:43 --> Loader Class Initialized
DEBUG - 2013-08-22 04:23:43 --> Helper loaded: url_helper
DEBUG - 2013-08-22 04:23:43 --> Helper loaded: file_helper
DEBUG - 2013-08-22 04:23:43 --> Helper loaded: form_helper
DEBUG - 2013-08-22 04:23:43 --> Database Driver Class Initialized
DEBUG - 2013-08-22 04:23:43 --> Session Class Initialized
DEBUG - 2013-08-22 04:23:43 --> Helper loaded: string_helper
DEBUG - 2013-08-22 04:23:43 --> A session cookie was not found.
DEBUG - 2013-08-22 04:23:43 --> Session routines successfully run
DEBUG - 2013-08-22 04:23:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 04:23:43 --> Controller Class Initialized
ERROR - 2013-08-22 04:23:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 04:23:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 04:23:44 --> Model Class Initialized
DEBUG - 2013-08-22 04:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 04:23:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 04:23:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 04:23:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 04:23:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 04:23:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 04:23:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 04:23:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 04:23:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 04:23:44 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 04:23:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 04:23:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 04:23:44 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-22 04:23:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 04:23:44 --> Final output sent to browser
DEBUG - 2013-08-22 04:23:44 --> Total execution time: 2.2491
DEBUG - 2013-08-22 04:23:44 --> Config Class Initialized
DEBUG - 2013-08-22 04:23:44 --> Hooks Class Initialized
DEBUG - 2013-08-22 04:23:44 --> Utf8 Class Initialized
DEBUG - 2013-08-22 04:23:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 04:23:44 --> URI Class Initialized
DEBUG - 2013-08-22 04:23:44 --> Router Class Initialized
ERROR - 2013-08-22 04:23:44 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 06:44:29 --> Config Class Initialized
DEBUG - 2013-08-22 06:44:29 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:44:29 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:44:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:44:29 --> URI Class Initialized
DEBUG - 2013-08-22 06:44:29 --> Router Class Initialized
ERROR - 2013-08-22 06:44:29 --> 404 Page Not Found --> gurus
DEBUG - 2013-08-22 06:45:20 --> Config Class Initialized
DEBUG - 2013-08-22 06:45:20 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:45:20 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:45:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:45:20 --> URI Class Initialized
DEBUG - 2013-08-22 06:45:20 --> Router Class Initialized
DEBUG - 2013-08-22 06:45:20 --> Output Class Initialized
DEBUG - 2013-08-22 06:45:20 --> Security Class Initialized
DEBUG - 2013-08-22 06:45:20 --> Input Class Initialized
DEBUG - 2013-08-22 06:45:20 --> XSS Filtering completed
DEBUG - 2013-08-22 06:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 06:45:20 --> Language Class Initialized
ERROR - 2013-08-22 06:45:20 --> Severity: Warning  --> include_once(application/core/gurus.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:45:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/gurus.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:45:20 --> 404 Page Not Found --> gurus/index
DEBUG - 2013-08-22 06:45:58 --> Config Class Initialized
DEBUG - 2013-08-22 06:45:58 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:45:58 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:45:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:45:58 --> URI Class Initialized
DEBUG - 2013-08-22 06:45:58 --> Router Class Initialized
DEBUG - 2013-08-22 06:45:58 --> Output Class Initialized
DEBUG - 2013-08-22 06:45:58 --> Security Class Initialized
DEBUG - 2013-08-22 06:45:58 --> Input Class Initialized
DEBUG - 2013-08-22 06:45:58 --> XSS Filtering completed
DEBUG - 2013-08-22 06:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 06:45:58 --> Language Class Initialized
DEBUG - 2013-08-22 06:46:15 --> Config Class Initialized
DEBUG - 2013-08-22 06:46:15 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:46:15 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:46:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:46:15 --> URI Class Initialized
DEBUG - 2013-08-22 06:46:15 --> Router Class Initialized
DEBUG - 2013-08-22 06:46:15 --> Output Class Initialized
DEBUG - 2013-08-22 06:46:15 --> Security Class Initialized
DEBUG - 2013-08-22 06:46:15 --> Input Class Initialized
DEBUG - 2013-08-22 06:46:15 --> XSS Filtering completed
DEBUG - 2013-08-22 06:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 06:46:15 --> Language Class Initialized
ERROR - 2013-08-22 06:46:15 --> Severity: Warning  --> include_once(application/core/gurus.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:46:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/gurus.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:46:15 --> 404 Page Not Found --> gurus/index
DEBUG - 2013-08-22 06:46:24 --> Config Class Initialized
DEBUG - 2013-08-22 06:46:24 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:46:24 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:46:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:46:24 --> URI Class Initialized
DEBUG - 2013-08-22 06:46:24 --> Router Class Initialized
DEBUG - 2013-08-22 06:46:24 --> Output Class Initialized
DEBUG - 2013-08-22 06:46:24 --> Security Class Initialized
DEBUG - 2013-08-22 06:46:24 --> Input Class Initialized
DEBUG - 2013-08-22 06:46:24 --> XSS Filtering completed
DEBUG - 2013-08-22 06:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 06:46:24 --> Language Class Initialized
ERROR - 2013-08-22 06:46:24 --> Severity: Warning  --> include_once(application/core/gurus.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:46:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/gurus.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:46:24 --> 404 Page Not Found --> gurus/index
DEBUG - 2013-08-22 06:47:25 --> Config Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:47:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:47:25 --> URI Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Router Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Output Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Security Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Input Class Initialized
DEBUG - 2013-08-22 06:47:25 --> XSS Filtering completed
DEBUG - 2013-08-22 06:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 06:47:25 --> Language Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Loader Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Helper loaded: url_helper
DEBUG - 2013-08-22 06:47:25 --> Helper loaded: file_helper
DEBUG - 2013-08-22 06:47:25 --> Helper loaded: form_helper
DEBUG - 2013-08-22 06:47:25 --> Database Driver Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Session Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Helper loaded: string_helper
DEBUG - 2013-08-22 06:47:25 --> A session cookie was not found.
DEBUG - 2013-08-22 06:47:25 --> Session routines successfully run
DEBUG - 2013-08-22 06:47:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Controller Class Initialized
ERROR - 2013-08-22 06:47:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:47:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 06:47:25 --> Model Class Initialized
DEBUG - 2013-08-22 06:47:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 06:47:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 06:47:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 06:47:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 06:47:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:47:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 06:47:25 --> Pagination Class Initialized
DEBUG - 2013-08-22 06:47:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 06:47:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 06:47:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 06:47:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 06:47:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 06:47:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 06:47:25 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-22 06:47:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 06:47:25 --> Final output sent to browser
DEBUG - 2013-08-22 06:47:25 --> Total execution time: 0.9571
DEBUG - 2013-08-22 06:47:26 --> Config Class Initialized
DEBUG - 2013-08-22 06:47:26 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:47:26 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:47:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:47:26 --> URI Class Initialized
DEBUG - 2013-08-22 06:47:26 --> Router Class Initialized
ERROR - 2013-08-22 06:47:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 06:47:29 --> Config Class Initialized
DEBUG - 2013-08-22 06:47:29 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:47:29 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:47:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:47:29 --> URI Class Initialized
DEBUG - 2013-08-22 06:47:30 --> Router Class Initialized
DEBUG - 2013-08-22 06:47:30 --> Output Class Initialized
DEBUG - 2013-08-22 06:47:30 --> Security Class Initialized
DEBUG - 2013-08-22 06:47:30 --> Input Class Initialized
DEBUG - 2013-08-22 06:47:30 --> XSS Filtering completed
DEBUG - 2013-08-22 06:47:30 --> XSS Filtering completed
DEBUG - 2013-08-22 06:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 06:47:30 --> Language Class Initialized
ERROR - 2013-08-22 06:47:30 --> Severity: Warning  --> include_once(application/core/gurus.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:47:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/gurus.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:47:30 --> 404 Page Not Found --> gurus/index
DEBUG - 2013-08-22 06:48:39 --> Config Class Initialized
DEBUG - 2013-08-22 06:48:39 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:48:39 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:48:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:48:39 --> URI Class Initialized
DEBUG - 2013-08-22 06:48:39 --> Router Class Initialized
DEBUG - 2013-08-22 06:48:39 --> Output Class Initialized
DEBUG - 2013-08-22 06:48:39 --> Security Class Initialized
DEBUG - 2013-08-22 06:48:39 --> Input Class Initialized
DEBUG - 2013-08-22 06:48:39 --> XSS Filtering completed
DEBUG - 2013-08-22 06:48:39 --> XSS Filtering completed
DEBUG - 2013-08-22 06:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 06:48:39 --> Language Class Initialized
ERROR - 2013-08-22 06:48:39 --> Severity: Warning  --> include_once(application/core/gurus.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:48:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/gurus.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:48:39 --> 404 Page Not Found --> gurus/index
DEBUG - 2013-08-22 06:49:07 --> Config Class Initialized
DEBUG - 2013-08-22 06:49:07 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:49:07 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:49:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:49:07 --> URI Class Initialized
DEBUG - 2013-08-22 06:49:07 --> Router Class Initialized
ERROR - 2013-08-22 06:49:07 --> 404 Page Not Found --> gurus
DEBUG - 2013-08-22 06:51:08 --> Config Class Initialized
DEBUG - 2013-08-22 06:51:08 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:51:08 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:51:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:51:08 --> URI Class Initialized
DEBUG - 2013-08-22 06:51:08 --> Router Class Initialized
ERROR - 2013-08-22 06:51:08 --> 404 Page Not Found --> gurus
DEBUG - 2013-08-22 06:51:12 --> Config Class Initialized
DEBUG - 2013-08-22 06:51:12 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:51:12 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:51:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:51:12 --> URI Class Initialized
DEBUG - 2013-08-22 06:51:12 --> Router Class Initialized
ERROR - 2013-08-22 06:51:12 --> 404 Page Not Found --> gurus
DEBUG - 2013-08-22 06:51:14 --> Config Class Initialized
DEBUG - 2013-08-22 06:51:14 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:51:14 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:51:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:51:14 --> URI Class Initialized
DEBUG - 2013-08-22 06:51:14 --> Router Class Initialized
ERROR - 2013-08-22 06:51:14 --> 404 Page Not Found --> gurus
DEBUG - 2013-08-22 06:51:26 --> Config Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Hooks Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Utf8 Class Initialized
DEBUG - 2013-08-22 06:51:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 06:51:26 --> URI Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Router Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Output Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Security Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Input Class Initialized
DEBUG - 2013-08-22 06:51:26 --> XSS Filtering completed
DEBUG - 2013-08-22 06:51:26 --> XSS Filtering completed
DEBUG - 2013-08-22 06:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 06:51:26 --> Language Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Loader Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Helper loaded: url_helper
DEBUG - 2013-08-22 06:51:26 --> Helper loaded: file_helper
DEBUG - 2013-08-22 06:51:26 --> Helper loaded: form_helper
DEBUG - 2013-08-22 06:51:26 --> Database Driver Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Session Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Helper loaded: string_helper
DEBUG - 2013-08-22 06:51:26 --> Session routines successfully run
DEBUG - 2013-08-22 06:51:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Controller Class Initialized
ERROR - 2013-08-22 06:51:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:51:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 06:51:26 --> Model Class Initialized
DEBUG - 2013-08-22 06:51:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 06:51:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 06:51:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 06:51:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 06:51:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:51:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:51:26 --> Severity: Warning  --> include_once(application/core/Guru_model.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 06:51:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Guru_model.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 08:09:53 --> Config Class Initialized
DEBUG - 2013-08-22 08:09:53 --> Hooks Class Initialized
DEBUG - 2013-08-22 08:09:53 --> Utf8 Class Initialized
DEBUG - 2013-08-22 08:09:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 08:09:53 --> URI Class Initialized
DEBUG - 2013-08-22 08:09:53 --> Router Class Initialized
DEBUG - 2013-08-22 08:09:53 --> Output Class Initialized
DEBUG - 2013-08-22 08:09:53 --> Security Class Initialized
DEBUG - 2013-08-22 08:09:53 --> Input Class Initialized
DEBUG - 2013-08-22 08:09:53 --> XSS Filtering completed
DEBUG - 2013-08-22 08:09:53 --> XSS Filtering completed
DEBUG - 2013-08-22 08:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 08:09:53 --> Language Class Initialized
DEBUG - 2013-08-22 08:09:53 --> Loader Class Initialized
DEBUG - 2013-08-22 08:09:53 --> Helper loaded: url_helper
DEBUG - 2013-08-22 08:09:53 --> Helper loaded: file_helper
DEBUG - 2013-08-22 08:09:53 --> Helper loaded: form_helper
DEBUG - 2013-08-22 08:09:54 --> Database Driver Class Initialized
DEBUG - 2013-08-22 08:09:54 --> Session Class Initialized
DEBUG - 2013-08-22 08:09:54 --> Helper loaded: string_helper
DEBUG - 2013-08-22 08:09:54 --> Session routines successfully run
DEBUG - 2013-08-22 08:09:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 08:09:54 --> Controller Class Initialized
ERROR - 2013-08-22 08:09:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:09:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 08:09:54 --> Model Class Initialized
DEBUG - 2013-08-22 08:09:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 08:09:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 08:09:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 08:09:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 08:09:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:09:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:09:54 --> Severity: Warning  --> include_once(application/core/Guru_model.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:09:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Guru_model.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 08:10:57 --> Config Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Hooks Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Utf8 Class Initialized
DEBUG - 2013-08-22 08:10:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 08:10:57 --> URI Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Router Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Output Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Security Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Input Class Initialized
DEBUG - 2013-08-22 08:10:57 --> XSS Filtering completed
DEBUG - 2013-08-22 08:10:57 --> XSS Filtering completed
DEBUG - 2013-08-22 08:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 08:10:57 --> Language Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Loader Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Helper loaded: url_helper
DEBUG - 2013-08-22 08:10:57 --> Helper loaded: file_helper
DEBUG - 2013-08-22 08:10:57 --> Helper loaded: form_helper
DEBUG - 2013-08-22 08:10:57 --> Database Driver Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Session Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Helper loaded: string_helper
DEBUG - 2013-08-22 08:10:57 --> Session routines successfully run
DEBUG - 2013-08-22 08:10:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Controller Class Initialized
ERROR - 2013-08-22 08:10:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:10:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 08:10:57 --> Model Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 08:10:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 08:10:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 08:10:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 08:10:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:10:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 08:10:57 --> Pagination Class Initialized
DEBUG - 2013-08-22 08:10:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 08:10:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 08:10:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 08:10:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 08:10:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 08:10:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 08:10:57 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-22 08:10:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 08:10:57 --> Final output sent to browser
DEBUG - 2013-08-22 08:10:57 --> Total execution time: 0.3350
DEBUG - 2013-08-22 08:10:57 --> Config Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Hooks Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Utf8 Class Initialized
DEBUG - 2013-08-22 08:10:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 08:10:57 --> URI Class Initialized
DEBUG - 2013-08-22 08:10:57 --> Router Class Initialized
ERROR - 2013-08-22 08:10:57 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 08:11:34 --> Config Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Hooks Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Utf8 Class Initialized
DEBUG - 2013-08-22 08:11:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 08:11:34 --> URI Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Router Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Output Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Security Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Input Class Initialized
DEBUG - 2013-08-22 08:11:34 --> XSS Filtering completed
DEBUG - 2013-08-22 08:11:34 --> XSS Filtering completed
DEBUG - 2013-08-22 08:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 08:11:34 --> Language Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Loader Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Helper loaded: url_helper
DEBUG - 2013-08-22 08:11:34 --> Helper loaded: file_helper
DEBUG - 2013-08-22 08:11:34 --> Helper loaded: form_helper
DEBUG - 2013-08-22 08:11:34 --> Database Driver Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Session Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Helper loaded: string_helper
DEBUG - 2013-08-22 08:11:34 --> Session routines successfully run
DEBUG - 2013-08-22 08:11:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Controller Class Initialized
ERROR - 2013-08-22 08:11:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:11:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 08:11:34 --> Model Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 08:11:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 08:11:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 08:11:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 08:11:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:11:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 08:11:34 --> Pagination Class Initialized
DEBUG - 2013-08-22 08:11:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 08:11:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 08:11:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 08:11:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 08:11:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 08:11:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 08:11:34 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-22 08:11:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 08:11:34 --> Final output sent to browser
DEBUG - 2013-08-22 08:11:34 --> Total execution time: 0.2350
DEBUG - 2013-08-22 08:11:34 --> Config Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Hooks Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Utf8 Class Initialized
DEBUG - 2013-08-22 08:11:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 08:11:34 --> URI Class Initialized
DEBUG - 2013-08-22 08:11:34 --> Router Class Initialized
ERROR - 2013-08-22 08:11:34 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 08:50:31 --> Config Class Initialized
DEBUG - 2013-08-22 08:50:31 --> Hooks Class Initialized
DEBUG - 2013-08-22 08:50:31 --> Utf8 Class Initialized
DEBUG - 2013-08-22 08:50:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 08:50:31 --> URI Class Initialized
DEBUG - 2013-08-22 08:50:31 --> Router Class Initialized
DEBUG - 2013-08-22 08:50:31 --> Output Class Initialized
DEBUG - 2013-08-22 08:50:31 --> Security Class Initialized
DEBUG - 2013-08-22 08:50:31 --> Input Class Initialized
DEBUG - 2013-08-22 08:50:31 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:31 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:31 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:31 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:31 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 08:50:32 --> Language Class Initialized
DEBUG - 2013-08-22 08:50:32 --> Loader Class Initialized
DEBUG - 2013-08-22 08:50:32 --> Helper loaded: url_helper
DEBUG - 2013-08-22 08:50:32 --> Helper loaded: file_helper
DEBUG - 2013-08-22 08:50:32 --> Helper loaded: form_helper
DEBUG - 2013-08-22 08:50:32 --> Database Driver Class Initialized
DEBUG - 2013-08-22 08:50:32 --> Session Class Initialized
DEBUG - 2013-08-22 08:50:32 --> Helper loaded: string_helper
DEBUG - 2013-08-22 08:50:32 --> Session routines successfully run
DEBUG - 2013-08-22 08:50:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 08:50:32 --> Controller Class Initialized
ERROR - 2013-08-22 08:50:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:50:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 08:50:32 --> Model Class Initialized
DEBUG - 2013-08-22 08:50:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 08:50:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 08:50:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 08:50:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 08:50:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 08:50:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 08:50:32 --> Pagination Class Initialized
DEBUG - 2013-08-22 08:50:32 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:32 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:32 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:32 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:32 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:32 --> XSS Filtering completed
DEBUG - 2013-08-22 08:50:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 08:50:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 08:50:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 08:50:32 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 08:50:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 08:50:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 08:50:33 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-08-22 08:50:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 08:50:33 --> Final output sent to browser
DEBUG - 2013-08-22 08:50:33 --> Total execution time: 1.4351
DEBUG - 2013-08-22 08:50:33 --> Config Class Initialized
DEBUG - 2013-08-22 08:50:33 --> Hooks Class Initialized
DEBUG - 2013-08-22 08:50:33 --> Utf8 Class Initialized
DEBUG - 2013-08-22 08:50:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 08:50:33 --> URI Class Initialized
DEBUG - 2013-08-22 08:50:33 --> Router Class Initialized
ERROR - 2013-08-22 08:50:33 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:01:44 --> Config Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:01:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:01:44 --> URI Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Router Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Output Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Security Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Input Class Initialized
DEBUG - 2013-08-22 09:01:44 --> XSS Filtering completed
DEBUG - 2013-08-22 09:01:44 --> XSS Filtering completed
DEBUG - 2013-08-22 09:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:01:44 --> Language Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Loader Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:01:44 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:01:44 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:01:44 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Session Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:01:44 --> Session routines successfully run
DEBUG - 2013-08-22 09:01:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:01:44 --> Controller Class Initialized
ERROR - 2013-08-22 09:01:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:01:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:01:45 --> Model Class Initialized
DEBUG - 2013-08-22 09:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:01:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:01:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:01:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:01:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:01:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:01:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:01:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:01:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:01:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:01:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:01:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:01:45 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:01:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:01:45 --> Final output sent to browser
DEBUG - 2013-08-22 09:01:45 --> Total execution time: 1.0271
DEBUG - 2013-08-22 09:01:45 --> Config Class Initialized
DEBUG - 2013-08-22 09:01:45 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:01:45 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:01:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:01:45 --> URI Class Initialized
DEBUG - 2013-08-22 09:01:45 --> Router Class Initialized
ERROR - 2013-08-22 09:01:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:01:45 --> Config Class Initialized
DEBUG - 2013-08-22 09:01:45 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:01:45 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:01:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:01:45 --> URI Class Initialized
DEBUG - 2013-08-22 09:01:45 --> Router Class Initialized
ERROR - 2013-08-22 09:01:45 --> 404 Page Not Found --> img
DEBUG - 2013-08-22 09:04:17 --> Config Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:04:17 --> URI Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Router Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Output Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Security Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Input Class Initialized
DEBUG - 2013-08-22 09:04:17 --> XSS Filtering completed
DEBUG - 2013-08-22 09:04:17 --> XSS Filtering completed
DEBUG - 2013-08-22 09:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:04:17 --> Language Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Loader Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:04:17 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:04:17 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:04:17 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Session Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:04:17 --> Session routines successfully run
DEBUG - 2013-08-22 09:04:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Controller Class Initialized
ERROR - 2013-08-22 09:04:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:04:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:04:17 --> Model Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:04:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:04:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:04:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:04:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:04:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:04:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:04:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:04:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:04:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:04:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:04:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:04:17 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:04:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:04:17 --> Final output sent to browser
DEBUG - 2013-08-22 09:04:17 --> Total execution time: 0.3660
DEBUG - 2013-08-22 09:04:17 --> Config Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:04:17 --> URI Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Router Class Initialized
ERROR - 2013-08-22 09:04:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:04:17 --> Config Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:04:17 --> URI Class Initialized
DEBUG - 2013-08-22 09:04:17 --> Router Class Initialized
ERROR - 2013-08-22 09:04:17 --> 404 Page Not Found --> img
DEBUG - 2013-08-22 09:08:21 --> Config Class Initialized
DEBUG - 2013-08-22 09:08:21 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:08:21 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:08:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:08:21 --> URI Class Initialized
DEBUG - 2013-08-22 09:08:21 --> Router Class Initialized
ERROR - 2013-08-22 09:08:21 --> 404 Page Not Found --> img
DEBUG - 2013-08-22 09:08:30 --> Config Class Initialized
DEBUG - 2013-08-22 09:08:30 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:08:30 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:08:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:08:30 --> URI Class Initialized
DEBUG - 2013-08-22 09:08:30 --> Router Class Initialized
ERROR - 2013-08-22 09:08:30 --> 404 Page Not Found --> in
DEBUG - 2013-08-22 09:08:31 --> Config Class Initialized
DEBUG - 2013-08-22 09:08:31 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:08:31 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:08:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:08:31 --> URI Class Initialized
DEBUG - 2013-08-22 09:08:31 --> Router Class Initialized
ERROR - 2013-08-22 09:08:31 --> 404 Page Not Found --> inclu
DEBUG - 2013-08-22 09:08:32 --> Config Class Initialized
DEBUG - 2013-08-22 09:08:32 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:08:32 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:08:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:08:32 --> URI Class Initialized
DEBUG - 2013-08-22 09:08:32 --> Router Class Initialized
ERROR - 2013-08-22 09:08:32 --> 404 Page Not Found --> includes
DEBUG - 2013-08-22 09:08:33 --> Config Class Initialized
DEBUG - 2013-08-22 09:08:33 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:08:33 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:08:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:08:33 --> URI Class Initialized
DEBUG - 2013-08-22 09:08:33 --> Router Class Initialized
ERROR - 2013-08-22 09:08:33 --> 404 Page Not Found --> includes
DEBUG - 2013-08-22 09:08:35 --> Config Class Initialized
DEBUG - 2013-08-22 09:08:35 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:08:35 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:08:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:08:35 --> URI Class Initialized
DEBUG - 2013-08-22 09:08:35 --> Router Class Initialized
ERROR - 2013-08-22 09:08:35 --> 404 Page Not Found --> includes
DEBUG - 2013-08-22 09:08:37 --> Config Class Initialized
DEBUG - 2013-08-22 09:08:37 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:08:37 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:08:37 --> URI Class Initialized
DEBUG - 2013-08-22 09:08:37 --> Router Class Initialized
ERROR - 2013-08-22 09:08:37 --> 404 Page Not Found --> includes
DEBUG - 2013-08-22 09:08:47 --> Config Class Initialized
DEBUG - 2013-08-22 09:08:47 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:08:47 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:08:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:08:47 --> URI Class Initialized
DEBUG - 2013-08-22 09:08:47 --> Router Class Initialized
ERROR - 2013-08-22 09:08:47 --> 404 Page Not Found --> includes
DEBUG - 2013-08-22 09:09:11 --> Config Class Initialized
DEBUG - 2013-08-22 09:09:11 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:09:11 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:09:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:09:11 --> URI Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Router Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Output Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Security Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Input Class Initialized
DEBUG - 2013-08-22 09:09:12 --> XSS Filtering completed
DEBUG - 2013-08-22 09:09:12 --> XSS Filtering completed
DEBUG - 2013-08-22 09:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:09:12 --> Language Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Loader Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:09:12 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:09:12 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:09:12 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Session Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:09:12 --> Session routines successfully run
DEBUG - 2013-08-22 09:09:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Controller Class Initialized
ERROR - 2013-08-22 09:09:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:09:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:09:12 --> Model Class Initialized
DEBUG - 2013-08-22 09:09:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:09:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:09:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:09:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:09:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:09:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:09:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:09:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:09:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:09:12 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:09:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:09:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:09:12 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:09:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:09:12 --> Final output sent to browser
DEBUG - 2013-08-22 09:09:12 --> Total execution time: 0.9061
DEBUG - 2013-08-22 09:09:13 --> Config Class Initialized
DEBUG - 2013-08-22 09:09:13 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:09:13 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:09:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:09:13 --> URI Class Initialized
DEBUG - 2013-08-22 09:09:13 --> Router Class Initialized
ERROR - 2013-08-22 09:09:13 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:09:13 --> Config Class Initialized
DEBUG - 2013-08-22 09:09:13 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:09:13 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:09:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:09:13 --> URI Class Initialized
DEBUG - 2013-08-22 09:09:13 --> Router Class Initialized
ERROR - 2013-08-22 09:09:13 --> 404 Page Not Found --> img
DEBUG - 2013-08-22 09:09:17 --> Config Class Initialized
DEBUG - 2013-08-22 09:09:17 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:09:17 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:09:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:09:17 --> URI Class Initialized
DEBUG - 2013-08-22 09:09:17 --> Router Class Initialized
ERROR - 2013-08-22 09:09:17 --> 404 Page Not Found --> img
DEBUG - 2013-08-22 09:09:33 --> Config Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:09:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:09:33 --> URI Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Router Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Output Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Security Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Input Class Initialized
DEBUG - 2013-08-22 09:09:33 --> XSS Filtering completed
DEBUG - 2013-08-22 09:09:33 --> XSS Filtering completed
DEBUG - 2013-08-22 09:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:09:33 --> Language Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Loader Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:09:33 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:09:33 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:09:33 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Session Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:09:33 --> Session routines successfully run
DEBUG - 2013-08-22 09:09:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Controller Class Initialized
ERROR - 2013-08-22 09:09:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:09:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:09:33 --> Model Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:09:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:09:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:09:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:09:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:09:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:09:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:09:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:09:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:09:33 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:09:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:09:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:09:33 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:09:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:09:33 --> Final output sent to browser
DEBUG - 2013-08-22 09:09:33 --> Total execution time: 0.3220
DEBUG - 2013-08-22 09:09:33 --> Config Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:09:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:09:33 --> URI Class Initialized
DEBUG - 2013-08-22 09:09:33 --> Router Class Initialized
ERROR - 2013-08-22 09:09:33 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:10:44 --> Config Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:10:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:10:44 --> URI Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Router Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Output Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Security Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Input Class Initialized
DEBUG - 2013-08-22 09:10:44 --> XSS Filtering completed
DEBUG - 2013-08-22 09:10:44 --> XSS Filtering completed
DEBUG - 2013-08-22 09:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:10:44 --> Language Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Loader Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:10:44 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:10:44 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:10:44 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Session Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:10:44 --> Session routines successfully run
DEBUG - 2013-08-22 09:10:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Controller Class Initialized
ERROR - 2013-08-22 09:10:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:10:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:10:44 --> Model Class Initialized
DEBUG - 2013-08-22 09:10:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:10:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:10:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:10:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:10:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:10:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:10:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:10:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:10:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:10:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:10:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:10:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:10:45 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:10:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:10:45 --> Final output sent to browser
DEBUG - 2013-08-22 09:10:45 --> Total execution time: 0.3690
DEBUG - 2013-08-22 09:10:45 --> Config Class Initialized
DEBUG - 2013-08-22 09:10:45 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:10:45 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:10:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:10:45 --> URI Class Initialized
DEBUG - 2013-08-22 09:10:45 --> Router Class Initialized
ERROR - 2013-08-22 09:10:45 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:11:03 --> Config Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:11:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:11:03 --> URI Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Router Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Output Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Security Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Input Class Initialized
DEBUG - 2013-08-22 09:11:03 --> XSS Filtering completed
DEBUG - 2013-08-22 09:11:03 --> XSS Filtering completed
DEBUG - 2013-08-22 09:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:11:03 --> Language Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Loader Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:11:03 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:11:03 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:11:03 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Session Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:11:03 --> Session routines successfully run
DEBUG - 2013-08-22 09:11:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Controller Class Initialized
ERROR - 2013-08-22 09:11:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:11:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:11:03 --> Model Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:11:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:11:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:11:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:11:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:11:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:11:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:11:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:11:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:11:03 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:11:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:11:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:11:03 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:11:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:11:03 --> Final output sent to browser
DEBUG - 2013-08-22 09:11:03 --> Total execution time: 0.3490
DEBUG - 2013-08-22 09:11:03 --> Config Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:11:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:11:03 --> URI Class Initialized
DEBUG - 2013-08-22 09:11:03 --> Router Class Initialized
ERROR - 2013-08-22 09:11:03 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:13:27 --> Config Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:13:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:13:27 --> URI Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Router Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Output Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Security Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Input Class Initialized
DEBUG - 2013-08-22 09:13:27 --> XSS Filtering completed
DEBUG - 2013-08-22 09:13:27 --> XSS Filtering completed
DEBUG - 2013-08-22 09:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:13:27 --> Language Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Loader Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:13:27 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:13:27 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:13:27 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Session Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:13:27 --> Session routines successfully run
DEBUG - 2013-08-22 09:13:27 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Controller Class Initialized
ERROR - 2013-08-22 09:13:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:13:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:13:27 --> Model Class Initialized
DEBUG - 2013-08-22 09:13:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:13:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:13:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:13:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:13:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:13:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:13:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:13:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:13:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:13:27 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:13:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:13:27 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:13:27 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:13:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:13:28 --> Final output sent to browser
DEBUG - 2013-08-22 09:13:28 --> Total execution time: 0.3520
DEBUG - 2013-08-22 09:13:28 --> Config Class Initialized
DEBUG - 2013-08-22 09:13:28 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:13:28 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:13:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:13:28 --> URI Class Initialized
DEBUG - 2013-08-22 09:13:28 --> Router Class Initialized
ERROR - 2013-08-22 09:13:28 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:13:42 --> Config Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:13:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:13:42 --> URI Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Router Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Output Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Security Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Input Class Initialized
DEBUG - 2013-08-22 09:13:42 --> XSS Filtering completed
DEBUG - 2013-08-22 09:13:42 --> XSS Filtering completed
DEBUG - 2013-08-22 09:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:13:42 --> Language Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Loader Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:13:42 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:13:42 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:13:42 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Session Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:13:42 --> Session routines successfully run
DEBUG - 2013-08-22 09:13:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Controller Class Initialized
ERROR - 2013-08-22 09:13:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:13:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:13:42 --> Model Class Initialized
DEBUG - 2013-08-22 09:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:13:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:13:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:13:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:13:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:13:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:13:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:13:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:13:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:13:42 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:13:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:13:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:13:42 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:13:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:13:42 --> Final output sent to browser
DEBUG - 2013-08-22 09:13:42 --> Total execution time: 0.3610
DEBUG - 2013-08-22 09:13:43 --> Config Class Initialized
DEBUG - 2013-08-22 09:13:43 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:13:43 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:13:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:13:43 --> URI Class Initialized
DEBUG - 2013-08-22 09:13:43 --> Router Class Initialized
ERROR - 2013-08-22 09:13:43 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:13:53 --> Config Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:13:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:13:53 --> URI Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Router Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Output Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Security Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Input Class Initialized
DEBUG - 2013-08-22 09:13:53 --> XSS Filtering completed
DEBUG - 2013-08-22 09:13:53 --> XSS Filtering completed
DEBUG - 2013-08-22 09:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:13:53 --> Language Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Loader Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:13:53 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:13:53 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:13:53 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Session Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:13:53 --> Session routines successfully run
DEBUG - 2013-08-22 09:13:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Controller Class Initialized
ERROR - 2013-08-22 09:13:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:13:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:13:53 --> Model Class Initialized
DEBUG - 2013-08-22 09:13:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:13:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:13:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:13:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:13:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:13:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:13:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:13:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:13:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:13:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:13:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:13:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:13:53 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:13:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:13:53 --> Final output sent to browser
DEBUG - 2013-08-22 09:13:53 --> Total execution time: 0.4000
DEBUG - 2013-08-22 09:13:53 --> Config Class Initialized
DEBUG - 2013-08-22 09:13:54 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:13:54 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:13:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:13:54 --> URI Class Initialized
DEBUG - 2013-08-22 09:13:54 --> Router Class Initialized
ERROR - 2013-08-22 09:13:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:42:50 --> Config Class Initialized
DEBUG - 2013-08-22 09:42:50 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:42:50 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:42:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:42:50 --> URI Class Initialized
DEBUG - 2013-08-22 09:42:50 --> Router Class Initialized
DEBUG - 2013-08-22 09:42:50 --> Output Class Initialized
DEBUG - 2013-08-22 09:42:50 --> Security Class Initialized
DEBUG - 2013-08-22 09:42:50 --> Input Class Initialized
DEBUG - 2013-08-22 09:42:50 --> XSS Filtering completed
DEBUG - 2013-08-22 09:42:50 --> XSS Filtering completed
DEBUG - 2013-08-22 09:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:42:50 --> Language Class Initialized
DEBUG - 2013-08-22 09:42:50 --> Loader Class Initialized
DEBUG - 2013-08-22 09:42:50 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:42:50 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:42:50 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:42:51 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:42:51 --> Session Class Initialized
DEBUG - 2013-08-22 09:42:51 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:42:51 --> Session routines successfully run
DEBUG - 2013-08-22 09:42:51 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:42:51 --> Controller Class Initialized
ERROR - 2013-08-22 09:42:51 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:42:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:42:51 --> Model Class Initialized
DEBUG - 2013-08-22 09:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:42:51 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:42:51 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:42:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:42:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:42:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:42:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:42:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:42:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:42:51 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:42:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:42:51 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-22 09:42:51 --> Severity: Notice  --> Undefined variable: no_handphone C:\xampp\htdocs\school\application\views\gurus\new.php 69
DEBUG - 2013-08-22 09:42:51 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:42:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:42:51 --> Final output sent to browser
DEBUG - 2013-08-22 09:42:51 --> Total execution time: 1.5121
DEBUG - 2013-08-22 09:42:52 --> Config Class Initialized
DEBUG - 2013-08-22 09:42:52 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:42:52 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:42:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:42:52 --> URI Class Initialized
DEBUG - 2013-08-22 09:42:52 --> Router Class Initialized
ERROR - 2013-08-22 09:42:52 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:43:17 --> Config Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:43:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:43:17 --> URI Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Router Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Output Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Security Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Input Class Initialized
DEBUG - 2013-08-22 09:43:17 --> XSS Filtering completed
DEBUG - 2013-08-22 09:43:17 --> XSS Filtering completed
DEBUG - 2013-08-22 09:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:43:17 --> Language Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Loader Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:43:17 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:43:17 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:43:17 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Session Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:43:17 --> Session routines successfully run
DEBUG - 2013-08-22 09:43:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Controller Class Initialized
ERROR - 2013-08-22 09:43:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:43:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:43:17 --> Model Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:43:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:43:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:43:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:43:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:43:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:43:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:43:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:43:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:43:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:43:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:43:17 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-22 09:43:17 --> Severity: Notice  --> Undefined variable: no_handphone C:\xampp\htdocs\school\application\views\gurus\new.php 69
DEBUG - 2013-08-22 09:43:17 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:43:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:43:17 --> Final output sent to browser
DEBUG - 2013-08-22 09:43:17 --> Total execution time: 0.4760
DEBUG - 2013-08-22 09:43:17 --> Config Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:43:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:43:17 --> URI Class Initialized
DEBUG - 2013-08-22 09:43:17 --> Router Class Initialized
ERROR - 2013-08-22 09:43:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:43:24 --> Config Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:43:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:43:24 --> URI Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Router Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Output Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Security Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Input Class Initialized
DEBUG - 2013-08-22 09:43:24 --> XSS Filtering completed
DEBUG - 2013-08-22 09:43:24 --> XSS Filtering completed
DEBUG - 2013-08-22 09:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:43:24 --> Language Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Loader Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:43:24 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:43:24 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:43:24 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Session Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:43:24 --> Session routines successfully run
DEBUG - 2013-08-22 09:43:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Controller Class Initialized
ERROR - 2013-08-22 09:43:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:43:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:43:24 --> Model Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:43:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:43:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:43:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:43:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:43:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:43:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:43:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:43:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:43:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:43:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:43:24 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-08-22 09:43:24 --> Severity: Notice  --> Undefined variable: no_handphone C:\xampp\htdocs\school\application\views\gurus\new.php 69
DEBUG - 2013-08-22 09:43:24 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:43:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:43:24 --> Final output sent to browser
DEBUG - 2013-08-22 09:43:24 --> Total execution time: 0.4020
DEBUG - 2013-08-22 09:43:24 --> Config Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:43:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:43:24 --> URI Class Initialized
DEBUG - 2013-08-22 09:43:24 --> Router Class Initialized
ERROR - 2013-08-22 09:43:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:44:42 --> Config Class Initialized
DEBUG - 2013-08-22 09:44:42 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:44:42 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:44:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:44:42 --> URI Class Initialized
DEBUG - 2013-08-22 09:44:42 --> Router Class Initialized
DEBUG - 2013-08-22 09:44:42 --> Output Class Initialized
DEBUG - 2013-08-22 09:44:42 --> Security Class Initialized
DEBUG - 2013-08-22 09:44:42 --> Input Class Initialized
DEBUG - 2013-08-22 09:44:42 --> XSS Filtering completed
DEBUG - 2013-08-22 09:44:42 --> XSS Filtering completed
DEBUG - 2013-08-22 09:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:44:42 --> Language Class Initialized
DEBUG - 2013-08-22 09:44:42 --> Loader Class Initialized
DEBUG - 2013-08-22 09:44:42 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:44:42 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:44:42 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:44:42 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:44:42 --> Session Class Initialized
DEBUG - 2013-08-22 09:44:43 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:44:43 --> Session routines successfully run
DEBUG - 2013-08-22 09:44:43 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:44:43 --> Controller Class Initialized
ERROR - 2013-08-22 09:44:43 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:44:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:44:43 --> Model Class Initialized
DEBUG - 2013-08-22 09:44:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:44:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:44:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:44:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:44:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:44:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:44:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:44:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:44:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:44:43 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:44:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:44:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:44:43 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:44:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:44:43 --> Final output sent to browser
DEBUG - 2013-08-22 09:44:43 --> Total execution time: 0.3800
DEBUG - 2013-08-22 09:44:43 --> Config Class Initialized
DEBUG - 2013-08-22 09:44:43 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:44:43 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:44:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:44:43 --> URI Class Initialized
DEBUG - 2013-08-22 09:44:43 --> Router Class Initialized
ERROR - 2013-08-22 09:44:43 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:52:52 --> Config Class Initialized
DEBUG - 2013-08-22 09:52:52 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:52:52 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:52:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:52:52 --> URI Class Initialized
DEBUG - 2013-08-22 09:52:52 --> Router Class Initialized
DEBUG - 2013-08-22 09:52:52 --> Output Class Initialized
DEBUG - 2013-08-22 09:52:52 --> Security Class Initialized
DEBUG - 2013-08-22 09:52:52 --> Input Class Initialized
DEBUG - 2013-08-22 09:52:52 --> XSS Filtering completed
DEBUG - 2013-08-22 09:52:52 --> XSS Filtering completed
DEBUG - 2013-08-22 09:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:52:52 --> Language Class Initialized
DEBUG - 2013-08-22 09:52:52 --> Loader Class Initialized
DEBUG - 2013-08-22 09:52:52 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:52:52 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:52:52 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:52:53 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:52:53 --> Session Class Initialized
DEBUG - 2013-08-22 09:52:53 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:52:53 --> Session routines successfully run
DEBUG - 2013-08-22 09:52:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:52:53 --> Controller Class Initialized
ERROR - 2013-08-22 09:52:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:52:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:52:53 --> Model Class Initialized
DEBUG - 2013-08-22 09:52:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:52:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:52:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:52:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:52:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:52:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:52:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:52:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:52:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:52:53 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:52:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:52:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:52:53 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:52:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:52:53 --> Final output sent to browser
DEBUG - 2013-08-22 09:52:53 --> Total execution time: 2.1611
DEBUG - 2013-08-22 09:52:54 --> Config Class Initialized
DEBUG - 2013-08-22 09:52:54 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:52:54 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:52:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:52:54 --> URI Class Initialized
DEBUG - 2013-08-22 09:52:54 --> Router Class Initialized
ERROR - 2013-08-22 09:52:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 09:56:25 --> Config Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:56:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:56:25 --> URI Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Router Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Output Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Security Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Input Class Initialized
DEBUG - 2013-08-22 09:56:25 --> XSS Filtering completed
DEBUG - 2013-08-22 09:56:25 --> XSS Filtering completed
DEBUG - 2013-08-22 09:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 09:56:25 --> Language Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Loader Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Helper loaded: url_helper
DEBUG - 2013-08-22 09:56:25 --> Helper loaded: file_helper
DEBUG - 2013-08-22 09:56:25 --> Helper loaded: form_helper
DEBUG - 2013-08-22 09:56:25 --> Database Driver Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Session Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Helper loaded: string_helper
DEBUG - 2013-08-22 09:56:25 --> Session routines successfully run
DEBUG - 2013-08-22 09:56:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Controller Class Initialized
ERROR - 2013-08-22 09:56:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:56:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:56:25 --> Model Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 09:56:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 09:56:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 09:56:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 09:56:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 09:56:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 09:56:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 09:56:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 09:56:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 09:56:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 09:56:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 09:56:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 09:56:25 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 09:56:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 09:56:25 --> Final output sent to browser
DEBUG - 2013-08-22 09:56:25 --> Total execution time: 0.3970
DEBUG - 2013-08-22 09:56:25 --> Config Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Hooks Class Initialized
DEBUG - 2013-08-22 09:56:25 --> Utf8 Class Initialized
DEBUG - 2013-08-22 09:56:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 09:56:26 --> URI Class Initialized
DEBUG - 2013-08-22 09:56:26 --> Router Class Initialized
ERROR - 2013-08-22 09:56:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 10:04:18 --> Config Class Initialized
DEBUG - 2013-08-22 10:04:18 --> Hooks Class Initialized
DEBUG - 2013-08-22 10:04:18 --> Utf8 Class Initialized
DEBUG - 2013-08-22 10:04:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 10:04:18 --> URI Class Initialized
DEBUG - 2013-08-22 10:04:18 --> Router Class Initialized
DEBUG - 2013-08-22 10:04:18 --> Output Class Initialized
DEBUG - 2013-08-22 10:04:18 --> Security Class Initialized
DEBUG - 2013-08-22 10:04:18 --> Input Class Initialized
DEBUG - 2013-08-22 10:04:18 --> XSS Filtering completed
DEBUG - 2013-08-22 10:04:18 --> XSS Filtering completed
DEBUG - 2013-08-22 10:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 10:04:18 --> Language Class Initialized
DEBUG - 2013-08-22 10:04:18 --> Loader Class Initialized
DEBUG - 2013-08-22 10:04:18 --> Helper loaded: url_helper
DEBUG - 2013-08-22 10:04:18 --> Helper loaded: file_helper
DEBUG - 2013-08-22 10:04:18 --> Helper loaded: form_helper
DEBUG - 2013-08-22 10:04:19 --> Database Driver Class Initialized
DEBUG - 2013-08-22 10:04:19 --> Session Class Initialized
DEBUG - 2013-08-22 10:04:19 --> Helper loaded: string_helper
DEBUG - 2013-08-22 10:04:19 --> Session routines successfully run
DEBUG - 2013-08-22 10:04:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 10:04:19 --> Controller Class Initialized
ERROR - 2013-08-22 10:04:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 10:04:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 10:04:19 --> Model Class Initialized
DEBUG - 2013-08-22 10:04:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 10:04:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 10:04:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 10:04:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 10:04:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 10:04:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 10:04:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 10:04:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 10:04:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 10:04:19 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 10:04:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 10:04:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 10:04:19 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 10:04:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 10:04:19 --> Final output sent to browser
DEBUG - 2013-08-22 10:04:19 --> Total execution time: 1.6401
DEBUG - 2013-08-22 10:04:20 --> Config Class Initialized
DEBUG - 2013-08-22 10:04:20 --> Hooks Class Initialized
DEBUG - 2013-08-22 10:04:20 --> Utf8 Class Initialized
DEBUG - 2013-08-22 10:04:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 10:04:20 --> URI Class Initialized
DEBUG - 2013-08-22 10:04:20 --> Router Class Initialized
ERROR - 2013-08-22 10:04:20 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 10:05:11 --> Config Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Hooks Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Utf8 Class Initialized
DEBUG - 2013-08-22 10:05:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 10:05:11 --> URI Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Router Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Output Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Security Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Input Class Initialized
DEBUG - 2013-08-22 10:05:11 --> XSS Filtering completed
DEBUG - 2013-08-22 10:05:11 --> XSS Filtering completed
DEBUG - 2013-08-22 10:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 10:05:11 --> Language Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Loader Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Helper loaded: url_helper
DEBUG - 2013-08-22 10:05:11 --> Helper loaded: file_helper
DEBUG - 2013-08-22 10:05:11 --> Helper loaded: form_helper
DEBUG - 2013-08-22 10:05:11 --> Database Driver Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Session Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Helper loaded: string_helper
DEBUG - 2013-08-22 10:05:11 --> Session routines successfully run
DEBUG - 2013-08-22 10:05:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Controller Class Initialized
ERROR - 2013-08-22 10:05:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 10:05:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 10:05:11 --> Model Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 10:05:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 10:05:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 10:05:11 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 10:05:11 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 10:05:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 10:05:11 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 10:05:11 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 10:05:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 10:05:11 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 10:05:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 10:05:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 10:05:11 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 10:05:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 10:05:11 --> Final output sent to browser
DEBUG - 2013-08-22 10:05:11 --> Total execution time: 0.4240
DEBUG - 2013-08-22 10:05:11 --> Config Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Hooks Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Utf8 Class Initialized
DEBUG - 2013-08-22 10:05:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 10:05:11 --> URI Class Initialized
DEBUG - 2013-08-22 10:05:11 --> Router Class Initialized
ERROR - 2013-08-22 10:05:11 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 10:12:22 --> Config Class Initialized
DEBUG - 2013-08-22 10:12:22 --> Hooks Class Initialized
DEBUG - 2013-08-22 10:12:22 --> Utf8 Class Initialized
DEBUG - 2013-08-22 10:12:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 10:12:22 --> URI Class Initialized
DEBUG - 2013-08-22 10:12:22 --> Router Class Initialized
DEBUG - 2013-08-22 10:12:22 --> Output Class Initialized
DEBUG - 2013-08-22 10:12:22 --> Security Class Initialized
DEBUG - 2013-08-22 10:12:22 --> Input Class Initialized
DEBUG - 2013-08-22 10:12:22 --> XSS Filtering completed
DEBUG - 2013-08-22 10:12:22 --> XSS Filtering completed
DEBUG - 2013-08-22 10:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 10:12:22 --> Language Class Initialized
DEBUG - 2013-08-22 10:12:23 --> Loader Class Initialized
DEBUG - 2013-08-22 10:12:23 --> Helper loaded: url_helper
DEBUG - 2013-08-22 10:12:23 --> Helper loaded: file_helper
DEBUG - 2013-08-22 10:12:23 --> Helper loaded: form_helper
DEBUG - 2013-08-22 10:12:23 --> Database Driver Class Initialized
DEBUG - 2013-08-22 10:12:23 --> Session Class Initialized
DEBUG - 2013-08-22 10:12:23 --> Helper loaded: string_helper
DEBUG - 2013-08-22 10:12:23 --> Session routines successfully run
DEBUG - 2013-08-22 10:12:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 10:12:23 --> Controller Class Initialized
ERROR - 2013-08-22 10:12:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 10:12:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 10:12:23 --> Model Class Initialized
DEBUG - 2013-08-22 10:12:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 10:12:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 10:12:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 10:12:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 10:12:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 10:12:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 10:12:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 10:12:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 10:12:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 10:12:23 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 10:12:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 10:12:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 10:12:23 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 10:12:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 10:12:23 --> Final output sent to browser
DEBUG - 2013-08-22 10:12:23 --> Total execution time: 1.8181
DEBUG - 2013-08-22 10:12:24 --> Config Class Initialized
DEBUG - 2013-08-22 10:12:24 --> Hooks Class Initialized
DEBUG - 2013-08-22 10:12:24 --> Utf8 Class Initialized
DEBUG - 2013-08-22 10:12:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 10:12:24 --> URI Class Initialized
DEBUG - 2013-08-22 10:12:24 --> Router Class Initialized
ERROR - 2013-08-22 10:12:24 --> 404 Page Not Found --> css
DEBUG - 2013-08-22 10:12:37 --> Config Class Initialized
DEBUG - 2013-08-22 10:12:37 --> Hooks Class Initialized
DEBUG - 2013-08-22 10:12:37 --> Utf8 Class Initialized
DEBUG - 2013-08-22 10:12:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 10:12:37 --> URI Class Initialized
DEBUG - 2013-08-22 10:12:37 --> Router Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Output Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Security Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Input Class Initialized
DEBUG - 2013-08-22 10:12:38 --> XSS Filtering completed
DEBUG - 2013-08-22 10:12:38 --> XSS Filtering completed
DEBUG - 2013-08-22 10:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-22 10:12:38 --> Language Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Loader Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Helper loaded: url_helper
DEBUG - 2013-08-22 10:12:38 --> Helper loaded: file_helper
DEBUG - 2013-08-22 10:12:38 --> Helper loaded: form_helper
DEBUG - 2013-08-22 10:12:38 --> Database Driver Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Session Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Helper loaded: string_helper
DEBUG - 2013-08-22 10:12:38 --> Session routines successfully run
DEBUG - 2013-08-22 10:12:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Controller Class Initialized
ERROR - 2013-08-22 10:12:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 10:12:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 10:12:38 --> Model Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-22 10:12:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-22 10:12:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-22 10:12:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-22 10:12:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-22 10:12:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-22 10:12:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-22 10:12:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-22 10:12:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-22 10:12:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-22 10:12:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-22 10:12:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-22 10:12:38 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-08-22 10:12:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-22 10:12:38 --> Final output sent to browser
DEBUG - 2013-08-22 10:12:38 --> Total execution time: 0.4540
DEBUG - 2013-08-22 10:12:38 --> Config Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Hooks Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Utf8 Class Initialized
DEBUG - 2013-08-22 10:12:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-22 10:12:38 --> URI Class Initialized
DEBUG - 2013-08-22 10:12:38 --> Router Class Initialized
ERROR - 2013-08-22 10:12:38 --> 404 Page Not Found --> css
