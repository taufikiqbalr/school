<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-17 03:55:49 --> Config Class Initialized
DEBUG - 2013-08-17 03:55:49 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:55:49 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:55:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:55:49 --> URI Class Initialized
DEBUG - 2013-08-17 03:55:49 --> Router Class Initialized
DEBUG - 2013-08-17 03:55:49 --> Output Class Initialized
DEBUG - 2013-08-17 03:55:49 --> Security Class Initialized
DEBUG - 2013-08-17 03:55:49 --> Input Class Initialized
DEBUG - 2013-08-17 03:55:49 --> XSS Filtering completed
DEBUG - 2013-08-17 03:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 03:55:49 --> Language Class Initialized
DEBUG - 2013-08-17 03:55:49 --> Loader Class Initialized
DEBUG - 2013-08-17 03:55:49 --> Helper loaded: url_helper
DEBUG - 2013-08-17 03:55:49 --> Helper loaded: file_helper
DEBUG - 2013-08-17 03:55:49 --> Helper loaded: form_helper
DEBUG - 2013-08-17 03:55:50 --> Database Driver Class Initialized
DEBUG - 2013-08-17 03:55:50 --> Session Class Initialized
DEBUG - 2013-08-17 03:55:50 --> Helper loaded: string_helper
DEBUG - 2013-08-17 03:55:50 --> A session cookie was not found.
DEBUG - 2013-08-17 03:55:50 --> Session routines successfully run
DEBUG - 2013-08-17 03:55:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 03:55:50 --> Controller Class Initialized
ERROR - 2013-08-17 03:55:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:55:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:55:50 --> Model Class Initialized
DEBUG - 2013-08-17 03:55:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 03:55:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 03:55:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 03:55:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 03:55:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:55:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:55:50 --> Pagination Class Initialized
DEBUG - 2013-08-17 03:55:51 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 03:55:51 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 03:55:51 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 03:55:51 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 03:55:51 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 03:55:51 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 03:55:51 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 03:55:51 --> Final output sent to browser
DEBUG - 2013-08-17 03:55:51 --> Total execution time: 1.4911
DEBUG - 2013-08-17 03:55:51 --> Config Class Initialized
DEBUG - 2013-08-17 03:55:51 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:55:51 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:55:51 --> URI Class Initialized
DEBUG - 2013-08-17 03:55:51 --> Router Class Initialized
ERROR - 2013-08-17 03:55:51 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 03:56:01 --> Config Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:56:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:56:01 --> URI Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Router Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Output Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Security Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Input Class Initialized
DEBUG - 2013-08-17 03:56:01 --> XSS Filtering completed
DEBUG - 2013-08-17 03:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 03:56:01 --> Language Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Loader Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: url_helper
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: file_helper
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: form_helper
DEBUG - 2013-08-17 03:56:01 --> Database Driver Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Session Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: string_helper
DEBUG - 2013-08-17 03:56:01 --> Session routines successfully run
DEBUG - 2013-08-17 03:56:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Controller Class Initialized
ERROR - 2013-08-17 03:56:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:56:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:56:01 --> Model Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 03:56:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 03:56:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 03:56:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:56:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:56:01 --> Config Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:56:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:56:01 --> URI Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Router Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Output Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Security Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Input Class Initialized
DEBUG - 2013-08-17 03:56:01 --> XSS Filtering completed
DEBUG - 2013-08-17 03:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 03:56:01 --> Language Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Loader Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: url_helper
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: file_helper
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: form_helper
DEBUG - 2013-08-17 03:56:01 --> Database Driver Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Session Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: string_helper
DEBUG - 2013-08-17 03:56:01 --> Session routines successfully run
DEBUG - 2013-08-17 03:56:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Controller Class Initialized
ERROR - 2013-08-17 03:56:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:56:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:56:01 --> Model Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 03:56:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 03:56:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 03:56:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 03:56:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:56:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:56:01 --> Pagination Class Initialized
DEBUG - 2013-08-17 03:56:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 03:56:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 03:56:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 03:56:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 03:56:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 03:56:01 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 03:56:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 03:56:01 --> Final output sent to browser
DEBUG - 2013-08-17 03:56:01 --> Total execution time: 0.1750
DEBUG - 2013-08-17 03:56:01 --> Config Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:56:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:56:01 --> URI Class Initialized
DEBUG - 2013-08-17 03:56:01 --> Router Class Initialized
ERROR - 2013-08-17 03:56:01 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 03:56:05 --> Config Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:56:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:56:05 --> URI Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Router Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Output Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Security Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Input Class Initialized
DEBUG - 2013-08-17 03:56:05 --> XSS Filtering completed
DEBUG - 2013-08-17 03:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 03:56:05 --> Language Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Loader Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Helper loaded: url_helper
DEBUG - 2013-08-17 03:56:05 --> Helper loaded: file_helper
DEBUG - 2013-08-17 03:56:05 --> Helper loaded: form_helper
DEBUG - 2013-08-17 03:56:05 --> Database Driver Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Session Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Helper loaded: string_helper
DEBUG - 2013-08-17 03:56:05 --> Session garbage collection performed.
DEBUG - 2013-08-17 03:56:05 --> Session routines successfully run
DEBUG - 2013-08-17 03:56:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Controller Class Initialized
ERROR - 2013-08-17 03:56:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:56:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:56:05 --> Model Class Initialized
DEBUG - 2013-08-17 03:56:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 03:56:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 03:56:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 03:56:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 03:56:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:56:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:56:06 --> Config Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:56:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:56:06 --> URI Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Router Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Output Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Security Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Input Class Initialized
DEBUG - 2013-08-17 03:56:06 --> XSS Filtering completed
DEBUG - 2013-08-17 03:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 03:56:06 --> Language Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Loader Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Helper loaded: url_helper
DEBUG - 2013-08-17 03:56:06 --> Helper loaded: file_helper
DEBUG - 2013-08-17 03:56:06 --> Helper loaded: form_helper
DEBUG - 2013-08-17 03:56:06 --> Database Driver Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Session Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Helper loaded: string_helper
DEBUG - 2013-08-17 03:56:06 --> Session routines successfully run
DEBUG - 2013-08-17 03:56:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Controller Class Initialized
ERROR - 2013-08-17 03:56:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:56:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:56:06 --> Model Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 03:56:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 03:56:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 03:56:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 03:56:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:56:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:56:06 --> Pagination Class Initialized
DEBUG - 2013-08-17 03:56:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 03:56:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 03:56:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 03:56:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 03:56:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 03:56:06 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 03:56:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 03:56:06 --> Final output sent to browser
DEBUG - 2013-08-17 03:56:06 --> Total execution time: 0.1940
DEBUG - 2013-08-17 03:56:06 --> Config Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:56:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:56:06 --> URI Class Initialized
DEBUG - 2013-08-17 03:56:06 --> Router Class Initialized
ERROR - 2013-08-17 03:56:06 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 03:58:29 --> Config Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:58:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:58:29 --> URI Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Router Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Output Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Security Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Input Class Initialized
DEBUG - 2013-08-17 03:58:29 --> XSS Filtering completed
DEBUG - 2013-08-17 03:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 03:58:29 --> Language Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Loader Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Helper loaded: url_helper
DEBUG - 2013-08-17 03:58:29 --> Helper loaded: file_helper
DEBUG - 2013-08-17 03:58:29 --> Helper loaded: form_helper
DEBUG - 2013-08-17 03:58:29 --> Database Driver Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Session Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Helper loaded: string_helper
DEBUG - 2013-08-17 03:58:29 --> Session routines successfully run
DEBUG - 2013-08-17 03:58:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Controller Class Initialized
ERROR - 2013-08-17 03:58:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:58:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:58:29 --> Model Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 03:58:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 03:58:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 03:58:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 03:58:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 03:58:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 03:58:29 --> Pagination Class Initialized
DEBUG - 2013-08-17 03:58:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 03:58:29 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 03:58:29 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 03:58:29 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 03:58:29 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 03:58:29 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 03:58:29 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 03:58:29 --> Final output sent to browser
DEBUG - 2013-08-17 03:58:29 --> Total execution time: 0.1990
DEBUG - 2013-08-17 03:58:29 --> Config Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Hooks Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Utf8 Class Initialized
DEBUG - 2013-08-17 03:58:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 03:58:29 --> URI Class Initialized
DEBUG - 2013-08-17 03:58:29 --> Router Class Initialized
ERROR - 2013-08-17 03:58:29 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:01:40 --> Config Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:01:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:01:40 --> URI Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Router Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Output Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Security Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Input Class Initialized
DEBUG - 2013-08-17 04:01:40 --> XSS Filtering completed
DEBUG - 2013-08-17 04:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:01:40 --> Language Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Loader Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:01:40 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:01:40 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:01:40 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Session Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:01:40 --> Session routines successfully run
DEBUG - 2013-08-17 04:01:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Controller Class Initialized
ERROR - 2013-08-17 04:01:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:01:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:01:40 --> Model Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:01:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:01:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:01:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:01:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:01:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:01:40 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:01:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:01:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:01:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:01:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:01:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:01:40 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:01:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:01:40 --> Final output sent to browser
DEBUG - 2013-08-17 04:01:40 --> Total execution time: 0.2530
DEBUG - 2013-08-17 04:01:40 --> Config Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:01:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:01:40 --> URI Class Initialized
DEBUG - 2013-08-17 04:01:40 --> Router Class Initialized
ERROR - 2013-08-17 04:01:40 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:02:09 --> Config Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:02:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:02:09 --> URI Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Router Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Output Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Security Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Input Class Initialized
DEBUG - 2013-08-17 04:02:09 --> XSS Filtering completed
DEBUG - 2013-08-17 04:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:02:09 --> Language Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Loader Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:02:09 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:02:09 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:02:09 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Session Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:02:09 --> Session routines successfully run
DEBUG - 2013-08-17 04:02:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Controller Class Initialized
ERROR - 2013-08-17 04:02:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:02:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:02:09 --> Model Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:02:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:02:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:02:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:02:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:02:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:02:09 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:02:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:02:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:02:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:02:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:02:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:02:09 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:02:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:02:09 --> Final output sent to browser
DEBUG - 2013-08-17 04:02:09 --> Total execution time: 0.2160
DEBUG - 2013-08-17 04:02:09 --> Config Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:02:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:02:09 --> URI Class Initialized
DEBUG - 2013-08-17 04:02:09 --> Router Class Initialized
ERROR - 2013-08-17 04:02:09 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:05:07 --> Config Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:05:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:05:07 --> URI Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Router Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Output Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Security Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Input Class Initialized
DEBUG - 2013-08-17 04:05:07 --> XSS Filtering completed
DEBUG - 2013-08-17 04:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:05:07 --> Language Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Loader Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:05:07 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:05:07 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:05:07 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Session Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:05:07 --> Session routines successfully run
DEBUG - 2013-08-17 04:05:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Controller Class Initialized
ERROR - 2013-08-17 04:05:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:05:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:05:07 --> Model Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:05:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:05:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:05:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:05:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:05:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:05:07 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:05:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:05:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:05:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:05:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:05:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:05:07 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:05:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:05:07 --> Final output sent to browser
DEBUG - 2013-08-17 04:05:07 --> Total execution time: 0.2390
DEBUG - 2013-08-17 04:05:07 --> Config Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:05:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:05:07 --> URI Class Initialized
DEBUG - 2013-08-17 04:05:07 --> Router Class Initialized
ERROR - 2013-08-17 04:05:07 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:05:35 --> Config Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:05:35 --> URI Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Router Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Output Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Security Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Input Class Initialized
DEBUG - 2013-08-17 04:05:35 --> XSS Filtering completed
DEBUG - 2013-08-17 04:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:05:35 --> Language Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Loader Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:05:35 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:05:35 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:05:35 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Session Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:05:35 --> Session routines successfully run
DEBUG - 2013-08-17 04:05:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Controller Class Initialized
ERROR - 2013-08-17 04:05:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:05:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:05:35 --> Model Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:05:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:05:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:05:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:05:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:05:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:05:35 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:05:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:05:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:05:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:05:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:05:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:05:35 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:05:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:05:35 --> Final output sent to browser
DEBUG - 2013-08-17 04:05:35 --> Total execution time: 0.2270
DEBUG - 2013-08-17 04:05:35 --> Config Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:05:35 --> URI Class Initialized
DEBUG - 2013-08-17 04:05:35 --> Router Class Initialized
ERROR - 2013-08-17 04:05:35 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:05:42 --> Config Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:05:42 --> URI Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Router Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Output Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Security Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Input Class Initialized
DEBUG - 2013-08-17 04:05:42 --> XSS Filtering completed
DEBUG - 2013-08-17 04:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:05:42 --> Language Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Loader Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:05:42 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Session Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:05:42 --> Session routines successfully run
DEBUG - 2013-08-17 04:05:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Controller Class Initialized
ERROR - 2013-08-17 04:05:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:05:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:05:42 --> Model Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:05:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:05:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:05:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:05:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:05:42 --> Config Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:05:42 --> URI Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Router Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Output Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Security Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Input Class Initialized
DEBUG - 2013-08-17 04:05:42 --> XSS Filtering completed
DEBUG - 2013-08-17 04:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:05:42 --> Language Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Loader Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:05:42 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Session Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:05:42 --> Session routines successfully run
DEBUG - 2013-08-17 04:05:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Controller Class Initialized
ERROR - 2013-08-17 04:05:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:05:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:05:42 --> Model Class Initialized
DEBUG - 2013-08-17 04:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:05:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:05:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:05:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:05:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:05:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:05:42 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:05:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:05:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:05:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:05:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:05:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:05:42 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:05:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:05:42 --> Final output sent to browser
DEBUG - 2013-08-17 04:05:42 --> Total execution time: 0.3260
DEBUG - 2013-08-17 04:05:42 --> Config Class Initialized
DEBUG - 2013-08-17 04:05:43 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:05:43 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:05:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:05:43 --> URI Class Initialized
DEBUG - 2013-08-17 04:05:43 --> Router Class Initialized
ERROR - 2013-08-17 04:05:43 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:08:41 --> Config Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:08:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:08:41 --> URI Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Router Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Output Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Security Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Input Class Initialized
DEBUG - 2013-08-17 04:08:41 --> XSS Filtering completed
DEBUG - 2013-08-17 04:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:08:41 --> Language Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Loader Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:08:41 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:08:41 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:08:41 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Session Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:08:41 --> Session routines successfully run
DEBUG - 2013-08-17 04:08:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Controller Class Initialized
ERROR - 2013-08-17 04:08:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:08:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:08:41 --> Model Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:08:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:08:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:08:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:08:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:08:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:08:41 --> Config Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:08:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:08:41 --> URI Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Router Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Output Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Security Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Input Class Initialized
DEBUG - 2013-08-17 04:08:41 --> XSS Filtering completed
DEBUG - 2013-08-17 04:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:08:41 --> Language Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Loader Class Initialized
DEBUG - 2013-08-17 04:08:41 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:08:41 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:08:41 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:08:42 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:08:42 --> Session Class Initialized
DEBUG - 2013-08-17 04:08:42 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:08:42 --> Session routines successfully run
DEBUG - 2013-08-17 04:08:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:08:42 --> Controller Class Initialized
ERROR - 2013-08-17 04:08:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:08:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:08:42 --> Model Class Initialized
DEBUG - 2013-08-17 04:08:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:08:42 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:08:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:08:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:08:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:08:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:08:42 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:08:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:08:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:08:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:08:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:08:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:08:42 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:08:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:08:42 --> Final output sent to browser
DEBUG - 2013-08-17 04:08:42 --> Total execution time: 0.3820
DEBUG - 2013-08-17 04:08:42 --> Config Class Initialized
DEBUG - 2013-08-17 04:08:42 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:08:42 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:08:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:08:42 --> URI Class Initialized
DEBUG - 2013-08-17 04:08:42 --> Router Class Initialized
ERROR - 2013-08-17 04:08:42 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:08:54 --> Config Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:08:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:08:54 --> URI Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Router Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Output Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Security Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Input Class Initialized
DEBUG - 2013-08-17 04:08:54 --> XSS Filtering completed
DEBUG - 2013-08-17 04:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:08:54 --> Language Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Loader Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:08:54 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:08:54 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:08:54 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Session Class Initialized
DEBUG - 2013-08-17 04:08:54 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:08:55 --> Session routines successfully run
DEBUG - 2013-08-17 04:08:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Controller Class Initialized
ERROR - 2013-08-17 04:08:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:08:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:08:55 --> Model Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:08:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:08:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:08:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:08:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:08:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:08:55 --> Config Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:08:55 --> URI Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Router Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Output Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Security Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Input Class Initialized
DEBUG - 2013-08-17 04:08:55 --> XSS Filtering completed
DEBUG - 2013-08-17 04:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:08:55 --> Language Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Loader Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:08:55 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:08:55 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:08:55 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Session Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:08:55 --> Session routines successfully run
DEBUG - 2013-08-17 04:08:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Controller Class Initialized
ERROR - 2013-08-17 04:08:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:08:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:08:55 --> Model Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:08:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:08:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:08:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:08:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:08:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:08:55 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:08:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:08:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:08:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:08:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:08:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:08:55 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:08:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:08:55 --> Final output sent to browser
DEBUG - 2013-08-17 04:08:55 --> Total execution time: 0.3020
DEBUG - 2013-08-17 04:08:55 --> Config Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:08:55 --> URI Class Initialized
DEBUG - 2013-08-17 04:08:55 --> Router Class Initialized
ERROR - 2013-08-17 04:08:55 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:09:27 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:27 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:28 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Router Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Output Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Security Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Input Class Initialized
DEBUG - 2013-08-17 04:09:28 --> XSS Filtering completed
DEBUG - 2013-08-17 04:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:09:28 --> Language Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Loader Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:09:28 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:09:28 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:09:28 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Session Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:09:28 --> Session routines successfully run
DEBUG - 2013-08-17 04:09:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Controller Class Initialized
ERROR - 2013-08-17 04:09:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:28 --> Model Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:09:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:09:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:09:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:09:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:28 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:09:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:09:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:09:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:09:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:09:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:09:28 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:09:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:09:28 --> Final output sent to browser
DEBUG - 2013-08-17 04:09:28 --> Total execution time: 0.3290
DEBUG - 2013-08-17 04:09:28 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:28 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:28 --> Router Class Initialized
ERROR - 2013-08-17 04:09:28 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:09:32 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:32 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Router Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Output Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Security Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Input Class Initialized
DEBUG - 2013-08-17 04:09:32 --> XSS Filtering completed
DEBUG - 2013-08-17 04:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:09:32 --> Language Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Loader Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:09:32 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Session Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:09:32 --> Session routines successfully run
DEBUG - 2013-08-17 04:09:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Controller Class Initialized
ERROR - 2013-08-17 04:09:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:32 --> Model Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:09:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:09:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:09:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:32 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:32 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Router Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Output Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Security Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Input Class Initialized
DEBUG - 2013-08-17 04:09:32 --> XSS Filtering completed
DEBUG - 2013-08-17 04:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:09:32 --> Language Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Loader Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:09:32 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Session Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:09:32 --> Session routines successfully run
DEBUG - 2013-08-17 04:09:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Controller Class Initialized
ERROR - 2013-08-17 04:09:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:32 --> Model Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:09:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:09:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:09:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:09:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:32 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:09:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:09:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:09:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:09:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:09:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:09:32 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:09:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:09:32 --> Final output sent to browser
DEBUG - 2013-08-17 04:09:32 --> Total execution time: 0.3870
DEBUG - 2013-08-17 04:09:32 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:32 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:32 --> Router Class Initialized
ERROR - 2013-08-17 04:09:32 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:09:38 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:38 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Router Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Output Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Security Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Input Class Initialized
DEBUG - 2013-08-17 04:09:38 --> XSS Filtering completed
DEBUG - 2013-08-17 04:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:09:38 --> Language Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Loader Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:09:38 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Session Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:09:38 --> Session routines successfully run
DEBUG - 2013-08-17 04:09:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Controller Class Initialized
ERROR - 2013-08-17 04:09:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:38 --> Model Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:09:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:09:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:09:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:38 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:38 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Router Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Output Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Security Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Input Class Initialized
DEBUG - 2013-08-17 04:09:38 --> XSS Filtering completed
DEBUG - 2013-08-17 04:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:09:38 --> Language Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Loader Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:09:38 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Session Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:09:38 --> Session routines successfully run
DEBUG - 2013-08-17 04:09:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Controller Class Initialized
ERROR - 2013-08-17 04:09:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:38 --> Model Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:09:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:09:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:09:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:09:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:38 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:09:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:09:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:09:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:09:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:09:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:09:38 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:09:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:09:38 --> Final output sent to browser
DEBUG - 2013-08-17 04:09:38 --> Total execution time: 0.3100
DEBUG - 2013-08-17 04:09:38 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:38 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:38 --> Router Class Initialized
ERROR - 2013-08-17 04:09:38 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:09:43 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:43 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:43 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:43 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:43 --> Router Class Initialized
DEBUG - 2013-08-17 04:09:43 --> Output Class Initialized
DEBUG - 2013-08-17 04:09:43 --> Security Class Initialized
DEBUG - 2013-08-17 04:09:43 --> Input Class Initialized
DEBUG - 2013-08-17 04:09:43 --> XSS Filtering completed
DEBUG - 2013-08-17 04:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:09:43 --> Language Class Initialized
DEBUG - 2013-08-17 04:09:43 --> Loader Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:09:44 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Session Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:09:44 --> Session routines successfully run
DEBUG - 2013-08-17 04:09:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Controller Class Initialized
ERROR - 2013-08-17 04:09:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:44 --> Model Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:09:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:09:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:09:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:44 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:44 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Router Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Output Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Security Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Input Class Initialized
DEBUG - 2013-08-17 04:09:44 --> XSS Filtering completed
DEBUG - 2013-08-17 04:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:09:44 --> Language Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Loader Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:09:44 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Session Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:09:44 --> Session routines successfully run
DEBUG - 2013-08-17 04:09:44 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Controller Class Initialized
ERROR - 2013-08-17 04:09:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:44 --> Model Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:09:44 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:09:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:09:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:09:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:44 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:09:44 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:09:44 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:09:44 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:09:44 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:09:44 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:09:44 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:09:44 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:09:44 --> Final output sent to browser
DEBUG - 2013-08-17 04:09:44 --> Total execution time: 0.3570
DEBUG - 2013-08-17 04:09:44 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:44 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:44 --> Router Class Initialized
ERROR - 2013-08-17 04:09:44 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:09:58 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:58 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Router Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Output Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Security Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Input Class Initialized
DEBUG - 2013-08-17 04:09:58 --> XSS Filtering completed
DEBUG - 2013-08-17 04:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:09:58 --> Language Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Loader Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:09:58 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Session Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:09:58 --> Session routines successfully run
DEBUG - 2013-08-17 04:09:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Controller Class Initialized
ERROR - 2013-08-17 04:09:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:58 --> Model Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:09:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:09:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:09:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:58 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:58 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Router Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Output Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Security Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Input Class Initialized
DEBUG - 2013-08-17 04:09:58 --> XSS Filtering completed
DEBUG - 2013-08-17 04:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:09:58 --> Language Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Loader Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:09:58 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Session Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:09:58 --> Session routines successfully run
DEBUG - 2013-08-17 04:09:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Controller Class Initialized
ERROR - 2013-08-17 04:09:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:58 --> Model Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:09:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:09:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:09:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:09:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:09:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:09:58 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:09:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:09:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:09:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:09:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:09:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:09:58 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:09:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:09:58 --> Final output sent to browser
DEBUG - 2013-08-17 04:09:58 --> Total execution time: 0.3450
DEBUG - 2013-08-17 04:09:58 --> Config Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:09:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:09:58 --> URI Class Initialized
DEBUG - 2013-08-17 04:09:58 --> Router Class Initialized
ERROR - 2013-08-17 04:09:58 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:12:32 --> Config Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:12:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:12:32 --> URI Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Router Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Output Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Security Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Input Class Initialized
DEBUG - 2013-08-17 04:12:32 --> XSS Filtering completed
DEBUG - 2013-08-17 04:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:12:32 --> Language Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Loader Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:12:32 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:12:32 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:12:32 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Session Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:12:32 --> Session routines successfully run
DEBUG - 2013-08-17 04:12:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Controller Class Initialized
ERROR - 2013-08-17 04:12:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:12:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:12:32 --> Model Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:12:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:12:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:12:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:12:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:12:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:12:32 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:12:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:12:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:12:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:12:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:12:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:12:32 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:12:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:12:32 --> Final output sent to browser
DEBUG - 2013-08-17 04:12:32 --> Total execution time: 0.3780
DEBUG - 2013-08-17 04:12:32 --> Config Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:12:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:12:32 --> URI Class Initialized
DEBUG - 2013-08-17 04:12:32 --> Router Class Initialized
ERROR - 2013-08-17 04:12:32 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:17:13 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:13 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Router Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Output Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Security Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Input Class Initialized
DEBUG - 2013-08-17 04:17:13 --> XSS Filtering completed
DEBUG - 2013-08-17 04:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:17:13 --> Language Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Loader Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:17:13 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:17:13 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:17:13 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Session Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:17:13 --> Session garbage collection performed.
DEBUG - 2013-08-17 04:17:13 --> Session routines successfully run
DEBUG - 2013-08-17 04:17:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Controller Class Initialized
ERROR - 2013-08-17 04:17:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:13 --> Model Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:17:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:17:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:17:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:17:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:13 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:17:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:17:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:17:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:17:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:17:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:17:13 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:17:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:17:13 --> Final output sent to browser
DEBUG - 2013-08-17 04:17:13 --> Total execution time: 0.3780
DEBUG - 2013-08-17 04:17:13 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:13 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:13 --> Router Class Initialized
ERROR - 2013-08-17 04:17:13 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:17:19 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:19 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Router Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Output Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Security Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Input Class Initialized
DEBUG - 2013-08-17 04:17:19 --> XSS Filtering completed
DEBUG - 2013-08-17 04:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:17:19 --> Language Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Loader Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:17:19 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:17:19 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:17:19 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Session Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:17:19 --> Session routines successfully run
DEBUG - 2013-08-17 04:17:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Controller Class Initialized
ERROR - 2013-08-17 04:17:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:19 --> Model Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:17:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:17:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:17:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:17:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:19 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:19 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Router Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Output Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Security Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Input Class Initialized
DEBUG - 2013-08-17 04:17:19 --> XSS Filtering completed
DEBUG - 2013-08-17 04:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:17:19 --> Language Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Loader Class Initialized
DEBUG - 2013-08-17 04:17:19 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:17:19 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:17:19 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:17:20 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:17:20 --> Session Class Initialized
DEBUG - 2013-08-17 04:17:20 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:17:20 --> Session routines successfully run
DEBUG - 2013-08-17 04:17:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:17:20 --> Controller Class Initialized
ERROR - 2013-08-17 04:17:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:20 --> Model Class Initialized
DEBUG - 2013-08-17 04:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:17:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:17:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:17:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:17:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:20 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:17:20 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:17:20 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:17:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:17:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:17:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:17:20 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:17:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:17:20 --> Final output sent to browser
DEBUG - 2013-08-17 04:17:20 --> Total execution time: 0.3810
DEBUG - 2013-08-17 04:17:20 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:20 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:20 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:20 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:20 --> Router Class Initialized
ERROR - 2013-08-17 04:17:20 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:17:25 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:25 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Router Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Output Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Security Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Input Class Initialized
DEBUG - 2013-08-17 04:17:25 --> XSS Filtering completed
DEBUG - 2013-08-17 04:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:17:25 --> Language Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Loader Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:17:25 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:17:25 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:17:25 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Session Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:17:25 --> Session routines successfully run
DEBUG - 2013-08-17 04:17:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Controller Class Initialized
ERROR - 2013-08-17 04:17:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:25 --> Model Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:17:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:17:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:17:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:17:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:25 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:25 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Router Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Output Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Security Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Input Class Initialized
DEBUG - 2013-08-17 04:17:25 --> XSS Filtering completed
DEBUG - 2013-08-17 04:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:17:25 --> Language Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Loader Class Initialized
DEBUG - 2013-08-17 04:17:25 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:17:25 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:17:25 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:17:26 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:17:26 --> Session Class Initialized
DEBUG - 2013-08-17 04:17:26 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:17:26 --> Session routines successfully run
DEBUG - 2013-08-17 04:17:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:17:26 --> Controller Class Initialized
ERROR - 2013-08-17 04:17:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:26 --> Model Class Initialized
DEBUG - 2013-08-17 04:17:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:17:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:17:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:17:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:17:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:26 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:17:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:17:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:17:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:17:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:17:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:17:26 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:17:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:17:26 --> Final output sent to browser
DEBUG - 2013-08-17 04:17:26 --> Total execution time: 0.3940
DEBUG - 2013-08-17 04:17:26 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:26 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:26 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:26 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:26 --> Router Class Initialized
ERROR - 2013-08-17 04:17:26 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:17:51 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:51 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:51 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:51 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:51 --> Router Class Initialized
DEBUG - 2013-08-17 04:17:51 --> Output Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Security Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Input Class Initialized
DEBUG - 2013-08-17 04:17:52 --> XSS Filtering completed
DEBUG - 2013-08-17 04:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:17:52 --> Language Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Loader Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:17:52 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:17:52 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:17:52 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Session Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:17:52 --> Session routines successfully run
DEBUG - 2013-08-17 04:17:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Controller Class Initialized
ERROR - 2013-08-17 04:17:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:52 --> Model Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:17:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:17:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:17:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:17:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:52 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:17:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:17:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:17:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:17:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:17:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:17:52 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:17:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:17:52 --> Final output sent to browser
DEBUG - 2013-08-17 04:17:52 --> Total execution time: 0.4050
DEBUG - 2013-08-17 04:17:52 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:52 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:52 --> Router Class Initialized
ERROR - 2013-08-17 04:17:52 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:17:56 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:56 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Router Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Output Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Security Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Input Class Initialized
DEBUG - 2013-08-17 04:17:56 --> XSS Filtering completed
DEBUG - 2013-08-17 04:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:17:56 --> Language Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Loader Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:17:56 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Session Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:17:56 --> Session routines successfully run
DEBUG - 2013-08-17 04:17:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Controller Class Initialized
ERROR - 2013-08-17 04:17:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:56 --> Model Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:17:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:17:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:17:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:56 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:56 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Router Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Output Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Security Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Input Class Initialized
DEBUG - 2013-08-17 04:17:56 --> XSS Filtering completed
DEBUG - 2013-08-17 04:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:17:56 --> Language Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Loader Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:17:56 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Session Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:17:56 --> Session routines successfully run
DEBUG - 2013-08-17 04:17:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Controller Class Initialized
ERROR - 2013-08-17 04:17:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:56 --> Model Class Initialized
DEBUG - 2013-08-17 04:17:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:17:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:17:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:17:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:17:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:17:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:17:57 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:17:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:17:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:17:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:17:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:17:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:17:57 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:17:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:17:57 --> Final output sent to browser
DEBUG - 2013-08-17 04:17:57 --> Total execution time: 0.4340
DEBUG - 2013-08-17 04:17:57 --> Config Class Initialized
DEBUG - 2013-08-17 04:17:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:17:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:17:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:17:57 --> URI Class Initialized
DEBUG - 2013-08-17 04:17:57 --> Router Class Initialized
ERROR - 2013-08-17 04:17:57 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:18:06 --> Config Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:18:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:18:06 --> URI Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Router Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Output Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Security Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Input Class Initialized
DEBUG - 2013-08-17 04:18:06 --> XSS Filtering completed
DEBUG - 2013-08-17 04:18:06 --> XSS Filtering completed
DEBUG - 2013-08-17 04:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:18:06 --> Language Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Loader Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:18:06 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:18:06 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:18:06 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Session Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:18:06 --> Session routines successfully run
DEBUG - 2013-08-17 04:18:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Controller Class Initialized
ERROR - 2013-08-17 04:18:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:18:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:18:06 --> Model Class Initialized
DEBUG - 2013-08-17 04:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:18:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:18:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:18:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:18:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:18:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:19:09 --> Config Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:19:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:19:09 --> URI Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Router Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Output Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Security Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Input Class Initialized
DEBUG - 2013-08-17 04:19:09 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:09 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:09 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:19:09 --> Language Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Loader Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:19:09 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:19:09 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:19:09 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Session Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:19:09 --> Session routines successfully run
DEBUG - 2013-08-17 04:19:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Controller Class Initialized
ERROR - 2013-08-17 04:19:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:19:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:19:09 --> Model Class Initialized
DEBUG - 2013-08-17 04:19:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:19:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:19:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:19:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:19:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:19:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:19:33 --> Config Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:19:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:19:33 --> URI Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Router Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Output Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Security Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Input Class Initialized
DEBUG - 2013-08-17 04:19:33 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:33 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:33 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:33 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:33 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:33 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:33 --> XSS Filtering completed
DEBUG - 2013-08-17 04:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:19:33 --> Language Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Loader Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:19:33 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:19:33 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:19:33 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Session Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:19:33 --> Session routines successfully run
DEBUG - 2013-08-17 04:19:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Controller Class Initialized
ERROR - 2013-08-17 04:19:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:19:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:19:33 --> Model Class Initialized
DEBUG - 2013-08-17 04:19:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:19:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:19:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:19:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:19:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:19:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:21:55 --> Config Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:21:55 --> URI Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Router Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Output Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Security Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Input Class Initialized
DEBUG - 2013-08-17 04:21:55 --> XSS Filtering completed
DEBUG - 2013-08-17 04:21:55 --> XSS Filtering completed
DEBUG - 2013-08-17 04:21:55 --> XSS Filtering completed
DEBUG - 2013-08-17 04:21:55 --> XSS Filtering completed
DEBUG - 2013-08-17 04:21:55 --> XSS Filtering completed
DEBUG - 2013-08-17 04:21:55 --> XSS Filtering completed
DEBUG - 2013-08-17 04:21:55 --> XSS Filtering completed
DEBUG - 2013-08-17 04:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:21:55 --> Language Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Loader Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:21:55 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:21:55 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:21:55 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Session Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:21:55 --> Session routines successfully run
DEBUG - 2013-08-17 04:21:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Controller Class Initialized
ERROR - 2013-08-17 04:21:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:21:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:21:55 --> Model Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:21:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:21:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:21:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:21:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:21:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:21:55 --> Config Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:21:55 --> URI Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Router Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Output Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Security Class Initialized
DEBUG - 2013-08-17 04:21:55 --> Input Class Initialized
DEBUG - 2013-08-17 04:21:55 --> XSS Filtering completed
DEBUG - 2013-08-17 04:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:21:56 --> Language Class Initialized
DEBUG - 2013-08-17 04:21:56 --> Loader Class Initialized
DEBUG - 2013-08-17 04:21:56 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:21:56 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:21:56 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:21:56 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:21:56 --> Session Class Initialized
DEBUG - 2013-08-17 04:21:56 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:21:56 --> Session routines successfully run
DEBUG - 2013-08-17 04:21:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:21:56 --> Controller Class Initialized
ERROR - 2013-08-17 04:21:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:21:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:21:56 --> Model Class Initialized
DEBUG - 2013-08-17 04:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:21:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:21:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:21:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:21:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:21:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:21:56 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:21:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:21:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:21:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:21:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:21:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:21:56 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:21:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:21:56 --> Final output sent to browser
DEBUG - 2013-08-17 04:21:56 --> Total execution time: 0.4520
DEBUG - 2013-08-17 04:21:56 --> Config Class Initialized
DEBUG - 2013-08-17 04:21:56 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:21:56 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:21:56 --> URI Class Initialized
DEBUG - 2013-08-17 04:21:56 --> Router Class Initialized
ERROR - 2013-08-17 04:21:56 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:23:03 --> Config Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:23:03 --> URI Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Router Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Output Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Security Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Input Class Initialized
DEBUG - 2013-08-17 04:23:03 --> XSS Filtering completed
DEBUG - 2013-08-17 04:23:03 --> XSS Filtering completed
DEBUG - 2013-08-17 04:23:03 --> XSS Filtering completed
DEBUG - 2013-08-17 04:23:03 --> XSS Filtering completed
DEBUG - 2013-08-17 04:23:03 --> XSS Filtering completed
DEBUG - 2013-08-17 04:23:03 --> XSS Filtering completed
DEBUG - 2013-08-17 04:23:03 --> XSS Filtering completed
DEBUG - 2013-08-17 04:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:23:03 --> Language Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Loader Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:23:03 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:23:03 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:23:03 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Session Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:23:03 --> Session routines successfully run
DEBUG - 2013-08-17 04:23:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Controller Class Initialized
ERROR - 2013-08-17 04:23:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:23:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:23:03 --> Model Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:23:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:23:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:23:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:23:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:23:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:23:03 --> Config Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:23:03 --> URI Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Router Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Output Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Security Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Input Class Initialized
DEBUG - 2013-08-17 04:23:03 --> XSS Filtering completed
DEBUG - 2013-08-17 04:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:23:03 --> Language Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Loader Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:23:03 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:23:03 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:23:03 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Session Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:23:03 --> Session routines successfully run
DEBUG - 2013-08-17 04:23:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:23:03 --> Controller Class Initialized
ERROR - 2013-08-17 04:23:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:23:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:23:04 --> Model Class Initialized
DEBUG - 2013-08-17 04:23:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:23:04 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:23:04 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:23:04 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:23:04 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:23:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:23:04 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:23:04 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:23:04 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:23:04 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:23:04 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:23:04 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:23:04 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:23:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:23:04 --> Final output sent to browser
DEBUG - 2013-08-17 04:23:04 --> Total execution time: 0.4750
DEBUG - 2013-08-17 04:23:04 --> Config Class Initialized
DEBUG - 2013-08-17 04:23:04 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:23:04 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:23:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:23:04 --> URI Class Initialized
DEBUG - 2013-08-17 04:23:04 --> Router Class Initialized
ERROR - 2013-08-17 04:23:04 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:32:57 --> Config Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:32:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:32:57 --> URI Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Router Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Output Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Security Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Input Class Initialized
DEBUG - 2013-08-17 04:32:57 --> XSS Filtering completed
DEBUG - 2013-08-17 04:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:32:57 --> Language Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Loader Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:32:57 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:32:57 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:32:57 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Session Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:32:57 --> Session routines successfully run
DEBUG - 2013-08-17 04:32:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Controller Class Initialized
ERROR - 2013-08-17 04:32:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:32:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:32:57 --> Model Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:32:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:32:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:32:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:32:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:32:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:32:57 --> Config Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:32:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:32:57 --> URI Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Router Class Initialized
DEBUG - 2013-08-17 04:32:57 --> Output Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Security Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Input Class Initialized
DEBUG - 2013-08-17 04:32:58 --> XSS Filtering completed
DEBUG - 2013-08-17 04:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:32:58 --> Language Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Loader Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:32:58 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:32:58 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:32:58 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Session Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:32:58 --> Session routines successfully run
DEBUG - 2013-08-17 04:32:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Controller Class Initialized
ERROR - 2013-08-17 04:32:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:32:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:32:58 --> Model Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:32:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:32:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:32:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:32:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:32:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:32:58 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:32:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:32:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:32:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:32:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:32:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:32:58 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:32:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:32:58 --> Final output sent to browser
DEBUG - 2013-08-17 04:32:58 --> Total execution time: 0.4840
DEBUG - 2013-08-17 04:32:58 --> Config Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:32:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:32:58 --> URI Class Initialized
DEBUG - 2013-08-17 04:32:58 --> Router Class Initialized
ERROR - 2013-08-17 04:32:58 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:33:05 --> Config Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:33:05 --> URI Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Router Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Output Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Security Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Input Class Initialized
DEBUG - 2013-08-17 04:33:05 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:05 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:05 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:05 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:05 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:05 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:05 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:33:05 --> Language Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Loader Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:33:05 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:33:05 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:33:05 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Session Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:33:05 --> Session routines successfully run
DEBUG - 2013-08-17 04:33:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Controller Class Initialized
ERROR - 2013-08-17 04:33:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:05 --> Model Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:33:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:33:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:33:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:33:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:05 --> Config Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:33:05 --> URI Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Router Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Output Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Security Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Input Class Initialized
DEBUG - 2013-08-17 04:33:05 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:33:05 --> Language Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Loader Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:33:05 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:33:05 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:33:05 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Session Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:33:05 --> Session routines successfully run
DEBUG - 2013-08-17 04:33:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:33:05 --> Controller Class Initialized
ERROR - 2013-08-17 04:33:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:06 --> Model Class Initialized
DEBUG - 2013-08-17 04:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:33:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:33:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:33:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:33:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:06 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:33:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:33:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:33:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:33:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:33:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:33:06 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:33:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:33:06 --> Final output sent to browser
DEBUG - 2013-08-17 04:33:06 --> Total execution time: 0.4980
DEBUG - 2013-08-17 04:33:06 --> Config Class Initialized
DEBUG - 2013-08-17 04:33:06 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:33:06 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:33:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:33:06 --> URI Class Initialized
DEBUG - 2013-08-17 04:33:06 --> Router Class Initialized
ERROR - 2013-08-17 04:33:06 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:33:21 --> Config Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:33:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:33:21 --> URI Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Router Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Output Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Security Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Input Class Initialized
DEBUG - 2013-08-17 04:33:21 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:21 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:21 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:21 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:21 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:21 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:21 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:33:21 --> Language Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Loader Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:33:21 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:33:21 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:33:21 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Session Class Initialized
DEBUG - 2013-08-17 04:33:21 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:33:21 --> Session routines successfully run
DEBUG - 2013-08-17 04:33:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:33:22 --> Controller Class Initialized
ERROR - 2013-08-17 04:33:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:22 --> Model Class Initialized
DEBUG - 2013-08-17 04:33:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:33:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:33:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:33:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:33:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:46 --> Config Class Initialized
DEBUG - 2013-08-17 04:33:46 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:33:46 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:33:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:33:46 --> URI Class Initialized
DEBUG - 2013-08-17 04:33:46 --> Router Class Initialized
DEBUG - 2013-08-17 04:33:46 --> Output Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Security Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Input Class Initialized
DEBUG - 2013-08-17 04:33:47 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:33:47 --> Language Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Loader Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:33:47 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Session Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:33:47 --> Session routines successfully run
DEBUG - 2013-08-17 04:33:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Controller Class Initialized
ERROR - 2013-08-17 04:33:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:47 --> Model Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:33:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:33:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:33:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:47 --> Config Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:33:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:33:47 --> URI Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Router Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Output Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Security Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Input Class Initialized
DEBUG - 2013-08-17 04:33:47 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:33:47 --> Language Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Loader Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:33:47 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Session Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:33:47 --> Session routines successfully run
DEBUG - 2013-08-17 04:33:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Controller Class Initialized
ERROR - 2013-08-17 04:33:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:47 --> Model Class Initialized
DEBUG - 2013-08-17 04:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:33:47 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:33:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:33:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:33:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:47 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:33:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:33:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:33:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:33:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:33:47 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:33:47 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:33:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:33:47 --> Final output sent to browser
DEBUG - 2013-08-17 04:33:47 --> Total execution time: 0.5450
DEBUG - 2013-08-17 04:33:48 --> Config Class Initialized
DEBUG - 2013-08-17 04:33:48 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:33:48 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:33:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:33:48 --> URI Class Initialized
DEBUG - 2013-08-17 04:33:48 --> Router Class Initialized
ERROR - 2013-08-17 04:33:48 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:33:57 --> Config Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:33:57 --> URI Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Router Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Output Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Security Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Input Class Initialized
DEBUG - 2013-08-17 04:33:57 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:57 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:57 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:57 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:57 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:57 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:57 --> XSS Filtering completed
DEBUG - 2013-08-17 04:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:33:57 --> Language Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Loader Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:33:57 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:33:57 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:33:57 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Session Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:33:57 --> Session routines successfully run
DEBUG - 2013-08-17 04:33:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Controller Class Initialized
ERROR - 2013-08-17 04:33:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:33:57 --> Model Class Initialized
DEBUG - 2013-08-17 04:33:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:33:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:33:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:33:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:33:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:33:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:34:26 --> Config Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:34:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:34:26 --> URI Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Router Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Output Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Security Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Input Class Initialized
DEBUG - 2013-08-17 04:34:26 --> XSS Filtering completed
DEBUG - 2013-08-17 04:34:26 --> XSS Filtering completed
DEBUG - 2013-08-17 04:34:26 --> XSS Filtering completed
DEBUG - 2013-08-17 04:34:26 --> XSS Filtering completed
DEBUG - 2013-08-17 04:34:26 --> XSS Filtering completed
DEBUG - 2013-08-17 04:34:26 --> XSS Filtering completed
DEBUG - 2013-08-17 04:34:26 --> XSS Filtering completed
DEBUG - 2013-08-17 04:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:34:26 --> Language Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Loader Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:34:26 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:34:26 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:34:26 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Session Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:34:26 --> Session routines successfully run
DEBUG - 2013-08-17 04:34:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Controller Class Initialized
ERROR - 2013-08-17 04:34:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:34:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:34:26 --> Model Class Initialized
DEBUG - 2013-08-17 04:34:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:34:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:34:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:34:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:34:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:34:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:37:44 --> Config Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:37:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:37:44 --> URI Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Router Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Output Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Security Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Input Class Initialized
DEBUG - 2013-08-17 04:37:44 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:44 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:44 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:44 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:44 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:44 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:44 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:37:44 --> Language Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Loader Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:37:44 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:37:44 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:37:44 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Session Class Initialized
DEBUG - 2013-08-17 04:37:44 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:37:44 --> Session routines successfully run
DEBUG - 2013-08-17 04:37:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:37:45 --> Controller Class Initialized
ERROR - 2013-08-17 04:37:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:37:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:37:45 --> Model Class Initialized
DEBUG - 2013-08-17 04:37:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:37:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:37:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:37:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:37:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:37:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:37:45 --> DB Transaction Failure
ERROR - 2013-08-17 04:37:45 --> Query error: Table 'school.tbl' doesn't exist
DEBUG - 2013-08-17 04:37:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-08-17 04:37:59 --> Config Class Initialized
DEBUG - 2013-08-17 04:37:59 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:37:59 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:37:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:37:59 --> URI Class Initialized
DEBUG - 2013-08-17 04:37:59 --> Router Class Initialized
DEBUG - 2013-08-17 04:37:59 --> Output Class Initialized
DEBUG - 2013-08-17 04:37:59 --> Security Class Initialized
DEBUG - 2013-08-17 04:37:59 --> Input Class Initialized
DEBUG - 2013-08-17 04:37:59 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:59 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:59 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:59 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:59 --> XSS Filtering completed
DEBUG - 2013-08-17 04:37:59 --> XSS Filtering completed
DEBUG - 2013-08-17 04:38:00 --> XSS Filtering completed
DEBUG - 2013-08-17 04:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:38:00 --> Language Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Loader Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:38:00 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Session Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:38:00 --> Session routines successfully run
DEBUG - 2013-08-17 04:38:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Controller Class Initialized
ERROR - 2013-08-17 04:38:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:38:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:38:00 --> Model Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:38:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:38:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:38:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:38:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:38:00 --> Config Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:38:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:38:00 --> URI Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Router Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Output Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Security Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Input Class Initialized
DEBUG - 2013-08-17 04:38:00 --> XSS Filtering completed
DEBUG - 2013-08-17 04:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:38:00 --> Language Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Loader Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:38:00 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Session Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:38:00 --> Session routines successfully run
DEBUG - 2013-08-17 04:38:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Controller Class Initialized
ERROR - 2013-08-17 04:38:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:38:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:38:00 --> Model Class Initialized
DEBUG - 2013-08-17 04:38:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:38:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:38:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:38:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:38:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:38:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:38:00 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:38:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:38:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:38:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:38:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:38:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:38:01 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:38:01 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:38:01 --> Final output sent to browser
DEBUG - 2013-08-17 04:38:01 --> Total execution time: 0.5670
DEBUG - 2013-08-17 04:38:01 --> Config Class Initialized
DEBUG - 2013-08-17 04:38:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:38:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:38:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:38:01 --> URI Class Initialized
DEBUG - 2013-08-17 04:38:01 --> Router Class Initialized
ERROR - 2013-08-17 04:38:01 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:39:57 --> Config Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:39:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:39:57 --> URI Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Router Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Output Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Security Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Input Class Initialized
DEBUG - 2013-08-17 04:39:57 --> XSS Filtering completed
DEBUG - 2013-08-17 04:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:39:57 --> Language Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Loader Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:39:57 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:39:57 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:39:57 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Session Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:39:57 --> Session routines successfully run
DEBUG - 2013-08-17 04:39:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Controller Class Initialized
ERROR - 2013-08-17 04:39:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:39:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:39:57 --> Model Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:39:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:39:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:39:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:39:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:39:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:39:57 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:39:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:39:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:39:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:39:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:39:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:39:57 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:39:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:39:57 --> Final output sent to browser
DEBUG - 2013-08-17 04:39:57 --> Total execution time: 0.5960
DEBUG - 2013-08-17 04:39:57 --> Config Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:39:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:39:57 --> URI Class Initialized
DEBUG - 2013-08-17 04:39:57 --> Router Class Initialized
ERROR - 2013-08-17 04:39:57 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 04:41:37 --> Config Class Initialized
DEBUG - 2013-08-17 04:41:37 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:41:37 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:41:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:41:37 --> URI Class Initialized
DEBUG - 2013-08-17 04:41:37 --> Router Class Initialized
DEBUG - 2013-08-17 04:41:37 --> Output Class Initialized
DEBUG - 2013-08-17 04:41:37 --> Security Class Initialized
DEBUG - 2013-08-17 04:41:37 --> Input Class Initialized
DEBUG - 2013-08-17 04:41:37 --> XSS Filtering completed
DEBUG - 2013-08-17 04:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 04:41:37 --> Language Class Initialized
DEBUG - 2013-08-17 04:41:37 --> Loader Class Initialized
DEBUG - 2013-08-17 04:41:37 --> Helper loaded: url_helper
DEBUG - 2013-08-17 04:41:37 --> Helper loaded: file_helper
DEBUG - 2013-08-17 04:41:38 --> Helper loaded: form_helper
DEBUG - 2013-08-17 04:41:38 --> Database Driver Class Initialized
DEBUG - 2013-08-17 04:41:38 --> Session Class Initialized
DEBUG - 2013-08-17 04:41:38 --> Helper loaded: string_helper
DEBUG - 2013-08-17 04:41:38 --> Session routines successfully run
DEBUG - 2013-08-17 04:41:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 04:41:38 --> Controller Class Initialized
ERROR - 2013-08-17 04:41:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:41:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:41:38 --> Model Class Initialized
DEBUG - 2013-08-17 04:41:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 04:41:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 04:41:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 04:41:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 04:41:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 04:41:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 04:41:38 --> Pagination Class Initialized
DEBUG - 2013-08-17 04:41:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 04:41:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 04:41:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 04:41:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 04:41:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 04:41:38 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 04:41:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 04:41:38 --> Final output sent to browser
DEBUG - 2013-08-17 04:41:38 --> Total execution time: 0.5890
DEBUG - 2013-08-17 04:41:38 --> Config Class Initialized
DEBUG - 2013-08-17 04:41:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 04:41:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 04:41:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 04:41:38 --> URI Class Initialized
DEBUG - 2013-08-17 04:41:38 --> Router Class Initialized
ERROR - 2013-08-17 04:41:38 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:05:39 --> Config Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:05:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:05:39 --> URI Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Router Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Output Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Security Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Input Class Initialized
DEBUG - 2013-08-17 05:05:39 --> XSS Filtering completed
DEBUG - 2013-08-17 05:05:39 --> XSS Filtering completed
DEBUG - 2013-08-17 05:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:05:39 --> Language Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Loader Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:05:39 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:05:39 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:05:39 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Session Class Initialized
DEBUG - 2013-08-17 05:05:39 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:05:40 --> Session routines successfully run
DEBUG - 2013-08-17 05:05:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:05:40 --> Controller Class Initialized
ERROR - 2013-08-17 05:05:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:05:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:05:40 --> Model Class Initialized
DEBUG - 2013-08-17 05:05:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:05:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:05:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:05:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:05:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:05:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:05:40 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:05:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:05:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:05:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:05:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:05:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:05:40 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:05:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:05:40 --> Final output sent to browser
DEBUG - 2013-08-17 05:05:40 --> Total execution time: 0.6440
DEBUG - 2013-08-17 05:05:40 --> Config Class Initialized
DEBUG - 2013-08-17 05:05:40 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:05:40 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:05:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:05:40 --> URI Class Initialized
DEBUG - 2013-08-17 05:05:40 --> Router Class Initialized
ERROR - 2013-08-17 05:05:40 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:22:38 --> Config Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:22:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:22:38 --> URI Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Router Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Output Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Security Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Input Class Initialized
DEBUG - 2013-08-17 05:22:38 --> XSS Filtering completed
DEBUG - 2013-08-17 05:22:38 --> XSS Filtering completed
DEBUG - 2013-08-17 05:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:22:38 --> Language Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Loader Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:22:38 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:22:38 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:22:38 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Session Class Initialized
DEBUG - 2013-08-17 05:22:38 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:22:39 --> Session routines successfully run
DEBUG - 2013-08-17 05:22:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:22:39 --> Controller Class Initialized
ERROR - 2013-08-17 05:22:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:22:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:22:39 --> Model Class Initialized
DEBUG - 2013-08-17 05:22:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:22:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:22:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:22:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:22:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:22:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:22:39 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:22:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:22:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:22:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:22:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:22:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:22:39 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:22:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:22:39 --> Final output sent to browser
DEBUG - 2013-08-17 05:22:39 --> Total execution time: 0.6460
DEBUG - 2013-08-17 05:22:39 --> Config Class Initialized
DEBUG - 2013-08-17 05:22:39 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:22:39 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:22:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:22:39 --> URI Class Initialized
DEBUG - 2013-08-17 05:22:39 --> Router Class Initialized
ERROR - 2013-08-17 05:22:39 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:22:41 --> Config Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:22:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:22:41 --> URI Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Router Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Output Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Security Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Input Class Initialized
DEBUG - 2013-08-17 05:22:41 --> XSS Filtering completed
DEBUG - 2013-08-17 05:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:22:41 --> Language Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Loader Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:22:41 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:22:41 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:22:41 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Session Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:22:41 --> Session routines successfully run
DEBUG - 2013-08-17 05:22:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Controller Class Initialized
ERROR - 2013-08-17 05:22:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:22:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:22:41 --> Model Class Initialized
DEBUG - 2013-08-17 05:22:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:22:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:22:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:22:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:22:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:22:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:22:41 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:22:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:22:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:22:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:22:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:22:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:22:41 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:22:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:22:42 --> Final output sent to browser
DEBUG - 2013-08-17 05:22:42 --> Total execution time: 0.6080
DEBUG - 2013-08-17 05:22:42 --> Config Class Initialized
DEBUG - 2013-08-17 05:22:42 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:22:42 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:22:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:22:42 --> URI Class Initialized
DEBUG - 2013-08-17 05:22:42 --> Router Class Initialized
ERROR - 2013-08-17 05:22:42 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:23:10 --> Config Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:23:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:23:10 --> URI Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Router Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Output Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Security Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Input Class Initialized
DEBUG - 2013-08-17 05:23:10 --> XSS Filtering completed
DEBUG - 2013-08-17 05:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:23:10 --> Language Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Loader Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:23:10 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:23:10 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:23:10 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Session Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:23:10 --> Session routines successfully run
DEBUG - 2013-08-17 05:23:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Controller Class Initialized
ERROR - 2013-08-17 05:23:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:23:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:23:10 --> Model Class Initialized
DEBUG - 2013-08-17 05:23:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:23:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:23:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:23:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:23:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:23:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:23:10 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:23:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:23:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:23:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:23:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:23:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:23:11 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:23:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:23:11 --> Final output sent to browser
DEBUG - 2013-08-17 05:23:11 --> Total execution time: 0.6160
DEBUG - 2013-08-17 05:23:11 --> Config Class Initialized
DEBUG - 2013-08-17 05:23:11 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:23:11 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:23:11 --> URI Class Initialized
DEBUG - 2013-08-17 05:23:11 --> Router Class Initialized
ERROR - 2013-08-17 05:23:11 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:23:13 --> Config Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:23:13 --> URI Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Router Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Output Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Security Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Input Class Initialized
DEBUG - 2013-08-17 05:23:13 --> XSS Filtering completed
DEBUG - 2013-08-17 05:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:23:13 --> Language Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Loader Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:23:13 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:23:13 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:23:13 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Session Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:23:13 --> Session routines successfully run
DEBUG - 2013-08-17 05:23:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Controller Class Initialized
ERROR - 2013-08-17 05:23:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:23:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:23:13 --> Model Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:23:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:23:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:23:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:23:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:23:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:23:13 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:23:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:23:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:23:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:23:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:23:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:23:13 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:23:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:23:13 --> Final output sent to browser
DEBUG - 2013-08-17 05:23:13 --> Total execution time: 0.6240
DEBUG - 2013-08-17 05:23:13 --> Config Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:23:13 --> URI Class Initialized
DEBUG - 2013-08-17 05:23:13 --> Router Class Initialized
ERROR - 2013-08-17 05:23:13 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:26:31 --> Config Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:26:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:26:31 --> URI Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Router Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Output Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Security Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Input Class Initialized
DEBUG - 2013-08-17 05:26:31 --> XSS Filtering completed
DEBUG - 2013-08-17 05:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:26:31 --> Language Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Loader Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:26:31 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:26:31 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:26:31 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Session Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:26:31 --> Session garbage collection performed.
DEBUG - 2013-08-17 05:26:31 --> Session routines successfully run
DEBUG - 2013-08-17 05:26:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Controller Class Initialized
ERROR - 2013-08-17 05:26:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:26:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:26:31 --> Model Class Initialized
DEBUG - 2013-08-17 05:26:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:26:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:26:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:26:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:26:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:26:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:26:31 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:26:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:26:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:26:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:26:31 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:26:31 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:26:31 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:26:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:26:31 --> Final output sent to browser
DEBUG - 2013-08-17 05:26:31 --> Total execution time: 0.6340
DEBUG - 2013-08-17 05:26:32 --> Config Class Initialized
DEBUG - 2013-08-17 05:26:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:26:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:26:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:26:32 --> URI Class Initialized
DEBUG - 2013-08-17 05:26:32 --> Router Class Initialized
ERROR - 2013-08-17 05:26:32 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:26:35 --> Config Class Initialized
DEBUG - 2013-08-17 05:26:35 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:26:35 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:26:35 --> URI Class Initialized
DEBUG - 2013-08-17 05:26:35 --> Router Class Initialized
DEBUG - 2013-08-17 05:26:35 --> Output Class Initialized
DEBUG - 2013-08-17 05:26:35 --> Security Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Input Class Initialized
DEBUG - 2013-08-17 05:26:36 --> XSS Filtering completed
DEBUG - 2013-08-17 05:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:26:36 --> Language Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Loader Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:26:36 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:26:36 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:26:36 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Session Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:26:36 --> Session routines successfully run
DEBUG - 2013-08-17 05:26:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Controller Class Initialized
ERROR - 2013-08-17 05:26:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:26:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:26:36 --> Model Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:26:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:26:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:26:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:26:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:26:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:26:36 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:26:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:26:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:26:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:26:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:26:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:26:36 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:26:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:26:36 --> Final output sent to browser
DEBUG - 2013-08-17 05:26:36 --> Total execution time: 0.7310
DEBUG - 2013-08-17 05:26:36 --> Config Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:26:36 --> URI Class Initialized
DEBUG - 2013-08-17 05:26:36 --> Router Class Initialized
ERROR - 2013-08-17 05:26:36 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:00 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:00 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:00 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:00 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:00 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:00 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:00 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:00 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:00 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:00 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:00 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:00 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:00 --> Total execution time: 0.7160
DEBUG - 2013-08-17 05:27:01 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:01 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:01 --> Router Class Initialized
ERROR - 2013-08-17 05:27:01 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:03 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:03 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:03 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:03 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:03 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:03 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:03 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:03 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:03 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:03 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:03 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:04 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:04 --> Total execution time: 0.6490
DEBUG - 2013-08-17 05:27:04 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:04 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:04 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:04 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:04 --> Router Class Initialized
ERROR - 2013-08-17 05:27:04 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:06 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:06 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:06 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:06 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:06 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:06 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:06 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:06 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:06 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:07 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:07 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:07 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:07 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:07 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:07 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:07 --> Total execution time: 0.6510
DEBUG - 2013-08-17 05:27:07 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:07 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:07 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:07 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:07 --> Router Class Initialized
ERROR - 2013-08-17 05:27:07 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:09 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:09 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:09 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:09 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:10 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:10 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:10 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:10 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:10 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:10 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:10 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:10 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:10 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:10 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:10 --> Total execution time: 0.6580
DEBUG - 2013-08-17 05:27:10 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:10 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:10 --> Router Class Initialized
ERROR - 2013-08-17 05:27:10 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:29 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:29 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:29 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:29 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:29 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:29 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:29 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:29 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:29 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:30 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:30 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:30 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:30 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:30 --> Total execution time: 0.7100
DEBUG - 2013-08-17 05:27:30 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:30 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:30 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:30 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:30 --> Router Class Initialized
ERROR - 2013-08-17 05:27:30 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:31 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:31 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:31 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:31 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:31 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:31 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:31 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:31 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:31 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:32 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:32 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:32 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:32 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:32 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:32 --> Total execution time: 0.6850
DEBUG - 2013-08-17 05:27:32 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:32 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:32 --> Router Class Initialized
ERROR - 2013-08-17 05:27:32 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:35 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:35 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:35 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:35 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:35 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:35 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:35 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:35 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:35 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:35 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:35 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:35 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:35 --> Total execution time: 0.6870
DEBUG - 2013-08-17 05:27:35 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:35 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:35 --> Router Class Initialized
ERROR - 2013-08-17 05:27:35 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:36 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:36 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:36 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:36 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:36 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:36 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:36 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:36 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:36 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:36 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:36 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:36 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:36 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:36 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:37 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:37 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:37 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:37 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:37 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:37 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:37 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:37 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:37 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:37 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:37 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:37 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:37 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:37 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:37 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:37 --> Total execution time: 0.7360
DEBUG - 2013-08-17 05:27:37 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:37 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:37 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:37 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:37 --> Router Class Initialized
ERROR - 2013-08-17 05:27:37 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:38 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:38 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:38 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:38 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:38 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:38 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:38 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:38 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:38 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:38 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:39 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:39 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:39 --> Total execution time: 0.7390
DEBUG - 2013-08-17 05:27:39 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:39 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:39 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:39 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:39 --> Router Class Initialized
ERROR - 2013-08-17 05:27:39 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:40 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:40 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:40 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:40 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:40 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:40 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:40 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:40 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:40 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:40 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:40 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:41 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:41 --> Total execution time: 0.7630
DEBUG - 2013-08-17 05:27:41 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:41 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:41 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:41 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:41 --> Router Class Initialized
ERROR - 2013-08-17 05:27:41 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:53 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:53 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:53 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:53 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:53 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:53 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:53 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:53 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:53 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:53 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:53 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:54 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:54 --> Total execution time: 0.7230
DEBUG - 2013-08-17 05:27:54 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:54 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:54 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:54 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:54 --> Router Class Initialized
ERROR - 2013-08-17 05:27:54 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:27:55 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:55 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Router Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Output Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Security Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Input Class Initialized
DEBUG - 2013-08-17 05:27:55 --> XSS Filtering completed
DEBUG - 2013-08-17 05:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:27:55 --> Language Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Loader Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:27:55 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:27:55 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:27:55 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Session Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:27:55 --> Session garbage collection performed.
DEBUG - 2013-08-17 05:27:55 --> Session routines successfully run
DEBUG - 2013-08-17 05:27:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Controller Class Initialized
ERROR - 2013-08-17 05:27:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:55 --> Model Class Initialized
DEBUG - 2013-08-17 05:27:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:27:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:27:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:27:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:27:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:27:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:27:56 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:27:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:27:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:27:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:27:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:27:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:27:56 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:27:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:27:56 --> Final output sent to browser
DEBUG - 2013-08-17 05:27:56 --> Total execution time: 0.7380
DEBUG - 2013-08-17 05:27:56 --> Config Class Initialized
DEBUG - 2013-08-17 05:27:56 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:27:56 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:27:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:27:56 --> URI Class Initialized
DEBUG - 2013-08-17 05:27:56 --> Router Class Initialized
ERROR - 2013-08-17 05:27:56 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:28:04 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:04 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:04 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:04 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:04 --> Router Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Output Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Security Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Input Class Initialized
DEBUG - 2013-08-17 05:28:05 --> XSS Filtering completed
DEBUG - 2013-08-17 05:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:28:05 --> Language Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Loader Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:28:05 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:28:05 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:28:05 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Session Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:28:05 --> Session routines successfully run
DEBUG - 2013-08-17 05:28:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Controller Class Initialized
ERROR - 2013-08-17 05:28:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:05 --> Model Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:28:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:28:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:28:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:28:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:05 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:28:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:28:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:28:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:28:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:28:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:28:05 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:28:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:28:05 --> Final output sent to browser
DEBUG - 2013-08-17 05:28:05 --> Total execution time: 0.8190
DEBUG - 2013-08-17 05:28:05 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:05 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:05 --> Router Class Initialized
ERROR - 2013-08-17 05:28:05 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:28:07 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:07 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Router Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Output Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Security Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Input Class Initialized
DEBUG - 2013-08-17 05:28:07 --> XSS Filtering completed
DEBUG - 2013-08-17 05:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:28:07 --> Language Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Loader Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:28:07 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:28:07 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:28:07 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Session Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:28:07 --> Session routines successfully run
DEBUG - 2013-08-17 05:28:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Controller Class Initialized
ERROR - 2013-08-17 05:28:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:07 --> Model Class Initialized
DEBUG - 2013-08-17 05:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:28:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:28:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:28:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:28:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:08 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:28:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:28:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:28:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:28:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:28:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:28:08 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:28:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:28:08 --> Final output sent to browser
DEBUG - 2013-08-17 05:28:08 --> Total execution time: 0.7470
DEBUG - 2013-08-17 05:28:08 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:08 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:08 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:08 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:08 --> Router Class Initialized
ERROR - 2013-08-17 05:28:08 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:28:09 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:09 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:09 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:09 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:09 --> Router Class Initialized
DEBUG - 2013-08-17 05:28:09 --> Output Class Initialized
DEBUG - 2013-08-17 05:28:09 --> Security Class Initialized
DEBUG - 2013-08-17 05:28:09 --> Input Class Initialized
DEBUG - 2013-08-17 05:28:09 --> XSS Filtering completed
DEBUG - 2013-08-17 05:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:28:09 --> Language Class Initialized
DEBUG - 2013-08-17 05:28:09 --> Loader Class Initialized
DEBUG - 2013-08-17 05:28:09 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:28:09 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:28:09 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:28:09 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:28:10 --> Session Class Initialized
DEBUG - 2013-08-17 05:28:10 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:28:10 --> Session routines successfully run
DEBUG - 2013-08-17 05:28:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:28:10 --> Controller Class Initialized
ERROR - 2013-08-17 05:28:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:10 --> Model Class Initialized
DEBUG - 2013-08-17 05:28:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:28:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:28:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:28:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:28:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:10 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:28:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:28:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:28:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:28:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:28:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:28:10 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:28:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:28:10 --> Final output sent to browser
DEBUG - 2013-08-17 05:28:10 --> Total execution time: 0.8000
DEBUG - 2013-08-17 05:28:10 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:10 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:10 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:10 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:10 --> Router Class Initialized
ERROR - 2013-08-17 05:28:10 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:28:11 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:11 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:11 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:11 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:11 --> Router Class Initialized
DEBUG - 2013-08-17 05:28:11 --> Output Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Security Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Input Class Initialized
DEBUG - 2013-08-17 05:28:12 --> XSS Filtering completed
DEBUG - 2013-08-17 05:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:28:12 --> Language Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Loader Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:28:12 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:28:12 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:28:12 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Session Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:28:12 --> Session routines successfully run
DEBUG - 2013-08-17 05:28:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Controller Class Initialized
ERROR - 2013-08-17 05:28:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:12 --> Model Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:28:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:28:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:28:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:28:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:12 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:28:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:28:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:28:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:28:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:28:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:28:12 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:28:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:28:12 --> Final output sent to browser
DEBUG - 2013-08-17 05:28:12 --> Total execution time: 0.7640
DEBUG - 2013-08-17 05:28:12 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:12 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:12 --> Router Class Initialized
ERROR - 2013-08-17 05:28:12 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:28:14 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:14 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Router Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Output Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Security Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Input Class Initialized
DEBUG - 2013-08-17 05:28:14 --> XSS Filtering completed
DEBUG - 2013-08-17 05:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:28:14 --> Language Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Loader Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:28:14 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:28:14 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:28:14 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Session Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:28:14 --> Session routines successfully run
DEBUG - 2013-08-17 05:28:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:28:14 --> Controller Class Initialized
ERROR - 2013-08-17 05:28:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:15 --> Model Class Initialized
DEBUG - 2013-08-17 05:28:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:28:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:28:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:28:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:28:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:15 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:28:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:28:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:28:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:28:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:28:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:28:15 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:28:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:28:15 --> Final output sent to browser
DEBUG - 2013-08-17 05:28:15 --> Total execution time: 0.7740
DEBUG - 2013-08-17 05:28:15 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:15 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:15 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:15 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:15 --> Router Class Initialized
ERROR - 2013-08-17 05:28:15 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:28:22 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:22 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:22 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:22 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:22 --> Router Class Initialized
DEBUG - 2013-08-17 05:28:22 --> Output Class Initialized
DEBUG - 2013-08-17 05:28:22 --> Security Class Initialized
DEBUG - 2013-08-17 05:28:22 --> Input Class Initialized
DEBUG - 2013-08-17 05:28:23 --> XSS Filtering completed
DEBUG - 2013-08-17 05:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:28:23 --> Language Class Initialized
DEBUG - 2013-08-17 05:28:23 --> Loader Class Initialized
DEBUG - 2013-08-17 05:28:23 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:28:23 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:28:23 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:28:23 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:28:23 --> Session Class Initialized
DEBUG - 2013-08-17 05:28:23 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:28:23 --> Session garbage collection performed.
DEBUG - 2013-08-17 05:28:23 --> Session routines successfully run
DEBUG - 2013-08-17 05:28:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:28:23 --> Controller Class Initialized
ERROR - 2013-08-17 05:28:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:23 --> Model Class Initialized
DEBUG - 2013-08-17 05:28:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:28:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:28:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:28:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:28:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:23 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:28:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:28:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:28:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:28:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:28:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:28:23 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:28:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:28:23 --> Final output sent to browser
DEBUG - 2013-08-17 05:28:23 --> Total execution time: 0.7980
DEBUG - 2013-08-17 05:28:23 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:23 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:23 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:23 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:23 --> Router Class Initialized
ERROR - 2013-08-17 05:28:23 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:28:26 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:26 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Router Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Output Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Security Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Input Class Initialized
DEBUG - 2013-08-17 05:28:26 --> XSS Filtering completed
DEBUG - 2013-08-17 05:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:28:26 --> Language Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Loader Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:28:26 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:28:26 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:28:26 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Session Class Initialized
DEBUG - 2013-08-17 05:28:26 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:28:26 --> Session routines successfully run
DEBUG - 2013-08-17 05:28:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:28:27 --> Controller Class Initialized
ERROR - 2013-08-17 05:28:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:27 --> Model Class Initialized
DEBUG - 2013-08-17 05:28:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:28:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:28:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:28:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:28:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:27 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:28:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:28:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:28:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:28:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:28:27 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:28:27 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:28:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:28:27 --> Final output sent to browser
DEBUG - 2013-08-17 05:28:27 --> Total execution time: 0.7940
DEBUG - 2013-08-17 05:28:27 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:27 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:27 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:27 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:27 --> Router Class Initialized
ERROR - 2013-08-17 05:28:27 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:28:34 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:34 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:34 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:34 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:34 --> Router Class Initialized
DEBUG - 2013-08-17 05:28:34 --> Output Class Initialized
DEBUG - 2013-08-17 05:28:34 --> Security Class Initialized
DEBUG - 2013-08-17 05:28:34 --> Input Class Initialized
DEBUG - 2013-08-17 05:28:34 --> XSS Filtering completed
DEBUG - 2013-08-17 05:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:28:34 --> Language Class Initialized
DEBUG - 2013-08-17 05:28:34 --> Loader Class Initialized
DEBUG - 2013-08-17 05:28:34 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:28:35 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:28:35 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:28:35 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:28:35 --> Session Class Initialized
DEBUG - 2013-08-17 05:28:35 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:28:35 --> Session routines successfully run
DEBUG - 2013-08-17 05:28:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:28:35 --> Controller Class Initialized
ERROR - 2013-08-17 05:28:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:35 --> Model Class Initialized
DEBUG - 2013-08-17 05:28:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:28:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:28:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:28:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:28:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:35 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:28:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:28:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:28:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:28:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:28:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:28:35 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:28:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:28:35 --> Final output sent to browser
DEBUG - 2013-08-17 05:28:35 --> Total execution time: 0.7960
DEBUG - 2013-08-17 05:28:35 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:35 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:35 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:35 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:35 --> Router Class Initialized
ERROR - 2013-08-17 05:28:35 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:28:37 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:37 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Router Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Output Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Security Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Input Class Initialized
DEBUG - 2013-08-17 05:28:37 --> XSS Filtering completed
DEBUG - 2013-08-17 05:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:28:37 --> Language Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Loader Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:28:37 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:28:37 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:28:37 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Session Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:28:37 --> Session routines successfully run
DEBUG - 2013-08-17 05:28:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:28:37 --> Controller Class Initialized
ERROR - 2013-08-17 05:28:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:37 --> Model Class Initialized
DEBUG - 2013-08-17 05:28:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:28:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:28:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:28:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:28:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:28:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:28:38 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:28:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:28:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:28:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:28:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:28:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:28:38 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:28:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:28:38 --> Final output sent to browser
DEBUG - 2013-08-17 05:28:38 --> Total execution time: 0.7880
DEBUG - 2013-08-17 05:28:38 --> Config Class Initialized
DEBUG - 2013-08-17 05:28:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:28:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:28:38 --> URI Class Initialized
DEBUG - 2013-08-17 05:28:38 --> Router Class Initialized
ERROR - 2013-08-17 05:28:38 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:35:58 --> Config Class Initialized
DEBUG - 2013-08-17 05:35:58 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:35:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:35:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:35:58 --> URI Class Initialized
DEBUG - 2013-08-17 05:35:58 --> Router Class Initialized
DEBUG - 2013-08-17 05:35:58 --> Output Class Initialized
DEBUG - 2013-08-17 05:35:58 --> Security Class Initialized
DEBUG - 2013-08-17 05:35:58 --> Input Class Initialized
DEBUG - 2013-08-17 05:35:58 --> XSS Filtering completed
DEBUG - 2013-08-17 05:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:35:59 --> Language Class Initialized
DEBUG - 2013-08-17 05:35:59 --> Loader Class Initialized
DEBUG - 2013-08-17 05:35:59 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:35:59 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:35:59 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:35:59 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:35:59 --> Session Class Initialized
DEBUG - 2013-08-17 05:35:59 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:35:59 --> Session routines successfully run
DEBUG - 2013-08-17 05:35:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:35:59 --> Controller Class Initialized
ERROR - 2013-08-17 05:35:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:35:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:35:59 --> Model Class Initialized
DEBUG - 2013-08-17 05:35:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:35:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:35:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:35:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:35:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:35:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:35:59 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:35:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:35:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:35:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:35:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:35:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:35:59 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:35:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:35:59 --> Final output sent to browser
DEBUG - 2013-08-17 05:35:59 --> Total execution time: 2.2961
DEBUG - 2013-08-17 05:35:59 --> Config Class Initialized
DEBUG - 2013-08-17 05:35:59 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:35:59 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:35:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:35:59 --> URI Class Initialized
DEBUG - 2013-08-17 05:35:59 --> Router Class Initialized
ERROR - 2013-08-17 05:35:59 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:36:01 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:01 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:01 --> Router Class Initialized
DEBUG - 2013-08-17 05:36:01 --> Output Class Initialized
DEBUG - 2013-08-17 05:36:01 --> Security Class Initialized
DEBUG - 2013-08-17 05:36:01 --> Input Class Initialized
DEBUG - 2013-08-17 05:36:01 --> XSS Filtering completed
DEBUG - 2013-08-17 05:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:36:01 --> Language Class Initialized
DEBUG - 2013-08-17 05:36:01 --> Loader Class Initialized
DEBUG - 2013-08-17 05:36:01 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:36:01 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:36:01 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:36:02 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:36:02 --> Session Class Initialized
DEBUG - 2013-08-17 05:36:02 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:36:02 --> Session routines successfully run
DEBUG - 2013-08-17 05:36:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:36:02 --> Controller Class Initialized
ERROR - 2013-08-17 05:36:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:02 --> Model Class Initialized
DEBUG - 2013-08-17 05:36:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:36:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:36:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:36:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:36:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:02 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:36:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:36:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:36:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:36:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:36:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:36:02 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:36:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:36:02 --> Final output sent to browser
DEBUG - 2013-08-17 05:36:02 --> Total execution time: 0.8380
DEBUG - 2013-08-17 05:36:02 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:02 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:02 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:02 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:02 --> Router Class Initialized
ERROR - 2013-08-17 05:36:02 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:36:12 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:12 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Router Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Output Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Security Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Input Class Initialized
DEBUG - 2013-08-17 05:36:12 --> XSS Filtering completed
DEBUG - 2013-08-17 05:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:36:12 --> Language Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Loader Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:36:12 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:36:12 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:36:12 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Session Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:36:12 --> Session routines successfully run
DEBUG - 2013-08-17 05:36:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Controller Class Initialized
ERROR - 2013-08-17 05:36:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:12 --> Model Class Initialized
DEBUG - 2013-08-17 05:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:36:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:36:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:36:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:36:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:13 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:36:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:36:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:36:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:36:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:36:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:36:13 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:36:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:36:13 --> Final output sent to browser
DEBUG - 2013-08-17 05:36:13 --> Total execution time: 0.8220
DEBUG - 2013-08-17 05:36:13 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:13 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:13 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:13 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:13 --> Router Class Initialized
ERROR - 2013-08-17 05:36:13 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:36:15 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:15 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Router Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Output Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Security Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Input Class Initialized
DEBUG - 2013-08-17 05:36:15 --> XSS Filtering completed
DEBUG - 2013-08-17 05:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:36:15 --> Language Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Loader Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:36:15 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:36:15 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:36:15 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Session Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:36:15 --> Session routines successfully run
DEBUG - 2013-08-17 05:36:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Controller Class Initialized
ERROR - 2013-08-17 05:36:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:15 --> Model Class Initialized
DEBUG - 2013-08-17 05:36:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:36:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:36:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:36:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:36:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:15 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:36:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:36:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:36:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:36:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:36:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:36:15 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:36:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:36:15 --> Final output sent to browser
DEBUG - 2013-08-17 05:36:15 --> Total execution time: 0.8290
DEBUG - 2013-08-17 05:36:16 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:16 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:16 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:16 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:16 --> Router Class Initialized
ERROR - 2013-08-17 05:36:16 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:36:17 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:17 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:17 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:18 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Router Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Output Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Security Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Input Class Initialized
DEBUG - 2013-08-17 05:36:18 --> XSS Filtering completed
DEBUG - 2013-08-17 05:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:36:18 --> Language Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Loader Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:36:18 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:36:18 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:36:18 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Session Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:36:18 --> Session routines successfully run
DEBUG - 2013-08-17 05:36:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Controller Class Initialized
ERROR - 2013-08-17 05:36:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:18 --> Model Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:36:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:36:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:36:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:36:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:18 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:36:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:36:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:36:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:36:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:36:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:36:18 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:36:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:36:18 --> Final output sent to browser
DEBUG - 2013-08-17 05:36:18 --> Total execution time: 0.8360
DEBUG - 2013-08-17 05:36:18 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:18 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:18 --> Router Class Initialized
ERROR - 2013-08-17 05:36:19 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:36:20 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:20 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Router Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Output Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Security Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Input Class Initialized
DEBUG - 2013-08-17 05:36:20 --> XSS Filtering completed
DEBUG - 2013-08-17 05:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:36:20 --> Language Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Loader Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:36:20 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:36:20 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:36:20 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Session Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:36:20 --> Session routines successfully run
DEBUG - 2013-08-17 05:36:20 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Controller Class Initialized
ERROR - 2013-08-17 05:36:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:20 --> Model Class Initialized
DEBUG - 2013-08-17 05:36:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:36:20 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:36:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:36:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:36:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:21 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:36:21 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:36:21 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:36:21 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:36:21 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:36:21 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:36:21 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:36:21 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:36:21 --> Final output sent to browser
DEBUG - 2013-08-17 05:36:21 --> Total execution time: 0.8390
DEBUG - 2013-08-17 05:36:21 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:21 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:21 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:21 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:21 --> Router Class Initialized
ERROR - 2013-08-17 05:36:21 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:36:22 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:22 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Router Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Output Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Security Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Input Class Initialized
DEBUG - 2013-08-17 05:36:22 --> XSS Filtering completed
DEBUG - 2013-08-17 05:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:36:22 --> Language Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Loader Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:36:22 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:36:22 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:36:22 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Session Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:36:22 --> Session routines successfully run
DEBUG - 2013-08-17 05:36:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:36:22 --> Controller Class Initialized
ERROR - 2013-08-17 05:36:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:23 --> Model Class Initialized
DEBUG - 2013-08-17 05:36:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:36:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:36:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:36:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:36:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:23 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:36:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:36:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:36:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:36:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:36:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:36:23 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:36:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:36:23 --> Final output sent to browser
DEBUG - 2013-08-17 05:36:23 --> Total execution time: 0.8691
DEBUG - 2013-08-17 05:36:23 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:23 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:23 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:23 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:23 --> Router Class Initialized
ERROR - 2013-08-17 05:36:23 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:36:38 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:38 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Router Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Output Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Security Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Input Class Initialized
DEBUG - 2013-08-17 05:36:38 --> XSS Filtering completed
DEBUG - 2013-08-17 05:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:36:38 --> Language Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Loader Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:36:38 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:36:38 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:36:38 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Session Class Initialized
DEBUG - 2013-08-17 05:36:38 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:36:38 --> Session routines successfully run
DEBUG - 2013-08-17 05:36:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:36:39 --> Controller Class Initialized
ERROR - 2013-08-17 05:36:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:39 --> Model Class Initialized
DEBUG - 2013-08-17 05:36:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:36:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:36:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:36:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:36:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:39 --> Final output sent to browser
DEBUG - 2013-08-17 05:36:39 --> Total execution time: 0.7030
DEBUG - 2013-08-17 05:36:42 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:42 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Router Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Output Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Security Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Input Class Initialized
DEBUG - 2013-08-17 05:36:42 --> XSS Filtering completed
DEBUG - 2013-08-17 05:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:36:42 --> Language Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Loader Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:36:42 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:36:42 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:36:42 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Session Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:36:42 --> Session routines successfully run
DEBUG - 2013-08-17 05:36:42 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:36:42 --> Controller Class Initialized
ERROR - 2013-08-17 05:36:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:43 --> Model Class Initialized
DEBUG - 2013-08-17 05:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:36:43 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:36:43 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:36:43 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:36:43 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:43 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:36:43 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:36:43 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:36:43 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:36:43 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:36:43 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:36:43 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:36:43 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:36:43 --> Final output sent to browser
DEBUG - 2013-08-17 05:36:43 --> Total execution time: 0.9611
DEBUG - 2013-08-17 05:36:43 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:43 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:43 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:43 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:43 --> Router Class Initialized
ERROR - 2013-08-17 05:36:43 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:36:58 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:58 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:58 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:58 --> Router Class Initialized
DEBUG - 2013-08-17 05:36:58 --> Output Class Initialized
DEBUG - 2013-08-17 05:36:58 --> Security Class Initialized
DEBUG - 2013-08-17 05:36:58 --> Input Class Initialized
DEBUG - 2013-08-17 05:36:58 --> XSS Filtering completed
DEBUG - 2013-08-17 05:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:36:58 --> Language Class Initialized
DEBUG - 2013-08-17 05:36:58 --> Loader Class Initialized
DEBUG - 2013-08-17 05:36:58 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:36:59 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:36:59 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:36:59 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:36:59 --> Session Class Initialized
DEBUG - 2013-08-17 05:36:59 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:36:59 --> Session routines successfully run
DEBUG - 2013-08-17 05:36:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:36:59 --> Controller Class Initialized
ERROR - 2013-08-17 05:36:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:59 --> Model Class Initialized
DEBUG - 2013-08-17 05:36:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:36:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:36:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:36:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:36:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:36:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:36:59 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:36:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:36:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:36:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:36:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:36:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:36:59 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:36:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:36:59 --> Final output sent to browser
DEBUG - 2013-08-17 05:36:59 --> Total execution time: 0.9611
DEBUG - 2013-08-17 05:36:59 --> Config Class Initialized
DEBUG - 2013-08-17 05:36:59 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:36:59 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:36:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:36:59 --> URI Class Initialized
DEBUG - 2013-08-17 05:36:59 --> Router Class Initialized
ERROR - 2013-08-17 05:36:59 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:37:01 --> Config Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:37:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:37:01 --> URI Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Router Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Output Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Security Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Input Class Initialized
DEBUG - 2013-08-17 05:37:01 --> XSS Filtering completed
DEBUG - 2013-08-17 05:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:37:01 --> Language Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Loader Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:37:01 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:37:01 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:37:01 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Session Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:37:01 --> Session routines successfully run
DEBUG - 2013-08-17 05:37:01 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Controller Class Initialized
ERROR - 2013-08-17 05:37:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:37:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:37:01 --> Model Class Initialized
DEBUG - 2013-08-17 05:37:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:37:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:37:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:37:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:37:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:37:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:37:01 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:37:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:37:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:37:01 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:37:01 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:37:01 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:37:02 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:37:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:37:02 --> Final output sent to browser
DEBUG - 2013-08-17 05:37:02 --> Total execution time: 0.8851
DEBUG - 2013-08-17 05:37:02 --> Config Class Initialized
DEBUG - 2013-08-17 05:37:02 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:37:02 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:37:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:37:02 --> URI Class Initialized
DEBUG - 2013-08-17 05:37:02 --> Router Class Initialized
ERROR - 2013-08-17 05:37:02 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:37:03 --> Config Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:37:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:37:03 --> URI Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Router Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Output Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Security Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Input Class Initialized
DEBUG - 2013-08-17 05:37:03 --> XSS Filtering completed
DEBUG - 2013-08-17 05:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:37:03 --> Language Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Loader Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:37:03 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:37:03 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:37:03 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Session Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:37:03 --> Session routines successfully run
DEBUG - 2013-08-17 05:37:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Controller Class Initialized
ERROR - 2013-08-17 05:37:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:37:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:37:03 --> Model Class Initialized
DEBUG - 2013-08-17 05:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:37:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:37:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:37:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:37:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:37:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:37:03 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:37:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:37:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:37:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:37:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:37:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:37:03 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:37:04 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:37:04 --> Final output sent to browser
DEBUG - 2013-08-17 05:37:04 --> Total execution time: 0.9121
DEBUG - 2013-08-17 05:39:31 --> Config Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:39:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:39:31 --> URI Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Router Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Output Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Security Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Input Class Initialized
DEBUG - 2013-08-17 05:39:31 --> XSS Filtering completed
DEBUG - 2013-08-17 05:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:39:31 --> Language Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Loader Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:39:31 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:39:31 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:39:31 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Session Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:39:31 --> Session routines successfully run
DEBUG - 2013-08-17 05:39:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Controller Class Initialized
ERROR - 2013-08-17 05:39:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:39:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:39:31 --> Model Class Initialized
DEBUG - 2013-08-17 05:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:39:31 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:39:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:39:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:39:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:39:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:39:32 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:39:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:39:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:39:32 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:39:32 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:39:32 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:39:32 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:39:32 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:39:32 --> Final output sent to browser
DEBUG - 2013-08-17 05:39:32 --> Total execution time: 0.9891
DEBUG - 2013-08-17 05:39:32 --> Config Class Initialized
DEBUG - 2013-08-17 05:39:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:39:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:39:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:39:32 --> URI Class Initialized
DEBUG - 2013-08-17 05:39:32 --> Router Class Initialized
ERROR - 2013-08-17 05:39:32 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:39:33 --> Config Class Initialized
DEBUG - 2013-08-17 05:39:33 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:39:33 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:39:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:39:33 --> URI Class Initialized
DEBUG - 2013-08-17 05:39:33 --> Router Class Initialized
DEBUG - 2013-08-17 05:39:33 --> Output Class Initialized
DEBUG - 2013-08-17 05:39:33 --> Security Class Initialized
DEBUG - 2013-08-17 05:39:33 --> Input Class Initialized
DEBUG - 2013-08-17 05:39:34 --> XSS Filtering completed
DEBUG - 2013-08-17 05:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:39:34 --> Language Class Initialized
DEBUG - 2013-08-17 05:39:34 --> Loader Class Initialized
DEBUG - 2013-08-17 05:39:34 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:39:34 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:39:34 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:39:34 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:39:34 --> Session Class Initialized
DEBUG - 2013-08-17 05:39:34 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:39:34 --> Session routines successfully run
DEBUG - 2013-08-17 05:39:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:39:34 --> Controller Class Initialized
ERROR - 2013-08-17 05:39:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:39:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:39:34 --> Model Class Initialized
DEBUG - 2013-08-17 05:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:39:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:39:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:39:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:39:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:39:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:39:34 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:39:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:39:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:39:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:39:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:39:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:39:34 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:39:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:39:34 --> Final output sent to browser
DEBUG - 2013-08-17 05:39:34 --> Total execution time: 0.9201
DEBUG - 2013-08-17 05:39:34 --> Config Class Initialized
DEBUG - 2013-08-17 05:39:34 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:39:34 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:39:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:39:34 --> URI Class Initialized
DEBUG - 2013-08-17 05:39:34 --> Router Class Initialized
ERROR - 2013-08-17 05:39:35 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:39:37 --> Config Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:39:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:39:37 --> URI Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Router Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Output Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Security Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Input Class Initialized
DEBUG - 2013-08-17 05:39:37 --> XSS Filtering completed
DEBUG - 2013-08-17 05:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:39:37 --> Language Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Loader Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:39:37 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:39:37 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:39:37 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Session Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:39:37 --> Session routines successfully run
DEBUG - 2013-08-17 05:39:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Controller Class Initialized
ERROR - 2013-08-17 05:39:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:39:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:39:37 --> Model Class Initialized
DEBUG - 2013-08-17 05:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:39:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:39:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:39:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:39:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:39:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:39:38 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:39:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:39:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:39:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:39:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:39:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:39:38 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:39:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:39:38 --> Final output sent to browser
DEBUG - 2013-08-17 05:39:38 --> Total execution time: 0.9241
DEBUG - 2013-08-17 05:39:38 --> Config Class Initialized
DEBUG - 2013-08-17 05:39:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:39:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:39:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:39:38 --> URI Class Initialized
DEBUG - 2013-08-17 05:39:38 --> Router Class Initialized
ERROR - 2013-08-17 05:39:38 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:56:59 --> Config Class Initialized
DEBUG - 2013-08-17 05:56:59 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:56:59 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:56:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:56:59 --> URI Class Initialized
DEBUG - 2013-08-17 05:56:59 --> Router Class Initialized
DEBUG - 2013-08-17 05:56:59 --> Output Class Initialized
DEBUG - 2013-08-17 05:56:59 --> Security Class Initialized
DEBUG - 2013-08-17 05:56:59 --> Input Class Initialized
DEBUG - 2013-08-17 05:56:59 --> XSS Filtering completed
DEBUG - 2013-08-17 05:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:56:59 --> Language Class Initialized
DEBUG - 2013-08-17 05:56:59 --> Loader Class Initialized
DEBUG - 2013-08-17 05:56:59 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:56:59 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:56:59 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:56:59 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:57:00 --> Session Class Initialized
DEBUG - 2013-08-17 05:57:00 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:57:00 --> Session routines successfully run
DEBUG - 2013-08-17 05:57:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:57:00 --> Controller Class Initialized
ERROR - 2013-08-17 05:57:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:57:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:57:00 --> Model Class Initialized
DEBUG - 2013-08-17 05:57:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:57:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:57:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:57:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:57:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:57:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:57:00 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:57:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:57:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:57:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:57:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:57:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:57:00 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:57:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:57:00 --> Final output sent to browser
DEBUG - 2013-08-17 05:57:00 --> Total execution time: 1.0201
DEBUG - 2013-08-17 05:57:00 --> Config Class Initialized
DEBUG - 2013-08-17 05:57:00 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:57:00 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:57:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:57:00 --> URI Class Initialized
DEBUG - 2013-08-17 05:57:00 --> Router Class Initialized
ERROR - 2013-08-17 05:57:00 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:57:02 --> Config Class Initialized
DEBUG - 2013-08-17 05:57:02 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:57:02 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:57:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:57:02 --> URI Class Initialized
DEBUG - 2013-08-17 05:57:02 --> Router Class Initialized
DEBUG - 2013-08-17 05:57:02 --> Output Class Initialized
DEBUG - 2013-08-17 05:57:02 --> Security Class Initialized
DEBUG - 2013-08-17 05:57:03 --> Input Class Initialized
DEBUG - 2013-08-17 05:57:03 --> XSS Filtering completed
DEBUG - 2013-08-17 05:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:57:03 --> Language Class Initialized
DEBUG - 2013-08-17 05:57:03 --> Loader Class Initialized
DEBUG - 2013-08-17 05:57:03 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:57:03 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:57:03 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:57:03 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:57:03 --> Session Class Initialized
DEBUG - 2013-08-17 05:57:03 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:57:03 --> Session routines successfully run
DEBUG - 2013-08-17 05:57:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:57:03 --> Controller Class Initialized
ERROR - 2013-08-17 05:57:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:57:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:57:03 --> Model Class Initialized
DEBUG - 2013-08-17 05:57:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:57:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:57:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:57:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:57:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:57:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:57:03 --> Final output sent to browser
DEBUG - 2013-08-17 05:57:03 --> Total execution time: 0.8410
DEBUG - 2013-08-17 05:57:06 --> Config Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:57:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:57:06 --> URI Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Router Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Output Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Security Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Input Class Initialized
DEBUG - 2013-08-17 05:57:06 --> XSS Filtering completed
DEBUG - 2013-08-17 05:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:57:06 --> Language Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Loader Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:57:06 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:57:06 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:57:06 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Session Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:57:06 --> Session routines successfully run
DEBUG - 2013-08-17 05:57:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Controller Class Initialized
ERROR - 2013-08-17 05:57:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:57:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:57:06 --> Model Class Initialized
DEBUG - 2013-08-17 05:57:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:57:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:57:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:57:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:57:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:57:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:57:06 --> Final output sent to browser
DEBUG - 2013-08-17 05:57:06 --> Total execution time: 0.8130
DEBUG - 2013-08-17 05:57:08 --> Config Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:57:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:57:08 --> URI Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Router Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Output Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Security Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Input Class Initialized
DEBUG - 2013-08-17 05:57:08 --> XSS Filtering completed
DEBUG - 2013-08-17 05:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:57:08 --> Language Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Loader Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:57:08 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:57:08 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:57:08 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Session Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:57:08 --> Session routines successfully run
DEBUG - 2013-08-17 05:57:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:57:08 --> Controller Class Initialized
ERROR - 2013-08-17 05:57:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:57:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:57:09 --> Model Class Initialized
DEBUG - 2013-08-17 05:57:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:57:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:57:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:57:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:57:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:57:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:57:09 --> Final output sent to browser
DEBUG - 2013-08-17 05:57:09 --> Total execution time: 0.8861
DEBUG - 2013-08-17 05:58:33 --> Config Class Initialized
DEBUG - 2013-08-17 05:58:33 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:58:33 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:58:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:58:33 --> URI Class Initialized
DEBUG - 2013-08-17 05:58:33 --> Router Class Initialized
DEBUG - 2013-08-17 05:58:33 --> Output Class Initialized
DEBUG - 2013-08-17 05:58:33 --> Security Class Initialized
DEBUG - 2013-08-17 05:58:33 --> Input Class Initialized
DEBUG - 2013-08-17 05:58:33 --> XSS Filtering completed
DEBUG - 2013-08-17 05:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:58:33 --> Language Class Initialized
DEBUG - 2013-08-17 05:58:33 --> Loader Class Initialized
DEBUG - 2013-08-17 05:58:33 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:58:33 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:58:33 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:58:33 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:58:33 --> Session Class Initialized
DEBUG - 2013-08-17 05:58:34 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:58:34 --> Session routines successfully run
DEBUG - 2013-08-17 05:58:34 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:58:34 --> Controller Class Initialized
ERROR - 2013-08-17 05:58:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:58:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:58:34 --> Model Class Initialized
DEBUG - 2013-08-17 05:58:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:58:34 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:58:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:58:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:58:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:58:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:58:34 --> Pagination Class Initialized
DEBUG - 2013-08-17 05:58:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 05:58:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 05:58:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 05:58:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 05:58:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 05:58:34 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 05:58:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 05:58:34 --> Final output sent to browser
DEBUG - 2013-08-17 05:58:34 --> Total execution time: 1.0771
DEBUG - 2013-08-17 05:58:34 --> Config Class Initialized
DEBUG - 2013-08-17 05:58:34 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:58:34 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:58:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:58:34 --> URI Class Initialized
DEBUG - 2013-08-17 05:58:34 --> Router Class Initialized
ERROR - 2013-08-17 05:58:34 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 05:58:36 --> Config Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Hooks Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Utf8 Class Initialized
DEBUG - 2013-08-17 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 05:58:36 --> URI Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Router Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Output Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Security Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Input Class Initialized
DEBUG - 2013-08-17 05:58:36 --> XSS Filtering completed
DEBUG - 2013-08-17 05:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 05:58:36 --> Language Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Loader Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Helper loaded: url_helper
DEBUG - 2013-08-17 05:58:36 --> Helper loaded: file_helper
DEBUG - 2013-08-17 05:58:36 --> Helper loaded: form_helper
DEBUG - 2013-08-17 05:58:36 --> Database Driver Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Session Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Helper loaded: string_helper
DEBUG - 2013-08-17 05:58:36 --> Session routines successfully run
DEBUG - 2013-08-17 05:58:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Controller Class Initialized
ERROR - 2013-08-17 05:58:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:58:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:58:36 --> Model Class Initialized
DEBUG - 2013-08-17 05:58:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 05:58:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 05:58:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 05:58:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 05:58:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 05:58:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 05:58:36 --> Final output sent to browser
DEBUG - 2013-08-17 05:58:36 --> Total execution time: 0.8450
DEBUG - 2013-08-17 06:01:27 --> Config Class Initialized
DEBUG - 2013-08-17 06:01:27 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:01:27 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:01:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:01:27 --> URI Class Initialized
DEBUG - 2013-08-17 06:01:27 --> Router Class Initialized
DEBUG - 2013-08-17 06:01:27 --> Output Class Initialized
DEBUG - 2013-08-17 06:01:27 --> Security Class Initialized
DEBUG - 2013-08-17 06:01:28 --> Input Class Initialized
DEBUG - 2013-08-17 06:01:28 --> XSS Filtering completed
DEBUG - 2013-08-17 06:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 06:01:28 --> Language Class Initialized
DEBUG - 2013-08-17 06:01:28 --> Loader Class Initialized
DEBUG - 2013-08-17 06:01:28 --> Helper loaded: url_helper
DEBUG - 2013-08-17 06:01:28 --> Helper loaded: file_helper
DEBUG - 2013-08-17 06:01:28 --> Helper loaded: form_helper
DEBUG - 2013-08-17 06:01:28 --> Database Driver Class Initialized
DEBUG - 2013-08-17 06:01:28 --> Session Class Initialized
DEBUG - 2013-08-17 06:01:28 --> Helper loaded: string_helper
DEBUG - 2013-08-17 06:01:28 --> Session routines successfully run
DEBUG - 2013-08-17 06:01:28 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 06:01:28 --> Controller Class Initialized
ERROR - 2013-08-17 06:01:28 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:01:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:01:28 --> Model Class Initialized
DEBUG - 2013-08-17 06:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 06:01:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 06:01:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 06:01:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 06:01:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:01:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:01:28 --> Pagination Class Initialized
DEBUG - 2013-08-17 06:01:28 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 06:01:28 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 06:01:28 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 06:01:28 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 06:01:28 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 06:01:28 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 06:01:28 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 06:01:28 --> Final output sent to browser
DEBUG - 2013-08-17 06:01:28 --> Total execution time: 1.1461
DEBUG - 2013-08-17 06:01:29 --> Config Class Initialized
DEBUG - 2013-08-17 06:01:29 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:01:29 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:01:29 --> URI Class Initialized
DEBUG - 2013-08-17 06:01:29 --> Router Class Initialized
ERROR - 2013-08-17 06:01:29 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 06:01:32 --> Config Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:01:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:01:32 --> URI Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Router Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Output Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Security Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Input Class Initialized
DEBUG - 2013-08-17 06:01:32 --> XSS Filtering completed
DEBUG - 2013-08-17 06:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 06:01:32 --> Language Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Loader Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Helper loaded: url_helper
DEBUG - 2013-08-17 06:01:32 --> Helper loaded: file_helper
DEBUG - 2013-08-17 06:01:32 --> Helper loaded: form_helper
DEBUG - 2013-08-17 06:01:32 --> Database Driver Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Session Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Helper loaded: string_helper
DEBUG - 2013-08-17 06:01:32 --> Session routines successfully run
DEBUG - 2013-08-17 06:01:32 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Controller Class Initialized
ERROR - 2013-08-17 06:01:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:01:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:01:32 --> Model Class Initialized
DEBUG - 2013-08-17 06:01:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 06:01:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 06:01:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 06:01:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 06:01:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:01:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:01:32 --> Pagination Class Initialized
DEBUG - 2013-08-17 06:01:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 06:01:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 06:01:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 06:01:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 06:01:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 06:01:33 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 06:01:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 06:01:33 --> Final output sent to browser
DEBUG - 2013-08-17 06:01:33 --> Total execution time: 1.0531
DEBUG - 2013-08-17 06:14:04 --> Config Class Initialized
DEBUG - 2013-08-17 06:14:04 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:14:04 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:14:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:14:04 --> URI Class Initialized
DEBUG - 2013-08-17 06:14:04 --> Router Class Initialized
DEBUG - 2013-08-17 06:14:04 --> Output Class Initialized
DEBUG - 2013-08-17 06:14:04 --> Security Class Initialized
DEBUG - 2013-08-17 06:14:04 --> Input Class Initialized
DEBUG - 2013-08-17 06:14:04 --> XSS Filtering completed
DEBUG - 2013-08-17 06:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 06:14:04 --> Language Class Initialized
DEBUG - 2013-08-17 06:14:04 --> Loader Class Initialized
DEBUG - 2013-08-17 06:14:04 --> Helper loaded: url_helper
DEBUG - 2013-08-17 06:14:04 --> Helper loaded: file_helper
DEBUG - 2013-08-17 06:14:04 --> Helper loaded: form_helper
DEBUG - 2013-08-17 06:14:05 --> Database Driver Class Initialized
DEBUG - 2013-08-17 06:14:05 --> Session Class Initialized
DEBUG - 2013-08-17 06:14:05 --> Helper loaded: string_helper
DEBUG - 2013-08-17 06:14:05 --> Session routines successfully run
DEBUG - 2013-08-17 06:14:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 06:14:05 --> Controller Class Initialized
ERROR - 2013-08-17 06:14:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:14:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:14:05 --> Model Class Initialized
DEBUG - 2013-08-17 06:14:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 06:14:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 06:14:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 06:14:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 06:14:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:14:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:14:05 --> Pagination Class Initialized
DEBUG - 2013-08-17 06:14:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 06:14:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 06:14:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 06:14:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 06:14:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 06:14:05 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 06:14:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 06:14:05 --> Final output sent to browser
DEBUG - 2013-08-17 06:14:05 --> Total execution time: 1.1781
DEBUG - 2013-08-17 06:14:05 --> Config Class Initialized
DEBUG - 2013-08-17 06:14:05 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:14:05 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:14:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:14:05 --> URI Class Initialized
DEBUG - 2013-08-17 06:14:05 --> Router Class Initialized
ERROR - 2013-08-17 06:14:05 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 06:14:39 --> Config Class Initialized
DEBUG - 2013-08-17 06:14:39 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:14:39 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:14:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:14:39 --> URI Class Initialized
DEBUG - 2013-08-17 06:14:39 --> Router Class Initialized
DEBUG - 2013-08-17 06:14:39 --> Output Class Initialized
DEBUG - 2013-08-17 06:14:40 --> Security Class Initialized
DEBUG - 2013-08-17 06:14:40 --> Input Class Initialized
DEBUG - 2013-08-17 06:14:40 --> XSS Filtering completed
DEBUG - 2013-08-17 06:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 06:14:40 --> Language Class Initialized
DEBUG - 2013-08-17 06:14:40 --> Loader Class Initialized
DEBUG - 2013-08-17 06:14:40 --> Helper loaded: url_helper
DEBUG - 2013-08-17 06:14:40 --> Helper loaded: file_helper
DEBUG - 2013-08-17 06:14:40 --> Helper loaded: form_helper
DEBUG - 2013-08-17 06:14:40 --> Database Driver Class Initialized
DEBUG - 2013-08-17 06:14:40 --> Session Class Initialized
DEBUG - 2013-08-17 06:14:40 --> Helper loaded: string_helper
DEBUG - 2013-08-17 06:14:40 --> Session routines successfully run
DEBUG - 2013-08-17 06:14:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 06:14:40 --> Controller Class Initialized
ERROR - 2013-08-17 06:14:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:14:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:14:40 --> Model Class Initialized
DEBUG - 2013-08-17 06:14:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 06:14:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 06:14:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 06:14:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 06:14:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:14:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:14:40 --> Pagination Class Initialized
DEBUG - 2013-08-17 06:14:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 06:14:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 06:14:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 06:14:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 06:14:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 06:14:40 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 06:14:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 06:14:40 --> Final output sent to browser
DEBUG - 2013-08-17 06:14:40 --> Total execution time: 0.9831
DEBUG - 2013-08-17 06:14:40 --> Config Class Initialized
DEBUG - 2013-08-17 06:14:40 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:14:41 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:14:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:14:41 --> URI Class Initialized
DEBUG - 2013-08-17 06:14:41 --> Router Class Initialized
ERROR - 2013-08-17 06:14:41 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 06:14:56 --> Config Class Initialized
DEBUG - 2013-08-17 06:14:56 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:14:57 --> URI Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Router Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Output Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Security Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Input Class Initialized
DEBUG - 2013-08-17 06:14:57 --> XSS Filtering completed
DEBUG - 2013-08-17 06:14:57 --> XSS Filtering completed
DEBUG - 2013-08-17 06:14:57 --> XSS Filtering completed
DEBUG - 2013-08-17 06:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 06:14:57 --> Language Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Loader Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Helper loaded: url_helper
DEBUG - 2013-08-17 06:14:57 --> Helper loaded: file_helper
DEBUG - 2013-08-17 06:14:57 --> Helper loaded: form_helper
DEBUG - 2013-08-17 06:14:57 --> Database Driver Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Session Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Helper loaded: string_helper
DEBUG - 2013-08-17 06:14:57 --> Session routines successfully run
DEBUG - 2013-08-17 06:14:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Controller Class Initialized
ERROR - 2013-08-17 06:14:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:14:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:14:57 --> Model Class Initialized
DEBUG - 2013-08-17 06:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 06:14:57 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 06:14:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 06:14:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 06:14:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:14:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:14:57 --> Pagination Class Initialized
DEBUG - 2013-08-17 06:14:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 06:14:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 06:14:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 06:14:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 06:14:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 06:14:58 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 06:14:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 06:14:58 --> Final output sent to browser
DEBUG - 2013-08-17 06:14:58 --> Total execution time: 1.1361
DEBUG - 2013-08-17 06:14:58 --> Config Class Initialized
DEBUG - 2013-08-17 06:14:58 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:14:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:14:58 --> URI Class Initialized
DEBUG - 2013-08-17 06:14:58 --> Router Class Initialized
ERROR - 2013-08-17 06:14:58 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 06:33:51 --> Config Class Initialized
DEBUG - 2013-08-17 06:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:33:51 --> URI Class Initialized
DEBUG - 2013-08-17 06:33:51 --> Router Class Initialized
DEBUG - 2013-08-17 06:33:52 --> Output Class Initialized
DEBUG - 2013-08-17 06:33:52 --> Security Class Initialized
DEBUG - 2013-08-17 06:33:52 --> Input Class Initialized
DEBUG - 2013-08-17 06:33:52 --> XSS Filtering completed
DEBUG - 2013-08-17 06:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 06:33:52 --> Language Class Initialized
DEBUG - 2013-08-17 06:33:52 --> Loader Class Initialized
DEBUG - 2013-08-17 06:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-17 06:33:52 --> Helper loaded: file_helper
DEBUG - 2013-08-17 06:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-17 06:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-17 06:33:52 --> Session Class Initialized
DEBUG - 2013-08-17 06:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-17 06:33:52 --> Session routines successfully run
DEBUG - 2013-08-17 06:33:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 06:33:52 --> Controller Class Initialized
ERROR - 2013-08-17 06:33:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:33:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:33:53 --> Model Class Initialized
DEBUG - 2013-08-17 06:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 06:33:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 06:33:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 06:33:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 06:33:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:33:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:33:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 06:33:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 06:33:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 06:33:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 06:33:53 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 06:33:53 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 06:33:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 06:33:53 --> Final output sent to browser
DEBUG - 2013-08-17 06:33:53 --> Total execution time: 2.9572
DEBUG - 2013-08-17 06:33:53 --> Config Class Initialized
DEBUG - 2013-08-17 06:33:54 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:33:54 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:33:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:33:54 --> URI Class Initialized
DEBUG - 2013-08-17 06:33:54 --> Router Class Initialized
ERROR - 2013-08-17 06:33:54 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 06:33:57 --> Config Class Initialized
DEBUG - 2013-08-17 06:33:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:33:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:33:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:33:57 --> URI Class Initialized
DEBUG - 2013-08-17 06:33:57 --> Router Class Initialized
DEBUG - 2013-08-17 06:33:57 --> Output Class Initialized
DEBUG - 2013-08-17 06:33:57 --> Security Class Initialized
DEBUG - 2013-08-17 06:33:58 --> Input Class Initialized
DEBUG - 2013-08-17 06:33:58 --> XSS Filtering completed
DEBUG - 2013-08-17 06:33:58 --> XSS Filtering completed
DEBUG - 2013-08-17 06:33:58 --> XSS Filtering completed
DEBUG - 2013-08-17 06:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 06:33:58 --> Language Class Initialized
DEBUG - 2013-08-17 06:33:58 --> Loader Class Initialized
DEBUG - 2013-08-17 06:33:58 --> Helper loaded: url_helper
DEBUG - 2013-08-17 06:33:58 --> Helper loaded: file_helper
DEBUG - 2013-08-17 06:33:58 --> Helper loaded: form_helper
DEBUG - 2013-08-17 06:33:58 --> Database Driver Class Initialized
DEBUG - 2013-08-17 06:33:58 --> Session Class Initialized
DEBUG - 2013-08-17 06:33:58 --> Helper loaded: string_helper
DEBUG - 2013-08-17 06:33:58 --> Session routines successfully run
DEBUG - 2013-08-17 06:33:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 06:33:58 --> Controller Class Initialized
ERROR - 2013-08-17 06:33:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:33:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:33:58 --> Model Class Initialized
DEBUG - 2013-08-17 06:33:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 06:33:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 06:33:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 06:33:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 06:33:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:33:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:33:58 --> Form Validation Class Initialized
DEBUG - 2013-08-17 06:33:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 06:33:58 --> Config Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:33:59 --> URI Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Router Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Output Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Security Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Input Class Initialized
DEBUG - 2013-08-17 06:33:59 --> XSS Filtering completed
DEBUG - 2013-08-17 06:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 06:33:59 --> Language Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Loader Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Helper loaded: url_helper
DEBUG - 2013-08-17 06:33:59 --> Helper loaded: file_helper
DEBUG - 2013-08-17 06:33:59 --> Helper loaded: form_helper
DEBUG - 2013-08-17 06:33:59 --> Database Driver Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Session Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Helper loaded: string_helper
DEBUG - 2013-08-17 06:33:59 --> Session routines successfully run
DEBUG - 2013-08-17 06:33:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Controller Class Initialized
ERROR - 2013-08-17 06:33:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:33:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:33:59 --> Model Class Initialized
DEBUG - 2013-08-17 06:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 06:33:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 06:33:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 06:33:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 06:33:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 06:33:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 06:33:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 06:34:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 06:34:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 06:34:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 06:34:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 06:34:00 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 06:34:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 06:34:00 --> Final output sent to browser
DEBUG - 2013-08-17 06:34:00 --> Total execution time: 1.1921
DEBUG - 2013-08-17 06:34:00 --> Config Class Initialized
DEBUG - 2013-08-17 06:34:00 --> Hooks Class Initialized
DEBUG - 2013-08-17 06:34:00 --> Utf8 Class Initialized
DEBUG - 2013-08-17 06:34:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 06:34:00 --> URI Class Initialized
DEBUG - 2013-08-17 06:34:00 --> Router Class Initialized
ERROR - 2013-08-17 06:34:00 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:01:11 --> Config Class Initialized
DEBUG - 2013-08-17 07:01:11 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:01:11 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:01:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:01:11 --> URI Class Initialized
DEBUG - 2013-08-17 07:01:11 --> Router Class Initialized
DEBUG - 2013-08-17 07:01:11 --> Output Class Initialized
DEBUG - 2013-08-17 07:01:11 --> Security Class Initialized
DEBUG - 2013-08-17 07:01:11 --> Input Class Initialized
DEBUG - 2013-08-17 07:01:11 --> XSS Filtering completed
DEBUG - 2013-08-17 07:01:11 --> XSS Filtering completed
DEBUG - 2013-08-17 07:01:12 --> XSS Filtering completed
DEBUG - 2013-08-17 07:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:01:12 --> Language Class Initialized
DEBUG - 2013-08-17 07:01:12 --> Loader Class Initialized
DEBUG - 2013-08-17 07:01:12 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:01:12 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:01:12 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:01:12 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:01:12 --> Session Class Initialized
DEBUG - 2013-08-17 07:01:12 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:01:12 --> Session routines successfully run
DEBUG - 2013-08-17 07:01:12 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:01:12 --> Controller Class Initialized
ERROR - 2013-08-17 07:01:12 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:01:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:01:12 --> Model Class Initialized
DEBUG - 2013-08-17 07:01:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:01:12 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:01:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:01:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:01:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:01:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:01:12 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:01:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:01:39 --> Config Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:01:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:01:39 --> URI Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Router Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Output Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Security Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Input Class Initialized
DEBUG - 2013-08-17 07:01:39 --> XSS Filtering completed
DEBUG - 2013-08-17 07:01:39 --> XSS Filtering completed
DEBUG - 2013-08-17 07:01:39 --> XSS Filtering completed
DEBUG - 2013-08-17 07:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:01:39 --> Language Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Loader Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:01:39 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:01:39 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:01:39 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Session Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:01:39 --> Session routines successfully run
DEBUG - 2013-08-17 07:01:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:01:39 --> Controller Class Initialized
ERROR - 2013-08-17 07:01:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:01:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:01:40 --> Model Class Initialized
DEBUG - 2013-08-17 07:01:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:01:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:01:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:01:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:01:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:01:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:01:40 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:01:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-17 07:01:40 --> Severity: Warning  --> Illegal string offset 'foo' C:\xampp\htdocs\school\application\controllers\guru\kelas.php 116
DEBUG - 2013-08-17 07:02:07 --> Config Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:02:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:02:07 --> URI Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Router Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Output Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Security Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Input Class Initialized
DEBUG - 2013-08-17 07:02:07 --> XSS Filtering completed
DEBUG - 2013-08-17 07:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:02:07 --> Language Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Loader Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:02:07 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:02:07 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:02:07 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Session Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:02:07 --> Session routines successfully run
DEBUG - 2013-08-17 07:02:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Controller Class Initialized
ERROR - 2013-08-17 07:02:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:02:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:02:07 --> Model Class Initialized
DEBUG - 2013-08-17 07:02:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:02:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:02:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:02:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:02:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:02:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:02:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:02:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:02:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:02:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:02:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:02:08 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:02:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:02:08 --> Final output sent to browser
DEBUG - 2013-08-17 07:02:08 --> Total execution time: 0.9971
DEBUG - 2013-08-17 07:02:08 --> Config Class Initialized
DEBUG - 2013-08-17 07:02:08 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:02:08 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:02:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:02:08 --> URI Class Initialized
DEBUG - 2013-08-17 07:02:08 --> Router Class Initialized
ERROR - 2013-08-17 07:02:08 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:02:11 --> Config Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:02:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:02:11 --> URI Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Router Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Output Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Security Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Input Class Initialized
DEBUG - 2013-08-17 07:02:11 --> XSS Filtering completed
DEBUG - 2013-08-17 07:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:02:11 --> Language Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Loader Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:02:11 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:02:11 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:02:11 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Session Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:02:11 --> Session routines successfully run
DEBUG - 2013-08-17 07:02:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Controller Class Initialized
ERROR - 2013-08-17 07:02:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:02:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:02:11 --> Model Class Initialized
DEBUG - 2013-08-17 07:02:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:02:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:02:12 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:02:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:02:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:02:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:02:12 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:02:12 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:02:12 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:02:12 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:02:12 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:02:12 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:02:12 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:02:12 --> Final output sent to browser
DEBUG - 2013-08-17 07:02:12 --> Total execution time: 1.0271
DEBUG - 2013-08-17 07:02:12 --> Config Class Initialized
DEBUG - 2013-08-17 07:02:12 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:02:12 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:02:12 --> URI Class Initialized
DEBUG - 2013-08-17 07:02:12 --> Router Class Initialized
ERROR - 2013-08-17 07:02:12 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:02:15 --> Config Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:02:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:02:15 --> URI Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Router Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Output Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Security Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Input Class Initialized
DEBUG - 2013-08-17 07:02:15 --> XSS Filtering completed
DEBUG - 2013-08-17 07:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:02:15 --> Language Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Loader Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:02:15 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:02:15 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:02:15 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Session Class Initialized
DEBUG - 2013-08-17 07:02:15 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:02:15 --> Session garbage collection performed.
DEBUG - 2013-08-17 07:02:15 --> Session routines successfully run
DEBUG - 2013-08-17 07:02:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:02:16 --> Controller Class Initialized
ERROR - 2013-08-17 07:02:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:02:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:02:16 --> Model Class Initialized
DEBUG - 2013-08-17 07:02:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:02:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:02:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:02:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:02:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:02:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:02:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:02:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:02:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:02:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:02:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:02:16 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:02:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:02:16 --> Final output sent to browser
DEBUG - 2013-08-17 07:02:16 --> Total execution time: 1.0511
DEBUG - 2013-08-17 07:02:16 --> Config Class Initialized
DEBUG - 2013-08-17 07:02:16 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:02:16 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:02:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:02:16 --> URI Class Initialized
DEBUG - 2013-08-17 07:02:16 --> Router Class Initialized
ERROR - 2013-08-17 07:02:16 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:02:17 --> Config Class Initialized
DEBUG - 2013-08-17 07:02:17 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:02:18 --> URI Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Router Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Output Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Security Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Input Class Initialized
DEBUG - 2013-08-17 07:02:18 --> XSS Filtering completed
DEBUG - 2013-08-17 07:02:18 --> XSS Filtering completed
DEBUG - 2013-08-17 07:02:18 --> XSS Filtering completed
DEBUG - 2013-08-17 07:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:02:18 --> Language Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Loader Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:02:18 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:02:18 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:02:18 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Session Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:02:18 --> Session routines successfully run
DEBUG - 2013-08-17 07:02:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Controller Class Initialized
ERROR - 2013-08-17 07:02:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:02:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:02:18 --> Model Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:02:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:02:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:02:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:02:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:02:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:02:18 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:02:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:03:01 --> Config Class Initialized
DEBUG - 2013-08-17 07:03:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:03:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:03:01 --> URI Class Initialized
DEBUG - 2013-08-17 07:03:01 --> Router Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Output Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Security Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Input Class Initialized
DEBUG - 2013-08-17 07:03:02 --> XSS Filtering completed
DEBUG - 2013-08-17 07:03:02 --> XSS Filtering completed
DEBUG - 2013-08-17 07:03:02 --> XSS Filtering completed
DEBUG - 2013-08-17 07:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:03:02 --> Language Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Loader Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:03:02 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:03:02 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:03:02 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Session Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:03:02 --> Session routines successfully run
DEBUG - 2013-08-17 07:03:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Controller Class Initialized
ERROR - 2013-08-17 07:03:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:03:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:03:02 --> Model Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:03:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:03:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:03:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:03:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:03:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:03:02 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:03:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:03:17 --> Config Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:03:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:03:17 --> URI Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Router Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Output Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Security Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Input Class Initialized
DEBUG - 2013-08-17 07:03:17 --> XSS Filtering completed
DEBUG - 2013-08-17 07:03:17 --> XSS Filtering completed
DEBUG - 2013-08-17 07:03:17 --> XSS Filtering completed
DEBUG - 2013-08-17 07:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:03:17 --> Language Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Loader Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:03:17 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:03:17 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:03:17 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Session Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:03:17 --> Session routines successfully run
DEBUG - 2013-08-17 07:03:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Controller Class Initialized
ERROR - 2013-08-17 07:03:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:03:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:03:17 --> Model Class Initialized
DEBUG - 2013-08-17 07:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:03:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:03:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:03:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:03:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:03:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:03:18 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:03:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:04:57 --> Config Class Initialized
DEBUG - 2013-08-17 07:04:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:04:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:04:58 --> URI Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Router Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Output Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Security Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Input Class Initialized
DEBUG - 2013-08-17 07:04:58 --> XSS Filtering completed
DEBUG - 2013-08-17 07:04:58 --> XSS Filtering completed
DEBUG - 2013-08-17 07:04:58 --> XSS Filtering completed
DEBUG - 2013-08-17 07:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:04:58 --> Language Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Loader Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:04:58 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:04:58 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:04:58 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Session Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:04:58 --> Session routines successfully run
DEBUG - 2013-08-17 07:04:58 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Controller Class Initialized
ERROR - 2013-08-17 07:04:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:04:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:04:58 --> Model Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:04:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:04:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:04:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:04:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:04:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:04:58 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:04:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-08-17 07:04:58 --> Severity: Notice  --> Undefined index: foo C:\xampp\htdocs\school\application\controllers\guru\kelas.php 118
DEBUG - 2013-08-17 07:05:07 --> Config Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:05:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:05:07 --> URI Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Router Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Output Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Security Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Input Class Initialized
DEBUG - 2013-08-17 07:05:07 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:07 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:07 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:05:07 --> Language Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Loader Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:05:07 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:05:07 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:05:07 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Session Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:05:07 --> Session routines successfully run
DEBUG - 2013-08-17 07:05:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Controller Class Initialized
ERROR - 2013-08-17 07:05:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:05:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:05:07 --> Model Class Initialized
DEBUG - 2013-08-17 07:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:05:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:05:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:05:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:05:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:05:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:05:08 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:05:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:05:15 --> Config Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:05:15 --> URI Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Router Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Output Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Security Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Input Class Initialized
DEBUG - 2013-08-17 07:05:15 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:05:15 --> Language Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Loader Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:05:15 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:05:15 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:05:15 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Session Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:05:15 --> Session routines successfully run
DEBUG - 2013-08-17 07:05:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:05:15 --> Controller Class Initialized
ERROR - 2013-08-17 07:05:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:05:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:05:16 --> Model Class Initialized
DEBUG - 2013-08-17 07:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:05:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:05:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:05:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:05:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:05:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:05:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:05:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:05:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:05:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:05:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:05:16 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:05:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:05:16 --> Final output sent to browser
DEBUG - 2013-08-17 07:05:16 --> Total execution time: 1.0991
DEBUG - 2013-08-17 07:05:16 --> Config Class Initialized
DEBUG - 2013-08-17 07:05:16 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:05:16 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:05:16 --> URI Class Initialized
DEBUG - 2013-08-17 07:05:16 --> Router Class Initialized
ERROR - 2013-08-17 07:05:16 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:05:20 --> Config Class Initialized
DEBUG - 2013-08-17 07:05:20 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:05:20 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:05:20 --> URI Class Initialized
DEBUG - 2013-08-17 07:05:20 --> Router Class Initialized
DEBUG - 2013-08-17 07:05:20 --> Output Class Initialized
DEBUG - 2013-08-17 07:05:20 --> Security Class Initialized
DEBUG - 2013-08-17 07:05:20 --> Input Class Initialized
DEBUG - 2013-08-17 07:05:21 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:21 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:21 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:05:21 --> Language Class Initialized
DEBUG - 2013-08-17 07:05:21 --> Loader Class Initialized
DEBUG - 2013-08-17 07:05:21 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:05:21 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:05:21 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:05:21 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:05:21 --> Session Class Initialized
DEBUG - 2013-08-17 07:05:21 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:05:21 --> Session routines successfully run
DEBUG - 2013-08-17 07:05:21 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:05:21 --> Controller Class Initialized
ERROR - 2013-08-17 07:05:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:05:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:05:21 --> Model Class Initialized
DEBUG - 2013-08-17 07:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:05:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:05:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:05:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:05:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:05:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:05:21 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:05:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:05:40 --> Config Class Initialized
DEBUG - 2013-08-17 07:05:40 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:05:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:05:41 --> URI Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Router Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Output Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Security Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Input Class Initialized
DEBUG - 2013-08-17 07:05:41 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:41 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:41 --> XSS Filtering completed
DEBUG - 2013-08-17 07:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:05:41 --> Language Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Loader Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:05:41 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:05:41 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:05:41 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Session Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:05:41 --> Session routines successfully run
DEBUG - 2013-08-17 07:05:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Controller Class Initialized
ERROR - 2013-08-17 07:05:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:05:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:05:41 --> Model Class Initialized
DEBUG - 2013-08-17 07:05:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:05:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:05:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:05:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:05:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:05:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:05:42 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:05:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:06:04 --> Config Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:06:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:06:04 --> URI Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Router Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Output Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Security Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Input Class Initialized
DEBUG - 2013-08-17 07:06:04 --> XSS Filtering completed
DEBUG - 2013-08-17 07:06:04 --> XSS Filtering completed
DEBUG - 2013-08-17 07:06:04 --> XSS Filtering completed
DEBUG - 2013-08-17 07:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:06:04 --> Language Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Loader Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:06:04 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:06:04 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:06:04 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Session Class Initialized
DEBUG - 2013-08-17 07:06:04 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:06:05 --> Session routines successfully run
DEBUG - 2013-08-17 07:06:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:06:05 --> Controller Class Initialized
ERROR - 2013-08-17 07:06:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:06:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:06:05 --> Model Class Initialized
DEBUG - 2013-08-17 07:06:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:06:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:06:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:06:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:06:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:06:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:06:05 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:06:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:06:12 --> Config Class Initialized
DEBUG - 2013-08-17 07:06:12 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:06:12 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:06:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:06:12 --> URI Class Initialized
DEBUG - 2013-08-17 07:06:12 --> Router Class Initialized
DEBUG - 2013-08-17 07:06:12 --> Output Class Initialized
DEBUG - 2013-08-17 07:06:12 --> Security Class Initialized
DEBUG - 2013-08-17 07:06:12 --> Input Class Initialized
DEBUG - 2013-08-17 07:06:12 --> XSS Filtering completed
DEBUG - 2013-08-17 07:06:13 --> XSS Filtering completed
DEBUG - 2013-08-17 07:06:13 --> XSS Filtering completed
DEBUG - 2013-08-17 07:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:06:13 --> Language Class Initialized
DEBUG - 2013-08-17 07:06:13 --> Loader Class Initialized
DEBUG - 2013-08-17 07:06:13 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:06:13 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:06:13 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:06:13 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:06:13 --> Session Class Initialized
DEBUG - 2013-08-17 07:06:13 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:06:13 --> Session routines successfully run
DEBUG - 2013-08-17 07:06:13 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:06:13 --> Controller Class Initialized
ERROR - 2013-08-17 07:06:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:06:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:06:13 --> Model Class Initialized
DEBUG - 2013-08-17 07:06:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:06:13 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:06:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:06:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:06:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:06:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:06:13 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:06:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:07:01 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:01 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:01 --> Router Class Initialized
DEBUG - 2013-08-17 07:07:01 --> Output Class Initialized
DEBUG - 2013-08-17 07:07:01 --> Security Class Initialized
DEBUG - 2013-08-17 07:07:01 --> Input Class Initialized
DEBUG - 2013-08-17 07:07:01 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:07:01 --> Language Class Initialized
DEBUG - 2013-08-17 07:07:01 --> Loader Class Initialized
DEBUG - 2013-08-17 07:07:01 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:07:01 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:07:01 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:07:02 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:07:02 --> Session Class Initialized
DEBUG - 2013-08-17 07:07:02 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:07:02 --> Session routines successfully run
DEBUG - 2013-08-17 07:07:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:07:02 --> Controller Class Initialized
ERROR - 2013-08-17 07:07:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:02 --> Model Class Initialized
DEBUG - 2013-08-17 07:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:07:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:07:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:07:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:07:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:07:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:07:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:07:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:07:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:07:02 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:07:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:07:02 --> Final output sent to browser
DEBUG - 2013-08-17 07:07:02 --> Total execution time: 1.0891
DEBUG - 2013-08-17 07:07:02 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:02 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:02 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:02 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:02 --> Router Class Initialized
ERROR - 2013-08-17 07:07:02 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:07:11 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:11 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Router Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Output Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Security Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Input Class Initialized
DEBUG - 2013-08-17 07:07:11 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:11 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:11 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:07:11 --> Language Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Loader Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:07:11 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:07:11 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:07:11 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Session Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:07:11 --> Session routines successfully run
DEBUG - 2013-08-17 07:07:11 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Controller Class Initialized
ERROR - 2013-08-17 07:07:11 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:11 --> Model Class Initialized
DEBUG - 2013-08-17 07:07:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:07:11 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:07:11 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:07:12 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:07:12 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:12 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:07:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:07:16 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:16 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Router Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Output Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Security Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Input Class Initialized
DEBUG - 2013-08-17 07:07:16 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:07:16 --> Language Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Loader Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:07:16 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:07:16 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:07:16 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Session Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:07:16 --> Session routines successfully run
DEBUG - 2013-08-17 07:07:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Controller Class Initialized
ERROR - 2013-08-17 07:07:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:16 --> Model Class Initialized
DEBUG - 2013-08-17 07:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:07:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:07:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:07:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:07:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:07:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:07:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:07:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:07:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:07:17 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:07:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:07:17 --> Final output sent to browser
DEBUG - 2013-08-17 07:07:17 --> Total execution time: 1.1291
DEBUG - 2013-08-17 07:07:17 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:17 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:17 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:17 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:17 --> Router Class Initialized
ERROR - 2013-08-17 07:07:17 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:07:25 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:25 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Router Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Output Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Security Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Input Class Initialized
DEBUG - 2013-08-17 07:07:25 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:25 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:25 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:07:25 --> Language Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Loader Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:07:25 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:07:25 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:07:25 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Session Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:07:25 --> Session routines successfully run
DEBUG - 2013-08-17 07:07:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Controller Class Initialized
ERROR - 2013-08-17 07:07:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:25 --> Model Class Initialized
DEBUG - 2013-08-17 07:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:07:25 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:07:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:07:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:07:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:26 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:07:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:07:29 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:29 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:29 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:29 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:29 --> Router Class Initialized
DEBUG - 2013-08-17 07:07:29 --> Output Class Initialized
DEBUG - 2013-08-17 07:07:30 --> Security Class Initialized
DEBUG - 2013-08-17 07:07:30 --> Input Class Initialized
DEBUG - 2013-08-17 07:07:30 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:07:30 --> Language Class Initialized
DEBUG - 2013-08-17 07:07:30 --> Loader Class Initialized
DEBUG - 2013-08-17 07:07:30 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:07:30 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:07:30 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:07:30 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:07:30 --> Session Class Initialized
DEBUG - 2013-08-17 07:07:30 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:07:30 --> Session routines successfully run
DEBUG - 2013-08-17 07:07:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:07:30 --> Controller Class Initialized
ERROR - 2013-08-17 07:07:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:30 --> Model Class Initialized
DEBUG - 2013-08-17 07:07:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:07:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:07:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:07:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:07:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:07:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:07:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:07:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:07:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:07:30 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:07:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:07:30 --> Final output sent to browser
DEBUG - 2013-08-17 07:07:30 --> Total execution time: 1.1301
DEBUG - 2013-08-17 07:07:31 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:31 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:31 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:31 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:31 --> Router Class Initialized
ERROR - 2013-08-17 07:07:31 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:07:33 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:33 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Router Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Output Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Security Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Input Class Initialized
DEBUG - 2013-08-17 07:07:33 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:07:33 --> Language Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Loader Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:07:33 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:07:33 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:07:33 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Session Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:07:33 --> Session routines successfully run
DEBUG - 2013-08-17 07:07:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Controller Class Initialized
ERROR - 2013-08-17 07:07:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:33 --> Model Class Initialized
DEBUG - 2013-08-17 07:07:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:07:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:07:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:07:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:07:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:07:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:07:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:07:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:07:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:07:34 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:07:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:07:34 --> Final output sent to browser
DEBUG - 2013-08-17 07:07:34 --> Total execution time: 1.2781
DEBUG - 2013-08-17 07:07:34 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:34 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:34 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:34 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:34 --> Router Class Initialized
ERROR - 2013-08-17 07:07:34 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:07:36 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:36 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:36 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:36 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:36 --> Router Class Initialized
DEBUG - 2013-08-17 07:07:36 --> Output Class Initialized
DEBUG - 2013-08-17 07:07:36 --> Security Class Initialized
DEBUG - 2013-08-17 07:07:36 --> Input Class Initialized
DEBUG - 2013-08-17 07:07:36 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:36 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:36 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:07:36 --> Language Class Initialized
DEBUG - 2013-08-17 07:07:36 --> Loader Class Initialized
DEBUG - 2013-08-17 07:07:36 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:07:36 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:07:36 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:07:37 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:07:37 --> Session Class Initialized
DEBUG - 2013-08-17 07:07:37 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:07:37 --> Session routines successfully run
DEBUG - 2013-08-17 07:07:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:07:37 --> Controller Class Initialized
ERROR - 2013-08-17 07:07:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:37 --> Model Class Initialized
DEBUG - 2013-08-17 07:07:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:07:37 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:07:37 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:07:37 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:07:37 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:37 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:07:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:07:56 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:56 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Router Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Output Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Security Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Input Class Initialized
DEBUG - 2013-08-17 07:07:56 --> XSS Filtering completed
DEBUG - 2013-08-17 07:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:07:56 --> Language Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Loader Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:07:56 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:07:56 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:07:56 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Session Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:07:56 --> Session routines successfully run
DEBUG - 2013-08-17 07:07:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Controller Class Initialized
ERROR - 2013-08-17 07:07:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:56 --> Model Class Initialized
DEBUG - 2013-08-17 07:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:07:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:07:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:07:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:07:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:07:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:07:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:07:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:07:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:07:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:07:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:07:57 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:07:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:07:57 --> Final output sent to browser
DEBUG - 2013-08-17 07:07:57 --> Total execution time: 1.1621
DEBUG - 2013-08-17 07:07:57 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:57 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:57 --> Router Class Initialized
ERROR - 2013-08-17 07:07:57 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:07:59 --> Config Class Initialized
DEBUG - 2013-08-17 07:07:59 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:07:59 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:07:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:07:59 --> URI Class Initialized
DEBUG - 2013-08-17 07:07:59 --> Router Class Initialized
DEBUG - 2013-08-17 07:07:59 --> Output Class Initialized
DEBUG - 2013-08-17 07:08:00 --> Security Class Initialized
DEBUG - 2013-08-17 07:08:00 --> Input Class Initialized
DEBUG - 2013-08-17 07:08:00 --> XSS Filtering completed
DEBUG - 2013-08-17 07:08:00 --> XSS Filtering completed
DEBUG - 2013-08-17 07:08:00 --> XSS Filtering completed
DEBUG - 2013-08-17 07:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:08:00 --> Language Class Initialized
DEBUG - 2013-08-17 07:08:00 --> Loader Class Initialized
DEBUG - 2013-08-17 07:08:00 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:08:00 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:08:00 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:08:00 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:08:00 --> Session Class Initialized
DEBUG - 2013-08-17 07:08:00 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:08:00 --> Session routines successfully run
DEBUG - 2013-08-17 07:08:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:08:00 --> Controller Class Initialized
ERROR - 2013-08-17 07:08:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:08:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:08:00 --> Model Class Initialized
DEBUG - 2013-08-17 07:08:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:08:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:08:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:08:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:08:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:08:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:08:00 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:08:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:10:54 --> Config Class Initialized
DEBUG - 2013-08-17 07:10:54 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:10:54 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:10:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:10:54 --> URI Class Initialized
DEBUG - 2013-08-17 07:10:54 --> Router Class Initialized
DEBUG - 2013-08-17 07:10:54 --> Output Class Initialized
DEBUG - 2013-08-17 07:10:54 --> Security Class Initialized
DEBUG - 2013-08-17 07:10:54 --> Input Class Initialized
DEBUG - 2013-08-17 07:10:54 --> XSS Filtering completed
DEBUG - 2013-08-17 07:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:10:54 --> Language Class Initialized
DEBUG - 2013-08-17 07:10:54 --> Loader Class Initialized
DEBUG - 2013-08-17 07:10:54 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:10:54 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:10:54 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:10:55 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:10:55 --> Session Class Initialized
DEBUG - 2013-08-17 07:10:55 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:10:55 --> Session routines successfully run
DEBUG - 2013-08-17 07:10:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:10:55 --> Controller Class Initialized
ERROR - 2013-08-17 07:10:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:10:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:10:55 --> Model Class Initialized
DEBUG - 2013-08-17 07:10:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:10:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:10:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:10:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:10:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:10:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:10:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:10:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:10:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:10:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:10:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:10:55 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:10:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:10:55 --> Final output sent to browser
DEBUG - 2013-08-17 07:10:55 --> Total execution time: 1.2041
DEBUG - 2013-08-17 07:10:55 --> Config Class Initialized
DEBUG - 2013-08-17 07:10:55 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:10:55 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:10:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:10:55 --> URI Class Initialized
DEBUG - 2013-08-17 07:10:56 --> Router Class Initialized
ERROR - 2013-08-17 07:10:56 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:11:00 --> Config Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:11:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:11:00 --> URI Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Router Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Output Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Security Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Input Class Initialized
DEBUG - 2013-08-17 07:11:00 --> XSS Filtering completed
DEBUG - 2013-08-17 07:11:00 --> XSS Filtering completed
DEBUG - 2013-08-17 07:11:00 --> XSS Filtering completed
DEBUG - 2013-08-17 07:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:11:00 --> Language Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Loader Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:11:00 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:11:00 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:11:00 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Session Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:11:00 --> Session routines successfully run
DEBUG - 2013-08-17 07:11:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:11:00 --> Controller Class Initialized
ERROR - 2013-08-17 07:11:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:11:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:11:01 --> Model Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:11:01 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:11:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:11:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:11:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:11:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:11:01 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:11:01 --> Config Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:11:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:11:01 --> URI Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Router Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Output Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Security Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Input Class Initialized
DEBUG - 2013-08-17 07:11:01 --> XSS Filtering completed
DEBUG - 2013-08-17 07:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:11:01 --> Language Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Loader Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:11:01 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:11:01 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:11:01 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Session Class Initialized
DEBUG - 2013-08-17 07:11:01 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:11:02 --> Session routines successfully run
DEBUG - 2013-08-17 07:11:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:11:02 --> Controller Class Initialized
ERROR - 2013-08-17 07:11:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:11:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:11:02 --> Model Class Initialized
DEBUG - 2013-08-17 07:11:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:11:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:11:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:11:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:11:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:11:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:11:02 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:11:02 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:11:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:11:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:11:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:11:02 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:11:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:11:02 --> Final output sent to browser
DEBUG - 2013-08-17 07:11:02 --> Total execution time: 1.3901
DEBUG - 2013-08-17 07:11:02 --> Config Class Initialized
DEBUG - 2013-08-17 07:11:02 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:11:03 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:11:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:11:03 --> URI Class Initialized
DEBUG - 2013-08-17 07:11:03 --> Router Class Initialized
ERROR - 2013-08-17 07:11:03 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:11:53 --> Config Class Initialized
DEBUG - 2013-08-17 07:11:53 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:11:53 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:11:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:11:53 --> URI Class Initialized
DEBUG - 2013-08-17 07:11:53 --> Router Class Initialized
DEBUG - 2013-08-17 07:11:53 --> Output Class Initialized
DEBUG - 2013-08-17 07:11:53 --> Security Class Initialized
DEBUG - 2013-08-17 07:11:53 --> Input Class Initialized
DEBUG - 2013-08-17 07:11:53 --> XSS Filtering completed
DEBUG - 2013-08-17 07:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:11:53 --> Language Class Initialized
DEBUG - 2013-08-17 07:11:53 --> Loader Class Initialized
DEBUG - 2013-08-17 07:11:53 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:11:53 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:11:53 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:11:53 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:11:54 --> Session Class Initialized
DEBUG - 2013-08-17 07:11:54 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:11:54 --> Session routines successfully run
DEBUG - 2013-08-17 07:11:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:11:54 --> Controller Class Initialized
ERROR - 2013-08-17 07:11:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:11:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:11:54 --> Model Class Initialized
DEBUG - 2013-08-17 07:11:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:11:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:11:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:11:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:11:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:11:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:11:54 --> Pagination Class Initialized
DEBUG - 2013-08-17 07:11:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:11:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:11:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:11:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:11:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:11:54 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 07:11:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:11:54 --> Final output sent to browser
DEBUG - 2013-08-17 07:11:54 --> Total execution time: 1.2731
DEBUG - 2013-08-17 07:11:54 --> Config Class Initialized
DEBUG - 2013-08-17 07:11:55 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:11:55 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:11:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:11:55 --> URI Class Initialized
DEBUG - 2013-08-17 07:11:55 --> Router Class Initialized
ERROR - 2013-08-17 07:11:55 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:11:57 --> Config Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:11:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:11:57 --> URI Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Router Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Output Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Security Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Input Class Initialized
DEBUG - 2013-08-17 07:11:57 --> XSS Filtering completed
DEBUG - 2013-08-17 07:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:11:57 --> Language Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Loader Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:11:57 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:11:57 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:11:57 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Session Class Initialized
DEBUG - 2013-08-17 07:11:57 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:11:57 --> Session routines successfully run
DEBUG - 2013-08-17 07:11:57 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:11:58 --> Controller Class Initialized
ERROR - 2013-08-17 07:11:58 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:11:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:11:58 --> Model Class Initialized
DEBUG - 2013-08-17 07:11:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:11:58 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:11:58 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:11:58 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:11:58 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:11:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:11:58 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:11:58 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:11:58 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:11:58 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:11:58 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:11:58 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:11:58 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:11:58 --> Final output sent to browser
DEBUG - 2013-08-17 07:11:58 --> Total execution time: 1.3111
DEBUG - 2013-08-17 07:11:58 --> Config Class Initialized
DEBUG - 2013-08-17 07:11:58 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:11:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:11:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:11:58 --> URI Class Initialized
DEBUG - 2013-08-17 07:11:59 --> Router Class Initialized
ERROR - 2013-08-17 07:11:59 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:12:04 --> Config Class Initialized
DEBUG - 2013-08-17 07:12:04 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:12:04 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:12:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:12:04 --> URI Class Initialized
DEBUG - 2013-08-17 07:12:04 --> Router Class Initialized
DEBUG - 2013-08-17 07:12:04 --> Output Class Initialized
DEBUG - 2013-08-17 07:12:04 --> Security Class Initialized
DEBUG - 2013-08-17 07:12:04 --> Input Class Initialized
DEBUG - 2013-08-17 07:12:04 --> XSS Filtering completed
DEBUG - 2013-08-17 07:12:04 --> XSS Filtering completed
DEBUG - 2013-08-17 07:12:04 --> XSS Filtering completed
DEBUG - 2013-08-17 07:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:12:04 --> Language Class Initialized
DEBUG - 2013-08-17 07:12:04 --> Loader Class Initialized
DEBUG - 2013-08-17 07:12:04 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:12:04 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:12:04 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:12:05 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Session Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:12:05 --> Session routines successfully run
DEBUG - 2013-08-17 07:12:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Controller Class Initialized
ERROR - 2013-08-17 07:12:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:12:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:12:05 --> Model Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:12:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:12:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:12:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:12:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:12:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:12:05 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:12:05 --> Config Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:12:05 --> URI Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Router Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Output Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Security Class Initialized
DEBUG - 2013-08-17 07:12:05 --> Input Class Initialized
DEBUG - 2013-08-17 07:12:05 --> XSS Filtering completed
DEBUG - 2013-08-17 07:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:12:05 --> Language Class Initialized
DEBUG - 2013-08-17 07:12:06 --> Loader Class Initialized
DEBUG - 2013-08-17 07:12:06 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:12:06 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:12:06 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:12:06 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:12:06 --> Session Class Initialized
DEBUG - 2013-08-17 07:12:06 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:12:06 --> Session routines successfully run
DEBUG - 2013-08-17 07:12:06 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:12:06 --> Controller Class Initialized
ERROR - 2013-08-17 07:12:06 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:12:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:12:06 --> Model Class Initialized
DEBUG - 2013-08-17 07:12:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:12:06 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:12:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:12:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:12:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:12:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:12:06 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:12:06 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:12:06 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:12:06 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:12:06 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:12:06 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:12:06 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:12:06 --> Final output sent to browser
DEBUG - 2013-08-17 07:12:06 --> Total execution time: 1.3291
DEBUG - 2013-08-17 07:12:07 --> Config Class Initialized
DEBUG - 2013-08-17 07:12:07 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:12:07 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:12:07 --> URI Class Initialized
DEBUG - 2013-08-17 07:12:07 --> Router Class Initialized
ERROR - 2013-08-17 07:12:07 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:13:31 --> Config Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:13:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:13:31 --> URI Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Router Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Output Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Security Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Input Class Initialized
DEBUG - 2013-08-17 07:13:31 --> XSS Filtering completed
DEBUG - 2013-08-17 07:13:31 --> XSS Filtering completed
DEBUG - 2013-08-17 07:13:31 --> XSS Filtering completed
DEBUG - 2013-08-17 07:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:13:31 --> Language Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Loader Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:13:31 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:13:31 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:13:31 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Session Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:13:31 --> Session garbage collection performed.
DEBUG - 2013-08-17 07:13:31 --> Session routines successfully run
DEBUG - 2013-08-17 07:13:31 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:13:31 --> Controller Class Initialized
ERROR - 2013-08-17 07:13:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:13:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:13:32 --> Model Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:13:32 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:13:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:13:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:13:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:13:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:13:32 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:13:32 --> Config Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:13:32 --> URI Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Router Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Output Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Security Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Input Class Initialized
DEBUG - 2013-08-17 07:13:32 --> XSS Filtering completed
DEBUG - 2013-08-17 07:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:13:32 --> Language Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Loader Class Initialized
DEBUG - 2013-08-17 07:13:32 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:13:32 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:13:32 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:13:33 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:13:33 --> Session Class Initialized
DEBUG - 2013-08-17 07:13:33 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:13:33 --> Session routines successfully run
DEBUG - 2013-08-17 07:13:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:13:33 --> Controller Class Initialized
ERROR - 2013-08-17 07:13:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:13:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:13:33 --> Model Class Initialized
DEBUG - 2013-08-17 07:13:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:13:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:13:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:13:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:13:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:13:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:13:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:13:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:13:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:13:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:13:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:13:33 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:13:33 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:13:33 --> Final output sent to browser
DEBUG - 2013-08-17 07:13:33 --> Total execution time: 1.4651
DEBUG - 2013-08-17 07:13:34 --> Config Class Initialized
DEBUG - 2013-08-17 07:13:34 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:13:34 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:13:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:13:34 --> URI Class Initialized
DEBUG - 2013-08-17 07:13:34 --> Router Class Initialized
ERROR - 2013-08-17 07:13:34 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:13:50 --> Config Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:13:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:13:50 --> URI Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Router Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Output Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Security Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Input Class Initialized
DEBUG - 2013-08-17 07:13:50 --> XSS Filtering completed
DEBUG - 2013-08-17 07:13:50 --> XSS Filtering completed
DEBUG - 2013-08-17 07:13:50 --> XSS Filtering completed
DEBUG - 2013-08-17 07:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:13:50 --> Language Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Loader Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:13:50 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:13:50 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:13:50 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Session Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:13:50 --> Session routines successfully run
DEBUG - 2013-08-17 07:13:50 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Controller Class Initialized
ERROR - 2013-08-17 07:13:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:13:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:13:50 --> Model Class Initialized
DEBUG - 2013-08-17 07:13:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:13:50 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:13:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:13:51 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:13:51 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:13:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:13:51 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:13:51 --> Config Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:13:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:13:51 --> URI Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Router Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Output Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Security Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Input Class Initialized
DEBUG - 2013-08-17 07:13:51 --> XSS Filtering completed
DEBUG - 2013-08-17 07:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:13:51 --> Language Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Loader Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:13:51 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:13:51 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:13:51 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Session Class Initialized
DEBUG - 2013-08-17 07:13:51 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:13:52 --> Session routines successfully run
DEBUG - 2013-08-17 07:13:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:13:52 --> Controller Class Initialized
ERROR - 2013-08-17 07:13:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:13:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:13:52 --> Model Class Initialized
DEBUG - 2013-08-17 07:13:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:13:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:13:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:13:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:13:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:13:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:13:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:13:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:13:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:13:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:13:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:13:52 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:13:52 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:13:52 --> Final output sent to browser
DEBUG - 2013-08-17 07:13:52 --> Total execution time: 1.4001
DEBUG - 2013-08-17 07:13:52 --> Config Class Initialized
DEBUG - 2013-08-17 07:13:52 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:13:52 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:13:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:13:53 --> URI Class Initialized
DEBUG - 2013-08-17 07:13:53 --> Router Class Initialized
ERROR - 2013-08-17 07:13:53 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:17:08 --> Config Class Initialized
DEBUG - 2013-08-17 07:17:08 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:17:08 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:17:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:17:08 --> URI Class Initialized
DEBUG - 2013-08-17 07:17:08 --> Router Class Initialized
DEBUG - 2013-08-17 07:17:08 --> Output Class Initialized
DEBUG - 2013-08-17 07:17:08 --> Security Class Initialized
DEBUG - 2013-08-17 07:17:08 --> Input Class Initialized
DEBUG - 2013-08-17 07:17:08 --> XSS Filtering completed
DEBUG - 2013-08-17 07:17:08 --> XSS Filtering completed
DEBUG - 2013-08-17 07:17:08 --> XSS Filtering completed
DEBUG - 2013-08-17 07:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:17:09 --> Language Class Initialized
DEBUG - 2013-08-17 07:17:09 --> Loader Class Initialized
DEBUG - 2013-08-17 07:17:09 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:17:09 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:17:09 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:17:09 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:17:09 --> Session Class Initialized
DEBUG - 2013-08-17 07:17:09 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:17:09 --> Session routines successfully run
DEBUG - 2013-08-17 07:17:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:17:09 --> Controller Class Initialized
ERROR - 2013-08-17 07:17:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:17:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:17:09 --> Model Class Initialized
DEBUG - 2013-08-17 07:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:17:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:17:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:17:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:17:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:17:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:17:09 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:17:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:19:09 --> Config Class Initialized
DEBUG - 2013-08-17 07:19:09 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:19:09 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:19:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:19:09 --> URI Class Initialized
DEBUG - 2013-08-17 07:19:09 --> Router Class Initialized
DEBUG - 2013-08-17 07:19:09 --> Output Class Initialized
DEBUG - 2013-08-17 07:19:09 --> Security Class Initialized
DEBUG - 2013-08-17 07:19:09 --> Input Class Initialized
DEBUG - 2013-08-17 07:19:09 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:10 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:10 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:19:10 --> Language Class Initialized
DEBUG - 2013-08-17 07:19:10 --> Loader Class Initialized
DEBUG - 2013-08-17 07:19:10 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:19:10 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:19:10 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:19:10 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:19:10 --> Session Class Initialized
DEBUG - 2013-08-17 07:19:10 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:19:10 --> Session routines successfully run
DEBUG - 2013-08-17 07:19:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:19:10 --> Controller Class Initialized
ERROR - 2013-08-17 07:19:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:19:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:19:10 --> Model Class Initialized
DEBUG - 2013-08-17 07:19:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:19:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:19:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:19:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:19:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:19:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:19:10 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:19:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:19:35 --> Config Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:19:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:19:35 --> URI Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Router Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Output Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Security Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Input Class Initialized
DEBUG - 2013-08-17 07:19:35 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:19:35 --> Language Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Loader Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:19:35 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:19:35 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:19:35 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Session Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:19:35 --> Session routines successfully run
DEBUG - 2013-08-17 07:19:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:19:35 --> Controller Class Initialized
ERROR - 2013-08-17 07:19:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:19:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:19:36 --> Model Class Initialized
DEBUG - 2013-08-17 07:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:19:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:19:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:19:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:19:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:19:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:19:36 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:19:36 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:19:36 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:19:36 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:19:36 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:19:36 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:19:36 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:19:36 --> Final output sent to browser
DEBUG - 2013-08-17 07:19:36 --> Total execution time: 1.2641
DEBUG - 2013-08-17 07:19:36 --> Config Class Initialized
DEBUG - 2013-08-17 07:19:36 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:19:36 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:19:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:19:37 --> URI Class Initialized
DEBUG - 2013-08-17 07:19:37 --> Router Class Initialized
ERROR - 2013-08-17 07:19:37 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:19:39 --> Config Class Initialized
DEBUG - 2013-08-17 07:19:39 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:19:39 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:19:39 --> URI Class Initialized
DEBUG - 2013-08-17 07:19:39 --> Router Class Initialized
DEBUG - 2013-08-17 07:19:39 --> Output Class Initialized
DEBUG - 2013-08-17 07:19:40 --> Security Class Initialized
DEBUG - 2013-08-17 07:19:40 --> Input Class Initialized
DEBUG - 2013-08-17 07:19:40 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:40 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:40 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:19:40 --> Language Class Initialized
DEBUG - 2013-08-17 07:19:40 --> Loader Class Initialized
DEBUG - 2013-08-17 07:19:40 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:19:40 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:19:40 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:19:40 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:19:40 --> Session Class Initialized
DEBUG - 2013-08-17 07:19:40 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:19:40 --> Session routines successfully run
DEBUG - 2013-08-17 07:19:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:19:40 --> Controller Class Initialized
ERROR - 2013-08-17 07:19:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:19:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:19:40 --> Model Class Initialized
DEBUG - 2013-08-17 07:19:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:19:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:19:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:19:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:19:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:19:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:19:40 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:19:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:19:59 --> Config Class Initialized
DEBUG - 2013-08-17 07:19:59 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:19:59 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:19:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:19:59 --> URI Class Initialized
DEBUG - 2013-08-17 07:19:59 --> Router Class Initialized
DEBUG - 2013-08-17 07:19:59 --> Output Class Initialized
DEBUG - 2013-08-17 07:19:59 --> Security Class Initialized
DEBUG - 2013-08-17 07:19:59 --> Input Class Initialized
DEBUG - 2013-08-17 07:19:59 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:59 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:59 --> XSS Filtering completed
DEBUG - 2013-08-17 07:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:19:59 --> Language Class Initialized
DEBUG - 2013-08-17 07:19:59 --> Loader Class Initialized
DEBUG - 2013-08-17 07:19:59 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:19:59 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:20:00 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:20:00 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:20:00 --> Session Class Initialized
DEBUG - 2013-08-17 07:20:00 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:20:00 --> Session garbage collection performed.
DEBUG - 2013-08-17 07:20:00 --> Session routines successfully run
DEBUG - 2013-08-17 07:20:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:20:00 --> Controller Class Initialized
ERROR - 2013-08-17 07:20:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:20:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:20:00 --> Model Class Initialized
DEBUG - 2013-08-17 07:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:20:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:20:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:20:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:20:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:20:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:20:00 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:20:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:21:35 --> Config Class Initialized
DEBUG - 2013-08-17 07:21:35 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:21:35 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:21:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:21:35 --> URI Class Initialized
DEBUG - 2013-08-17 07:21:35 --> Router Class Initialized
DEBUG - 2013-08-17 07:21:35 --> Output Class Initialized
DEBUG - 2013-08-17 07:21:35 --> Security Class Initialized
DEBUG - 2013-08-17 07:21:35 --> Input Class Initialized
DEBUG - 2013-08-17 07:21:36 --> XSS Filtering completed
DEBUG - 2013-08-17 07:21:36 --> XSS Filtering completed
DEBUG - 2013-08-17 07:21:36 --> XSS Filtering completed
DEBUG - 2013-08-17 07:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:21:36 --> Language Class Initialized
DEBUG - 2013-08-17 07:21:36 --> Loader Class Initialized
DEBUG - 2013-08-17 07:21:36 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:21:36 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:21:36 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:21:36 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:21:36 --> Session Class Initialized
DEBUG - 2013-08-17 07:21:36 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:21:36 --> Session routines successfully run
DEBUG - 2013-08-17 07:21:36 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:21:36 --> Controller Class Initialized
ERROR - 2013-08-17 07:21:36 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:21:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:21:36 --> Model Class Initialized
DEBUG - 2013-08-17 07:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:21:36 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:21:36 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:21:36 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:21:36 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:21:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:21:36 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:21:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:21:37 --> Config Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:21:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:21:37 --> URI Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Router Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Output Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Security Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Input Class Initialized
DEBUG - 2013-08-17 07:21:37 --> XSS Filtering completed
DEBUG - 2013-08-17 07:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:21:37 --> Language Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Loader Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:21:37 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:21:37 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:21:37 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Session Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:21:37 --> Session routines successfully run
DEBUG - 2013-08-17 07:21:37 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:21:37 --> Controller Class Initialized
ERROR - 2013-08-17 07:21:37 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:21:37 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:21:38 --> Model Class Initialized
DEBUG - 2013-08-17 07:21:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:21:38 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:21:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:21:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:21:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:21:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:21:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:21:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:21:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:21:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:21:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:21:38 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:21:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:21:38 --> Final output sent to browser
DEBUG - 2013-08-17 07:21:38 --> Total execution time: 1.5561
DEBUG - 2013-08-17 07:21:38 --> Config Class Initialized
DEBUG - 2013-08-17 07:21:38 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:21:38 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:21:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:21:38 --> URI Class Initialized
DEBUG - 2013-08-17 07:21:38 --> Router Class Initialized
ERROR - 2013-08-17 07:21:39 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:23:16 --> Config Class Initialized
DEBUG - 2013-08-17 07:23:16 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:23:16 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:23:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:23:16 --> URI Class Initialized
DEBUG - 2013-08-17 07:23:16 --> Router Class Initialized
DEBUG - 2013-08-17 07:23:16 --> Output Class Initialized
DEBUG - 2013-08-17 07:23:16 --> Security Class Initialized
DEBUG - 2013-08-17 07:23:17 --> Input Class Initialized
DEBUG - 2013-08-17 07:23:17 --> XSS Filtering completed
DEBUG - 2013-08-17 07:23:17 --> XSS Filtering completed
DEBUG - 2013-08-17 07:23:17 --> XSS Filtering completed
DEBUG - 2013-08-17 07:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:23:17 --> Language Class Initialized
DEBUG - 2013-08-17 07:23:17 --> Loader Class Initialized
DEBUG - 2013-08-17 07:23:17 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:23:17 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:23:17 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:23:17 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:23:17 --> Session Class Initialized
DEBUG - 2013-08-17 07:23:17 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:23:17 --> Session routines successfully run
DEBUG - 2013-08-17 07:23:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:23:17 --> Controller Class Initialized
ERROR - 2013-08-17 07:23:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:23:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:23:17 --> Model Class Initialized
DEBUG - 2013-08-17 07:23:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:23:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:23:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:23:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:23:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:23:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:23:18 --> Form Validation Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-08-17 07:23:18 --> Config Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:23:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:23:18 --> URI Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Router Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Output Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Security Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Input Class Initialized
DEBUG - 2013-08-17 07:23:18 --> XSS Filtering completed
DEBUG - 2013-08-17 07:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:23:18 --> Language Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Loader Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:23:18 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:23:18 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:23:18 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Session Class Initialized
DEBUG - 2013-08-17 07:23:18 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:23:18 --> Session routines successfully run
DEBUG - 2013-08-17 07:23:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:23:19 --> Controller Class Initialized
ERROR - 2013-08-17 07:23:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:23:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:23:19 --> Model Class Initialized
DEBUG - 2013-08-17 07:23:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:23:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:23:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:23:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:23:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:23:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:23:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:23:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:23:19 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:23:19 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:23:19 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:23:19 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:23:19 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:23:19 --> Final output sent to browser
DEBUG - 2013-08-17 07:23:19 --> Total execution time: 1.5031
DEBUG - 2013-08-17 07:23:19 --> Config Class Initialized
DEBUG - 2013-08-17 07:23:19 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:23:19 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:23:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:23:20 --> URI Class Initialized
DEBUG - 2013-08-17 07:23:20 --> Router Class Initialized
ERROR - 2013-08-17 07:23:20 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:23:25 --> Config Class Initialized
DEBUG - 2013-08-17 07:23:25 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:23:25 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:23:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:23:26 --> URI Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Router Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Output Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Security Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Input Class Initialized
DEBUG - 2013-08-17 07:23:26 --> XSS Filtering completed
DEBUG - 2013-08-17 07:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:23:26 --> Language Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Loader Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:23:26 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:23:26 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:23:26 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Session Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:23:26 --> Session routines successfully run
DEBUG - 2013-08-17 07:23:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Controller Class Initialized
ERROR - 2013-08-17 07:23:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:23:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:23:26 --> Model Class Initialized
DEBUG - 2013-08-17 07:23:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:23:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:23:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:23:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:23:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:23:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:23:26 --> Pagination Class Initialized
DEBUG - 2013-08-17 07:23:27 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:23:27 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:23:27 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:23:27 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:23:27 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:23:27 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 07:23:27 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:23:27 --> Final output sent to browser
DEBUG - 2013-08-17 07:23:27 --> Total execution time: 1.3701
DEBUG - 2013-08-17 07:23:27 --> Config Class Initialized
DEBUG - 2013-08-17 07:23:27 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:23:27 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:23:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:23:27 --> URI Class Initialized
DEBUG - 2013-08-17 07:23:27 --> Router Class Initialized
ERROR - 2013-08-17 07:23:27 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:23:29 --> Config Class Initialized
DEBUG - 2013-08-17 07:23:29 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:23:29 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:23:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:23:29 --> URI Class Initialized
DEBUG - 2013-08-17 07:23:29 --> Router Class Initialized
DEBUG - 2013-08-17 07:23:29 --> Output Class Initialized
DEBUG - 2013-08-17 07:23:29 --> Security Class Initialized
DEBUG - 2013-08-17 07:23:29 --> Input Class Initialized
DEBUG - 2013-08-17 07:23:29 --> XSS Filtering completed
DEBUG - 2013-08-17 07:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:23:30 --> Language Class Initialized
DEBUG - 2013-08-17 07:23:30 --> Loader Class Initialized
DEBUG - 2013-08-17 07:23:30 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:23:30 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:23:30 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:23:30 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:23:30 --> Session Class Initialized
DEBUG - 2013-08-17 07:23:30 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:23:30 --> Session routines successfully run
DEBUG - 2013-08-17 07:23:30 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:23:30 --> Controller Class Initialized
ERROR - 2013-08-17 07:23:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:23:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:23:30 --> Model Class Initialized
DEBUG - 2013-08-17 07:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:23:30 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:23:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:23:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:23:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:23:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:23:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:23:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:23:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:23:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:23:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:23:30 --> File loaded: application/views/kelas/new.php
DEBUG - 2013-08-17 07:23:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:23:31 --> Final output sent to browser
DEBUG - 2013-08-17 07:23:31 --> Total execution time: 1.3731
DEBUG - 2013-08-17 07:23:31 --> Config Class Initialized
DEBUG - 2013-08-17 07:23:31 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:23:31 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:23:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:23:31 --> URI Class Initialized
DEBUG - 2013-08-17 07:23:31 --> Router Class Initialized
ERROR - 2013-08-17 07:23:31 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:28:39 --> Config Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:28:39 --> URI Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Router Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Output Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Security Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Input Class Initialized
DEBUG - 2013-08-17 07:28:39 --> XSS Filtering completed
DEBUG - 2013-08-17 07:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:28:39 --> Language Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Loader Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:28:39 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:28:39 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:28:39 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Session Class Initialized
DEBUG - 2013-08-17 07:28:39 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:28:40 --> Session routines successfully run
DEBUG - 2013-08-17 07:28:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:28:40 --> Controller Class Initialized
ERROR - 2013-08-17 07:28:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:28:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:28:40 --> Model Class Initialized
DEBUG - 2013-08-17 07:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:28:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:28:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:28:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:28:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:28:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:28:40 --> Pagination Class Initialized
DEBUG - 2013-08-17 07:28:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:28:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:28:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:28:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:28:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:28:40 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 07:28:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:28:40 --> Final output sent to browser
DEBUG - 2013-08-17 07:28:40 --> Total execution time: 1.3891
DEBUG - 2013-08-17 07:28:41 --> Config Class Initialized
DEBUG - 2013-08-17 07:28:41 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:28:41 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:28:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:28:41 --> URI Class Initialized
DEBUG - 2013-08-17 07:28:41 --> Router Class Initialized
ERROR - 2013-08-17 07:28:41 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:37:52 --> Config Class Initialized
DEBUG - 2013-08-17 07:37:52 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:37:52 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:37:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:37:52 --> URI Class Initialized
DEBUG - 2013-08-17 07:37:52 --> Router Class Initialized
DEBUG - 2013-08-17 07:37:52 --> Output Class Initialized
DEBUG - 2013-08-17 07:37:52 --> Security Class Initialized
DEBUG - 2013-08-17 07:37:53 --> Input Class Initialized
DEBUG - 2013-08-17 07:37:53 --> XSS Filtering completed
DEBUG - 2013-08-17 07:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:37:53 --> Language Class Initialized
DEBUG - 2013-08-17 07:37:53 --> Loader Class Initialized
DEBUG - 2013-08-17 07:37:53 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:37:53 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:37:53 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:37:53 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:37:53 --> Session Class Initialized
DEBUG - 2013-08-17 07:37:53 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:37:53 --> Session routines successfully run
DEBUG - 2013-08-17 07:37:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:37:53 --> Controller Class Initialized
ERROR - 2013-08-17 07:37:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:37:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:37:53 --> Model Class Initialized
DEBUG - 2013-08-17 07:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:37:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:37:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:37:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:37:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:37:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:37:53 --> Pagination Class Initialized
DEBUG - 2013-08-17 07:37:53 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:37:53 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:37:53 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:37:53 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:37:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:37:54 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 07:37:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:37:54 --> Final output sent to browser
DEBUG - 2013-08-17 07:37:54 --> Total execution time: 1.3491
DEBUG - 2013-08-17 07:37:54 --> Config Class Initialized
DEBUG - 2013-08-17 07:37:54 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:37:54 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:37:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:37:54 --> URI Class Initialized
DEBUG - 2013-08-17 07:37:54 --> Router Class Initialized
ERROR - 2013-08-17 07:37:54 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:38:16 --> Config Class Initialized
DEBUG - 2013-08-17 07:38:16 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:38:16 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:38:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:38:16 --> URI Class Initialized
DEBUG - 2013-08-17 07:38:16 --> Router Class Initialized
DEBUG - 2013-08-17 07:38:16 --> Output Class Initialized
DEBUG - 2013-08-17 07:38:16 --> Security Class Initialized
DEBUG - 2013-08-17 07:38:17 --> Input Class Initialized
DEBUG - 2013-08-17 07:38:17 --> XSS Filtering completed
DEBUG - 2013-08-17 07:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:38:17 --> Language Class Initialized
DEBUG - 2013-08-17 07:38:17 --> Loader Class Initialized
DEBUG - 2013-08-17 07:38:17 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:38:17 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:38:17 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:38:17 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:38:17 --> Session Class Initialized
DEBUG - 2013-08-17 07:38:17 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:38:17 --> Session routines successfully run
DEBUG - 2013-08-17 07:38:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:38:17 --> Controller Class Initialized
ERROR - 2013-08-17 07:38:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:38:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:38:17 --> Model Class Initialized
DEBUG - 2013-08-17 07:38:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:38:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:38:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:38:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:38:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:38:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:38:17 --> Pagination Class Initialized
DEBUG - 2013-08-17 07:38:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:38:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:38:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:38:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:38:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:38:18 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 07:38:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:38:18 --> Final output sent to browser
DEBUG - 2013-08-17 07:38:18 --> Total execution time: 1.4071
DEBUG - 2013-08-17 07:38:18 --> Config Class Initialized
DEBUG - 2013-08-17 07:38:18 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:38:18 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:38:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:38:18 --> URI Class Initialized
DEBUG - 2013-08-17 07:38:18 --> Router Class Initialized
ERROR - 2013-08-17 07:38:18 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:40:22 --> Config Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:40:22 --> URI Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Router Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Output Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Security Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Input Class Initialized
DEBUG - 2013-08-17 07:40:22 --> XSS Filtering completed
DEBUG - 2013-08-17 07:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:40:22 --> Language Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Loader Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:40:22 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:40:22 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:40:22 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Session Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:40:22 --> Session routines successfully run
DEBUG - 2013-08-17 07:40:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Controller Class Initialized
ERROR - 2013-08-17 07:40:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:40:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:40:22 --> Model Class Initialized
DEBUG - 2013-08-17 07:40:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:40:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:40:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:40:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:40:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:40:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:40:23 --> Pagination Class Initialized
DEBUG - 2013-08-17 07:40:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:40:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:40:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:40:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:40:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:40:23 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 07:40:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:40:23 --> Final output sent to browser
DEBUG - 2013-08-17 07:40:23 --> Total execution time: 1.3331
DEBUG - 2013-08-17 07:40:23 --> Config Class Initialized
DEBUG - 2013-08-17 07:40:23 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:40:23 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:40:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:40:23 --> URI Class Initialized
DEBUG - 2013-08-17 07:40:23 --> Router Class Initialized
ERROR - 2013-08-17 07:40:23 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:40:25 --> Config Class Initialized
DEBUG - 2013-08-17 07:40:25 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:40:25 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:40:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:40:25 --> URI Class Initialized
DEBUG - 2013-08-17 07:40:25 --> Router Class Initialized
DEBUG - 2013-08-17 07:40:25 --> Output Class Initialized
DEBUG - 2013-08-17 07:40:25 --> Security Class Initialized
DEBUG - 2013-08-17 07:40:25 --> Input Class Initialized
DEBUG - 2013-08-17 07:40:25 --> XSS Filtering completed
DEBUG - 2013-08-17 07:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:40:25 --> Language Class Initialized
DEBUG - 2013-08-17 07:40:25 --> Loader Class Initialized
DEBUG - 2013-08-17 07:40:25 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:40:25 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:40:25 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:40:25 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:40:25 --> Session Class Initialized
DEBUG - 2013-08-17 07:40:26 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:40:26 --> Session routines successfully run
DEBUG - 2013-08-17 07:40:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:40:26 --> Controller Class Initialized
ERROR - 2013-08-17 07:40:26 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:40:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:40:26 --> Model Class Initialized
DEBUG - 2013-08-17 07:40:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:40:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:40:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:40:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:40:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:40:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:40:26 --> Pagination Class Initialized
DEBUG - 2013-08-17 07:40:26 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:40:26 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:40:26 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:40:26 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:40:26 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:40:26 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 07:40:26 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:40:26 --> Final output sent to browser
DEBUG - 2013-08-17 07:40:26 --> Total execution time: 1.4071
DEBUG - 2013-08-17 07:40:27 --> Config Class Initialized
DEBUG - 2013-08-17 07:40:27 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:40:27 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:40:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:40:27 --> URI Class Initialized
DEBUG - 2013-08-17 07:40:27 --> Router Class Initialized
ERROR - 2013-08-17 07:40:27 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 07:59:39 --> Config Class Initialized
DEBUG - 2013-08-17 07:59:39 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:59:39 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:59:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:59:39 --> URI Class Initialized
DEBUG - 2013-08-17 07:59:39 --> Router Class Initialized
DEBUG - 2013-08-17 07:59:39 --> Output Class Initialized
DEBUG - 2013-08-17 07:59:39 --> Security Class Initialized
DEBUG - 2013-08-17 07:59:39 --> Input Class Initialized
DEBUG - 2013-08-17 07:59:39 --> XSS Filtering completed
DEBUG - 2013-08-17 07:59:39 --> XSS Filtering completed
DEBUG - 2013-08-17 07:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 07:59:39 --> Language Class Initialized
DEBUG - 2013-08-17 07:59:39 --> Loader Class Initialized
DEBUG - 2013-08-17 07:59:40 --> Helper loaded: url_helper
DEBUG - 2013-08-17 07:59:40 --> Helper loaded: file_helper
DEBUG - 2013-08-17 07:59:40 --> Helper loaded: form_helper
DEBUG - 2013-08-17 07:59:40 --> Database Driver Class Initialized
DEBUG - 2013-08-17 07:59:40 --> Session Class Initialized
DEBUG - 2013-08-17 07:59:40 --> Helper loaded: string_helper
DEBUG - 2013-08-17 07:59:40 --> Session routines successfully run
DEBUG - 2013-08-17 07:59:40 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 07:59:40 --> Controller Class Initialized
ERROR - 2013-08-17 07:59:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:59:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:59:40 --> Model Class Initialized
DEBUG - 2013-08-17 07:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 07:59:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 07:59:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 07:59:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 07:59:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 07:59:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 07:59:40 --> Pagination Class Initialized
DEBUG - 2013-08-17 07:59:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 07:59:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 07:59:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 07:59:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 07:59:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 07:59:40 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 07:59:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 07:59:40 --> Final output sent to browser
DEBUG - 2013-08-17 07:59:41 --> Total execution time: 1.4251
DEBUG - 2013-08-17 07:59:41 --> Config Class Initialized
DEBUG - 2013-08-17 07:59:41 --> Hooks Class Initialized
DEBUG - 2013-08-17 07:59:41 --> Utf8 Class Initialized
DEBUG - 2013-08-17 07:59:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 07:59:41 --> URI Class Initialized
DEBUG - 2013-08-17 07:59:41 --> Router Class Initialized
ERROR - 2013-08-17 07:59:41 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:00:28 --> Config Class Initialized
DEBUG - 2013-08-17 08:00:28 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:00:28 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:00:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:00:28 --> URI Class Initialized
DEBUG - 2013-08-17 08:00:28 --> Router Class Initialized
DEBUG - 2013-08-17 08:00:28 --> Output Class Initialized
DEBUG - 2013-08-17 08:00:28 --> Security Class Initialized
DEBUG - 2013-08-17 08:00:28 --> Input Class Initialized
DEBUG - 2013-08-17 08:00:28 --> XSS Filtering completed
DEBUG - 2013-08-17 08:00:28 --> XSS Filtering completed
DEBUG - 2013-08-17 08:00:28 --> XSS Filtering completed
DEBUG - 2013-08-17 08:00:29 --> XSS Filtering completed
DEBUG - 2013-08-17 08:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:00:29 --> Language Class Initialized
DEBUG - 2013-08-17 08:00:29 --> Loader Class Initialized
DEBUG - 2013-08-17 08:00:29 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:00:29 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:00:29 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:00:29 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:00:29 --> Session Class Initialized
DEBUG - 2013-08-17 08:00:29 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:00:29 --> Session routines successfully run
DEBUG - 2013-08-17 08:00:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:00:29 --> Controller Class Initialized
ERROR - 2013-08-17 08:00:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:00:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:00:29 --> Model Class Initialized
DEBUG - 2013-08-17 08:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:00:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:00:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:00:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:00:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:00:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:00:29 --> Pagination Class Initialized
ERROR - 2013-08-17 08:00:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\school\application\controllers\guru\kelas.php 53
DEBUG - 2013-08-17 08:01:48 --> Config Class Initialized
DEBUG - 2013-08-17 08:01:48 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:01:48 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:01:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:01:49 --> URI Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Router Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Output Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Security Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Input Class Initialized
DEBUG - 2013-08-17 08:01:49 --> XSS Filtering completed
DEBUG - 2013-08-17 08:01:49 --> XSS Filtering completed
DEBUG - 2013-08-17 08:01:49 --> XSS Filtering completed
DEBUG - 2013-08-17 08:01:49 --> XSS Filtering completed
DEBUG - 2013-08-17 08:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:01:49 --> Language Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Loader Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:01:49 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:01:49 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:01:49 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Session Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:01:49 --> Session routines successfully run
DEBUG - 2013-08-17 08:01:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Controller Class Initialized
ERROR - 2013-08-17 08:01:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:01:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:01:49 --> Model Class Initialized
DEBUG - 2013-08-17 08:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:01:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:01:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:01:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:01:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:01:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:01:50 --> Pagination Class Initialized
ERROR - 2013-08-17 08:01:50 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\school\application\controllers\guru\kelas.php 53
DEBUG - 2013-08-17 08:02:53 --> Config Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:02:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:02:54 --> URI Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Router Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Output Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Security Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Input Class Initialized
DEBUG - 2013-08-17 08:02:54 --> XSS Filtering completed
DEBUG - 2013-08-17 08:02:54 --> XSS Filtering completed
DEBUG - 2013-08-17 08:02:54 --> XSS Filtering completed
DEBUG - 2013-08-17 08:02:54 --> XSS Filtering completed
DEBUG - 2013-08-17 08:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:02:54 --> Language Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Loader Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:02:54 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:02:54 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:02:54 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Session Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:02:54 --> Session routines successfully run
DEBUG - 2013-08-17 08:02:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:02:54 --> Controller Class Initialized
ERROR - 2013-08-17 08:02:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:02:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:02:55 --> Model Class Initialized
DEBUG - 2013-08-17 08:02:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:02:55 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:02:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:02:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:02:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:02:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:02:55 --> Pagination Class Initialized
ERROR - 2013-08-17 08:02:55 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\school\application\controllers\guru\kelas.php 53
DEBUG - 2013-08-17 08:03:26 --> Config Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:03:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:03:26 --> URI Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Router Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Output Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Security Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Input Class Initialized
DEBUG - 2013-08-17 08:03:26 --> XSS Filtering completed
DEBUG - 2013-08-17 08:03:26 --> XSS Filtering completed
DEBUG - 2013-08-17 08:03:26 --> XSS Filtering completed
DEBUG - 2013-08-17 08:03:26 --> XSS Filtering completed
DEBUG - 2013-08-17 08:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:03:26 --> Language Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Loader Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:03:26 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:03:26 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:03:26 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Session Class Initialized
DEBUG - 2013-08-17 08:03:26 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:03:26 --> Session routines successfully run
DEBUG - 2013-08-17 08:03:26 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:03:27 --> Controller Class Initialized
ERROR - 2013-08-17 08:03:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:03:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:03:27 --> Model Class Initialized
DEBUG - 2013-08-17 08:03:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:03:27 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:03:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:03:27 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:03:27 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:03:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:03:27 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:04:01 --> Config Class Initialized
DEBUG - 2013-08-17 08:04:01 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:04:01 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:04:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:04:01 --> URI Class Initialized
DEBUG - 2013-08-17 08:04:01 --> Router Class Initialized
DEBUG - 2013-08-17 08:04:01 --> Output Class Initialized
DEBUG - 2013-08-17 08:04:01 --> Security Class Initialized
DEBUG - 2013-08-17 08:04:01 --> Input Class Initialized
DEBUG - 2013-08-17 08:04:01 --> XSS Filtering completed
DEBUG - 2013-08-17 08:04:01 --> XSS Filtering completed
DEBUG - 2013-08-17 08:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:04:01 --> Language Class Initialized
DEBUG - 2013-08-17 08:04:02 --> Loader Class Initialized
DEBUG - 2013-08-17 08:04:02 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:04:02 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:04:02 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:04:02 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:04:02 --> Session Class Initialized
DEBUG - 2013-08-17 08:04:02 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:04:02 --> Session routines successfully run
DEBUG - 2013-08-17 08:04:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:04:02 --> Controller Class Initialized
ERROR - 2013-08-17 08:04:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:04:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:04:02 --> Model Class Initialized
DEBUG - 2013-08-17 08:04:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:04:02 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:04:02 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:04:02 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:04:02 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:04:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:04:02 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:04:09 --> Config Class Initialized
DEBUG - 2013-08-17 08:04:09 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:04:09 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:04:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:04:09 --> URI Class Initialized
DEBUG - 2013-08-17 08:04:09 --> Router Class Initialized
DEBUG - 2013-08-17 08:04:09 --> Output Class Initialized
DEBUG - 2013-08-17 08:04:09 --> Security Class Initialized
DEBUG - 2013-08-17 08:04:10 --> Input Class Initialized
DEBUG - 2013-08-17 08:04:10 --> XSS Filtering completed
DEBUG - 2013-08-17 08:04:10 --> XSS Filtering completed
DEBUG - 2013-08-17 08:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:04:10 --> Language Class Initialized
DEBUG - 2013-08-17 08:04:10 --> Loader Class Initialized
DEBUG - 2013-08-17 08:04:10 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:04:10 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:04:10 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:04:10 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:04:10 --> Session Class Initialized
DEBUG - 2013-08-17 08:04:10 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:04:10 --> Session routines successfully run
DEBUG - 2013-08-17 08:04:10 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:04:10 --> Controller Class Initialized
ERROR - 2013-08-17 08:04:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:04:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:04:10 --> Model Class Initialized
DEBUG - 2013-08-17 08:04:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:04:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:04:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:04:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:04:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:04:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:04:10 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:04:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:04:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:04:11 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:04:11 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:04:11 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:04:11 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:04:11 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:04:11 --> Final output sent to browser
DEBUG - 2013-08-17 08:04:11 --> Total execution time: 1.4421
DEBUG - 2013-08-17 08:04:11 --> Config Class Initialized
DEBUG - 2013-08-17 08:04:11 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:04:11 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:04:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:04:11 --> URI Class Initialized
DEBUG - 2013-08-17 08:04:11 --> Router Class Initialized
ERROR - 2013-08-17 08:04:11 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:05:08 --> Config Class Initialized
DEBUG - 2013-08-17 08:05:08 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:05:08 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:05:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:05:08 --> URI Class Initialized
DEBUG - 2013-08-17 08:05:08 --> Router Class Initialized
DEBUG - 2013-08-17 08:05:08 --> Output Class Initialized
DEBUG - 2013-08-17 08:05:08 --> Security Class Initialized
DEBUG - 2013-08-17 08:05:08 --> Input Class Initialized
DEBUG - 2013-08-17 08:05:08 --> XSS Filtering completed
DEBUG - 2013-08-17 08:05:08 --> XSS Filtering completed
DEBUG - 2013-08-17 08:05:09 --> XSS Filtering completed
DEBUG - 2013-08-17 08:05:09 --> XSS Filtering completed
DEBUG - 2013-08-17 08:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:05:09 --> Language Class Initialized
DEBUG - 2013-08-17 08:05:09 --> Loader Class Initialized
DEBUG - 2013-08-17 08:05:09 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:05:09 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:05:09 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:05:09 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:05:09 --> Session Class Initialized
DEBUG - 2013-08-17 08:05:09 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:05:09 --> Session routines successfully run
DEBUG - 2013-08-17 08:05:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:05:09 --> Controller Class Initialized
ERROR - 2013-08-17 08:05:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:05:09 --> Model Class Initialized
DEBUG - 2013-08-17 08:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:05:09 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:05:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:05:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:05:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:05:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:05:09 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Config Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:05:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:05:25 --> URI Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Router Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Output Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Security Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Input Class Initialized
DEBUG - 2013-08-17 08:05:25 --> XSS Filtering completed
DEBUG - 2013-08-17 08:05:25 --> XSS Filtering completed
DEBUG - 2013-08-17 08:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:05:25 --> Language Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Loader Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:05:25 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:05:25 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:05:25 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Session Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:05:25 --> Session routines successfully run
DEBUG - 2013-08-17 08:05:25 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:05:25 --> Controller Class Initialized
ERROR - 2013-08-17 08:05:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:05:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:05:25 --> Model Class Initialized
DEBUG - 2013-08-17 08:05:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:05:26 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:05:26 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:05:26 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:05:26 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:05:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:05:26 --> Pagination Class Initialized
ERROR - 2013-08-17 08:05:26 --> Severity: Notice  --> Undefined index: column C:\xampp\htdocs\school\application\controllers\guru\kelas.php 50
DEBUG - 2013-08-17 08:05:59 --> Config Class Initialized
DEBUG - 2013-08-17 08:05:59 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:05:59 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:05:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:05:59 --> URI Class Initialized
DEBUG - 2013-08-17 08:05:59 --> Router Class Initialized
DEBUG - 2013-08-17 08:05:59 --> Output Class Initialized
DEBUG - 2013-08-17 08:05:59 --> Security Class Initialized
DEBUG - 2013-08-17 08:05:59 --> Input Class Initialized
DEBUG - 2013-08-17 08:05:59 --> XSS Filtering completed
DEBUG - 2013-08-17 08:06:00 --> XSS Filtering completed
DEBUG - 2013-08-17 08:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:06:00 --> Language Class Initialized
DEBUG - 2013-08-17 08:06:00 --> Loader Class Initialized
DEBUG - 2013-08-17 08:06:00 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:06:00 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:06:00 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:06:00 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:06:00 --> Session Class Initialized
DEBUG - 2013-08-17 08:06:00 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:06:00 --> Session routines successfully run
DEBUG - 2013-08-17 08:06:00 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:06:00 --> Controller Class Initialized
ERROR - 2013-08-17 08:06:00 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:06:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:06:00 --> Model Class Initialized
DEBUG - 2013-08-17 08:06:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:06:00 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:06:00 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:06:00 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:06:00 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:06:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:06:00 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Config Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:06:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:06:15 --> URI Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Router Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Output Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Security Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Input Class Initialized
DEBUG - 2013-08-17 08:06:15 --> XSS Filtering completed
DEBUG - 2013-08-17 08:06:15 --> XSS Filtering completed
DEBUG - 2013-08-17 08:06:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:06:15 --> Language Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Loader Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:06:15 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:06:15 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:06:15 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Session Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:06:15 --> Session routines successfully run
DEBUG - 2013-08-17 08:06:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:06:15 --> Controller Class Initialized
ERROR - 2013-08-17 08:06:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:06:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:06:16 --> Model Class Initialized
DEBUG - 2013-08-17 08:06:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:06:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:06:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:06:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:06:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:06:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:06:16 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:06:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:06:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:06:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:06:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:06:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:06:16 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:06:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:06:16 --> Final output sent to browser
DEBUG - 2013-08-17 08:06:16 --> Total execution time: 1.5361
DEBUG - 2013-08-17 08:06:17 --> Config Class Initialized
DEBUG - 2013-08-17 08:06:17 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:06:17 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:06:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:06:17 --> URI Class Initialized
DEBUG - 2013-08-17 08:06:17 --> Router Class Initialized
ERROR - 2013-08-17 08:06:17 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:06:23 --> Config Class Initialized
DEBUG - 2013-08-17 08:06:23 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:06:23 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:06:23 --> URI Class Initialized
DEBUG - 2013-08-17 08:06:23 --> Router Class Initialized
DEBUG - 2013-08-17 08:06:23 --> Output Class Initialized
DEBUG - 2013-08-17 08:06:23 --> Security Class Initialized
DEBUG - 2013-08-17 08:06:23 --> Input Class Initialized
DEBUG - 2013-08-17 08:06:24 --> XSS Filtering completed
DEBUG - 2013-08-17 08:06:24 --> XSS Filtering completed
DEBUG - 2013-08-17 08:06:24 --> XSS Filtering completed
DEBUG - 2013-08-17 08:06:24 --> XSS Filtering completed
DEBUG - 2013-08-17 08:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:06:24 --> Language Class Initialized
DEBUG - 2013-08-17 08:06:24 --> Loader Class Initialized
DEBUG - 2013-08-17 08:06:24 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:06:24 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:06:24 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:06:24 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:06:24 --> Session Class Initialized
DEBUG - 2013-08-17 08:06:24 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:06:24 --> Session routines successfully run
DEBUG - 2013-08-17 08:06:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:06:24 --> Controller Class Initialized
ERROR - 2013-08-17 08:06:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:06:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:06:24 --> Model Class Initialized
DEBUG - 2013-08-17 08:06:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:06:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:06:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:06:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:06:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:06:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:06:24 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:06:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:06:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:06:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:06:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:06:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:06:25 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:06:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:06:25 --> Final output sent to browser
DEBUG - 2013-08-17 08:06:25 --> Total execution time: 1.7601
DEBUG - 2013-08-17 08:06:25 --> Config Class Initialized
DEBUG - 2013-08-17 08:06:25 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:06:25 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:06:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:06:25 --> URI Class Initialized
DEBUG - 2013-08-17 08:06:25 --> Router Class Initialized
ERROR - 2013-08-17 08:06:25 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:10:18 --> Config Class Initialized
DEBUG - 2013-08-17 08:10:18 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:10:18 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:10:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:10:18 --> URI Class Initialized
DEBUG - 2013-08-17 08:10:18 --> Router Class Initialized
DEBUG - 2013-08-17 08:10:18 --> Output Class Initialized
DEBUG - 2013-08-17 08:10:18 --> Security Class Initialized
DEBUG - 2013-08-17 08:10:18 --> Input Class Initialized
DEBUG - 2013-08-17 08:10:18 --> XSS Filtering completed
DEBUG - 2013-08-17 08:10:18 --> XSS Filtering completed
DEBUG - 2013-08-17 08:10:18 --> XSS Filtering completed
DEBUG - 2013-08-17 08:10:19 --> XSS Filtering completed
DEBUG - 2013-08-17 08:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:10:19 --> Language Class Initialized
DEBUG - 2013-08-17 08:10:19 --> Loader Class Initialized
DEBUG - 2013-08-17 08:10:19 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:10:19 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:10:19 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:10:19 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:10:19 --> Session Class Initialized
DEBUG - 2013-08-17 08:10:19 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:10:19 --> Session routines successfully run
DEBUG - 2013-08-17 08:10:19 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:10:19 --> Controller Class Initialized
ERROR - 2013-08-17 08:10:19 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:10:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:10:19 --> Model Class Initialized
DEBUG - 2013-08-17 08:10:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:10:19 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:10:19 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:10:19 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:10:19 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:10:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:10:19 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:10:19 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:10:19 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:10:20 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:10:20 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:10:20 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:10:20 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:10:20 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:10:20 --> Final output sent to browser
DEBUG - 2013-08-17 08:10:20 --> Total execution time: 1.7701
DEBUG - 2013-08-17 08:10:20 --> Config Class Initialized
DEBUG - 2013-08-17 08:10:20 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:10:20 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:10:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:10:20 --> URI Class Initialized
DEBUG - 2013-08-17 08:10:20 --> Router Class Initialized
ERROR - 2013-08-17 08:10:20 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:12:02 --> Config Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:12:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:12:02 --> URI Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Router Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Output Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Security Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Input Class Initialized
DEBUG - 2013-08-17 08:12:02 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:02 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:12:02 --> Language Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Loader Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:12:02 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:12:02 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:12:02 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Session Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:12:02 --> Session routines successfully run
DEBUG - 2013-08-17 08:12:02 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:12:02 --> Controller Class Initialized
ERROR - 2013-08-17 08:12:02 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:12:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:12:02 --> Model Class Initialized
DEBUG - 2013-08-17 08:12:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:12:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:12:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:12:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:12:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:12:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:12:03 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:12:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:12:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:12:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:12:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:12:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:12:03 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:12:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:12:03 --> Final output sent to browser
DEBUG - 2013-08-17 08:12:03 --> Total execution time: 1.4721
DEBUG - 2013-08-17 08:12:03 --> Config Class Initialized
DEBUG - 2013-08-17 08:12:03 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:12:03 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:12:03 --> URI Class Initialized
DEBUG - 2013-08-17 08:12:03 --> Router Class Initialized
ERROR - 2013-08-17 08:12:04 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:12:07 --> Config Class Initialized
DEBUG - 2013-08-17 08:12:07 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:12:07 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:12:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:12:07 --> URI Class Initialized
DEBUG - 2013-08-17 08:12:07 --> Router Class Initialized
DEBUG - 2013-08-17 08:12:07 --> Output Class Initialized
DEBUG - 2013-08-17 08:12:07 --> Security Class Initialized
DEBUG - 2013-08-17 08:12:07 --> Input Class Initialized
DEBUG - 2013-08-17 08:12:07 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:08 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:08 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:08 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:12:08 --> Language Class Initialized
DEBUG - 2013-08-17 08:12:08 --> Loader Class Initialized
DEBUG - 2013-08-17 08:12:08 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:12:08 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:12:08 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:12:08 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:12:08 --> Session Class Initialized
DEBUG - 2013-08-17 08:12:08 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:12:08 --> Session routines successfully run
DEBUG - 2013-08-17 08:12:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:12:08 --> Controller Class Initialized
ERROR - 2013-08-17 08:12:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:12:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:12:08 --> Model Class Initialized
DEBUG - 2013-08-17 08:12:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:12:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:12:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:12:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:12:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:12:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:12:08 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:12:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:12:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:12:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:12:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:12:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:12:09 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:12:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:12:09 --> Final output sent to browser
DEBUG - 2013-08-17 08:12:09 --> Total execution time: 1.7111
DEBUG - 2013-08-17 08:12:09 --> Config Class Initialized
DEBUG - 2013-08-17 08:12:09 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:12:09 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:12:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:12:09 --> URI Class Initialized
DEBUG - 2013-08-17 08:12:10 --> Router Class Initialized
ERROR - 2013-08-17 08:12:10 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:12:13 --> Config Class Initialized
DEBUG - 2013-08-17 08:12:13 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:12:13 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:12:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:12:13 --> URI Class Initialized
DEBUG - 2013-08-17 08:12:13 --> Router Class Initialized
DEBUG - 2013-08-17 08:12:13 --> Output Class Initialized
DEBUG - 2013-08-17 08:12:13 --> Security Class Initialized
DEBUG - 2013-08-17 08:12:13 --> Input Class Initialized
DEBUG - 2013-08-17 08:12:13 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:13 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:13 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:13 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:12:13 --> Language Class Initialized
DEBUG - 2013-08-17 08:12:13 --> Loader Class Initialized
DEBUG - 2013-08-17 08:12:13 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:12:13 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:12:13 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:12:13 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:12:13 --> Session Class Initialized
DEBUG - 2013-08-17 08:12:14 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:12:14 --> Session routines successfully run
DEBUG - 2013-08-17 08:12:14 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:12:14 --> Controller Class Initialized
ERROR - 2013-08-17 08:12:14 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:12:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:12:14 --> Model Class Initialized
DEBUG - 2013-08-17 08:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:12:14 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:12:14 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:12:14 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:12:14 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:12:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:12:14 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:12:14 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:12:14 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:12:14 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:12:14 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:12:14 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:12:14 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:12:14 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:12:14 --> Final output sent to browser
DEBUG - 2013-08-17 08:12:14 --> Total execution time: 1.6491
DEBUG - 2013-08-17 08:12:15 --> Config Class Initialized
DEBUG - 2013-08-17 08:12:15 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:12:15 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:12:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:12:15 --> URI Class Initialized
DEBUG - 2013-08-17 08:12:15 --> Router Class Initialized
ERROR - 2013-08-17 08:12:15 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:12:21 --> Config Class Initialized
DEBUG - 2013-08-17 08:12:21 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:12:21 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:12:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:12:21 --> URI Class Initialized
DEBUG - 2013-08-17 08:12:21 --> Router Class Initialized
DEBUG - 2013-08-17 08:12:21 --> Output Class Initialized
DEBUG - 2013-08-17 08:12:21 --> Security Class Initialized
DEBUG - 2013-08-17 08:12:21 --> Input Class Initialized
DEBUG - 2013-08-17 08:12:21 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:21 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:21 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:21 --> XSS Filtering completed
DEBUG - 2013-08-17 08:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:12:21 --> Language Class Initialized
DEBUG - 2013-08-17 08:12:21 --> Loader Class Initialized
DEBUG - 2013-08-17 08:12:21 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:12:21 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:12:21 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:12:21 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:12:21 --> Session Class Initialized
DEBUG - 2013-08-17 08:12:22 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:12:22 --> Session routines successfully run
DEBUG - 2013-08-17 08:12:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:12:22 --> Controller Class Initialized
ERROR - 2013-08-17 08:12:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:12:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:12:22 --> Model Class Initialized
DEBUG - 2013-08-17 08:12:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:12:22 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:12:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:12:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:12:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:12:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:12:22 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:12:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:12:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:12:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:12:22 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:12:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:12:22 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:12:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:12:22 --> Final output sent to browser
DEBUG - 2013-08-17 08:12:22 --> Total execution time: 1.6421
DEBUG - 2013-08-17 08:12:23 --> Config Class Initialized
DEBUG - 2013-08-17 08:12:23 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:12:23 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:12:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:12:23 --> URI Class Initialized
DEBUG - 2013-08-17 08:12:23 --> Router Class Initialized
ERROR - 2013-08-17 08:12:23 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:18:22 --> Config Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:18:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:18:23 --> URI Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Router Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Output Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Security Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Input Class Initialized
DEBUG - 2013-08-17 08:18:23 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:23 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:23 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:23 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:18:23 --> Language Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Loader Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:18:23 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:18:23 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:18:23 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Session Class Initialized
DEBUG - 2013-08-17 08:18:23 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:18:23 --> Session garbage collection performed.
DEBUG - 2013-08-17 08:18:23 --> Session routines successfully run
DEBUG - 2013-08-17 08:18:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:18:24 --> Controller Class Initialized
ERROR - 2013-08-17 08:18:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:18:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:18:24 --> Model Class Initialized
DEBUG - 2013-08-17 08:18:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:18:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:18:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:18:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:18:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:18:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:18:24 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:18:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:18:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:18:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:18:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:18:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:18:24 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:18:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:18:24 --> Final output sent to browser
DEBUG - 2013-08-17 08:18:24 --> Total execution time: 1.8161
DEBUG - 2013-08-17 08:18:25 --> Config Class Initialized
DEBUG - 2013-08-17 08:18:25 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:18:25 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:18:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:18:25 --> URI Class Initialized
DEBUG - 2013-08-17 08:18:25 --> Router Class Initialized
ERROR - 2013-08-17 08:18:25 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:18:32 --> Config Class Initialized
DEBUG - 2013-08-17 08:18:32 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:18:32 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:18:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:18:32 --> URI Class Initialized
DEBUG - 2013-08-17 08:18:32 --> Router Class Initialized
DEBUG - 2013-08-17 08:18:32 --> Output Class Initialized
DEBUG - 2013-08-17 08:18:32 --> Security Class Initialized
DEBUG - 2013-08-17 08:18:32 --> Input Class Initialized
DEBUG - 2013-08-17 08:18:32 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:32 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:32 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:32 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:18:32 --> Language Class Initialized
DEBUG - 2013-08-17 08:18:32 --> Loader Class Initialized
DEBUG - 2013-08-17 08:18:32 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:18:33 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:18:33 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:18:33 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:18:33 --> Session Class Initialized
DEBUG - 2013-08-17 08:18:33 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:18:33 --> Session routines successfully run
DEBUG - 2013-08-17 08:18:33 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:18:33 --> Controller Class Initialized
ERROR - 2013-08-17 08:18:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:18:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:18:33 --> Model Class Initialized
DEBUG - 2013-08-17 08:18:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:18:33 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:18:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:18:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:18:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:18:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:18:33 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:18:33 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:18:33 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:18:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:18:33 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:18:33 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:18:34 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:18:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:18:34 --> Final output sent to browser
DEBUG - 2013-08-17 08:18:34 --> Total execution time: 1.7871
DEBUG - 2013-08-17 08:18:34 --> Config Class Initialized
DEBUG - 2013-08-17 08:18:34 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:18:34 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:18:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:18:34 --> URI Class Initialized
DEBUG - 2013-08-17 08:18:34 --> Router Class Initialized
ERROR - 2013-08-17 08:18:34 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:18:39 --> Config Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:18:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:18:39 --> URI Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Router Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Output Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Security Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Input Class Initialized
DEBUG - 2013-08-17 08:18:39 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:39 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:39 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:39 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:18:39 --> Language Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Loader Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:18:39 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:18:39 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:18:39 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Session Class Initialized
DEBUG - 2013-08-17 08:18:39 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:18:39 --> Session routines successfully run
DEBUG - 2013-08-17 08:18:39 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:18:40 --> Controller Class Initialized
ERROR - 2013-08-17 08:18:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:18:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:18:40 --> Model Class Initialized
DEBUG - 2013-08-17 08:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:18:40 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:18:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:18:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:18:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:18:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:18:40 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:18:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:18:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:18:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:18:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:18:40 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:18:40 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:18:40 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:18:40 --> Final output sent to browser
DEBUG - 2013-08-17 08:18:40 --> Total execution time: 1.7551
DEBUG - 2013-08-17 08:18:41 --> Config Class Initialized
DEBUG - 2013-08-17 08:18:41 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:18:41 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:18:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:18:41 --> URI Class Initialized
DEBUG - 2013-08-17 08:18:41 --> Router Class Initialized
ERROR - 2013-08-17 08:18:41 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:18:44 --> Config Class Initialized
DEBUG - 2013-08-17 08:18:44 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:18:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:18:45 --> URI Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Router Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Output Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Security Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Input Class Initialized
DEBUG - 2013-08-17 08:18:45 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:45 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:45 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:45 --> XSS Filtering completed
DEBUG - 2013-08-17 08:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:18:45 --> Language Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Loader Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:18:45 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:18:45 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:18:45 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Session Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:18:45 --> Session routines successfully run
DEBUG - 2013-08-17 08:18:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:18:45 --> Controller Class Initialized
ERROR - 2013-08-17 08:18:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:18:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:18:46 --> Model Class Initialized
DEBUG - 2013-08-17 08:18:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:18:46 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:18:46 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:18:46 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:18:46 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:18:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:18:46 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:18:46 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:18:46 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:18:46 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:18:46 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:18:46 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:18:46 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:18:46 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:18:46 --> Final output sent to browser
DEBUG - 2013-08-17 08:18:46 --> Total execution time: 1.7441
DEBUG - 2013-08-17 08:18:46 --> Config Class Initialized
DEBUG - 2013-08-17 08:18:47 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:18:47 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:18:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:18:47 --> URI Class Initialized
DEBUG - 2013-08-17 08:18:47 --> Router Class Initialized
ERROR - 2013-08-17 08:18:47 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:19:16 --> Config Class Initialized
DEBUG - 2013-08-17 08:19:16 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:19:16 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:19:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:19:16 --> URI Class Initialized
DEBUG - 2013-08-17 08:19:16 --> Router Class Initialized
DEBUG - 2013-08-17 08:19:16 --> Output Class Initialized
DEBUG - 2013-08-17 08:19:16 --> Security Class Initialized
DEBUG - 2013-08-17 08:19:17 --> Input Class Initialized
DEBUG - 2013-08-17 08:19:17 --> XSS Filtering completed
DEBUG - 2013-08-17 08:19:17 --> XSS Filtering completed
DEBUG - 2013-08-17 08:19:17 --> XSS Filtering completed
DEBUG - 2013-08-17 08:19:17 --> XSS Filtering completed
DEBUG - 2013-08-17 08:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:19:17 --> Language Class Initialized
DEBUG - 2013-08-17 08:19:17 --> Loader Class Initialized
DEBUG - 2013-08-17 08:19:17 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:19:17 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:19:17 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:19:17 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:19:17 --> Session Class Initialized
DEBUG - 2013-08-17 08:19:17 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:19:17 --> Session routines successfully run
DEBUG - 2013-08-17 08:19:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:19:17 --> Controller Class Initialized
ERROR - 2013-08-17 08:19:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:19:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:19:17 --> Model Class Initialized
DEBUG - 2013-08-17 08:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:19:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:19:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:19:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:19:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:19:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:19:18 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:19:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:19:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:19:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:19:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:19:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:19:18 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:19:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:19:18 --> Final output sent to browser
DEBUG - 2013-08-17 08:19:18 --> Total execution time: 1.7421
DEBUG - 2013-08-17 08:19:18 --> Config Class Initialized
DEBUG - 2013-08-17 08:19:18 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:19:18 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:19:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:19:19 --> URI Class Initialized
DEBUG - 2013-08-17 08:19:19 --> Router Class Initialized
ERROR - 2013-08-17 08:19:19 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:32:48 --> Config Class Initialized
DEBUG - 2013-08-17 08:32:48 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:32:48 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:32:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:32:48 --> URI Class Initialized
DEBUG - 2013-08-17 08:32:48 --> Router Class Initialized
DEBUG - 2013-08-17 08:32:48 --> Output Class Initialized
DEBUG - 2013-08-17 08:32:48 --> Security Class Initialized
DEBUG - 2013-08-17 08:32:48 --> Input Class Initialized
DEBUG - 2013-08-17 08:32:48 --> XSS Filtering completed
DEBUG - 2013-08-17 08:32:48 --> XSS Filtering completed
DEBUG - 2013-08-17 08:32:48 --> XSS Filtering completed
DEBUG - 2013-08-17 08:32:48 --> XSS Filtering completed
DEBUG - 2013-08-17 08:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:32:48 --> Language Class Initialized
DEBUG - 2013-08-17 08:32:48 --> Loader Class Initialized
DEBUG - 2013-08-17 08:32:48 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:32:48 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:32:48 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:32:48 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:32:49 --> Session Class Initialized
DEBUG - 2013-08-17 08:32:49 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:32:49 --> Session routines successfully run
DEBUG - 2013-08-17 08:32:49 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:32:49 --> Controller Class Initialized
ERROR - 2013-08-17 08:32:49 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:32:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:32:49 --> Model Class Initialized
DEBUG - 2013-08-17 08:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:32:49 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:32:49 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:32:49 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:32:49 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:32:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:32:49 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:32:49 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:32:49 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:32:49 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:32:49 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:32:49 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:32:49 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:32:49 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:32:50 --> Final output sent to browser
DEBUG - 2013-08-17 08:32:50 --> Total execution time: 1.7841
DEBUG - 2013-08-17 08:32:50 --> Config Class Initialized
DEBUG - 2013-08-17 08:32:50 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:32:50 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:32:50 --> URI Class Initialized
DEBUG - 2013-08-17 08:32:50 --> Router Class Initialized
ERROR - 2013-08-17 08:32:50 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:32:54 --> Config Class Initialized
DEBUG - 2013-08-17 08:32:54 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:32:54 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:32:55 --> URI Class Initialized
DEBUG - 2013-08-17 08:32:55 --> Router Class Initialized
DEBUG - 2013-08-17 08:32:55 --> Output Class Initialized
DEBUG - 2013-08-17 08:32:55 --> Security Class Initialized
DEBUG - 2013-08-17 08:32:55 --> Input Class Initialized
DEBUG - 2013-08-17 08:32:55 --> XSS Filtering completed
DEBUG - 2013-08-17 08:32:55 --> XSS Filtering completed
DEBUG - 2013-08-17 08:32:55 --> XSS Filtering completed
DEBUG - 2013-08-17 08:32:55 --> XSS Filtering completed
DEBUG - 2013-08-17 08:32:55 --> XSS Filtering completed
DEBUG - 2013-08-17 08:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:32:55 --> Language Class Initialized
DEBUG - 2013-08-17 08:32:55 --> Loader Class Initialized
DEBUG - 2013-08-17 08:32:55 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:32:55 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:32:55 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:32:55 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:32:55 --> Session Class Initialized
DEBUG - 2013-08-17 08:32:55 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:32:55 --> Session routines successfully run
DEBUG - 2013-08-17 08:32:55 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:32:55 --> Controller Class Initialized
ERROR - 2013-08-17 08:32:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:32:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:32:56 --> Model Class Initialized
DEBUG - 2013-08-17 08:32:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:32:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:32:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:32:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:32:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:32:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:32:56 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:32:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:32:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:32:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:32:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:32:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:32:56 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:32:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:32:56 --> Final output sent to browser
DEBUG - 2013-08-17 08:32:56 --> Total execution time: 1.8461
DEBUG - 2013-08-17 08:32:56 --> Config Class Initialized
DEBUG - 2013-08-17 08:32:56 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:32:57 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:32:57 --> URI Class Initialized
DEBUG - 2013-08-17 08:32:57 --> Router Class Initialized
ERROR - 2013-08-17 08:32:57 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:33:02 --> Config Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:33:02 --> URI Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Router Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Output Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Security Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Input Class Initialized
DEBUG - 2013-08-17 08:33:02 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:02 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:02 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:33:02 --> Language Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Loader Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:33:02 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:33:02 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:33:02 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Session Class Initialized
DEBUG - 2013-08-17 08:33:02 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:33:03 --> Session routines successfully run
DEBUG - 2013-08-17 08:33:03 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:33:03 --> Controller Class Initialized
ERROR - 2013-08-17 08:33:03 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:33:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:33:03 --> Model Class Initialized
DEBUG - 2013-08-17 08:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:33:03 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:33:03 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:33:03 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:33:03 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:33:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:33:03 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:33:03 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:33:03 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:33:03 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:33:03 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:33:03 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:33:03 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:33:03 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:33:03 --> Final output sent to browser
DEBUG - 2013-08-17 08:33:03 --> Total execution time: 1.7811
DEBUG - 2013-08-17 08:33:04 --> Config Class Initialized
DEBUG - 2013-08-17 08:33:04 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:33:04 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:33:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:33:04 --> URI Class Initialized
DEBUG - 2013-08-17 08:33:04 --> Router Class Initialized
ERROR - 2013-08-17 08:33:04 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:33:08 --> Config Class Initialized
DEBUG - 2013-08-17 08:33:08 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:33:08 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:33:08 --> URI Class Initialized
DEBUG - 2013-08-17 08:33:08 --> Router Class Initialized
DEBUG - 2013-08-17 08:33:08 --> Output Class Initialized
DEBUG - 2013-08-17 08:33:08 --> Security Class Initialized
DEBUG - 2013-08-17 08:33:09 --> Input Class Initialized
DEBUG - 2013-08-17 08:33:09 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:09 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:09 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:33:09 --> Language Class Initialized
DEBUG - 2013-08-17 08:33:09 --> Loader Class Initialized
DEBUG - 2013-08-17 08:33:09 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:33:09 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:33:09 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:33:09 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:33:09 --> Session Class Initialized
DEBUG - 2013-08-17 08:33:09 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:33:09 --> Session garbage collection performed.
DEBUG - 2013-08-17 08:33:09 --> Session routines successfully run
DEBUG - 2013-08-17 08:33:09 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:33:09 --> Controller Class Initialized
ERROR - 2013-08-17 08:33:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:33:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:33:09 --> Model Class Initialized
DEBUG - 2013-08-17 08:33:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:33:10 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:33:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:33:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:33:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:33:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:33:10 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:33:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:33:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:33:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:33:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:33:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:33:10 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:33:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:33:10 --> Final output sent to browser
DEBUG - 2013-08-17 08:33:10 --> Total execution time: 1.9621
DEBUG - 2013-08-17 08:33:10 --> Config Class Initialized
DEBUG - 2013-08-17 08:33:11 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:33:11 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:33:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:33:11 --> URI Class Initialized
DEBUG - 2013-08-17 08:33:11 --> Router Class Initialized
ERROR - 2013-08-17 08:33:11 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:33:28 --> Config Class Initialized
DEBUG - 2013-08-17 08:33:28 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:33:28 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:33:28 --> URI Class Initialized
DEBUG - 2013-08-17 08:33:28 --> Router Class Initialized
DEBUG - 2013-08-17 08:33:28 --> Output Class Initialized
DEBUG - 2013-08-17 08:33:28 --> Security Class Initialized
DEBUG - 2013-08-17 08:33:28 --> Input Class Initialized
DEBUG - 2013-08-17 08:33:28 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:28 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:28 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:33:29 --> Language Class Initialized
DEBUG - 2013-08-17 08:33:29 --> Loader Class Initialized
DEBUG - 2013-08-17 08:33:29 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:33:29 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:33:29 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:33:29 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:33:29 --> Session Class Initialized
DEBUG - 2013-08-17 08:33:29 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:33:29 --> Session routines successfully run
DEBUG - 2013-08-17 08:33:29 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:33:29 --> Controller Class Initialized
ERROR - 2013-08-17 08:33:29 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:33:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:33:29 --> Model Class Initialized
DEBUG - 2013-08-17 08:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:33:29 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:33:29 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:33:29 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:33:29 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:33:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:33:29 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:33:29 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:33:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:33:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:33:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:33:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:33:30 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:33:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:33:30 --> Final output sent to browser
DEBUG - 2013-08-17 08:33:30 --> Total execution time: 1.7661
DEBUG - 2013-08-17 08:33:30 --> Config Class Initialized
DEBUG - 2013-08-17 08:33:30 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:33:30 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:33:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:33:30 --> URI Class Initialized
DEBUG - 2013-08-17 08:33:30 --> Router Class Initialized
ERROR - 2013-08-17 08:33:30 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:33:40 --> Config Class Initialized
DEBUG - 2013-08-17 08:33:40 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:33:40 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:33:40 --> URI Class Initialized
DEBUG - 2013-08-17 08:33:40 --> Router Class Initialized
DEBUG - 2013-08-17 08:33:40 --> Output Class Initialized
DEBUG - 2013-08-17 08:33:40 --> Security Class Initialized
DEBUG - 2013-08-17 08:33:40 --> Input Class Initialized
DEBUG - 2013-08-17 08:33:40 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:40 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:40 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:40 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:40 --> XSS Filtering completed
DEBUG - 2013-08-17 08:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:33:41 --> Language Class Initialized
DEBUG - 2013-08-17 08:33:41 --> Loader Class Initialized
DEBUG - 2013-08-17 08:33:41 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:33:41 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:33:41 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:33:41 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:33:41 --> Session Class Initialized
DEBUG - 2013-08-17 08:33:41 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:33:41 --> Session routines successfully run
DEBUG - 2013-08-17 08:33:41 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:33:41 --> Controller Class Initialized
ERROR - 2013-08-17 08:33:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:33:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:33:41 --> Model Class Initialized
DEBUG - 2013-08-17 08:33:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:33:41 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:33:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:33:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:33:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:33:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:33:42 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:33:42 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:33:42 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:33:42 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:33:42 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:33:42 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:33:42 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:33:42 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:33:42 --> Final output sent to browser
DEBUG - 2013-08-17 08:33:42 --> Total execution time: 1.9711
DEBUG - 2013-08-17 08:33:42 --> Config Class Initialized
DEBUG - 2013-08-17 08:33:42 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:33:42 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:33:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:33:42 --> URI Class Initialized
DEBUG - 2013-08-17 08:33:42 --> Router Class Initialized
ERROR - 2013-08-17 08:33:42 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:41:37 --> Config Class Initialized
DEBUG - 2013-08-17 08:41:37 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:41:37 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:41:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:41:37 --> URI Class Initialized
DEBUG - 2013-08-17 08:41:37 --> Router Class Initialized
DEBUG - 2013-08-17 08:41:37 --> Output Class Initialized
DEBUG - 2013-08-17 08:41:37 --> Security Class Initialized
DEBUG - 2013-08-17 08:41:37 --> Input Class Initialized
DEBUG - 2013-08-17 08:41:38 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:38 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:38 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:38 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:38 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:41:38 --> Language Class Initialized
DEBUG - 2013-08-17 08:41:38 --> Loader Class Initialized
DEBUG - 2013-08-17 08:41:38 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:41:38 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:41:38 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:41:38 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:41:38 --> Session Class Initialized
DEBUG - 2013-08-17 08:41:38 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:41:38 --> Session routines successfully run
DEBUG - 2013-08-17 08:41:38 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:41:38 --> Controller Class Initialized
ERROR - 2013-08-17 08:41:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:41:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:41:38 --> Model Class Initialized
DEBUG - 2013-08-17 08:41:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:41:39 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:41:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:41:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:41:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:41:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:41:39 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:41:39 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:41:39 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:41:39 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:41:39 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:41:39 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:41:39 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:41:39 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:41:39 --> Final output sent to browser
DEBUG - 2013-08-17 08:41:39 --> Total execution time: 2.2081
DEBUG - 2013-08-17 08:41:39 --> Config Class Initialized
DEBUG - 2013-08-17 08:41:40 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:41:40 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:41:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:41:40 --> URI Class Initialized
DEBUG - 2013-08-17 08:41:40 --> Router Class Initialized
ERROR - 2013-08-17 08:41:40 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:41:51 --> Config Class Initialized
DEBUG - 2013-08-17 08:41:51 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:41:51 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:41:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:41:51 --> URI Class Initialized
DEBUG - 2013-08-17 08:41:51 --> Router Class Initialized
DEBUG - 2013-08-17 08:41:51 --> Output Class Initialized
DEBUG - 2013-08-17 08:41:51 --> Security Class Initialized
DEBUG - 2013-08-17 08:41:51 --> Input Class Initialized
DEBUG - 2013-08-17 08:41:51 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:51 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:51 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:51 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:51 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:41:51 --> Language Class Initialized
DEBUG - 2013-08-17 08:41:51 --> Loader Class Initialized
DEBUG - 2013-08-17 08:41:51 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:41:51 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:41:51 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:41:51 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:41:51 --> Session Class Initialized
DEBUG - 2013-08-17 08:41:52 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:41:52 --> Session routines successfully run
DEBUG - 2013-08-17 08:41:52 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:41:52 --> Controller Class Initialized
ERROR - 2013-08-17 08:41:52 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:41:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:41:52 --> Model Class Initialized
DEBUG - 2013-08-17 08:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:41:52 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:41:52 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:41:52 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:41:52 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:41:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:41:52 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:41:52 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:41:52 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:41:52 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:41:52 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:41:52 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:41:52 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:41:53 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:41:53 --> Final output sent to browser
DEBUG - 2013-08-17 08:41:53 --> Total execution time: 1.9741
DEBUG - 2013-08-17 08:41:53 --> Config Class Initialized
DEBUG - 2013-08-17 08:41:53 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:41:53 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:41:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:41:53 --> URI Class Initialized
DEBUG - 2013-08-17 08:41:53 --> Router Class Initialized
ERROR - 2013-08-17 08:41:53 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:41:58 --> Config Class Initialized
DEBUG - 2013-08-17 08:41:58 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:41:58 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:41:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:41:58 --> URI Class Initialized
DEBUG - 2013-08-17 08:41:58 --> Router Class Initialized
DEBUG - 2013-08-17 08:41:58 --> Output Class Initialized
DEBUG - 2013-08-17 08:41:58 --> Security Class Initialized
DEBUG - 2013-08-17 08:41:58 --> Input Class Initialized
DEBUG - 2013-08-17 08:41:58 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:58 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:58 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:58 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:58 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:58 --> XSS Filtering completed
DEBUG - 2013-08-17 08:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:41:59 --> Language Class Initialized
DEBUG - 2013-08-17 08:41:59 --> Loader Class Initialized
DEBUG - 2013-08-17 08:41:59 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:41:59 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:41:59 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:41:59 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:41:59 --> Session Class Initialized
DEBUG - 2013-08-17 08:41:59 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:41:59 --> Session routines successfully run
DEBUG - 2013-08-17 08:41:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:41:59 --> Controller Class Initialized
ERROR - 2013-08-17 08:41:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:41:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:41:59 --> Model Class Initialized
DEBUG - 2013-08-17 08:41:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:41:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:41:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:41:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:41:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:42:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:42:00 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:42:00 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:42:00 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:42:00 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:42:00 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:42:00 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:42:00 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:42:00 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:42:00 --> Final output sent to browser
DEBUG - 2013-08-17 08:42:00 --> Total execution time: 2.1371
DEBUG - 2013-08-17 08:42:00 --> Config Class Initialized
DEBUG - 2013-08-17 08:42:00 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:42:00 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:42:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:42:00 --> URI Class Initialized
DEBUG - 2013-08-17 08:42:00 --> Router Class Initialized
ERROR - 2013-08-17 08:42:00 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:42:06 --> Config Class Initialized
DEBUG - 2013-08-17 08:42:06 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:42:06 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:42:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:42:06 --> URI Class Initialized
DEBUG - 2013-08-17 08:42:06 --> Router Class Initialized
DEBUG - 2013-08-17 08:42:06 --> Output Class Initialized
DEBUG - 2013-08-17 08:42:06 --> Security Class Initialized
DEBUG - 2013-08-17 08:42:06 --> Input Class Initialized
DEBUG - 2013-08-17 08:42:06 --> XSS Filtering completed
DEBUG - 2013-08-17 08:42:06 --> XSS Filtering completed
DEBUG - 2013-08-17 08:42:06 --> XSS Filtering completed
DEBUG - 2013-08-17 08:42:06 --> XSS Filtering completed
DEBUG - 2013-08-17 08:42:06 --> XSS Filtering completed
DEBUG - 2013-08-17 08:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:42:06 --> Language Class Initialized
DEBUG - 2013-08-17 08:42:06 --> Loader Class Initialized
DEBUG - 2013-08-17 08:42:06 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:42:07 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:42:07 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:42:07 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:42:07 --> Session Class Initialized
DEBUG - 2013-08-17 08:42:07 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:42:07 --> Session routines successfully run
DEBUG - 2013-08-17 08:42:07 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:42:07 --> Controller Class Initialized
ERROR - 2013-08-17 08:42:07 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:42:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:42:07 --> Model Class Initialized
DEBUG - 2013-08-17 08:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:42:07 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:42:07 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:42:07 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:42:07 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:42:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:42:07 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:42:07 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:42:07 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:42:07 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:42:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:42:08 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:42:08 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:42:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:42:08 --> Final output sent to browser
DEBUG - 2013-08-17 08:42:08 --> Total execution time: 1.9361
DEBUG - 2013-08-17 08:42:08 --> Config Class Initialized
DEBUG - 2013-08-17 08:42:08 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:42:08 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:42:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:42:08 --> URI Class Initialized
DEBUG - 2013-08-17 08:42:08 --> Router Class Initialized
ERROR - 2013-08-17 08:42:08 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:44:14 --> Config Class Initialized
DEBUG - 2013-08-17 08:44:14 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:44:14 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:44:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:44:14 --> URI Class Initialized
DEBUG - 2013-08-17 08:44:14 --> Router Class Initialized
DEBUG - 2013-08-17 08:44:14 --> Output Class Initialized
DEBUG - 2013-08-17 08:44:14 --> Security Class Initialized
DEBUG - 2013-08-17 08:44:14 --> Input Class Initialized
DEBUG - 2013-08-17 08:44:14 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:14 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:14 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:14 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:14 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:44:15 --> Language Class Initialized
DEBUG - 2013-08-17 08:44:15 --> Loader Class Initialized
DEBUG - 2013-08-17 08:44:15 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:44:15 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:44:15 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:44:15 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:44:15 --> Session Class Initialized
DEBUG - 2013-08-17 08:44:15 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:44:15 --> Session routines successfully run
DEBUG - 2013-08-17 08:44:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:44:15 --> Controller Class Initialized
ERROR - 2013-08-17 08:44:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:44:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:44:15 --> Model Class Initialized
DEBUG - 2013-08-17 08:44:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:44:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:44:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:44:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:44:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:44:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:44:15 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:44:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:44:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:44:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:44:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:44:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:44:16 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:44:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:44:16 --> Final output sent to browser
DEBUG - 2013-08-17 08:44:16 --> Total execution time: 1.8921
DEBUG - 2013-08-17 08:44:16 --> Config Class Initialized
DEBUG - 2013-08-17 08:44:16 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:44:16 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:44:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:44:16 --> URI Class Initialized
DEBUG - 2013-08-17 08:44:16 --> Router Class Initialized
ERROR - 2013-08-17 08:44:16 --> 404 Page Not Found --> includes
DEBUG - 2013-08-17 08:44:21 --> Config Class Initialized
DEBUG - 2013-08-17 08:44:21 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:44:21 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:44:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:44:22 --> URI Class Initialized
DEBUG - 2013-08-17 08:44:22 --> Router Class Initialized
DEBUG - 2013-08-17 08:44:22 --> Output Class Initialized
DEBUG - 2013-08-17 08:44:22 --> Security Class Initialized
DEBUG - 2013-08-17 08:44:22 --> Input Class Initialized
DEBUG - 2013-08-17 08:44:22 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:22 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:22 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:22 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:22 --> XSS Filtering completed
DEBUG - 2013-08-17 08:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-17 08:44:22 --> Language Class Initialized
DEBUG - 2013-08-17 08:44:22 --> Loader Class Initialized
DEBUG - 2013-08-17 08:44:22 --> Helper loaded: url_helper
DEBUG - 2013-08-17 08:44:22 --> Helper loaded: file_helper
DEBUG - 2013-08-17 08:44:22 --> Helper loaded: form_helper
DEBUG - 2013-08-17 08:44:22 --> Database Driver Class Initialized
DEBUG - 2013-08-17 08:44:22 --> Session Class Initialized
DEBUG - 2013-08-17 08:44:22 --> Helper loaded: string_helper
DEBUG - 2013-08-17 08:44:22 --> Session routines successfully run
DEBUG - 2013-08-17 08:44:22 --> XML-RPC Class Initialized
DEBUG - 2013-08-17 08:44:23 --> Controller Class Initialized
ERROR - 2013-08-17 08:44:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:44:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:44:23 --> Model Class Initialized
DEBUG - 2013-08-17 08:44:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-17 08:44:23 --> Helper loaded: cookie_helper
DEBUG - 2013-08-17 08:44:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-17 08:44:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-17 08:44:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-17 08:44:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-17 08:44:23 --> Pagination Class Initialized
DEBUG - 2013-08-17 08:44:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-17 08:44:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-17 08:44:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-17 08:44:23 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-17 08:44:23 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-17 08:44:23 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-17 08:44:23 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-17 08:44:23 --> Final output sent to browser
DEBUG - 2013-08-17 08:44:23 --> Total execution time: 2.0841
DEBUG - 2013-08-17 08:44:24 --> Config Class Initialized
DEBUG - 2013-08-17 08:44:24 --> Hooks Class Initialized
DEBUG - 2013-08-17 08:44:24 --> Utf8 Class Initialized
DEBUG - 2013-08-17 08:44:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-17 08:44:24 --> URI Class Initialized
DEBUG - 2013-08-17 08:44:24 --> Router Class Initialized
ERROR - 2013-08-17 08:44:24 --> 404 Page Not Found --> includes
