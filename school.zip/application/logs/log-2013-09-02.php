<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-02 04:58:18 --> Config Class Initialized
DEBUG - 2013-09-02 04:58:18 --> Hooks Class Initialized
DEBUG - 2013-09-02 04:58:18 --> Utf8 Class Initialized
DEBUG - 2013-09-02 04:58:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 04:58:18 --> URI Class Initialized
DEBUG - 2013-09-02 04:58:18 --> Router Class Initialized
DEBUG - 2013-09-02 04:58:18 --> Output Class Initialized
DEBUG - 2013-09-02 04:58:18 --> Security Class Initialized
DEBUG - 2013-09-02 04:58:18 --> Input Class Initialized
DEBUG - 2013-09-02 04:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 04:58:18 --> Language Class Initialized
DEBUG - 2013-09-02 04:58:18 --> Loader Class Initialized
DEBUG - 2013-09-02 04:58:18 --> Helper loaded: url_helper
DEBUG - 2013-09-02 04:58:18 --> Helper loaded: file_helper
DEBUG - 2013-09-02 04:58:18 --> Helper loaded: form_helper
DEBUG - 2013-09-02 04:58:18 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 04:58:18 --> Helper loaded: application_helper
DEBUG - 2013-09-02 04:58:19 --> Database Driver Class Initialized
DEBUG - 2013-09-02 04:58:19 --> Session Class Initialized
DEBUG - 2013-09-02 04:58:19 --> Helper loaded: string_helper
DEBUG - 2013-09-02 04:58:19 --> A session cookie was not found.
DEBUG - 2013-09-02 04:58:20 --> Session garbage collection performed.
DEBUG - 2013-09-02 04:58:20 --> Session routines successfully run
DEBUG - 2013-09-02 04:58:20 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 04:58:20 --> Controller Class Initialized
ERROR - 2013-09-02 04:58:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:21 --> Model Class Initialized
DEBUG - 2013-09-02 04:58:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 04:58:21 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 04:58:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 04:58:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 04:58:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:21 --> Config Class Initialized
DEBUG - 2013-09-02 04:58:21 --> Hooks Class Initialized
DEBUG - 2013-09-02 04:58:21 --> Utf8 Class Initialized
DEBUG - 2013-09-02 04:58:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 04:58:21 --> URI Class Initialized
DEBUG - 2013-09-02 04:58:21 --> Router Class Initialized
DEBUG - 2013-09-02 04:58:21 --> Output Class Initialized
DEBUG - 2013-09-02 04:58:21 --> Security Class Initialized
DEBUG - 2013-09-02 04:58:21 --> Input Class Initialized
DEBUG - 2013-09-02 04:58:21 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 04:58:21 --> Language Class Initialized
DEBUG - 2013-09-02 04:58:22 --> Loader Class Initialized
DEBUG - 2013-09-02 04:58:22 --> Helper loaded: url_helper
DEBUG - 2013-09-02 04:58:22 --> Helper loaded: file_helper
DEBUG - 2013-09-02 04:58:22 --> Helper loaded: form_helper
DEBUG - 2013-09-02 04:58:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 04:58:22 --> Helper loaded: application_helper
DEBUG - 2013-09-02 04:58:22 --> Database Driver Class Initialized
DEBUG - 2013-09-02 04:58:22 --> Session Class Initialized
DEBUG - 2013-09-02 04:58:22 --> Helper loaded: string_helper
DEBUG - 2013-09-02 04:58:22 --> Session routines successfully run
DEBUG - 2013-09-02 04:58:22 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 04:58:22 --> Controller Class Initialized
ERROR - 2013-09-02 04:58:22 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:22 --> Model Class Initialized
DEBUG - 2013-09-02 04:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 04:58:22 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 04:58:22 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 04:58:22 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 04:58:22 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:22 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-02 04:58:22 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-02 04:58:22 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-02 04:58:22 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-02 04:58:22 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-02 04:58:22 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-02 04:58:22 --> Final output sent to browser
DEBUG - 2013-09-02 04:58:22 --> Total execution time: 0.8981
DEBUG - 2013-09-02 04:58:23 --> Config Class Initialized
DEBUG - 2013-09-02 04:58:23 --> Hooks Class Initialized
DEBUG - 2013-09-02 04:58:23 --> Utf8 Class Initialized
DEBUG - 2013-09-02 04:58:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 04:58:23 --> URI Class Initialized
DEBUG - 2013-09-02 04:58:23 --> Router Class Initialized
ERROR - 2013-09-02 04:58:23 --> 404 Page Not Found --> css
DEBUG - 2013-09-02 04:58:31 --> Config Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Hooks Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Utf8 Class Initialized
DEBUG - 2013-09-02 04:58:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 04:58:31 --> URI Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Router Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Output Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Security Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Input Class Initialized
DEBUG - 2013-09-02 04:58:31 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:31 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:31 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:31 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 04:58:31 --> Language Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Loader Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Helper loaded: url_helper
DEBUG - 2013-09-02 04:58:31 --> Helper loaded: file_helper
DEBUG - 2013-09-02 04:58:31 --> Helper loaded: form_helper
DEBUG - 2013-09-02 04:58:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 04:58:31 --> Helper loaded: application_helper
DEBUG - 2013-09-02 04:58:31 --> Database Driver Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Session Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Helper loaded: string_helper
DEBUG - 2013-09-02 04:58:31 --> Session routines successfully run
DEBUG - 2013-09-02 04:58:31 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Controller Class Initialized
ERROR - 2013-09-02 04:58:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:31 --> Model Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 04:58:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 04:58:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 04:58:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 04:58:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:31 --> Model Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Form Validation Class Initialized
DEBUG - 2013-09-02 04:58:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-02 04:58:33 --> Config Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Hooks Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Utf8 Class Initialized
DEBUG - 2013-09-02 04:58:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 04:58:33 --> URI Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Router Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Output Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Security Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Input Class Initialized
DEBUG - 2013-09-02 04:58:33 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:33 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 04:58:33 --> Language Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Loader Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: url_helper
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: file_helper
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: form_helper
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: application_helper
DEBUG - 2013-09-02 04:58:33 --> Database Driver Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Session Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: string_helper
DEBUG - 2013-09-02 04:58:33 --> Session routines successfully run
DEBUG - 2013-09-02 04:58:33 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Controller Class Initialized
ERROR - 2013-09-02 04:58:33 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:33 --> Model Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 04:58:33 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 04:58:33 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 04:58:33 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:33 --> Config Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Hooks Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Utf8 Class Initialized
DEBUG - 2013-09-02 04:58:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 04:58:33 --> URI Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Router Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Output Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Security Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Input Class Initialized
DEBUG - 2013-09-02 04:58:33 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:33 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 04:58:33 --> Language Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Loader Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: url_helper
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: file_helper
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: form_helper
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: application_helper
DEBUG - 2013-09-02 04:58:33 --> Database Driver Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Session Class Initialized
DEBUG - 2013-09-02 04:58:33 --> Helper loaded: string_helper
DEBUG - 2013-09-02 04:58:34 --> Session routines successfully run
DEBUG - 2013-09-02 04:58:34 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 04:58:34 --> Controller Class Initialized
ERROR - 2013-09-02 04:58:34 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:34 --> Model Class Initialized
DEBUG - 2013-09-02 04:58:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 04:58:34 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 04:58:34 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 04:58:34 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 04:58:34 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:34 --> Model Class Initialized
DEBUG - 2013-09-02 04:58:34 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-02 04:58:34 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-02 04:58:34 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-02 04:58:34 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-02 04:58:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-02 04:58:34 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-02 04:58:34 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-02 04:58:34 --> File loaded: application/views/home.php
DEBUG - 2013-09-02 04:58:34 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-02 04:58:34 --> Final output sent to browser
DEBUG - 2013-09-02 04:58:34 --> Total execution time: 0.9261
DEBUG - 2013-09-02 04:58:34 --> Config Class Initialized
DEBUG - 2013-09-02 04:58:34 --> Hooks Class Initialized
DEBUG - 2013-09-02 04:58:34 --> Utf8 Class Initialized
DEBUG - 2013-09-02 04:58:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 04:58:34 --> URI Class Initialized
DEBUG - 2013-09-02 04:58:34 --> Router Class Initialized
ERROR - 2013-09-02 04:58:34 --> 404 Page Not Found --> css
DEBUG - 2013-09-02 04:58:41 --> Config Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Hooks Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Utf8 Class Initialized
DEBUG - 2013-09-02 04:58:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 04:58:41 --> URI Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Router Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Output Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Security Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Input Class Initialized
DEBUG - 2013-09-02 04:58:41 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:41 --> XSS Filtering completed
DEBUG - 2013-09-02 04:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 04:58:41 --> Language Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Loader Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Helper loaded: url_helper
DEBUG - 2013-09-02 04:58:41 --> Helper loaded: file_helper
DEBUG - 2013-09-02 04:58:41 --> Helper loaded: form_helper
DEBUG - 2013-09-02 04:58:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 04:58:41 --> Helper loaded: application_helper
DEBUG - 2013-09-02 04:58:41 --> Database Driver Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Session Class Initialized
DEBUG - 2013-09-02 04:58:41 --> Helper loaded: string_helper
DEBUG - 2013-09-02 04:58:41 --> Session routines successfully run
DEBUG - 2013-09-02 04:58:42 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 04:58:42 --> Controller Class Initialized
ERROR - 2013-09-02 04:58:42 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:42 --> Model Class Initialized
DEBUG - 2013-09-02 04:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 04:58:42 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 04:58:42 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 04:58:42 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 04:58:42 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 04:58:42 --> Model Class Initialized
DEBUG - 2013-09-02 04:58:42 --> Pagination Class Initialized
ERROR - 2013-09-02 04:58:42 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 04:58:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:02:30 --> Config Class Initialized
DEBUG - 2013-09-02 05:02:30 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:02:30 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:02:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:02:30 --> URI Class Initialized
DEBUG - 2013-09-02 05:02:30 --> Router Class Initialized
DEBUG - 2013-09-02 05:02:30 --> Output Class Initialized
DEBUG - 2013-09-02 05:02:30 --> Security Class Initialized
DEBUG - 2013-09-02 05:02:30 --> Input Class Initialized
DEBUG - 2013-09-02 05:02:30 --> XSS Filtering completed
DEBUG - 2013-09-02 05:02:30 --> XSS Filtering completed
DEBUG - 2013-09-02 05:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:02:30 --> Language Class Initialized
DEBUG - 2013-09-02 05:02:30 --> Loader Class Initialized
DEBUG - 2013-09-02 05:02:30 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:02:30 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:02:30 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:02:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:02:30 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:02:30 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:02:31 --> Session Class Initialized
DEBUG - 2013-09-02 05:02:31 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:02:31 --> Session routines successfully run
DEBUG - 2013-09-02 05:02:31 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:02:31 --> Controller Class Initialized
ERROR - 2013-09-02 05:02:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:02:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:02:31 --> Model Class Initialized
DEBUG - 2013-09-02 05:02:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:02:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:02:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:02:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:02:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:02:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:02:31 --> Model Class Initialized
DEBUG - 2013-09-02 05:02:31 --> Pagination Class Initialized
ERROR - 2013-09-02 05:02:31 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:02:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:02:31 --> Severity: Notice  --> Use of undefined constant doc_path - assumed 'doc_path' C:\xampp\htdocs\school\application\controllers\guru\absensis.php 35
DEBUG - 2013-09-02 05:02:39 --> Config Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:02:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:02:39 --> URI Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Router Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Output Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Security Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Input Class Initialized
DEBUG - 2013-09-02 05:02:39 --> XSS Filtering completed
DEBUG - 2013-09-02 05:02:39 --> XSS Filtering completed
DEBUG - 2013-09-02 05:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:02:39 --> Language Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Loader Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:02:39 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:02:39 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:02:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:02:39 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:02:39 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Session Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:02:39 --> Session routines successfully run
DEBUG - 2013-09-02 05:02:39 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Controller Class Initialized
ERROR - 2013-09-02 05:02:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:02:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:02:39 --> Model Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:02:39 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:02:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:02:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:02:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:02:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:02:39 --> Model Class Initialized
DEBUG - 2013-09-02 05:02:39 --> Pagination Class Initialized
ERROR - 2013-09-02 05:02:39 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:02:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:02:39 --> Severity: Notice  --> Undefined variable: doc_path C:\xampp\htdocs\school\application\controllers\guru\absensis.php 35
DEBUG - 2013-09-02 05:03:20 --> Config Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:03:20 --> URI Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Router Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Output Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Security Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Input Class Initialized
DEBUG - 2013-09-02 05:03:20 --> XSS Filtering completed
DEBUG - 2013-09-02 05:03:20 --> XSS Filtering completed
DEBUG - 2013-09-02 05:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:03:20 --> Language Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Loader Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:03:20 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:03:20 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:03:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:03:20 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:03:20 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Session Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:03:20 --> Session routines successfully run
DEBUG - 2013-09-02 05:03:20 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Controller Class Initialized
ERROR - 2013-09-02 05:03:20 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:03:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:03:20 --> Model Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:03:20 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:03:20 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:03:20 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:03:20 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:03:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:03:20 --> Model Class Initialized
DEBUG - 2013-09-02 05:03:20 --> Pagination Class Initialized
ERROR - 2013-09-02 05:03:20 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:03:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:03:20 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\school\application\controllers\guru\absensis.php 35
DEBUG - 2013-09-02 05:03:44 --> Config Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:03:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:03:44 --> URI Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Router Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Output Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Security Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Input Class Initialized
DEBUG - 2013-09-02 05:03:44 --> XSS Filtering completed
DEBUG - 2013-09-02 05:03:44 --> XSS Filtering completed
DEBUG - 2013-09-02 05:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:03:44 --> Language Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Loader Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:03:44 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:03:44 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:03:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:03:44 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:03:44 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Session Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:03:44 --> Session routines successfully run
DEBUG - 2013-09-02 05:03:44 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Controller Class Initialized
ERROR - 2013-09-02 05:03:44 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:03:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:03:44 --> Model Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:03:44 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:03:44 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:03:44 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:03:44 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:03:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:03:44 --> Model Class Initialized
DEBUG - 2013-09-02 05:03:44 --> Pagination Class Initialized
ERROR - 2013-09-02 05:03:44 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:03:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:03:44 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\school\application\controllers\guru\absensis.php 35
DEBUG - 2013-09-02 05:08:05 --> Config Class Initialized
DEBUG - 2013-09-02 05:08:05 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:08:05 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:08:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:08:05 --> URI Class Initialized
DEBUG - 2013-09-02 05:08:06 --> Router Class Initialized
DEBUG - 2013-09-02 05:08:07 --> Output Class Initialized
DEBUG - 2013-09-02 05:08:07 --> Security Class Initialized
DEBUG - 2013-09-02 05:08:08 --> Input Class Initialized
DEBUG - 2013-09-02 05:08:08 --> XSS Filtering completed
DEBUG - 2013-09-02 05:08:08 --> XSS Filtering completed
DEBUG - 2013-09-02 05:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:08:09 --> Language Class Initialized
DEBUG - 2013-09-02 05:08:10 --> Loader Class Initialized
DEBUG - 2013-09-02 05:08:13 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:08:13 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:08:14 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:08:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:08:16 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:08:27 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:08:27 --> Session Class Initialized
DEBUG - 2013-09-02 05:08:27 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:08:27 --> Session routines successfully run
DEBUG - 2013-09-02 05:08:27 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:08:27 --> Controller Class Initialized
ERROR - 2013-09-02 05:08:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:08:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:08:29 --> Model Class Initialized
DEBUG - 2013-09-02 05:08:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:08:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:08:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:08:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:08:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:08:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:08:33 --> Model Class Initialized
DEBUG - 2013-09-02 05:08:34 --> Pagination Class Initialized
ERROR - 2013-09-02 05:08:34 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:08:34 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\school\application\controllers\guru\absensis.php 35
DEBUG - 2013-09-02 05:14:52 --> Config Class Initialized
DEBUG - 2013-09-02 05:14:52 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:14:54 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:14:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:14:55 --> URI Class Initialized
DEBUG - 2013-09-02 05:14:56 --> Router Class Initialized
DEBUG - 2013-09-02 05:15:01 --> Output Class Initialized
DEBUG - 2013-09-02 05:15:04 --> Security Class Initialized
DEBUG - 2013-09-02 05:15:06 --> Input Class Initialized
DEBUG - 2013-09-02 05:15:06 --> XSS Filtering completed
DEBUG - 2013-09-02 05:15:06 --> XSS Filtering completed
DEBUG - 2013-09-02 05:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:15:07 --> Language Class Initialized
DEBUG - 2013-09-02 05:15:10 --> Loader Class Initialized
DEBUG - 2013-09-02 05:15:15 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:15:19 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:15:19 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:15:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:15:22 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:15:29 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:15:31 --> Session Class Initialized
DEBUG - 2013-09-02 05:15:32 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:15:32 --> Session routines successfully run
DEBUG - 2013-09-02 05:15:34 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:15:34 --> Controller Class Initialized
ERROR - 2013-09-02 05:15:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:15:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:15:40 --> Model Class Initialized
DEBUG - 2013-09-02 05:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:15:43 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:15:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:15:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:15:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:15:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:15:47 --> Model Class Initialized
DEBUG - 2013-09-02 05:15:52 --> Pagination Class Initialized
ERROR - 2013-09-02 05:15:53 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:15:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:18:05 --> Config Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:18:05 --> URI Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Router Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Output Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Security Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Input Class Initialized
DEBUG - 2013-09-02 05:18:05 --> XSS Filtering completed
DEBUG - 2013-09-02 05:18:05 --> XSS Filtering completed
DEBUG - 2013-09-02 05:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:18:05 --> Language Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Loader Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:18:05 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:18:05 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:18:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:18:05 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:18:05 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Session Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:18:05 --> Session routines successfully run
DEBUG - 2013-09-02 05:18:05 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:18:05 --> Controller Class Initialized
ERROR - 2013-09-02 05:18:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:18:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:18:06 --> Model Class Initialized
DEBUG - 2013-09-02 05:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:18:06 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:18:06 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:18:06 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:18:06 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:18:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:18:06 --> Model Class Initialized
DEBUG - 2013-09-02 05:18:06 --> Pagination Class Initialized
ERROR - 2013-09-02 05:18:06 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:18:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:18:25 --> Config Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:18:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:18:25 --> URI Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Router Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Output Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Security Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Input Class Initialized
DEBUG - 2013-09-02 05:18:25 --> XSS Filtering completed
DEBUG - 2013-09-02 05:18:25 --> XSS Filtering completed
DEBUG - 2013-09-02 05:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:18:25 --> Language Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Loader Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:18:25 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:18:25 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:18:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:18:25 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:18:25 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Session Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:18:25 --> Session routines successfully run
DEBUG - 2013-09-02 05:18:25 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Controller Class Initialized
ERROR - 2013-09-02 05:18:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:18:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:18:25 --> Model Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:18:25 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:18:25 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:18:25 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:18:25 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:18:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:18:25 --> Model Class Initialized
DEBUG - 2013-09-02 05:18:25 --> Pagination Class Initialized
ERROR - 2013-09-02 05:18:25 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:18:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:19:27 --> Config Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:19:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:19:27 --> URI Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Router Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Output Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Security Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Input Class Initialized
DEBUG - 2013-09-02 05:19:27 --> XSS Filtering completed
DEBUG - 2013-09-02 05:19:27 --> XSS Filtering completed
DEBUG - 2013-09-02 05:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:19:27 --> Language Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Loader Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:19:27 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:19:27 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:19:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:19:27 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:19:27 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Session Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:19:27 --> Session routines successfully run
DEBUG - 2013-09-02 05:19:27 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Controller Class Initialized
ERROR - 2013-09-02 05:19:27 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:19:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:19:27 --> Model Class Initialized
DEBUG - 2013-09-02 05:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:19:27 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:19:27 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:19:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:19:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:19:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:19:28 --> Model Class Initialized
DEBUG - 2013-09-02 05:19:28 --> Pagination Class Initialized
ERROR - 2013-09-02 05:19:28 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:19:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:19:49 --> Config Class Initialized
DEBUG - 2013-09-02 05:19:49 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:19:49 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:19:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:19:49 --> URI Class Initialized
DEBUG - 2013-09-02 05:19:49 --> Router Class Initialized
DEBUG - 2013-09-02 05:19:49 --> Output Class Initialized
DEBUG - 2013-09-02 05:19:49 --> Security Class Initialized
DEBUG - 2013-09-02 05:19:49 --> Input Class Initialized
DEBUG - 2013-09-02 05:19:49 --> XSS Filtering completed
DEBUG - 2013-09-02 05:19:49 --> XSS Filtering completed
DEBUG - 2013-09-02 05:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:19:49 --> Language Class Initialized
DEBUG - 2013-09-02 05:19:49 --> Loader Class Initialized
DEBUG - 2013-09-02 05:19:49 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:19:49 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:19:49 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:19:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:19:49 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:19:50 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:19:50 --> Session Class Initialized
DEBUG - 2013-09-02 05:19:50 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:19:50 --> Session routines successfully run
DEBUG - 2013-09-02 05:19:50 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:19:50 --> Controller Class Initialized
ERROR - 2013-09-02 05:19:50 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:19:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:19:50 --> Model Class Initialized
DEBUG - 2013-09-02 05:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:19:50 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:19:50 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:19:50 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:19:50 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:19:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:19:50 --> Model Class Initialized
DEBUG - 2013-09-02 05:19:50 --> Pagination Class Initialized
ERROR - 2013-09-02 05:19:50 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:19:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:25:36 --> Config Class Initialized
DEBUG - 2013-09-02 05:25:36 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:25:36 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:25:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:25:37 --> URI Class Initialized
DEBUG - 2013-09-02 05:25:37 --> Router Class Initialized
DEBUG - 2013-09-02 05:25:37 --> Output Class Initialized
DEBUG - 2013-09-02 05:25:38 --> Security Class Initialized
DEBUG - 2013-09-02 05:25:38 --> Input Class Initialized
DEBUG - 2013-09-02 05:25:38 --> XSS Filtering completed
DEBUG - 2013-09-02 05:25:38 --> XSS Filtering completed
DEBUG - 2013-09-02 05:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:25:38 --> Language Class Initialized
DEBUG - 2013-09-02 05:25:38 --> Loader Class Initialized
DEBUG - 2013-09-02 05:25:38 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:25:38 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:25:39 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:25:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:25:39 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:25:39 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:25:39 --> Session Class Initialized
DEBUG - 2013-09-02 05:25:39 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:25:39 --> Session routines successfully run
DEBUG - 2013-09-02 05:25:39 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:25:39 --> Controller Class Initialized
ERROR - 2013-09-02 05:25:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:25:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:25:40 --> Model Class Initialized
DEBUG - 2013-09-02 05:25:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:25:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:25:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:25:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:25:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:25:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:25:42 --> Model Class Initialized
DEBUG - 2013-09-02 05:25:43 --> Pagination Class Initialized
ERROR - 2013-09-02 05:25:44 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:25:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:27:13 --> Config Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:27:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:27:13 --> URI Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Router Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Output Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Security Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Input Class Initialized
DEBUG - 2013-09-02 05:27:13 --> XSS Filtering completed
DEBUG - 2013-09-02 05:27:13 --> XSS Filtering completed
DEBUG - 2013-09-02 05:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:27:13 --> Language Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Loader Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:27:13 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:27:13 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:27:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:27:13 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:27:13 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Session Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:27:13 --> Session routines successfully run
DEBUG - 2013-09-02 05:27:13 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Controller Class Initialized
ERROR - 2013-09-02 05:27:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:27:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:27:13 --> Model Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:27:13 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:27:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:27:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:27:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:27:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:27:13 --> Model Class Initialized
DEBUG - 2013-09-02 05:27:13 --> Pagination Class Initialized
ERROR - 2013-09-02 05:27:13 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:27:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:29:31 --> Config Class Initialized
DEBUG - 2013-09-02 05:29:31 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:29:31 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:29:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:29:31 --> URI Class Initialized
DEBUG - 2013-09-02 05:29:31 --> Router Class Initialized
DEBUG - 2013-09-02 05:29:31 --> Output Class Initialized
DEBUG - 2013-09-02 05:29:31 --> Security Class Initialized
DEBUG - 2013-09-02 05:29:31 --> Input Class Initialized
DEBUG - 2013-09-02 05:29:31 --> XSS Filtering completed
DEBUG - 2013-09-02 05:29:31 --> XSS Filtering completed
DEBUG - 2013-09-02 05:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:29:31 --> Language Class Initialized
DEBUG - 2013-09-02 05:29:31 --> Loader Class Initialized
DEBUG - 2013-09-02 05:29:31 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:29:31 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:29:31 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:29:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:29:31 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:29:32 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:29:32 --> Session Class Initialized
DEBUG - 2013-09-02 05:29:32 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:29:32 --> Session routines successfully run
DEBUG - 2013-09-02 05:29:32 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:29:32 --> Controller Class Initialized
ERROR - 2013-09-02 05:29:32 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:29:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:29:32 --> Model Class Initialized
DEBUG - 2013-09-02 05:29:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:29:32 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:29:32 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:29:32 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:29:32 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:29:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:29:32 --> Model Class Initialized
DEBUG - 2013-09-02 05:29:32 --> Pagination Class Initialized
ERROR - 2013-09-02 05:29:32 --> Severity: Warning  --> include_once(application/core/MY_Excel_reader.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:29:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Excel_reader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:58:22 --> Config Class Initialized
DEBUG - 2013-09-02 05:58:22 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:58:22 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:58:22 --> URI Class Initialized
DEBUG - 2013-09-02 05:58:22 --> Router Class Initialized
DEBUG - 2013-09-02 05:58:22 --> No URI present. Default controller set.
DEBUG - 2013-09-02 05:58:22 --> Output Class Initialized
DEBUG - 2013-09-02 05:58:22 --> Security Class Initialized
DEBUG - 2013-09-02 05:58:22 --> Input Class Initialized
DEBUG - 2013-09-02 05:58:22 --> XSS Filtering completed
DEBUG - 2013-09-02 05:58:22 --> XSS Filtering completed
DEBUG - 2013-09-02 05:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:58:22 --> Language Class Initialized
DEBUG - 2013-09-02 05:58:22 --> Loader Class Initialized
DEBUG - 2013-09-02 05:58:22 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:58:22 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:58:22 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:58:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:58:22 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:58:23 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:58:23 --> Session Class Initialized
DEBUG - 2013-09-02 05:58:23 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:58:23 --> Session routines successfully run
DEBUG - 2013-09-02 05:58:23 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:58:23 --> Controller Class Initialized
ERROR - 2013-09-02 05:58:23 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:58:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:58:23 --> Model Class Initialized
DEBUG - 2013-09-02 05:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:58:23 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:58:23 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:58:23 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:58:23 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:58:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:58:24 --> Model Class Initialized
DEBUG - 2013-09-02 05:58:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-02 05:58:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-02 05:58:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-02 05:58:24 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-02 05:58:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-02 05:58:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-02 05:58:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-02 05:58:24 --> File loaded: application/views/home.php
DEBUG - 2013-09-02 05:58:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-02 05:58:24 --> Final output sent to browser
DEBUG - 2013-09-02 05:58:24 --> Total execution time: 2.8742
DEBUG - 2013-09-02 05:58:25 --> Config Class Initialized
DEBUG - 2013-09-02 05:58:25 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:58:25 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:58:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:58:25 --> URI Class Initialized
DEBUG - 2013-09-02 05:58:25 --> Router Class Initialized
ERROR - 2013-09-02 05:58:25 --> 404 Page Not Found --> css
DEBUG - 2013-09-02 05:58:30 --> Config Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:58:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:58:30 --> URI Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Router Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Output Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Security Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Input Class Initialized
DEBUG - 2013-09-02 05:58:30 --> XSS Filtering completed
DEBUG - 2013-09-02 05:58:30 --> XSS Filtering completed
DEBUG - 2013-09-02 05:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 05:58:30 --> Language Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Loader Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Helper loaded: url_helper
DEBUG - 2013-09-02 05:58:30 --> Helper loaded: file_helper
DEBUG - 2013-09-02 05:58:30 --> Helper loaded: form_helper
DEBUG - 2013-09-02 05:58:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 05:58:30 --> Helper loaded: application_helper
DEBUG - 2013-09-02 05:58:30 --> Database Driver Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Session Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Helper loaded: string_helper
DEBUG - 2013-09-02 05:58:30 --> Session routines successfully run
DEBUG - 2013-09-02 05:58:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Controller Class Initialized
ERROR - 2013-09-02 05:58:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:58:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:58:30 --> Model Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-02 05:58:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-02 05:58:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-02 05:58:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-02 05:58:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-02 05:58:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-02 05:58:30 --> Model Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Pagination Class Initialized
DEBUG - 2013-09-02 05:58:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-02 05:58:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-02 05:58:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-02 05:58:30 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-02 05:58:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-02 05:58:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-02 05:58:30 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-02 05:58:30 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-02 05:58:30 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-02 05:58:30 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-02 05:58:30 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
ERROR - 2013-09-02 05:58:30 --> Severity: Notice  --> Undefined index: nip C:\xampp\htdocs\school\application\views\siswas\index.php 95
DEBUG - 2013-09-02 05:58:30 --> File loaded: application/views/siswas/index.php
DEBUG - 2013-09-02 05:58:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-02 05:58:30 --> Final output sent to browser
DEBUG - 2013-09-02 05:58:30 --> Total execution time: 0.7380
DEBUG - 2013-09-02 05:58:30 --> Config Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Hooks Class Initialized
DEBUG - 2013-09-02 05:58:30 --> Utf8 Class Initialized
DEBUG - 2013-09-02 05:58:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 05:58:31 --> URI Class Initialized
DEBUG - 2013-09-02 05:58:31 --> Router Class Initialized
ERROR - 2013-09-02 05:58:31 --> 404 Page Not Found --> css
