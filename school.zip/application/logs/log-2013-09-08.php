<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-08 03:58:47 --> Config Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:58:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:58:47 --> URI Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Router Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Output Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Security Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Input Class Initialized
DEBUG - 2013-09-08 03:58:47 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:47 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:47 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:47 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:58:47 --> Language Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Loader Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:58:47 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:58:47 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:58:47 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:58:47 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:58:47 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Session Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:58:47 --> A session cookie was not found.
DEBUG - 2013-09-08 03:58:47 --> Session routines successfully run
DEBUG - 2013-09-08 03:58:47 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Controller Class Initialized
ERROR - 2013-09-08 03:58:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:47 --> Model Class Initialized
DEBUG - 2013-09-08 03:58:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:58:47 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:58:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:58:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:58:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:48 --> Config Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:58:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:58:48 --> URI Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Router Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Output Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Security Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Input Class Initialized
DEBUG - 2013-09-08 03:58:48 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:48 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:58:48 --> Language Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Loader Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:58:48 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:58:48 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:58:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:58:48 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:58:48 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Session Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:58:48 --> Session routines successfully run
DEBUG - 2013-09-08 03:58:48 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Controller Class Initialized
ERROR - 2013-09-08 03:58:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:48 --> Model Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:58:48 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:58:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:58:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:58:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 03:58:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 03:58:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 03:58:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 03:58:48 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-08 03:58:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 03:58:48 --> Final output sent to browser
DEBUG - 2013-09-08 03:58:48 --> Total execution time: 0.2380
DEBUG - 2013-09-08 03:58:48 --> Config Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:58:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:58:48 --> URI Class Initialized
DEBUG - 2013-09-08 03:58:48 --> Router Class Initialized
ERROR - 2013-09-08 03:58:48 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 03:58:56 --> Config Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:58:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:58:56 --> URI Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Router Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Output Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Security Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Input Class Initialized
DEBUG - 2013-09-08 03:58:56 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:56 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:56 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:56 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:56 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:56 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:58:56 --> Language Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Loader Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:58:56 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:58:56 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:58:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:58:56 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:58:56 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Session Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:58:56 --> Session routines successfully run
DEBUG - 2013-09-08 03:58:56 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Controller Class Initialized
ERROR - 2013-09-08 03:58:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:56 --> Model Class Initialized
DEBUG - 2013-09-08 03:58:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:58:56 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:58:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:58:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:58:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:56 --> Model Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Form Validation Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-08 03:58:57 --> Config Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:58:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:58:57 --> URI Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Router Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Output Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Security Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Input Class Initialized
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:58:57 --> Language Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Loader Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:58:57 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Session Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:58:57 --> Session routines successfully run
DEBUG - 2013-09-08 03:58:57 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Controller Class Initialized
ERROR - 2013-09-08 03:58:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:57 --> Model Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:58:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:58:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:58:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:57 --> Config Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:58:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:58:57 --> URI Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Router Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Output Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Security Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Input Class Initialized
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:58:57 --> Language Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Loader Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:58:57 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Session Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:58:57 --> Session routines successfully run
DEBUG - 2013-09-08 03:58:57 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Controller Class Initialized
ERROR - 2013-09-08 03:58:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:57 --> Model Class Initialized
DEBUG - 2013-09-08 03:58:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:58:57 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:58:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:58:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:58:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:58:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:58:57 --> Model Class Initialized
DEBUG - 2013-09-08 03:58:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 03:58:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 03:58:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 03:58:57 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 03:58:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 03:58:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 03:58:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 03:58:57 --> File loaded: application/views/home.php
DEBUG - 2013-09-08 03:58:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 03:58:57 --> Final output sent to browser
DEBUG - 2013-09-08 03:58:57 --> Total execution time: 0.4270
DEBUG - 2013-09-08 03:58:58 --> Config Class Initialized
DEBUG - 2013-09-08 03:58:58 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:58:58 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:58:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:58:58 --> URI Class Initialized
DEBUG - 2013-09-08 03:58:58 --> Router Class Initialized
ERROR - 2013-09-08 03:58:58 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 03:59:01 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:01 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Router Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Output Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Security Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Input Class Initialized
DEBUG - 2013-09-08 03:59:01 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:01 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:01 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:01 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:01 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:59:01 --> Language Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Loader Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:59:01 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:59:01 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:59:01 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:59:01 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:59:01 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Session Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:59:01 --> Session routines successfully run
DEBUG - 2013-09-08 03:59:01 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Controller Class Initialized
ERROR - 2013-09-08 03:59:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:01 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:59:01 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:59:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:59:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:59:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:01 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:01 --> Pagination Class Initialized
DEBUG - 2013-09-08 03:59:01 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 03:59:01 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 03:59:02 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 03:59:02 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 03:59:02 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 03:59:02 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 03:59:02 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 03:59:02 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-09-08 03:59:02 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 03:59:02 --> Final output sent to browser
DEBUG - 2013-09-08 03:59:02 --> Total execution time: 0.4990
DEBUG - 2013-09-08 03:59:02 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:02 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:02 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:02 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:02 --> Router Class Initialized
ERROR - 2013-09-08 03:59:02 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 03:59:08 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:08 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:08 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:08 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:08 --> Router Class Initialized
DEBUG - 2013-09-08 03:59:08 --> Output Class Initialized
DEBUG - 2013-09-08 03:59:08 --> Security Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Input Class Initialized
DEBUG - 2013-09-08 03:59:09 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:09 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:09 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:09 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:09 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:59:09 --> Language Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Loader Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:59:09 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:59:09 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:59:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:59:09 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:59:09 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Session Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:59:09 --> Session routines successfully run
DEBUG - 2013-09-08 03:59:09 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Controller Class Initialized
ERROR - 2013-09-08 03:59:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:09 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:59:09 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:59:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:59:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:59:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:09 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:09 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 03:59:09 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 03:59:09 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 03:59:09 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 03:59:09 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 03:59:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 03:59:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 03:59:09 --> File loaded: application/views/gurus/new.php
DEBUG - 2013-09-08 03:59:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 03:59:09 --> Final output sent to browser
DEBUG - 2013-09-08 03:59:09 --> Total execution time: 0.2900
DEBUG - 2013-09-08 03:59:09 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:09 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:09 --> Router Class Initialized
ERROR - 2013-09-08 03:59:09 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 03:59:41 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:41 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Router Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Output Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Security Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Input Class Initialized
DEBUG - 2013-09-08 03:59:41 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:41 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:41 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:41 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:41 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:59:41 --> Language Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Loader Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:59:41 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:59:41 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:59:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:59:41 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:59:41 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Session Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:59:41 --> Session routines successfully run
DEBUG - 2013-09-08 03:59:41 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Controller Class Initialized
ERROR - 2013-09-08 03:59:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:41 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:59:41 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:59:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:59:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:59:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:41 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Pagination Class Initialized
DEBUG - 2013-09-08 03:59:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 03:59:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 03:59:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 03:59:41 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 03:59:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 03:59:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 03:59:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 03:59:41 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-09-08 03:59:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 03:59:41 --> Final output sent to browser
DEBUG - 2013-09-08 03:59:41 --> Total execution time: 0.2640
DEBUG - 2013-09-08 03:59:41 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:41 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:41 --> Router Class Initialized
ERROR - 2013-09-08 03:59:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 03:59:44 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:44 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:44 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:44 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:44 --> Router Class Initialized
DEBUG - 2013-09-08 03:59:44 --> Output Class Initialized
DEBUG - 2013-09-08 03:59:44 --> Security Class Initialized
DEBUG - 2013-09-08 03:59:44 --> Input Class Initialized
DEBUG - 2013-09-08 03:59:45 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:45 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:45 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:45 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:45 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:59:45 --> Language Class Initialized
DEBUG - 2013-09-08 03:59:45 --> Loader Class Initialized
DEBUG - 2013-09-08 03:59:45 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:59:45 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:59:45 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:59:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:59:45 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:59:45 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:59:45 --> Session Class Initialized
DEBUG - 2013-09-08 03:59:45 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:59:45 --> Session routines successfully run
DEBUG - 2013-09-08 03:59:45 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:59:45 --> Controller Class Initialized
ERROR - 2013-09-08 03:59:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:45 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:59:45 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:59:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:59:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:59:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:45 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 03:59:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 03:59:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 03:59:45 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 03:59:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 03:59:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 03:59:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 03:59:45 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-09-08 03:59:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 03:59:45 --> Final output sent to browser
DEBUG - 2013-09-08 03:59:45 --> Total execution time: 0.3170
DEBUG - 2013-09-08 03:59:45 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:45 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:45 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:45 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:45 --> Router Class Initialized
ERROR - 2013-09-08 03:59:45 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 03:59:54 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:54 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Router Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Output Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Security Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Input Class Initialized
DEBUG - 2013-09-08 03:59:54 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:54 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:54 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:54 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:54 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:59:54 --> Language Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Loader Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:59:54 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:59:54 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:59:54 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:59:54 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:59:54 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Session Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:59:54 --> Session routines successfully run
DEBUG - 2013-09-08 03:59:54 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Controller Class Initialized
ERROR - 2013-09-08 03:59:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:54 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:59:54 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:59:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:59:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:59:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:54 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Pagination Class Initialized
DEBUG - 2013-09-08 03:59:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 03:59:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 03:59:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 03:59:54 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 03:59:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 03:59:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 03:59:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 03:59:54 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-09-08 03:59:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 03:59:54 --> Final output sent to browser
DEBUG - 2013-09-08 03:59:54 --> Total execution time: 0.2780
DEBUG - 2013-09-08 03:59:54 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:54 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:54 --> Router Class Initialized
ERROR - 2013-09-08 03:59:54 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 03:59:57 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:57 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Router Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Output Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Security Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Input Class Initialized
DEBUG - 2013-09-08 03:59:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:57 --> XSS Filtering completed
DEBUG - 2013-09-08 03:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 03:59:57 --> Language Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Loader Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Helper loaded: url_helper
DEBUG - 2013-09-08 03:59:57 --> Helper loaded: file_helper
DEBUG - 2013-09-08 03:59:57 --> Helper loaded: form_helper
DEBUG - 2013-09-08 03:59:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 03:59:57 --> Helper loaded: application_helper
DEBUG - 2013-09-08 03:59:57 --> Database Driver Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Session Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Helper loaded: string_helper
DEBUG - 2013-09-08 03:59:57 --> Session routines successfully run
DEBUG - 2013-09-08 03:59:57 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Controller Class Initialized
ERROR - 2013-09-08 03:59:57 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:57 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 03:59:57 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 03:59:57 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 03:59:57 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 03:59:57 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 03:59:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 03:59:57 --> Model Class Initialized
DEBUG - 2013-09-08 03:59:57 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 03:59:57 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 03:59:57 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 03:59:57 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 03:59:57 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 03:59:57 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 03:59:57 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 03:59:57 --> File loaded: application/views/gurus/edit.php
DEBUG - 2013-09-08 03:59:57 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 03:59:57 --> Final output sent to browser
DEBUG - 2013-09-08 03:59:57 --> Total execution time: 0.3200
DEBUG - 2013-09-08 03:59:57 --> Config Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Hooks Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Utf8 Class Initialized
DEBUG - 2013-09-08 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 03:59:57 --> URI Class Initialized
DEBUG - 2013-09-08 03:59:57 --> Router Class Initialized
ERROR - 2013-09-08 03:59:57 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:00:09 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:09 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:09 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:09 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:09 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:09 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:09 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:09 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:09 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:10 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:10 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:10 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:10 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:10 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:10 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:10 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:10 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:10 --> Session garbage collection performed.
DEBUG - 2013-09-08 04:00:10 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:10 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:10 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:10 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:10 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:10 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:00:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:00:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:00:10 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:00:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:00:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:00:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 04:00:10 --> File loaded: application/views/guru_mata_pelajarans/new.php
DEBUG - 2013-09-08 04:00:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:00:10 --> Final output sent to browser
DEBUG - 2013-09-08 04:00:10 --> Total execution time: 0.4050
DEBUG - 2013-09-08 04:00:10 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:10 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:10 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:10 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:10 --> Router Class Initialized
ERROR - 2013-09-08 04:00:10 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:00:17 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:17 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:17 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:17 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:17 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:17 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:17 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:17 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:17 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:17 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:17 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:17 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:17 --> Session garbage collection performed.
DEBUG - 2013-09-08 04:00:17 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:17 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:17 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:17 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:17 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Pagination Class Initialized
DEBUG - 2013-09-08 04:00:17 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:00:17 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:00:17 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:00:17 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:00:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:00:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:00:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 04:00:17 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-09-08 04:00:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:00:17 --> Final output sent to browser
DEBUG - 2013-09-08 04:00:17 --> Total execution time: 0.3620
DEBUG - 2013-09-08 04:00:17 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:17 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:17 --> Router Class Initialized
ERROR - 2013-09-08 04:00:17 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:00:23 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:24 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:24 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:24 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:24 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:24 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:24 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:24 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:24 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:24 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:24 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:24 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:24 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:24 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:24 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:24 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:24 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:24 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:00:24 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:00:24 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:00:24 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:00:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:00:24 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:00:24 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 04:00:24 --> File loaded: application/views/kurikulums/new.php
DEBUG - 2013-09-08 04:00:24 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:00:24 --> Final output sent to browser
DEBUG - 2013-09-08 04:00:24 --> Total execution time: 0.3870
DEBUG - 2013-09-08 04:00:24 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:24 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:24 --> Router Class Initialized
ERROR - 2013-09-08 04:00:24 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:00:30 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:30 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:30 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:30 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:30 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:30 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:30 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Form Validation Class Initialized
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-08 04:00:30 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:30 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:30 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:30 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:30 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:30 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:30 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:30 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:30 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:30 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:30 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:30 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:30 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Pagination Class Initialized
DEBUG - 2013-09-08 04:00:30 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:00:30 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:00:30 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:00:30 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:00:30 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:00:30 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:00:30 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 04:00:30 --> File loaded: application/views/kurikulums/index.php
DEBUG - 2013-09-08 04:00:30 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:00:30 --> Final output sent to browser
DEBUG - 2013-09-08 04:00:30 --> Total execution time: 0.3460
DEBUG - 2013-09-08 04:00:30 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:30 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:30 --> Router Class Initialized
ERROR - 2013-09-08 04:00:30 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:00:38 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:38 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:38 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:38 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:38 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:38 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:38 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:38 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:38 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:38 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:38 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:38 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:38 --> Session garbage collection performed.
DEBUG - 2013-09-08 04:00:38 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:38 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:38 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:38 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:38 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:38 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:38 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:38 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:38 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Pagination Class Initialized
DEBUG - 2013-09-08 04:00:38 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:00:38 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:00:38 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:00:38 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:00:38 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:00:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:00:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 04:00:38 --> File loaded: application/views/gurus/index.php
DEBUG - 2013-09-08 04:00:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:00:38 --> Final output sent to browser
DEBUG - 2013-09-08 04:00:38 --> Total execution time: 0.3700
DEBUG - 2013-09-08 04:00:38 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:38 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:38 --> Router Class Initialized
ERROR - 2013-09-08 04:00:38 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:00:41 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:41 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:41 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:41 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:41 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:41 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:41 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:41 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:41 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:41 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:41 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:41 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:41 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:41 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:41 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:41 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:41 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:41 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:41 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:41 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:41 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:00:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:00:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:00:41 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:00:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:00:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:00:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 04:00:41 --> File loaded: application/views/gurus/edit.php
DEBUG - 2013-09-08 04:00:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:00:41 --> Final output sent to browser
DEBUG - 2013-09-08 04:00:41 --> Total execution time: 0.3620
DEBUG - 2013-09-08 04:00:41 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:41 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:41 --> Router Class Initialized
ERROR - 2013-09-08 04:00:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:00:47 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:47 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:47 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:47 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:47 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:47 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:47 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:47 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:47 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:47 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:47 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:47 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:47 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:47 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:47 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:47 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:47 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:47 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:47 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:00:47 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:00:47 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:00:47 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:00:47 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:00:47 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:00:47 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 04:00:47 --> File loaded: application/views/guru_mata_pelajarans/new.php
DEBUG - 2013-09-08 04:00:47 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:00:47 --> Final output sent to browser
DEBUG - 2013-09-08 04:00:47 --> Total execution time: 0.4020
DEBUG - 2013-09-08 04:00:47 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:47 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:48 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:48 --> Router Class Initialized
ERROR - 2013-09-08 04:00:48 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:00:54 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:54 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:54 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:54 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:54 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:54 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:54 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:54 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:54 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:54 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:54 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:54 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:54 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:54 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:54 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:55 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:55 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:55 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:55 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:55 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:55 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Form Validation Class Initialized
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-08 04:00:55 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:55 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Router Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Output Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Security Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Input Class Initialized
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> XSS Filtering completed
DEBUG - 2013-09-08 04:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:00:55 --> Language Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Loader Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:00:55 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Session Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:00:55 --> Session routines successfully run
DEBUG - 2013-09-08 04:00:55 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Controller Class Initialized
ERROR - 2013-09-08 04:00:55 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:55 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:00:55 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:00:55 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:00:55 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:00:55 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:00:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:00:55 --> Model Class Initialized
DEBUG - 2013-09-08 04:00:55 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:00:55 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:00:55 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:00:55 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:00:55 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:00:55 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:00:55 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 04:00:55 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-09-08 04:00:55 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:00:55 --> Final output sent to browser
DEBUG - 2013-09-08 04:00:55 --> Total execution time: 0.3930
DEBUG - 2013-09-08 04:00:55 --> Config Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:00:55 --> URI Class Initialized
DEBUG - 2013-09-08 04:00:55 --> Router Class Initialized
ERROR - 2013-09-08 04:00:55 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:01:09 --> Config Class Initialized
DEBUG - 2013-09-08 04:01:09 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:01:09 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:01:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:01:09 --> URI Class Initialized
DEBUG - 2013-09-08 04:01:09 --> Router Class Initialized
DEBUG - 2013-09-08 04:01:09 --> Output Class Initialized
DEBUG - 2013-09-08 04:01:09 --> Security Class Initialized
DEBUG - 2013-09-08 04:01:09 --> Input Class Initialized
DEBUG - 2013-09-08 04:01:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:01:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:01:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:01:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:01:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:01:09 --> Language Class Initialized
DEBUG - 2013-09-08 04:01:09 --> Loader Class Initialized
DEBUG - 2013-09-08 04:01:09 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:01:09 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:01:09 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:01:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:01:10 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:01:10 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:01:10 --> Session Class Initialized
DEBUG - 2013-09-08 04:01:10 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:01:10 --> Session routines successfully run
DEBUG - 2013-09-08 04:01:10 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:01:10 --> Controller Class Initialized
ERROR - 2013-09-08 04:01:10 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:01:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:01:10 --> Model Class Initialized
DEBUG - 2013-09-08 04:01:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:01:10 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:01:10 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:01:10 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:01:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:01:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:01:10 --> Model Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Config Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:02:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:02:00 --> URI Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Router Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Output Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Security Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Input Class Initialized
DEBUG - 2013-09-08 04:02:00 --> XSS Filtering completed
DEBUG - 2013-09-08 04:02:00 --> XSS Filtering completed
DEBUG - 2013-09-08 04:02:00 --> XSS Filtering completed
DEBUG - 2013-09-08 04:02:00 --> XSS Filtering completed
DEBUG - 2013-09-08 04:02:00 --> XSS Filtering completed
DEBUG - 2013-09-08 04:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:02:00 --> Language Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Loader Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:02:00 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:02:00 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:02:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:02:00 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:02:00 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:02:00 --> Session Class Initialized
DEBUG - 2013-09-08 04:02:01 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:02:01 --> Session routines successfully run
DEBUG - 2013-09-08 04:02:01 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:02:01 --> Controller Class Initialized
ERROR - 2013-09-08 04:02:01 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:02:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:02:01 --> Model Class Initialized
DEBUG - 2013-09-08 04:02:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:02:01 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:02:01 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:02:01 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:02:01 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:02:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:02:01 --> Model Class Initialized
DEBUG - 2013-09-08 04:03:07 --> Config Class Initialized
DEBUG - 2013-09-08 04:03:07 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:03:07 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:03:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:03:07 --> URI Class Initialized
DEBUG - 2013-09-08 04:03:07 --> Router Class Initialized
DEBUG - 2013-09-08 04:03:07 --> Output Class Initialized
DEBUG - 2013-09-08 04:03:07 --> Security Class Initialized
DEBUG - 2013-09-08 04:03:07 --> Input Class Initialized
DEBUG - 2013-09-08 04:03:07 --> XSS Filtering completed
DEBUG - 2013-09-08 04:03:07 --> XSS Filtering completed
DEBUG - 2013-09-08 04:03:08 --> XSS Filtering completed
DEBUG - 2013-09-08 04:03:08 --> XSS Filtering completed
DEBUG - 2013-09-08 04:03:08 --> XSS Filtering completed
DEBUG - 2013-09-08 04:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:03:08 --> Language Class Initialized
DEBUG - 2013-09-08 04:03:08 --> Loader Class Initialized
DEBUG - 2013-09-08 04:03:08 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:03:08 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:03:08 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:03:08 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:03:08 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:03:08 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:03:08 --> Session Class Initialized
DEBUG - 2013-09-08 04:03:08 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:03:08 --> Session routines successfully run
DEBUG - 2013-09-08 04:03:08 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:03:08 --> Controller Class Initialized
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:03:08 --> Model Class Initialized
DEBUG - 2013-09-08 04:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:03:08 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:03:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:03:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:03:08 --> Model Class Initialized
DEBUG - 2013-09-08 04:03:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:03:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:03:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:03:08 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:03:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:03:08 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:03:08 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:03:08 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:03:08 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:03:08 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:03:08 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:03:08 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:03:08 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:03:08 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:03:08 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'mata_pelajaran_id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'mata_pelajaran_id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'mata_pelajaran_id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'mata_pelajaran_id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'mata_pelajaran_id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
ERROR - 2013-09-08 04:03:08 --> Severity: Warning  --> Illegal string offset 'mata_pelajaran_id' C:\xampp\htdocs\school\application\views\guru_kelas_matpels\new.php 31
DEBUG - 2013-09-08 04:03:08 --> File loaded: application/views/guru_kelas_matpels/new.php
DEBUG - 2013-09-08 04:03:08 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:03:08 --> Final output sent to browser
DEBUG - 2013-09-08 04:03:08 --> Total execution time: 0.8400
DEBUG - 2013-09-08 04:03:08 --> Config Class Initialized
DEBUG - 2013-09-08 04:03:08 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:03:08 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:03:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:03:08 --> URI Class Initialized
DEBUG - 2013-09-08 04:03:08 --> Router Class Initialized
ERROR - 2013-09-08 04:03:08 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:07:40 --> Config Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:07:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:07:40 --> URI Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Router Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Output Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Security Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Input Class Initialized
DEBUG - 2013-09-08 04:07:40 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:40 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:40 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:40 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:40 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:07:40 --> Language Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Loader Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:07:40 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:07:40 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:07:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:07:40 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:07:40 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Session Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:07:40 --> Session routines successfully run
DEBUG - 2013-09-08 04:07:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Controller Class Initialized
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:07:40 --> Model Class Initialized
DEBUG - 2013-09-08 04:07:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:07:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:07:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:07:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:07:40 --> Model Class Initialized
DEBUG - 2013-09-08 04:07:40 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:07:40 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:07:40 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:07:40 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:07:40 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:07:40 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:07:40 --> File loaded: application/views/shared/content_title.php
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:07:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:07:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:07:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:07:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:07:40 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:07:40 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:07:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:07:41 --> Severity: Warning  --> Illegal string offset 'jurusan_id' C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:07:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 86
ERROR - 2013-09-08 04:07:41 --> Severity: Warning  --> Illegal string offset 'tingkat' C:\xampp\htdocs\school\application\helpers\application_helper.php 88
ERROR - 2013-09-08 04:07:41 --> Severity: Notice  --> Uninitialized string offset: 0 C:\xampp\htdocs\school\application\helpers\application_helper.php 88
DEBUG - 2013-09-08 04:07:41 --> File loaded: application/views/guru_kelas_matpels/new.php
DEBUG - 2013-09-08 04:07:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:07:41 --> Final output sent to browser
DEBUG - 2013-09-08 04:07:41 --> Total execution time: 0.7150
DEBUG - 2013-09-08 04:07:41 --> Config Class Initialized
DEBUG - 2013-09-08 04:07:41 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:07:41 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:07:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:07:41 --> URI Class Initialized
DEBUG - 2013-09-08 04:07:41 --> Router Class Initialized
ERROR - 2013-09-08 04:07:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 04:07:45 --> Config Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:07:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:07:45 --> URI Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Router Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Output Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Security Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Input Class Initialized
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:07:45 --> Language Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Loader Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:07:45 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:07:45 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:07:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:07:45 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:07:45 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Session Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:07:45 --> Session routines successfully run
DEBUG - 2013-09-08 04:07:45 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Controller Class Initialized
ERROR - 2013-09-08 04:07:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:07:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:07:45 --> Model Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:07:45 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:07:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:07:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:07:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:07:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:07:45 --> Model Class Initialized
DEBUG - 2013-09-08 04:07:45 --> Form Validation Class Initialized
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> XSS Filtering completed
DEBUG - 2013-09-08 04:07:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-08 04:07:45 --> DB Transaction Failure
ERROR - 2013-09-08 04:07:45 --> Query error: Field 'id' doesn't have a default value
DEBUG - 2013-09-08 04:07:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-08 04:24:08 --> Config Class Initialized
DEBUG - 2013-09-08 04:24:08 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:24:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:24:09 --> URI Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Router Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Output Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Security Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Input Class Initialized
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:24:09 --> Language Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Loader Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:24:09 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Session Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:24:09 --> Session routines successfully run
DEBUG - 2013-09-08 04:24:09 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Controller Class Initialized
ERROR - 2013-09-08 04:24:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:24:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:24:09 --> Model Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:24:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:24:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:24:09 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:24:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:24:09 --> Model Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Form Validation Class Initialized
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-08 04:24:09 --> Config Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:24:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:24:09 --> URI Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Router Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Output Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Security Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Input Class Initialized
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> XSS Filtering completed
DEBUG - 2013-09-08 04:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 04:24:09 --> Language Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Loader Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: url_helper
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: file_helper
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: form_helper
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: application_helper
DEBUG - 2013-09-08 04:24:09 --> Database Driver Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Session Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: string_helper
DEBUG - 2013-09-08 04:24:09 --> Session routines successfully run
DEBUG - 2013-09-08 04:24:09 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Controller Class Initialized
ERROR - 2013-09-08 04:24:09 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:24:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:24:09 --> Model Class Initialized
DEBUG - 2013-09-08 04:24:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 04:24:09 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 04:24:09 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 04:24:09 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 04:24:10 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 04:24:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 04:24:10 --> Model Class Initialized
DEBUG - 2013-09-08 04:24:10 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 04:24:10 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 04:24:10 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 04:24:10 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 04:24:10 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 04:24:10 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 04:24:10 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 04:24:10 --> File loaded: application/views/gurus/show.php
DEBUG - 2013-09-08 04:24:10 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 04:24:10 --> Final output sent to browser
DEBUG - 2013-09-08 04:24:10 --> Total execution time: 0.6810
DEBUG - 2013-09-08 04:24:10 --> Config Class Initialized
DEBUG - 2013-09-08 04:24:10 --> Hooks Class Initialized
DEBUG - 2013-09-08 04:24:10 --> Utf8 Class Initialized
DEBUG - 2013-09-08 04:24:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 04:24:10 --> URI Class Initialized
DEBUG - 2013-09-08 04:24:10 --> Router Class Initialized
ERROR - 2013-09-08 04:24:10 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 11:39:44 --> Config Class Initialized
DEBUG - 2013-09-08 11:39:44 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:39:44 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:39:44 --> URI Class Initialized
DEBUG - 2013-09-08 11:39:44 --> Router Class Initialized
ERROR - 2013-09-08 11:39:44 --> 404 Page Not Found --> staff/mata_pelajaran_persentases
DEBUG - 2013-09-08 11:42:30 --> Config Class Initialized
DEBUG - 2013-09-08 11:42:30 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:42:30 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:42:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:42:30 --> URI Class Initialized
DEBUG - 2013-09-08 11:42:30 --> Router Class Initialized
DEBUG - 2013-09-08 11:42:30 --> Output Class Initialized
DEBUG - 2013-09-08 11:42:30 --> Security Class Initialized
DEBUG - 2013-09-08 11:42:30 --> Input Class Initialized
DEBUG - 2013-09-08 11:42:30 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:30 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:30 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:30 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:42:31 --> Language Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Loader Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:42:31 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Session Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:42:31 --> A session cookie was not found.
DEBUG - 2013-09-08 11:42:31 --> Session routines successfully run
DEBUG - 2013-09-08 11:42:31 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Controller Class Initialized
ERROR - 2013-09-08 11:42:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:31 --> Model Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:42:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:42:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:42:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:31 --> Config Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:42:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:42:31 --> URI Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Router Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Output Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Security Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Input Class Initialized
DEBUG - 2013-09-08 11:42:31 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:31 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:42:31 --> Language Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Loader Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:42:31 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Session Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:42:31 --> Session routines successfully run
DEBUG - 2013-09-08 11:42:31 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Controller Class Initialized
ERROR - 2013-09-08 11:42:31 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:31 --> Model Class Initialized
DEBUG - 2013-09-08 11:42:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:42:31 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:42:31 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:42:31 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:42:31 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:31 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 11:42:31 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 11:42:31 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 11:42:31 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 11:42:31 --> File loaded: application/views/user_sessions/login.php
DEBUG - 2013-09-08 11:42:31 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 11:42:31 --> Final output sent to browser
DEBUG - 2013-09-08 11:42:31 --> Total execution time: 0.4270
DEBUG - 2013-09-08 11:42:32 --> Config Class Initialized
DEBUG - 2013-09-08 11:42:32 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:42:32 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:42:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:42:32 --> URI Class Initialized
DEBUG - 2013-09-08 11:42:32 --> Router Class Initialized
ERROR - 2013-09-08 11:42:32 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 11:42:39 --> Config Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:42:39 --> URI Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Router Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Output Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Security Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Input Class Initialized
DEBUG - 2013-09-08 11:42:39 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:39 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:39 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:39 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:39 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:42:39 --> Language Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Loader Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:42:39 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:42:39 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:42:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:42:39 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:42:39 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Session Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:42:39 --> Session routines successfully run
DEBUG - 2013-09-08 11:42:39 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Controller Class Initialized
ERROR - 2013-09-08 11:42:39 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:39 --> Model Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:42:39 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:42:39 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:42:39 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:42:39 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:39 --> Model Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Form Validation Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-08 11:42:39 --> Config Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:42:39 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:42:39 --> URI Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Router Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Output Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Security Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Input Class Initialized
DEBUG - 2013-09-08 11:42:40 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:40 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:42:40 --> Language Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Loader Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:42:40 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Session Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:42:40 --> Session routines successfully run
DEBUG - 2013-09-08 11:42:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Controller Class Initialized
ERROR - 2013-09-08 11:42:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:40 --> Model Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:42:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:42:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:42:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:40 --> Config Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:42:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:42:40 --> URI Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Router Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Output Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Security Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Input Class Initialized
DEBUG - 2013-09-08 11:42:40 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:40 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:42:40 --> Language Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Loader Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:42:40 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Session Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:42:40 --> Session routines successfully run
DEBUG - 2013-09-08 11:42:40 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Controller Class Initialized
ERROR - 2013-09-08 11:42:40 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:40 --> Model Class Initialized
DEBUG - 2013-09-08 11:42:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:42:40 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:42:40 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:42:40 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:42:40 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:40 --> Model Class Initialized
DEBUG - 2013-09-08 11:42:41 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 11:42:41 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 11:42:41 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 11:42:41 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 11:42:41 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 11:42:41 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 11:42:41 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 11:42:41 --> File loaded: application/views/home.php
DEBUG - 2013-09-08 11:42:41 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 11:42:41 --> Final output sent to browser
DEBUG - 2013-09-08 11:42:41 --> Total execution time: 0.6590
DEBUG - 2013-09-08 11:42:41 --> Config Class Initialized
DEBUG - 2013-09-08 11:42:41 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:42:41 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:42:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:42:41 --> URI Class Initialized
DEBUG - 2013-09-08 11:42:41 --> Router Class Initialized
ERROR - 2013-09-08 11:42:41 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 11:42:46 --> Config Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:42:46 --> URI Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Router Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Output Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Security Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Input Class Initialized
DEBUG - 2013-09-08 11:42:46 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:46 --> XSS Filtering completed
DEBUG - 2013-09-08 11:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:42:46 --> Language Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Loader Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:42:46 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:42:46 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:42:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:42:46 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:42:46 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Session Class Initialized
DEBUG - 2013-09-08 11:42:46 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:42:47 --> Session routines successfully run
DEBUG - 2013-09-08 11:42:47 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:42:47 --> Controller Class Initialized
ERROR - 2013-09-08 11:42:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:47 --> Model Class Initialized
DEBUG - 2013-09-08 11:42:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:42:47 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:42:47 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:42:47 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:42:47 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:42:47 --> Model Class Initialized
ERROR - 2013-09-08 11:42:47 --> Severity: Warning  --> include_once(application/core/Mata_pelajaran_persentase_model.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:42:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Mata_pelajaran_persentase_model.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:43:48 --> Config Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:43:48 --> URI Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Router Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Output Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Security Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Input Class Initialized
DEBUG - 2013-09-08 11:43:48 --> XSS Filtering completed
DEBUG - 2013-09-08 11:43:48 --> XSS Filtering completed
DEBUG - 2013-09-08 11:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:43:48 --> Language Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Loader Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:43:48 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:43:48 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:43:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:43:48 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:43:48 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Session Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:43:48 --> Session routines successfully run
DEBUG - 2013-09-08 11:43:48 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Controller Class Initialized
ERROR - 2013-09-08 11:43:48 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:43:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:43:48 --> Model Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:43:48 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:43:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:43:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:43:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:43:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:43:48 --> Model Class Initialized
DEBUG - 2013-09-08 11:43:48 --> Pagination Class Initialized
DEBUG - 2013-09-08 11:43:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 11:43:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 11:43:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 11:43:48 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 11:43:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 11:43:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 11:43:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 11:43:48 --> File loaded: application/views/mata_pelajaran_persentases/index.php
DEBUG - 2013-09-08 11:43:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 11:43:48 --> Final output sent to browser
DEBUG - 2013-09-08 11:43:48 --> Total execution time: 0.5120
DEBUG - 2013-09-08 11:43:49 --> Config Class Initialized
DEBUG - 2013-09-08 11:43:49 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:43:49 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:43:49 --> URI Class Initialized
DEBUG - 2013-09-08 11:43:49 --> Router Class Initialized
ERROR - 2013-09-08 11:43:49 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 11:44:12 --> Config Class Initialized
DEBUG - 2013-09-08 11:44:12 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:44:12 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:44:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:44:13 --> URI Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Router Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Output Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Security Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Input Class Initialized
DEBUG - 2013-09-08 11:44:13 --> XSS Filtering completed
DEBUG - 2013-09-08 11:44:13 --> XSS Filtering completed
DEBUG - 2013-09-08 11:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:44:13 --> Language Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Loader Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:44:13 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:44:13 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:44:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:44:13 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:44:13 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Session Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:44:13 --> Session routines successfully run
DEBUG - 2013-09-08 11:44:13 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Controller Class Initialized
ERROR - 2013-09-08 11:44:13 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:44:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:44:13 --> Model Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:44:13 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:44:13 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:44:13 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:44:13 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:44:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:44:13 --> Model Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Pagination Class Initialized
DEBUG - 2013-09-08 11:44:13 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 11:44:13 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 11:44:13 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 11:44:13 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 11:44:13 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 11:44:13 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 11:44:13 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 11:44:13 --> File loaded: application/views/staffs/index.php
DEBUG - 2013-09-08 11:44:13 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 11:44:13 --> Final output sent to browser
DEBUG - 2013-09-08 11:44:13 --> Total execution time: 0.7360
DEBUG - 2013-09-08 11:44:13 --> Config Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:44:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:44:13 --> URI Class Initialized
DEBUG - 2013-09-08 11:44:13 --> Router Class Initialized
ERROR - 2013-09-08 11:44:13 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 11:44:16 --> Config Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:44:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:44:16 --> URI Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Router Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Output Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Security Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Input Class Initialized
DEBUG - 2013-09-08 11:44:16 --> XSS Filtering completed
DEBUG - 2013-09-08 11:44:16 --> XSS Filtering completed
DEBUG - 2013-09-08 11:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:44:16 --> Language Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Loader Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:44:16 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:44:16 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:44:16 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:44:16 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:44:16 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Session Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:44:16 --> Session routines successfully run
DEBUG - 2013-09-08 11:44:16 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Controller Class Initialized
ERROR - 2013-09-08 11:44:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:44:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:44:16 --> Model Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:44:16 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:44:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:44:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:44:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:44:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:44:16 --> Model Class Initialized
DEBUG - 2013-09-08 11:44:16 --> Pagination Class Initialized
DEBUG - 2013-09-08 11:44:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-09-08 11:44:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-09-08 11:44:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-09-08 11:44:16 --> File loaded: application/views/shared/user_menu.php
DEBUG - 2013-09-08 11:44:17 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-09-08 11:44:17 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-09-08 11:44:17 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-09-08 11:44:17 --> File loaded: application/views/spps/index.php
DEBUG - 2013-09-08 11:44:17 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-09-08 11:44:17 --> Final output sent to browser
DEBUG - 2013-09-08 11:44:17 --> Total execution time: 0.6180
DEBUG - 2013-09-08 11:44:17 --> Config Class Initialized
DEBUG - 2013-09-08 11:44:17 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:44:17 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:44:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:44:17 --> URI Class Initialized
DEBUG - 2013-09-08 11:44:17 --> Router Class Initialized
ERROR - 2013-09-08 11:44:17 --> 404 Page Not Found --> css
DEBUG - 2013-09-08 11:45:21 --> Config Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Hooks Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Utf8 Class Initialized
DEBUG - 2013-09-08 11:45:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-08 11:45:21 --> URI Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Router Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Output Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Security Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Input Class Initialized
DEBUG - 2013-09-08 11:45:21 --> XSS Filtering completed
DEBUG - 2013-09-08 11:45:21 --> XSS Filtering completed
DEBUG - 2013-09-08 11:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-08 11:45:21 --> Language Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Loader Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Helper loaded: url_helper
DEBUG - 2013-09-08 11:45:21 --> Helper loaded: file_helper
DEBUG - 2013-09-08 11:45:21 --> Helper loaded: form_helper
DEBUG - 2013-09-08 11:45:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-08 11:45:21 --> Helper loaded: application_helper
DEBUG - 2013-09-08 11:45:21 --> Database Driver Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Session Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Helper loaded: string_helper
DEBUG - 2013-09-08 11:45:21 --> Session routines successfully run
DEBUG - 2013-09-08 11:45:21 --> XML-RPC Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Controller Class Initialized
ERROR - 2013-09-08 11:45:21 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:45:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:45:21 --> Model Class Initialized
DEBUG - 2013-09-08 11:45:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-09-08 11:45:21 --> Helper loaded: cookie_helper
DEBUG - 2013-09-08 11:45:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-09-08 11:45:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-09-08 11:45:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-09-08 11:45:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-09-08 11:45:21 --> Model Class Initialized
