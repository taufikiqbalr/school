<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-20 11:46:57 --> Config Class Initialized
DEBUG - 2013-08-20 11:46:57 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:46:57 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:46:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:46:57 --> URI Class Initialized
DEBUG - 2013-08-20 11:46:58 --> Router Class Initialized
DEBUG - 2013-08-20 11:46:58 --> Output Class Initialized
DEBUG - 2013-08-20 11:46:58 --> Security Class Initialized
DEBUG - 2013-08-20 11:46:58 --> Input Class Initialized
DEBUG - 2013-08-20 11:46:58 --> XSS Filtering completed
DEBUG - 2013-08-20 11:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:46:58 --> Language Class Initialized
DEBUG - 2013-08-20 11:46:58 --> Loader Class Initialized
DEBUG - 2013-08-20 11:46:58 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:46:58 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:46:58 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:46:58 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:46:58 --> Session Class Initialized
DEBUG - 2013-08-20 11:46:58 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:46:58 --> A session cookie was not found.
DEBUG - 2013-08-20 11:46:58 --> Session routines successfully run
DEBUG - 2013-08-20 11:46:59 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:46:59 --> Controller Class Initialized
ERROR - 2013-08-20 11:46:59 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:46:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:46:59 --> Model Class Initialized
DEBUG - 2013-08-20 11:46:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:46:59 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:46:59 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:46:59 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:46:59 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:46:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:46:59 --> Pagination Class Initialized
DEBUG - 2013-08-20 11:46:59 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 11:46:59 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 11:46:59 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 11:46:59 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 11:46:59 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 11:46:59 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 11:46:59 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-20 11:46:59 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 11:46:59 --> Final output sent to browser
DEBUG - 2013-08-20 11:46:59 --> Total execution time: 2.1191
DEBUG - 2013-08-20 11:47:00 --> Config Class Initialized
DEBUG - 2013-08-20 11:47:00 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:47:00 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:47:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:47:00 --> URI Class Initialized
DEBUG - 2013-08-20 11:47:00 --> Router Class Initialized
ERROR - 2013-08-20 11:47:00 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 11:47:08 --> Config Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:47:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:47:08 --> URI Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Router Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Output Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Security Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Input Class Initialized
DEBUG - 2013-08-20 11:47:08 --> XSS Filtering completed
DEBUG - 2013-08-20 11:47:08 --> XSS Filtering completed
DEBUG - 2013-08-20 11:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:47:08 --> Language Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Loader Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:47:08 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:47:08 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:47:08 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Session Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:47:08 --> Session routines successfully run
DEBUG - 2013-08-20 11:47:08 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Controller Class Initialized
ERROR - 2013-08-20 11:47:08 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:47:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:47:08 --> Model Class Initialized
DEBUG - 2013-08-20 11:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:47:08 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:47:08 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:47:08 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:47:08 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:47:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:47:08 --> Pagination Class Initialized
DEBUG - 2013-08-20 11:47:08 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 11:47:08 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 11:47:08 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 11:47:08 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 11:47:09 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 11:47:09 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 11:47:09 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-20 11:47:09 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 11:47:09 --> Final output sent to browser
DEBUG - 2013-08-20 11:47:09 --> Total execution time: 0.2230
DEBUG - 2013-08-20 11:47:09 --> Config Class Initialized
DEBUG - 2013-08-20 11:47:09 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:47:09 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:47:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:47:09 --> URI Class Initialized
DEBUG - 2013-08-20 11:47:09 --> Router Class Initialized
ERROR - 2013-08-20 11:47:09 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 11:47:24 --> Config Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:47:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:47:24 --> URI Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Router Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Output Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Security Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Input Class Initialized
DEBUG - 2013-08-20 11:47:24 --> XSS Filtering completed
DEBUG - 2013-08-20 11:47:24 --> XSS Filtering completed
DEBUG - 2013-08-20 11:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:47:24 --> Language Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Loader Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:47:24 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:47:24 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:47:24 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Session Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:47:24 --> Session routines successfully run
DEBUG - 2013-08-20 11:47:24 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Controller Class Initialized
ERROR - 2013-08-20 11:47:24 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:47:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:47:24 --> Model Class Initialized
DEBUG - 2013-08-20 11:47:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:47:24 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:47:24 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:47:24 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:47:24 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:47:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:47:25 --> Pagination Class Initialized
DEBUG - 2013-08-20 11:47:25 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 11:47:25 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 11:47:25 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 11:47:25 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 11:47:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 11:47:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 11:47:25 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-20 11:47:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 11:47:25 --> Final output sent to browser
DEBUG - 2013-08-20 11:47:25 --> Total execution time: 0.2460
DEBUG - 2013-08-20 11:47:25 --> Config Class Initialized
DEBUG - 2013-08-20 11:47:25 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:47:25 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:47:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:47:25 --> URI Class Initialized
DEBUG - 2013-08-20 11:47:25 --> Router Class Initialized
ERROR - 2013-08-20 11:47:25 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 11:48:16 --> Config Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:48:16 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:48:16 --> URI Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Router Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Output Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Security Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Input Class Initialized
DEBUG - 2013-08-20 11:48:16 --> XSS Filtering completed
DEBUG - 2013-08-20 11:48:16 --> XSS Filtering completed
DEBUG - 2013-08-20 11:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:48:16 --> Language Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Loader Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:48:16 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:48:16 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:48:16 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Session Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:48:16 --> Session routines successfully run
DEBUG - 2013-08-20 11:48:16 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Controller Class Initialized
ERROR - 2013-08-20 11:48:16 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:48:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:48:16 --> Model Class Initialized
DEBUG - 2013-08-20 11:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:48:16 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:48:16 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:48:16 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:48:16 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:48:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:48:16 --> Pagination Class Initialized
DEBUG - 2013-08-20 11:48:16 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 11:48:16 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 11:48:16 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 11:48:16 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 11:48:16 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 11:48:16 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 11:48:16 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-20 11:48:16 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 11:48:16 --> Final output sent to browser
DEBUG - 2013-08-20 11:48:16 --> Total execution time: 0.3180
DEBUG - 2013-08-20 11:48:17 --> Config Class Initialized
DEBUG - 2013-08-20 11:48:17 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:48:17 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:48:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:48:17 --> URI Class Initialized
DEBUG - 2013-08-20 11:48:17 --> Router Class Initialized
ERROR - 2013-08-20 11:48:17 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 11:48:35 --> Config Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:48:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:48:35 --> URI Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Router Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Output Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Security Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Input Class Initialized
DEBUG - 2013-08-20 11:48:35 --> XSS Filtering completed
DEBUG - 2013-08-20 11:48:35 --> XSS Filtering completed
DEBUG - 2013-08-20 11:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:48:35 --> Language Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Loader Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:48:35 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:48:35 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:48:35 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Session Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:48:35 --> Session routines successfully run
DEBUG - 2013-08-20 11:48:35 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Controller Class Initialized
ERROR - 2013-08-20 11:48:35 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:48:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:48:35 --> Model Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:48:35 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:48:35 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:48:35 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:48:35 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:48:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:48:35 --> Pagination Class Initialized
DEBUG - 2013-08-20 11:48:35 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 11:48:35 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 11:48:35 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 11:48:35 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 11:48:35 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 11:48:35 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 11:48:35 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-20 11:48:35 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 11:48:35 --> Final output sent to browser
DEBUG - 2013-08-20 11:48:35 --> Total execution time: 0.2390
DEBUG - 2013-08-20 11:48:35 --> Config Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:48:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:48:35 --> URI Class Initialized
DEBUG - 2013-08-20 11:48:35 --> Router Class Initialized
ERROR - 2013-08-20 11:48:35 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 11:48:56 --> Config Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:48:56 --> URI Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Router Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Output Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Security Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Input Class Initialized
DEBUG - 2013-08-20 11:48:56 --> XSS Filtering completed
DEBUG - 2013-08-20 11:48:56 --> XSS Filtering completed
DEBUG - 2013-08-20 11:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:48:56 --> Language Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Loader Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:48:56 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:48:56 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:48:56 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Session Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:48:56 --> Session routines successfully run
DEBUG - 2013-08-20 11:48:56 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Controller Class Initialized
ERROR - 2013-08-20 11:48:56 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:48:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:48:56 --> Model Class Initialized
DEBUG - 2013-08-20 11:48:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:48:56 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:48:56 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:48:56 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:48:56 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:48:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:48:56 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 11:48:56 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 11:48:56 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 11:48:56 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 11:48:56 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 11:48:56 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 11:48:56 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-20 11:48:56 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 11:48:56 --> Final output sent to browser
DEBUG - 2013-08-20 11:48:56 --> Total execution time: 0.2950
DEBUG - 2013-08-20 11:48:57 --> Config Class Initialized
DEBUG - 2013-08-20 11:48:57 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:48:57 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:48:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:48:57 --> URI Class Initialized
DEBUG - 2013-08-20 11:48:57 --> Router Class Initialized
ERROR - 2013-08-20 11:48:57 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 11:49:53 --> Config Class Initialized
DEBUG - 2013-08-20 11:49:53 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:49:53 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:49:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:49:53 --> URI Class Initialized
DEBUG - 2013-08-20 11:49:53 --> Router Class Initialized
DEBUG - 2013-08-20 11:49:53 --> Output Class Initialized
DEBUG - 2013-08-20 11:49:53 --> Security Class Initialized
DEBUG - 2013-08-20 11:49:53 --> Input Class Initialized
DEBUG - 2013-08-20 11:49:53 --> XSS Filtering completed
DEBUG - 2013-08-20 11:49:53 --> XSS Filtering completed
DEBUG - 2013-08-20 11:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:49:53 --> Language Class Initialized
DEBUG - 2013-08-20 11:49:53 --> Loader Class Initialized
DEBUG - 2013-08-20 11:49:53 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:49:53 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:49:53 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:49:53 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:49:54 --> Session Class Initialized
DEBUG - 2013-08-20 11:49:54 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:49:54 --> Session routines successfully run
DEBUG - 2013-08-20 11:49:54 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:49:54 --> Controller Class Initialized
ERROR - 2013-08-20 11:49:54 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:49:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:49:54 --> Model Class Initialized
DEBUG - 2013-08-20 11:49:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:49:54 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:49:54 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:49:54 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:49:54 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:49:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:49:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 11:49:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 11:49:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 11:49:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 11:49:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 11:49:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 11:49:54 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-20 11:49:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 11:49:54 --> Final output sent to browser
DEBUG - 2013-08-20 11:49:54 --> Total execution time: 0.3030
DEBUG - 2013-08-20 11:49:54 --> Config Class Initialized
DEBUG - 2013-08-20 11:49:54 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:49:54 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:49:54 --> URI Class Initialized
DEBUG - 2013-08-20 11:49:54 --> Router Class Initialized
ERROR - 2013-08-20 11:49:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 11:57:04 --> Config Class Initialized
DEBUG - 2013-08-20 11:57:04 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:57:04 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:57:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:57:04 --> URI Class Initialized
DEBUG - 2013-08-20 11:57:04 --> Router Class Initialized
DEBUG - 2013-08-20 11:57:04 --> Output Class Initialized
DEBUG - 2013-08-20 11:57:04 --> Security Class Initialized
DEBUG - 2013-08-20 11:57:05 --> Input Class Initialized
DEBUG - 2013-08-20 11:57:05 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:05 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:57:05 --> Language Class Initialized
DEBUG - 2013-08-20 11:57:05 --> Loader Class Initialized
DEBUG - 2013-08-20 11:57:05 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:57:05 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:57:05 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:57:05 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:57:05 --> Session Class Initialized
DEBUG - 2013-08-20 11:57:05 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:57:05 --> Session routines successfully run
DEBUG - 2013-08-20 11:57:05 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:57:05 --> Controller Class Initialized
ERROR - 2013-08-20 11:57:05 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:57:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:57:05 --> Model Class Initialized
DEBUG - 2013-08-20 11:57:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:57:05 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:57:05 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:57:05 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:57:05 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:57:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:57:05 --> Pagination Class Initialized
DEBUG - 2013-08-20 11:57:05 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 11:57:05 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 11:57:05 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 11:57:05 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 11:57:05 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 11:57:05 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 11:57:05 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-20 11:57:05 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 11:57:05 --> Final output sent to browser
DEBUG - 2013-08-20 11:57:05 --> Total execution time: 1.1291
DEBUG - 2013-08-20 11:57:06 --> Config Class Initialized
DEBUG - 2013-08-20 11:57:06 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:57:06 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:57:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:57:06 --> URI Class Initialized
DEBUG - 2013-08-20 11:57:06 --> Router Class Initialized
ERROR - 2013-08-20 11:57:06 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 11:57:17 --> Config Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:57:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:57:17 --> URI Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Router Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Output Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Security Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Input Class Initialized
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:57:17 --> Language Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Loader Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:57:17 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:57:17 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:57:17 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Session Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:57:17 --> Session routines successfully run
DEBUG - 2013-08-20 11:57:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Controller Class Initialized
ERROR - 2013-08-20 11:57:17 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:57:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:57:17 --> Model Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:57:17 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:57:17 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:57:17 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:57:17 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:57:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:17 --> Config Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:57:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:57:17 --> URI Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Router Class Initialized
DEBUG - 2013-08-20 11:57:17 --> Output Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Security Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Input Class Initialized
DEBUG - 2013-08-20 11:57:18 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:18 --> XSS Filtering completed
DEBUG - 2013-08-20 11:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 11:57:18 --> Language Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Loader Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Helper loaded: url_helper
DEBUG - 2013-08-20 11:57:18 --> Helper loaded: file_helper
DEBUG - 2013-08-20 11:57:18 --> Helper loaded: form_helper
DEBUG - 2013-08-20 11:57:18 --> Database Driver Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Session Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Helper loaded: string_helper
DEBUG - 2013-08-20 11:57:18 --> Session routines successfully run
DEBUG - 2013-08-20 11:57:18 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Controller Class Initialized
ERROR - 2013-08-20 11:57:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:57:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:57:18 --> Model Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 11:57:18 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 11:57:18 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 11:57:18 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 11:57:18 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 11:57:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 11:57:18 --> Pagination Class Initialized
DEBUG - 2013-08-20 11:57:18 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 11:57:18 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 11:57:18 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 11:57:18 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 11:57:18 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 11:57:18 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 11:57:18 --> File loaded: application/views/kelas/index.php
DEBUG - 2013-08-20 11:57:18 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 11:57:18 --> Final output sent to browser
DEBUG - 2013-08-20 11:57:18 --> Total execution time: 0.3510
DEBUG - 2013-08-20 11:57:18 --> Config Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Hooks Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Utf8 Class Initialized
DEBUG - 2013-08-20 11:57:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 11:57:18 --> URI Class Initialized
DEBUG - 2013-08-20 11:57:18 --> Router Class Initialized
ERROR - 2013-08-20 11:57:18 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 12:00:17 --> Config Class Initialized
DEBUG - 2013-08-20 12:00:17 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:00:17 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:00:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:00:17 --> URI Class Initialized
DEBUG - 2013-08-20 12:00:17 --> Router Class Initialized
DEBUG - 2013-08-20 12:00:19 --> Output Class Initialized
DEBUG - 2013-08-20 12:00:19 --> Security Class Initialized
DEBUG - 2013-08-20 12:00:19 --> Input Class Initialized
DEBUG - 2013-08-20 12:00:19 --> XSS Filtering completed
DEBUG - 2013-08-20 12:00:19 --> XSS Filtering completed
DEBUG - 2013-08-20 12:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 12:00:19 --> Language Class Initialized
DEBUG - 2013-08-20 12:00:21 --> Loader Class Initialized
DEBUG - 2013-08-20 12:00:21 --> Helper loaded: url_helper
DEBUG - 2013-08-20 12:00:21 --> Helper loaded: file_helper
DEBUG - 2013-08-20 12:00:21 --> Helper loaded: form_helper
DEBUG - 2013-08-20 12:00:22 --> Database Driver Class Initialized
DEBUG - 2013-08-20 12:00:22 --> Session Class Initialized
DEBUG - 2013-08-20 12:00:22 --> Helper loaded: string_helper
DEBUG - 2013-08-20 12:00:23 --> Session garbage collection performed.
DEBUG - 2013-08-20 12:00:23 --> Session routines successfully run
DEBUG - 2013-08-20 12:00:23 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 12:00:23 --> Controller Class Initialized
ERROR - 2013-08-20 12:00:25 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:00:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:00:27 --> Model Class Initialized
DEBUG - 2013-08-20 12:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 12:00:28 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 12:00:28 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 12:00:28 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 12:00:28 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:00:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:00:32 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 12:00:32 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 12:00:33 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 12:00:34 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 12:00:38 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 12:00:38 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 12:00:38 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-20 12:00:38 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 12:00:38 --> Final output sent to browser
DEBUG - 2013-08-20 12:00:38 --> Total execution time: 23.3513
DEBUG - 2013-08-20 12:00:40 --> Config Class Initialized
DEBUG - 2013-08-20 12:00:40 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:00:40 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:00:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:00:40 --> URI Class Initialized
DEBUG - 2013-08-20 12:00:40 --> Router Class Initialized
ERROR - 2013-08-20 12:00:40 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 12:02:03 --> Config Class Initialized
DEBUG - 2013-08-20 12:02:03 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:02:03 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:02:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:02:03 --> URI Class Initialized
DEBUG - 2013-08-20 12:02:03 --> Router Class Initialized
DEBUG - 2013-08-20 12:02:04 --> Output Class Initialized
DEBUG - 2013-08-20 12:02:04 --> Security Class Initialized
DEBUG - 2013-08-20 12:02:04 --> Input Class Initialized
DEBUG - 2013-08-20 12:02:04 --> XSS Filtering completed
DEBUG - 2013-08-20 12:02:04 --> XSS Filtering completed
DEBUG - 2013-08-20 12:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 12:02:04 --> Language Class Initialized
DEBUG - 2013-08-20 12:02:05 --> Loader Class Initialized
DEBUG - 2013-08-20 12:02:06 --> Helper loaded: url_helper
DEBUG - 2013-08-20 12:02:06 --> Helper loaded: file_helper
DEBUG - 2013-08-20 12:02:06 --> Helper loaded: form_helper
DEBUG - 2013-08-20 12:02:08 --> Database Driver Class Initialized
DEBUG - 2013-08-20 12:02:08 --> Session Class Initialized
DEBUG - 2013-08-20 12:02:10 --> Helper loaded: string_helper
DEBUG - 2013-08-20 12:02:17 --> Session routines successfully run
DEBUG - 2013-08-20 12:02:17 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 12:02:17 --> Controller Class Initialized
ERROR - 2013-08-20 12:02:18 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:02:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:02:20 --> Model Class Initialized
DEBUG - 2013-08-20 12:02:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 12:02:21 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 12:02:21 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 12:02:21 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 12:02:21 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:02:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:02:23 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 12:02:23 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 12:02:23 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 12:02:24 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 12:02:25 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 12:02:25 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 12:02:25 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-20 12:02:25 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 12:02:25 --> Final output sent to browser
DEBUG - 2013-08-20 12:02:25 --> Total execution time: 22.0003
DEBUG - 2013-08-20 12:02:26 --> Config Class Initialized
DEBUG - 2013-08-20 12:02:26 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:02:26 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:02:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:02:26 --> URI Class Initialized
DEBUG - 2013-08-20 12:02:26 --> Router Class Initialized
ERROR - 2013-08-20 12:02:26 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 12:02:44 --> Config Class Initialized
DEBUG - 2013-08-20 12:02:44 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:02:44 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:02:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:02:44 --> URI Class Initialized
DEBUG - 2013-08-20 12:02:44 --> Router Class Initialized
DEBUG - 2013-08-20 12:02:44 --> Output Class Initialized
DEBUG - 2013-08-20 12:02:44 --> Security Class Initialized
DEBUG - 2013-08-20 12:02:44 --> Input Class Initialized
DEBUG - 2013-08-20 12:02:44 --> XSS Filtering completed
DEBUG - 2013-08-20 12:02:44 --> XSS Filtering completed
DEBUG - 2013-08-20 12:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 12:02:44 --> Language Class Initialized
DEBUG - 2013-08-20 12:02:44 --> Loader Class Initialized
DEBUG - 2013-08-20 12:02:44 --> Helper loaded: url_helper
DEBUG - 2013-08-20 12:02:44 --> Helper loaded: file_helper
DEBUG - 2013-08-20 12:02:44 --> Helper loaded: form_helper
DEBUG - 2013-08-20 12:02:44 --> Database Driver Class Initialized
DEBUG - 2013-08-20 12:02:45 --> Session Class Initialized
DEBUG - 2013-08-20 12:02:45 --> Helper loaded: string_helper
DEBUG - 2013-08-20 12:02:45 --> Session routines successfully run
DEBUG - 2013-08-20 12:02:45 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 12:02:45 --> Controller Class Initialized
ERROR - 2013-08-20 12:02:45 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:02:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:02:45 --> Model Class Initialized
DEBUG - 2013-08-20 12:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 12:02:45 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 12:02:45 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 12:02:45 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 12:02:45 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:02:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:02:45 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 12:02:45 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 12:02:45 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 12:02:45 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 12:02:45 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 12:02:45 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 12:02:45 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-20 12:02:45 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 12:02:45 --> Final output sent to browser
DEBUG - 2013-08-20 12:02:45 --> Total execution time: 1.2601
DEBUG - 2013-08-20 12:02:46 --> Config Class Initialized
DEBUG - 2013-08-20 12:02:46 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:02:46 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:02:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:02:46 --> URI Class Initialized
DEBUG - 2013-08-20 12:02:46 --> Router Class Initialized
ERROR - 2013-08-20 12:02:46 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 12:03:15 --> Config Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:03:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:03:15 --> URI Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Router Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Output Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Security Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Input Class Initialized
DEBUG - 2013-08-20 12:03:15 --> XSS Filtering completed
DEBUG - 2013-08-20 12:03:15 --> XSS Filtering completed
DEBUG - 2013-08-20 12:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 12:03:15 --> Language Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Loader Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Helper loaded: url_helper
DEBUG - 2013-08-20 12:03:15 --> Helper loaded: file_helper
DEBUG - 2013-08-20 12:03:15 --> Helper loaded: form_helper
DEBUG - 2013-08-20 12:03:15 --> Database Driver Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Session Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Helper loaded: string_helper
DEBUG - 2013-08-20 12:03:15 --> Session routines successfully run
DEBUG - 2013-08-20 12:03:15 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Controller Class Initialized
ERROR - 2013-08-20 12:03:15 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:03:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:03:15 --> Model Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 12:03:15 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 12:03:15 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 12:03:15 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 12:03:15 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:03:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:03:15 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 12:03:15 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 12:03:15 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 12:03:15 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 12:03:15 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 12:03:15 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 12:03:15 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-20 12:03:15 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 12:03:15 --> Final output sent to browser
DEBUG - 2013-08-20 12:03:15 --> Total execution time: 0.3630
DEBUG - 2013-08-20 12:03:15 --> Config Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:03:15 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:03:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:03:15 --> URI Class Initialized
DEBUG - 2013-08-20 12:03:16 --> Router Class Initialized
ERROR - 2013-08-20 12:03:16 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 12:07:46 --> Config Class Initialized
DEBUG - 2013-08-20 12:07:46 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:07:46 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:07:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:07:46 --> URI Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Router Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Output Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Security Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Input Class Initialized
DEBUG - 2013-08-20 12:07:47 --> XSS Filtering completed
DEBUG - 2013-08-20 12:07:47 --> XSS Filtering completed
DEBUG - 2013-08-20 12:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 12:07:47 --> Language Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Loader Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Helper loaded: url_helper
DEBUG - 2013-08-20 12:07:47 --> Helper loaded: file_helper
DEBUG - 2013-08-20 12:07:47 --> Helper loaded: form_helper
DEBUG - 2013-08-20 12:07:47 --> Database Driver Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Session Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Helper loaded: string_helper
DEBUG - 2013-08-20 12:07:47 --> Session routines successfully run
DEBUG - 2013-08-20 12:07:47 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Controller Class Initialized
ERROR - 2013-08-20 12:07:47 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:07:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:07:47 --> Model Class Initialized
DEBUG - 2013-08-20 12:07:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 12:07:48 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 12:07:48 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 12:07:48 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 12:07:48 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:07:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:07:48 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 12:07:48 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 12:07:48 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 12:07:48 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 12:07:48 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 12:07:48 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 12:07:48 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-20 12:07:48 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 12:07:48 --> Final output sent to browser
DEBUG - 2013-08-20 12:07:48 --> Total execution time: 1.9351
DEBUG - 2013-08-20 12:07:49 --> Config Class Initialized
DEBUG - 2013-08-20 12:07:49 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:07:49 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:07:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:07:49 --> URI Class Initialized
DEBUG - 2013-08-20 12:07:49 --> Router Class Initialized
ERROR - 2013-08-20 12:07:49 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 12:14:53 --> Config Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:14:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:14:53 --> URI Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Router Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Output Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Security Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Input Class Initialized
DEBUG - 2013-08-20 12:14:53 --> XSS Filtering completed
DEBUG - 2013-08-20 12:14:53 --> XSS Filtering completed
DEBUG - 2013-08-20 12:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-20 12:14:53 --> Language Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Loader Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Helper loaded: url_helper
DEBUG - 2013-08-20 12:14:53 --> Helper loaded: file_helper
DEBUG - 2013-08-20 12:14:53 --> Helper loaded: form_helper
DEBUG - 2013-08-20 12:14:53 --> Database Driver Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Session Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Helper loaded: string_helper
DEBUG - 2013-08-20 12:14:53 --> Session routines successfully run
DEBUG - 2013-08-20 12:14:53 --> XML-RPC Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Controller Class Initialized
ERROR - 2013-08-20 12:14:53 --> Severity: Warning  --> include_once(application/core/Flexi_auth_lite.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:14:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/Flexi_auth_lite.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:14:53 --> Model Class Initialized
DEBUG - 2013-08-20 12:14:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-20 12:14:53 --> Helper loaded: cookie_helper
DEBUG - 2013-08-20 12:14:53 --> Config file loaded: application/config/flexi_auth.php
DEBUG - 2013-08-20 12:14:53 --> Language file loaded: language/english/flexi_auth_lang.php
ERROR - 2013-08-20 12:14:53 --> Severity: Warning  --> include_once(application/core/MY_Flexi_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\school\application\config\config.php 373
ERROR - 2013-08-20 12:14:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Flexi_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\school\application\config\config.php 373
DEBUG - 2013-08-20 12:14:54 --> File loaded: application/views/shared/head.php
DEBUG - 2013-08-20 12:14:54 --> File loaded: application/views/shared/scripts.php
DEBUG - 2013-08-20 12:14:54 --> File loaded: application/views/shared/header.php
DEBUG - 2013-08-20 12:14:54 --> File loaded: application/views/shared/menu.php
DEBUG - 2013-08-20 12:14:54 --> File loaded: application/views/shared/breadcrumb.php
DEBUG - 2013-08-20 12:14:54 --> File loaded: application/views/shared/content_title.php
DEBUG - 2013-08-20 12:14:54 --> File loaded: application/views/kelas/edit.php
DEBUG - 2013-08-20 12:14:54 --> File loaded: application/views/shared/footer.php
DEBUG - 2013-08-20 12:14:54 --> Final output sent to browser
DEBUG - 2013-08-20 12:14:54 --> Total execution time: 1.2931
DEBUG - 2013-08-20 12:14:54 --> Config Class Initialized
DEBUG - 2013-08-20 12:14:54 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:14:54 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:14:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:14:54 --> URI Class Initialized
DEBUG - 2013-08-20 12:14:54 --> Router Class Initialized
ERROR - 2013-08-20 12:14:54 --> 404 Page Not Found --> css
DEBUG - 2013-08-20 12:15:12 --> Config Class Initialized
DEBUG - 2013-08-20 12:15:12 --> Hooks Class Initialized
DEBUG - 2013-08-20 12:15:12 --> Utf8 Class Initialized
DEBUG - 2013-08-20 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-20 12:15:12 --> URI Class Initialized
DEBUG - 2013-08-20 12:15:12 --> Router Class Initialized
ERROR - 2013-08-20 12:15:12 --> 404 Page Not Found --> kelasbagians
