<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of users
 *
 * @author L745
 */
class users extends MY_application_controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->vars('menu', 'user');
    }
    
}

?>
