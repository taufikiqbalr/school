<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of privileges
 *
 * @author L745
 */
class privileges extends MY_application_controller{
    
    public function __construct() {
        parent::__construct();
        $this->load->model('privilege_model');
        $this->load->vars('menu', 'privilege');
    }
    
    
}

?>
