<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of user_privileges
 *
 * @author L745
 */
class user_privileges extends MY_application_controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('user_privilege_model');
        $this->load->vars('menu', 'user_privilege');
    }
    
}

?>
