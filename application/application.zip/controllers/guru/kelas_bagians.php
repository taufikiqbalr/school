<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of kelas_bagians
 *
 * @author L745
 */
class kelas_bagians extends MY_application_controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('kelas_model');
        $this->load->vars('menu', 'kelas');
    }
    
    public function new_k($kelas_id){
        
    }
    
    public function edit($kelas_id,$id){
        
    }
    
    public function create($kelas_id){
        
    }
    
    public function update($kelas_id,$id){
        
    }
    
    public function delete($id){
        
    }
}

?>
