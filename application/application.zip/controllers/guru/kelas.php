<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of kelas
 *
 * @author L745
 */
class kelas extends MY_application_controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('kelas_model');
        // used in script to determine menu
        $this->load->vars('menu', 'kelas');
    }

    // for index view
    public function index() {
        // pagination
        $this->load->library('pagination');

        // condition for pagination
        if ($this->input->get('column'))
            $data['column'] = in_array(trim($this->input->get('column', TRUE)), $this->kelas_model->column_names()) ? trim($this->input->get('column', TRUE)) : "tingkat";
        else
            $data['column'] = "tingkat";
        if ($this->input->get('order', TRUE))
            $data['order'] = in_array(trim($this->input->get('order', TRUE)), array("asc", "desc")) ? trim($this->input->get('order', TRUE)) : "asc";
        else
            $data['order'] = "asc";
        $data['cond'] = $this->input->get('cond', TRUE) ? trim($this->input->get('cond', TRUE)) : "";

        // set pagination custom config
        $config['base_url'] = site_url('kelas?');
        $config['total_rows'] = $this->kelas_model->get_total($data['cond']);
        $config['per_page'] = '5';
        $this->pagination->initialize($config);

        // use when pagination use_page_number = true
        if ($this->input->get('per_page', TRUE)) {
            if (intval($this->input->get('per_page', TRUE)) > 0)
                $page = (intval($this->input->get('per_page', TRUE)) - 1) * $this->pagination->per_page;
            else
                $page = 0;
        }
        else
            $page = 0;

//        use when pagination use_page_number = false
//        $page = $this->input->get('per_page', TRUE) ? $this->input->get('per_page', TRUE) : 0;
        // create pagination html
        $data['links'] = $this->pagination->create_links();

        // set custom pagination text
        $data['total_rows'] = $this->pagination->total_rows;
        $data['num_pages'] = ceil($this->pagination->total_rows / $this->pagination->per_page);
        $data['cur_page'] = ($this->pagination->cur_page > 0) ? $this->pagination->cur_page : 1;

        // fetch kelas
        $data['kelas'] = $this->kelas_model->
                fetch_kelas($config["per_page"], $page, $data['order'], $data['column'], $data['cond']);

        $data['content_title'] = "Data Kelas";
        $data['breadc'] = array('menu' => "index_kelas");
        $data['title'] = $this->load->get_var('web_title') . " - " . $data['content_title'];
        ;

        $this->load_view('kelas', 'index', $data);
    }

    // for show view
    public function show($id) {
        $data['content_title'] = "Lihat Kelas";
        $data['breadc'] = array('menu' => "show_kelas", 'id' => $id);
        $data['title'] = $this->load->get_var('web_title') . " - " . $data['content_title'];
        $data['kela'] = $this->kelas_model->get_kelas($id);
        $data['kelas_bagians'] = $this->kelas_model->get_kelas_bagians($id);
        if (empty($data['kela']))
            show_404();
        $this->load_view('kelas', 'show', $data);
    }

    // for new view
    public function new_k() {
        $data['content_title'] = "Buat Kelas";
        $data['breadc'] = array('menu' => "new_kelas");
        $data['title'] = $this->load->get_var('web_title') . " - " . $data['content_title'];

        // set texted field from create method
        $data['field_tingkat'] = isset($this->session->userdata('field')['tingkat']) ? $this->session->userdata('field')['tingkat'] : '';

        $this->load_view('kelas', 'new', $data);

        // unset session field data when error from method create
        $this->session->unset_userdata('field');
    }

    // for edit view
    public function edit($id) {
        $data['content_title'] = "Ubah Kelas";
        $data['breadc'] = array('menu' => "edit_kelas", 'id' => $id);
        $data['title'] = $this->load->get_var('web_title') . " - " . $data['content_title'];
        $data['kela'] = $this->kelas_model->get_kelas($id);
        if (empty($data['kela']))
            show_404();
        $this->load_view('kelas', 'edit', $data);
    }

    // for create new kelas
    public function create() {
        $this->load->library('form_validation');

        $validation_rules = array(
            array('field' => 'tingkat', 'label' => 'Tingkat', 'rules' => 'trim|required|callback_tingkat_check')
        );

        $this->form_validation->set_rules($validation_rules);

        // Get tingkat from input.
        $tingkat = trim($this->input->post('tingkat', TRUE));

        if ($this->form_validation->run()) {
            $data = array(
                'tingkat' => $tingkat
            );

            if ($this->kelas_model->create($data)) {
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a class="close" data-dismiss="alert" href="#">&times;</a>Data kelas berhasil ditambah</div>');
                redirect('kelas');
            }
        }

        // Set validation errors.
        $this->data['message'] = validation_errors('<div class="alert alert-error"><a class="close" data-dismiss="alert" href="#">&times;</a>', '</div>');
        $this->session->set_flashdata('message', $this->data['message']);
        $this->session->set_flashdata('tingkat', form_error('tingkat'));

        // capture texted field
        $this->session->set_userdata('field', array('tingkat' => $tingkat));

        redirect('kelas/new');
    }

    // for update kelas
    public function update($id) {
        $this->load->library('form_validation');

        $validation_rules = array(
            array('field' => 'tingkat', 'label' => 'Tingkat', 'rules' => 'trim|required|callback_tingkat_check_update[' . $id . ']')
        );

        $this->form_validation->set_rules($validation_rules);

        // Get tingkat from input.
        $tingkat = trim($this->input->post('tingkat',TRUE));

        if ($this->form_validation->run()) {
            $data = array(
                'tingkat' => $tingkat
            );

            if ($this->kelas_model->update($data, $id)) {
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a class="close" data-dismiss="alert" href="#">&times;</a>Data kelas berhasil ditambah</div>');
                redirect('kelas/' . $id);
            }
        }

        // Set validation errors.
        $this->data['message'] = validation_errors('<div class="alert alert-error"><a class="close" data-dismiss="alert" href="#">&times;</a>', '</div>');
        $this->session->set_flashdata('message', $this->data['message']);
        $this->session->set_flashdata('tingkat', form_error('tingkat'));
        redirect('kelas/' . $id . '/edit');
    }

    // for delete kelas with ID
    public function delete($id) {
        if ($this->kelas_model->delete($id)) {
            $this->session->set_flashdata('message', '<div class="alert alert-info"><a class="close" data-dismiss="alert" href="#">&times;</a>Data kelas berhasil dihapus</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert"><a class="close" data-dismiss="alert" href="#">&times;</a>Data kelas gagal dihapus</div>');
        }
        redirect('kelas');
    }

    // for delete kelas with multiple ID
    public function deletes() {
        $affected_row = $this->input->post('ids', TRUE) ? $this->kelas_model->deletes($this->input->post('ids', TRUE)) : 0;
        $this->session->set_flashdata('message', '<div class="alert alert-info"><a class="close" data-dismiss="alert" href="#">&times;</a>' . $affected_row . ' data kelas berhasil dihapus</div>');
        redirect('kelas');
    }

    // validation for check unique tingkat
    public function tingkat_check($str) {
        $query = $this->db->get_where('kelas', array('tingkat' => trim($str)));
        if ($query->num_rows() > 0) {
            $this->form_validation->set_message('tingkat_check', 'Field %s sudah ada');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    // validation for check unique tingkat in update
    public function tingkat_check_update($str, $id) {
        $query = $this->db->get_where('kelas', array('tingkat' => trim($str)));
        if ($query->num_rows() > 0) {
            $kela = $query->row_array();
            if (trim($id) === trim($kela['id'])) {
                return TRUE;
            } else {
                $this->form_validation->set_message('tingkat_check_update', 'Field %s sudah ada');
                return FALSE;
            }
        } else {
            return TRUE;
        }
    }

}

?>
