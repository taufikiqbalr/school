<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of kelas
 *
 * @author L745
 */
class kelas_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }
    
    // get column names
    public function column_names(){
        return $this->db->list_fields('kelas');
    }

    // get kelas with ID
    public function get_kelas($id = FALSE) {
        if ($id === FALSE) {
            $query = $this->db->get('kelas');
            return $query->result_array();
        }
        $query = $this->db->get_where('kelas', array('id' => $id));
        return $query->row_array();
    }

    // count total rows
    public function get_total($cond = FALSE) {
        if(!empty($cond)) {
            $this->db->like('tingkat',$cond);
//            $this->db->or_like('tingkat',$cond);
        }
        return $this->db->count_all_results('kelas');
    }

    // get kelas for pagination
    public function fetch_kelas($limit, $start, $order = FALSE, $field = FALSE, $cond = FALSE) {
        if($order === FALSE || $field === FALSE)
            $this->db->order_by("tingkat", "asc");
        else
            $this->db->order_by($field, $order);
        $this->db->limit($limit, $start);

        if ($cond === FALSE || empty($cond)) {
            $query = $this->db->get("kelas");
        } else {
            $this->db->like('tingkat',$cond);
            $query = $this->db->get('kelas');
        }
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return FALSE;
    }

    // get kelas bagian with ID kelas
    public function get_kelas_bagians($id = FALSE) {
        if ($id === FALSE) {
            $this->db->order_by("nama", "asc");
            $query = $this->db->get('kelas_bagians');
            return $query->result_array();
        }
        $this->db->order_by("nama", "asc");
        $query = $this->db->get_where('kelas_bagians', array('kelas_id' => $id));
        return $query->result_array();
    }

    // create new kelas
    public function create($data) {
        if (isset($data)) {
            return $this->db->insert('kelas', $data);
        } else {
            return FALSE;
        }
    }

    // update kelas
    public function update($data, $id) {
        if (isset($data)) {
            $this->db->where('id', $id);
            $this->db->update('kelas', $data);
            return TRUE;
        } else {
            return FALSE;
        }
    }

    // delete kelas with ID
    public function delete($id) {
        $query = $this->db->get_where("kelas", array('id' => trim($id)));
        if ($query->num_rows() > 0) {
            $this->db->delete('kelas', array('id' => $id));
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function deletes($ids) {
        if (!empty($ids)) {
            $this->db->query("DELETE FROM kelas WHERE id IN (".implode(',',$ids).");");
            return $this->db->affected_rows();
        }else{
            return 0;
        }
    }

}

?>
