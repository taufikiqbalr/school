<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of privilege_model
 *
 * @author L745
 */
class privilege_model extends CI_Model {
    
    public function __construct() {
        $this->load->database();
    }
    
    /**
     * insert_privilege
     * Inserts a new privilege.
     */
    function insert_privilege() {
        $this->load->library('form_validation');

        // Set validation rules.
        $validation_rules = array(
            array('field' => 'insert_privilege_name', 'label' => 'Privilege Name', 'rules' => 'required')
        );

        $this->form_validation->set_rules($validation_rules);

        if ($this->form_validation->run()) {
            // Get privilege data from input.
            $privilege_name = $this->input->post('insert_privilege_name');
            $privilege_desc = $this->input->post('insert_privilege_description');

            $this->flexi_auth->insert_privilege($privilege_name, $privilege_desc);

            // Save any public or admin status or error messages to CI's flash session data.
            $this->session->set_flashdata('message', $this->flexi_auth->get_messages());

            // Redirect user.
            redirect('auth_admin/manage_privileges');
        }
    }

    /**
     * update_privilege
     * Updates a specific privilege.
     */
    function update_privilege($privilege_id) {
        $this->load->library('form_validation');

        // Set validation rules.
        $validation_rules = array(
            array('field' => 'update_privilege_name', 'label' => 'Privilege Name', 'rules' => 'required')
        );

        $this->form_validation->set_rules($validation_rules);

        if ($this->form_validation->run()) {
            // Get privilege data from input.
            $data = array(
                $this->flexi_auth->db_column('user_privileges', 'name') => $this->input->post('update_privilege_name'),
                $this->flexi_auth->db_column('user_privileges', 'description') => $this->input->post('update_privilege_description')
            );

            $this->flexi_auth->update_privilege($privilege_id, $data);

            // Save any public or admin status or error messages to CI's flash session data.
            $this->session->set_flashdata('message', $this->flexi_auth->get_messages());

            // Redirect user.
            redirect('auth_admin/manage_privileges');
        }
    }
    
}

?>
