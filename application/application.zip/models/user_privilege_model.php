<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of user_privilege_model
 *
 * @author L745
 */
class user_privilege_model extends CI_Model {
    
    public function __construct() {
        $this->load->database();
    }
    
    
    
}

?>
