<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of application_controller
 *
 * @author L745
 */
if (!defined('BASEPATH')) exit('No direct script access allowed');
class MY_application_controller extends CI_Controller{
    
    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->auth = new stdClass;
        $this->load->library('flexi_auth');
        
        // Variables
        $this->load->vars('base_url', base_url());
        $this->load->vars('includes_dir', base_url().'/includes/');
        $this->load->vars('web_title', 'Sekolah');
    }
    
    // load the specific view
    public function load_view($p_view, $p_menu, $data) {
        $this->load->view('shared/head', $data);
        $this->load->view('shared/scripts', $data);
        $this->load->view('shared/header', $data);
        $this->load->view('shared/menu', $data);
        $this->load->view('shared/breadcrumb', $data);
        $this->load->view('shared/content_title', $data);
        // load per menu
        $this->load->view($p_view.'/' . $p_menu, $data);

        $this->load->view('shared/footer', $data);
    }
}

?>
