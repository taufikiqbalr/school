<label>
    Nama Grup
</label>
<?php echo $user_group['ugrp_name']; ?>
 <label>
    Deskripsi Grup
</label>
<?php echo $user_group['ugrp_desc']; ?>
