<div class="page-header">
    <h2><?php echo $content_title ?></h2>
</div>