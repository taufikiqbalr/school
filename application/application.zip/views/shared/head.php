<html>
    <head>
        <meta name="robots" content="index, follow"/>
        <meta name="designer" content="SATU IT MEDIA - Taufik Iqbal R : taufikiqbalr@gmail.com"/> 
        <meta name="copyright" content="Copyright <?php echo date('Y'); ?> SATU IT MEDIA, All Copyrights Reserved"/>
        <meta http-equiv="imagetoolbar" content="no"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="<?php echo $includes_dir; ?>css/bootstrap-responsive.css" >
        <link rel="stylesheet" href="<?php echo $includes_dir; ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $includes_dir; ?>css/base.css">
        <title><?php echo $title ?></title>
    </head>