</div>
</div>
</div>
<div class="clearfix"></div>
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="span4 text-left">I-Panel M.Ts YPP Darul Hikam</div>
            <div class="span4 offset4 text-right">License By SATU IT MEDIA</div>
        </div>
    </div>
</footer>
</body>
</html>