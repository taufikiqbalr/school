<div id="mainmenu" class="span3 sidebar">
    <ul class="nav nav-list">
        <li class="nav-header">Main</li>
        <li id="sidebar-guru" class="">
            <a href="<?php echo site_url("gurus"); ?>">Guru</a>
        </li>
        <li id="sidebar-kelas" class="">
            <a href="<?php echo site_url("kelas"); ?>">Kelas</a>
        </li>
        <li class="nav-header">User Management</li>
        <li id="sidebar-user" class="">
            <a href="<?php echo site_url("users"); ?>">User</a>
        </li>
        <li id="sidebar-user_group" class="">
            <a href="<?php echo site_url("usergroups"); ?>">User Group</a>
        </li>
        <li id="sidebar-privilege" class="">
            <a href="<?php echo site_url("privileges"); ?>">Privilege</a>
        </li>
        <li id="sidebar-user_privilege" class="">
            <a href="<?php echo site_url("userprivileges"); ?>">User Privilege</a>
        </li>
    </ul>
</div>
<div class="span9">