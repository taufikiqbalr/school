<!-- JS Includes -->
<script src="<?php echo $includes_dir;?>js/jquery-1.10.2.min.js"></script>
<script src="<?php echo $includes_dir;?>js/bootstrap.min.js"></script>

<script src="<?php echo $includes_dir;?>js/base.js"></script>

<?php
    if(isset($menu)){
        if($menu === "kelas"){ ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    $("#mainmenu ul li").removeClass("active");
                    $("#sidebar-kelas").addClass("active");
                });
            </script>
<?php   }else if($menu === "gurus"){ ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    $("#mainmenu ul li").removeClass("active");
                    $("#sidebar-guru").addClass("active");
                });
            </script>
<?php   }else if($menu === "users"){ ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    $("#mainmenu ul li").removeClass("active");
                    $("#sidebar-user").addClass("active");
                });
            </script>
<?php   }else if($menu === "user_groups"){ ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    $("#mainmenu ul li").removeClass("active");
                    $("#sidebar-user_group").addClass("active");
                });
            </script>
<?php   }else if($menu === "user_privileges"){ ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    $("#mainmenu ul li").removeClass("active");
                    $("#sidebar-user_privilege").addClass("active");
                });
            </script>
<?php   }else if($menu === "privileges"){ ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    $("#mainmenu ul li").removeClass("active");
                    $("#sidebar-privilege").addClass("active");
                });
            </script>
 <?php       } ?>
 <?php   } ?>