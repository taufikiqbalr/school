<?php if (isset($breadc)) { ?>
        <ul class="breadcrumb">
            <li>
                <a href="<?php echo base_url(); ?>">Home</a>
                <span class="divider">/</span>
            </li>
<!-- Kelas -->
<?php    if ($breadc['menu'] === "index_kelas") { ?>
            <li class="active">Kelas</li>
    <?php }
         else if($breadc['menu'] === "new_kelas") { ?>
            <li>
                <a href="<?php echo site_url('kelas'); ?>">Kelas</a>
                <span class="divider">/</span>
            </li>
            <li class="active">New</li>
    <?php }
         else if($breadc['menu'] === "show_kelas") { ?>
            <li>
                <a href="<?php echo site_url('kelas'); ?>">Kelas</a>
                <span class="divider">/</span>
            </li>
            <li class="active"><?php echo $breadc['id']; ?></li>
    <?php }
         else if($breadc['menu'] === "edit_kelas") { ?>
            <li>
                <a href="<?php echo site_url('kelas'); ?>">Kelas</a>
                <span class="divider">/</span>
            </li>
            <li>
                <a href="<?php echo site_url('kelas/'.$breadc['id']); ?>"><?php echo $breadc['id']; ?></a>
                <span class="divider">/</span>
            </li>
            <li class="active">Edit</li>
<!-- User Group -->
    <?php }
         else if($breadc['menu'] === "index_user_group") { ?>
            <li class="active">User Group</li>
    <?php }
         else if($breadc['menu'] === "new_user_group") { ?>
            <li>
                <a href="<?php echo site_url('usergroups'); ?>">User Group</a>
                <span class="divider">/</span>
            </li>
            <li class="active">New</li>
    <?php }
         else if($breadc['menu'] === "show_user_group") { ?>
            <li>
                <a href="<?php echo site_url('usergroups'); ?>">User Group</a>
                <span class="divider">/</span>
            </li>
            <li class="active"><?php echo $breadc['id']; ?></li>
    <?php }
         else if($breadc['menu'] === "edit_user_group") { ?>
            <li>
                <a href="<?php echo site_url('usergroups'); ?>">User Group</a>
                <span class="divider">/</span>
            </li>
            <li>
                <a href="<?php echo site_url('usergroups/'.$breadc['id']); ?>"><?php echo $breadc['id']; ?></a>
                <span class="divider">/</span>
            </li>
            <li class="active">Edit</li>
<!-- Privilege -->
    <?php }
         else if($breadc['menu'] === "index_privilege") { ?>
            <li class="active">Privilege</li>
    <?php }
         else if($breadc['menu'] === "new_privilege") { ?>
            <li>
                <a href="<?php echo site_url('privileges'); ?>">Privilege</a>
                <span class="divider">/</span>
            </li>
            <li class="active">New</li>
    <?php }
         else if($breadc['menu'] === "show_privilege") { ?>
            <li>
                <a href="<?php echo site_url('privileges'); ?>">Privilege</a>
                <span class="divider">/</span>
            </li>
            <li class="active"><?php echo $breadc['id']; ?></li>
    <?php }
         else if($breadc['menu'] === "edit_privilege") { ?>
            <li>
                <a href="<?php echo site_url('privileges'); ?>">Privilege</a>
                <span class="divider">/</span>
            </li>
            <li>
                <a href="<?php echo site_url('privileges/'.$breadc['id']); ?>"><?php echo $breadc['id']; ?></a>
                <span class="divider">/</span>
            </li>
            <li class="active">Edit</li>
<!-- User Privilege -->
    <?php }
         else if($breadc['menu'] === "index_user_privilege") { ?>
            <li class="active">User Privilege</li>
    <?php }
         else if($breadc['menu'] === "new_user_privilege") { ?>
            <li>
                <a href="<?php echo site_url('userprivileges'); ?>">User Privilege</a>
                <span class="divider">/</span>
            </li>
            <li class="active">New</li>
    <?php }
         else if($breadc['menu'] === "show_user_privilege") { ?>
            <li>
                <a href="<?php echo site_url('userprivileges'); ?>">User Privilege</a>
                <span class="divider">/</span>
            </li>
            <li class="active"><?php echo $breadc['id']; ?></li>
    <?php }
         else if($breadc['menu'] === "edit_user_privilege") { ?>
            <li>
                <a href="<?php echo site_url('userprivileges'); ?>">User Privilege</a>
                <span class="divider">/</span>
            </li>
            <li>
                <a href="<?php echo site_url('userprivileges/'.$breadc['id']); ?>"><?php echo $breadc['id']; ?></a>
                <span class="divider">/</span>
            </li>
            <li class="active">Edit</li>
    <?php } ?>
        </ul>
<?php } ?>

