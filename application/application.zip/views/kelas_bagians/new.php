<h2>TES</h2>

<?php echo form_open('kelas/create') ?>

<label for="tingkat">Tingkat</label>
<input type="input" name="tingkat" /><br />

<input type="submit" name="submit" value="Simpan" />

</form>