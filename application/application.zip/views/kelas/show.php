<h3>Tingkat <?php echo $kela['tingkat']; ?></h3>
Bagian:
<table class="table table-hover">
    <thead>
        <tr>
            <td>No</td>
            <td>Tingkat</td>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($kelas_bagians as $key => $kelas_bagian): ?>
            <tr>
                <td>
                    <?php echo $key + 1 ?>
                </td>
                <td>
                    <?php echo $kelas_bagian['nama'] ?>
                </td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>
 
